package com.sas.mkt.config.core;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Set;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertySource;
import org.springframework.stereotype.Component;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.appspecific.GlobalConfiguration;

@Component
public class PropertyMap {

	private final static Logger logger = LoggerFactory.getLogger(PropertyMap.class);

	public static final String APPLICATION = "application";
	public static final String GLOBAL = "global";
	public final HashMap<String, TreeMap<String, PropertyDetails>> propertyMap = new HashMap<>();

	Environment env;
	ApplicationConfiguration appConfig;
	GlobalConfiguration globalConfig;
	@Autowired
	public PropertyMap(ApplicationConfiguration appConfig, GlobalConfiguration globalConfig, Environment env) {
		this.appConfig = appConfig;
		this.globalConfig = globalConfig;
		this.env = env;
	}

	private TreeMap<String, PropertyDetails> basePropertyDetails(Configuration config) {
		Class<?> c = config.getClass();
		Field[] fields = c.getDeclaredFields();
		TreeMap<String, PropertyDetails> map = new TreeMap<>();
		for (Field f : fields) {
			ReflectionFieldInfo ftype = new ReflectionFieldInfo(f.getName(), f.getType());
			try {
				Method getMethod = c.getDeclaredMethod(ftype.getMethod, new Class<?>[0]);
				Method setMethod = c.getDeclaredMethod(ftype.setMethod, ftype.type);
				Object object = getMethod.invoke(config);
				String stringValue = null;
				if (object != null) {
					stringValue = object.toString();
				}
				String normName = ConfigUtils.normalizeName(f.getName());
				PropertyDetails pd = new PropertyDetails(f.getName(), stringValue, f.getType(), getMethod, setMethod);
				map.put(normName, pd);
			} catch (Exception ex) {
				logger.error(ex.getMessage());
			}
		}
		return map;
	}
	
	public void initialize() {
		// Set up the property maps and initialize with the base data for the properties
		TreeMap<String, PropertyDetails> applicationMap = basePropertyDetails(appConfig);
		TreeMap<String, PropertyDetails> globalMap = basePropertyDetails(globalConfig);
		propertyMap.put(APPLICATION, applicationMap);
		propertyMap.put(GLOBAL, globalMap);
		
		PropertyDetails pd = null;
		
		// get the source (*.properties file, Environment Variable, System Property) for each property
		ConfigurableEnvironment ce = (ConfigurableEnvironment) env;
		MutablePropertySources sources = ce.getPropertySources();
		
		// ********************************************************
		// Application Properties (from lowest priority to highest)
		// ********************************************************
		Set<String> appKeySet = applicationMap.keySet();
		
		// 1. application.properties
		PropertySource<?> ps = sources.get(ApplicationConstants.PSN_APPLICATION_CONFIG);		
		for (String normName : appKeySet) {
			pd = applicationMap.get(normName);
			String name = pd.getName();
			String ss = ApplicationConstants.APPLICATION_PROPERTY_PREFIX + name;
			if (ps != null && ps.containsProperty(ss)) {
				pd.setPropertySourceName(ApplicationConstants.PSN_APPLICATION_CONFIG);
				appConfig.originalProperties.put(normName, new PropertyDetails(pd));
				logger.debug(ApplicationConstants.PSN_APPLICATION_CONFIG + ": " + name + ", " + pd.getValue());
			}
		}
		
		// 2. environment variables
		ps = sources.get(ApplicationConstants.PSN_SYSTEM_ENVIRONMENT);		
		for (String normName : appKeySet) {
			pd = applicationMap.get(normName);
			String name = pd.getName();
			String ss = convertToEnv(name);
			if (ps != null && ps.containsProperty(ss)) {
				pd.setPropertySourceName(ApplicationConstants.PSN_SYSTEM_ENVIRONMENT);
				appConfig.originalProperties.put(normName, new PropertyDetails(pd));
				logger.debug(ApplicationConstants.PSN_SYSTEM_ENVIRONMENT + ": " + name + ", " + pd.getValue());
			}
		}
		
		// 3. system properties
		ps = sources.get(ApplicationConstants.PSN_SYSTEM_PROPERTIES);		
		for (String normName : appKeySet) {
			pd = applicationMap.get(normName);
			String name = pd.getName();
			String ss = ApplicationConstants.APPLICATION_PROPERTY_PREFIX + name;
			if (ps != null && ps.containsProperty(ss)) {
				pd.setPropertySourceName(ApplicationConstants.PSN_SYSTEM_PROPERTIES);
				appConfig.originalProperties.put(normName, new PropertyDetails(pd));
				logger.debug(ApplicationConstants.PSN_SYSTEM_PROPERTIES + ": " + name + ", " + pd.getValue());
			}
		}
		
		// ********************************************************
		// Tier Global Properties (from lowest priority to highest)
		// ********************************************************
		Set<String> globalKeySet = globalMap.keySet();
		
		// 1. tier_global_overrides.properties
		ps = sources.get(ApplicationConstants.PSN_TIER_GLOBAL_OVERRIDES);		
		for (String normName : globalKeySet) {
			pd = globalMap.get(normName);
			String name = pd.getName();
			String ss = ApplicationConstants.GLOBAL_PROPERTY_PREFIX + name;
			if (ps != null && ps.containsProperty(ss)) {
				pd.setPropertySourceName(ApplicationConstants.PSN_TIER_GLOBAL_OVERRIDES);
				globalConfig.originalProperties.put(normName, new PropertyDetails(pd));
				logger.debug(ApplicationConstants.PSN_TIER_GLOBAL_OVERRIDES + ": " + name + ", " + pd.getValue());
			}
		}
		
		// 2. environment variables
		ps = sources.get(ApplicationConstants.PSN_SYSTEM_ENVIRONMENT);		
		for (String normName : globalKeySet) {
			pd = globalMap.get(normName);
			String name = pd.getName();
			String ss = convertToEnv(name);
			if (ps != null && ps.containsProperty(ss)) {
				pd.setPropertySourceName(ApplicationConstants.PSN_SYSTEM_ENVIRONMENT);
				globalConfig.originalProperties.put(normName, new PropertyDetails(pd));
				logger.debug(ApplicationConstants.PSN_SYSTEM_ENVIRONMENT + ": " + name + ", " + pd.getValue());
			}
		}
		
		// 3. system properties
		ps = sources.get(ApplicationConstants.PSN_SYSTEM_PROPERTIES);		
		for (String normName : globalKeySet) {
			pd = globalMap.get(normName);
			String name = pd.getName();
			String ss = ApplicationConstants.GLOBAL_PROPERTY_PREFIX + name;
			if (ps != null && ps.containsProperty(ss)) {
				pd.setPropertySourceName(ApplicationConstants.PSN_SYSTEM_PROPERTIES);
				globalConfig.originalProperties.put(normName, new PropertyDetails(pd));
				logger.debug(ApplicationConstants.PSN_SYSTEM_PROPERTIES + ": " + name + ", " + pd.getValue());
			}
		}
		
		
	}

	private String convertToEnv(String s) {
		char[] cs = s.toCharArray();
		StringBuilder buff = new StringBuilder();
		buff.append("APPLICATION_");
		for (char c : cs) {
			if (Character.isUpperCase(c)) {
				buff.append("_");
				buff.append(c);
			} else if (c == '.') {
				buff.append("_");
			} else {
				buff.append(Character.toUpperCase(c));
			}
		}
		return buff.toString();
	}

}
