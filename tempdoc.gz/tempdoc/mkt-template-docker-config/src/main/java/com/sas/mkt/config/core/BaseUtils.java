package com.sas.mkt.config.core;

import org.slf4j.Logger;

public class BaseUtils {

	public static void bigPrint(String message) {
		System.out.println("***********************************");
		System.out.println("*  " + message);
		System.out.println("***********************************");
	}
	
	public static void bigInfo(String message, Logger lgr) {
		lgr.info("***********************************");
		lgr.info("*  " + message);
		lgr.info("***********************************");
	}
	
	public static void bigDebug(String message, Logger lgr) {
		lgr.debug("***********************************");
		lgr.debug("*  " + message);
		lgr.debug("***********************************");
	}
	
}
