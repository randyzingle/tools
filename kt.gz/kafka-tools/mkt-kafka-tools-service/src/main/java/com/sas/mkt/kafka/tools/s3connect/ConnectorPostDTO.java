package com.sas.mkt.kafka.tools.s3connect;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
@JsonInclude(Include.NON_NULL)
public class ConnectorPostDTO {
	
	public String name;
	
	@JsonProperty("config")
	public ConnectConfigDTO connectConfigDTO;
	
	@Override
	public String toString() {
		return "ConnectorPostDTO [name=" + name + ", connectConfigDTO=" + connectConfigDTO + "]";
	}

}
