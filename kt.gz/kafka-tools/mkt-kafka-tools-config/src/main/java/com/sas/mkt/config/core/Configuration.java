package com.sas.mkt.config.core;

import java.util.HashMap;

/**
 * @author razing
 *
 */
public class Configuration {

	// Properties as they were before hitting the configuration server
    public HashMap<String, PropertyDetails> originalProperties = new HashMap<>();
    // Properties at some time after hitting the configuration server
    public HashMap<String, PropertyDetails> oldOverrides = new HashMap<>();
    public HashMap<String, PropertyDetails> newOverrides = new HashMap<>();
    
	public HashMap<String, PropertyDetails> getOriginalProperties() {
		return originalProperties;
	}
	public HashMap<String, PropertyDetails> getOldOverrides() {
		return oldOverrides;
	}
	public HashMap<String, PropertyDetails> getNewOverrides() {
		return newOverrides;
	}
   
}
