package com.sas.mkt.kubectl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.ryantenney.metrics.spring.config.annotation.EnableMetrics;

@SpringBootApplication
@EnableMetrics
@ComponentScan({ "com.sas.mkt.kubectl.*", "com.sas.mkt.config.*" })
public class KubectlApplication {
	public static void main(String[] args) throws Throwable {
		SpringApplication application = new SpringApplication(KubectlApplication.class);
		application.run(args);
	}
}
