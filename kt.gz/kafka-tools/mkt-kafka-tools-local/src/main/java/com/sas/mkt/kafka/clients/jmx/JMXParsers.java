package com.sas.mkt.kafka.clients.jmx;

import javax.management.AttributeList;
import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

public class JMXParsers {
	
//	private JMXConnector jmxc1;
//	private MBeanServerConnection mbsc1;
	private JMXConnector jmxc2;
	private MBeanServerConnection mbsc2;
//	private JMXConnector jmxc3;
//	private MBeanServerConnection mbsc3;

	public static void main(String[] args) {
		JMXParsers jp = new JMXParsers();
		try {
			jp.openJMXConnections();
			jp.getStats();
			jp.closeJMXConnections();
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
	
	public void getStats() throws Exception {
		String topic = "butters-test-events";
		String[] attributes = { "Count", "EventType", "FifteenMinuteRate", "FiveMinuteRate", "MeanRate",
				"OneMinuteRate", "RateUnit" };

		ObjectName objectName = new ObjectName("kafka.server:type=BrokerTopicMetrics,name=MessagesInPerSec,topic=" + topic);
		
//		AttributeList alist1 = mbsc1.getAttributes(objectName, attributes);
//		for (Object obj: alist1) {
//			System.out.println(obj);
//		}
		AttributeList alist2 = mbsc2.getAttributes(objectName, attributes);
		for (Object obj: alist2) {
			System.out.println(obj);
		}
//		AttributeList alist3 = mbsc3.getAttributes(objectName, attributes);
//		for (Object obj: alist3) {
//			System.out.println(obj);
//		}
	

	}
	
	public void openJMXConnections() throws Exception {
//		JMXServiceURL url1 = new JMXServiceURL("service:jmx:rmi:///jndi/rmi://kafkang-kafka1.cidev.sas.us:9393/jmxrmi");
//		jmxc1 = JMXConnectorFactory.connect(url1, null);
//		mbsc1 = jmxc1.getMBeanServerConnection();
		
		JMXServiceURL url2 = new JMXServiceURL("service:jmx:rmi:///jndi/rmi://10.240.38.81:9393/jmxrmi");
		jmxc2 = JMXConnectorFactory.connect(url2, null);
		mbsc2 = jmxc2.getMBeanServerConnection();
		
//		JMXServiceURL url3 = new JMXServiceURL("service:jmx:rmi:///jndi/rmi://kafkang-kafka3.cidev.sas.us:9393/jmxrmi");
//		jmxc3 = JMXConnectorFactory.connect(url3, null);
//		mbsc3 = jmxc3.getMBeanServerConnection();
		
	}
	
	public void closeJMXConnections() {
		try {
//			jmxc1.close();
			jmxc2.close();
//			jmxc3.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
