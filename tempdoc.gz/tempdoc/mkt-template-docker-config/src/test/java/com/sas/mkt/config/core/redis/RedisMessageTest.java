package com.sas.mkt.config.core.redis;

import static org.junit.Assert.*;

import org.junit.Test;

public class RedisMessageTest {

	@Test
	public void testRedisMessage() {
		
		String component = "mockComponent";
		String eventType = "mockEventType";
		String id = "mockId";
		String name = "mockName";
		String tier = "mockTier";
		String timestamp = "0";
		String value = "mockValue";

		RedisMessage rMessage = new RedisMessage();
		
		rMessage.setComponentNm(component);
		rMessage.setEventType(eventType);
		rMessage.setId(id);
		rMessage.setName(name);
		rMessage.setTierNm(tier);
		rMessage.setTimestamp(timestamp);
		rMessage.setValue(value);
		
		assertEquals(component, rMessage.getComponentNm());
		assertEquals(eventType, rMessage.getEventType());
		assertEquals(id, rMessage.getId());
		assertEquals(name, rMessage.getName());
		assertEquals(tier, rMessage.getTierNm());
		assertEquals(timestamp, rMessage.getTimestamp());
		assertEquals(value, rMessage.getValue());
		
		assertNotNull(rMessage.toString());	
		
	}

}
