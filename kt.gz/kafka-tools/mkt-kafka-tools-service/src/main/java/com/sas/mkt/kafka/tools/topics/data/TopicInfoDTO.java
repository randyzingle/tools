package com.sas.mkt.kafka.tools.topics.data;

import java.io.Serializable;
import java.util.List;
import java.util.Properties;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TopicInfoDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	public enum ValueType {StringType, AvroType, Unknown}
	
	public String topic;
	public ValueType valueType;
	public long numberMessages;
	public String schemaName;
	public List<FieldDTO> fieldList;
	public List<String> cleanFieldList;
	public boolean compacted;
	public Properties customConfig;
	public int numberPartitions;
	public long firstTimestamp;
	public long lastTimestamp;
	public String errorMessage;
	public int maxRecords;
	
	public TopicInfoDTO() {}
	
	public void setInfo(String topic, ValueType valueType, long numberMessages, String schemaName,
			List<FieldDTO> fieldList, List<String> cleanFieldList, boolean compacted, Properties customConfig,
			int numberPartitions, long firstTimestamp, long lastTimestamp, String errorMessage, int maxRecords) {
		this.topic = topic;
		this.valueType = valueType;
		this.numberMessages = numberMessages;
		this.schemaName = schemaName;
		this.fieldList = fieldList;
		this.cleanFieldList = cleanFieldList;
		this.compacted = compacted;
		this.customConfig = customConfig;
		this.numberPartitions = numberPartitions;
		this.firstTimestamp = firstTimestamp;
		this.lastTimestamp = lastTimestamp;
		this.errorMessage = errorMessage;
		this.maxRecords = maxRecords;
	}

	public TopicInfoDTO(String topic, ValueType valueType, long numberMessages, String schemaName,
			List<FieldDTO> fieldList, List<String> cleanFieldList, boolean compacted, Properties customConfig,
			int numberPartitions, long firstTimestamp, long lastTimestamp, String errorMessage, int maxRecords) {
		super();
		this.topic = topic;
		this.valueType = valueType;
		this.numberMessages = numberMessages;
		this.schemaName = schemaName;
		this.fieldList = fieldList;
		this.cleanFieldList = cleanFieldList;
		this.compacted = compacted;
		this.customConfig = customConfig;
		this.numberPartitions = numberPartitions;
		this.firstTimestamp = firstTimestamp;
		this.lastTimestamp = lastTimestamp;
		this.errorMessage = errorMessage;
		this.maxRecords = maxRecords;
	}

	@Override
	public String toString() {
		return "TopicInfoDTO [topic=" + topic + ", valueType=" + valueType + ", numberMessages=" + numberMessages
				+ ", schemaName=" + schemaName + ", fieldList=" + fieldList + ", cleanFieldList=" + cleanFieldList
				+ ", compacted=" + compacted + ", customConfig=" + customConfig + ", numberPartitions="
				+ numberPartitions + ", firstTimestamp=" + firstTimestamp + ", lastTimestamp=" + lastTimestamp
				+ ", errorMessage=" + errorMessage + ", maxRecords=" + maxRecords + "]";
	}
	

}
