package com.sas.mkt.baldur.spring.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class KafkaController {
	
	@Autowired
	KafkaProducerDriver producerDriver;
	
	@Autowired
	KafkaConsumerDriver consumerDriver;
	
	@RequestMapping(value = "kafka/producer/start", method = RequestMethod.GET)
	public void startProducer() {
		producerDriver.start();
	}
	
	@RequestMapping(value = "kafka/producer/stop", method = RequestMethod.GET)
	public void stopProducer() {
		producerDriver.stop();
	}
	
	@RequestMapping(value = "kafka/consumer/start", method = RequestMethod.GET)
	public void startConsumer() {
		consumerDriver.start();
	}
	
	@RequestMapping(value = "kafka/consumer/stop", method = RequestMethod.GET)
	public void stopConsumer() {
		consumerDriver.stop();
	}

}
