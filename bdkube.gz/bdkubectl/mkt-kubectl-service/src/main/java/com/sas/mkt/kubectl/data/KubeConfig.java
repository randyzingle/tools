package com.sas.mkt.kubectl.data;

public class KubeConfig {
	
	public String message;
	public String status;
	public String userName;
	@Override
	public String toString() {
		return "KubeConfig [message=" + message + ", status=" + status + ", userName=" + userName + "]";
	}

}
