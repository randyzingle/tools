package com.sas.mkt.config.core.redis;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.env.MockEnvironment;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.appspecific.GlobalConfiguration;
import com.sas.mkt.config.core.ConfigUtils;
import com.sas.mkt.config.core.PropertyMap;
import com.sas.mkt.config.core.configserver.ConfigServerClient;
import com.sas.mkt.config.core.startup.ConfigServiceHelper;

public class RedisConfigListenerTest {
	
	ApplicationConfiguration appConfig;
	GlobalConfiguration globalConfig;
	ConfigServiceHelper configServiceHelper;
	ConfigUtils configUtils;
	MockEnvironment env;
	ConfigServerClient client;
	PropertyMap propertyMap;
	
	@Before
	public void setUp() {
		appConfig = new ApplicationConfiguration();
		globalConfig = new GlobalConfiguration();
		env = new MockEnvironment();
		propertyMap = new PropertyMap(appConfig, globalConfig, env);
		client = new ConfigServerClient(appConfig);
		configUtils = new ConfigUtils(appConfig, globalConfig, propertyMap, client, env);
		configServiceHelper = new ConfigServiceHelper(configUtils, appConfig, globalConfig);
	}
	
	@Test
	public void testRedisSetup() {
		String blargelHost = "blarg,blat";
		String blargelPorts = "blarg,blat";
		String goodHost = "cache-dev-redis.cidev.sas.us";
		int goodPort = 6379;
		globalConfig.setRedisClusterPrimaryEndpoint(goodHost);
		globalConfig.setRedisClusterPrimaryEndpointPort(goodPort);
		globalConfig.setRedisClusterReadEndpoints(blargelHost);
		globalConfig.setRedisClusterReadEndpointPorts(blargelPorts);
		RedisConfigListener redisConfigListener = new RedisConfigListener(appConfig, globalConfig, configServiceHelper);
		redisConfigListener.setupRedisEndpoints();
		
		assertEquals(goodHost, redisConfigListener.redisHost);
		assertEquals(goodPort, redisConfigListener.redisPort);

	}

}
