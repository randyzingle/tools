package com.sas.mkt.baldur.spring.startup;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import com.sas.mkt.config.core.ApplicationConstants;
import com.sas.mkt.config.core.BaseUtils;

@Component
public class ApplicationStartupRunner implements ApplicationRunner, Ordered {

	private final static Logger logger = LoggerFactory.getLogger(ApplicationStartupRunner.class);

	@Override
	public int getOrder() {
		return ApplicationConstants.CONFIG_SERVICE_RUNNER_ORDER + 10;
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		BaseUtils.bigPrint("Baldur Spring Application is Running!");
		logger.info("Baldur Spring Application is Running!");
		System.out.println("Using Java: " + System.getProperty("java.version"));

	}

}
