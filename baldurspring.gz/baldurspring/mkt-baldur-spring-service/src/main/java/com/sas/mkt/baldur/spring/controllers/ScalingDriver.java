package com.sas.mkt.baldur.spring.controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sas.mkt.baldur.spring.tools.CPULoader;

@RestController
@RequestMapping("/")
public class ScalingDriver {
	
	private byte[][] heapOfBytes;
	private List<CPULoader> loaders = new ArrayList<>();
	
	
	@CrossOrigin(origins = "http://localhost:8000") 
	@RequestMapping(value = "scaling/sayhi", method = RequestMethod.GET)
	public String sayHiBaldur() {
		return "Hi from Baldur!";
	}
	
	@CrossOrigin(origins = "http://localhost:8000") 
	@RequestMapping(value = "scaling/getstats", method = RequestMethod.GET)
	public List<String> getStats() {
		long million = 1000000;
		List<String> result = new ArrayList<>();
		Runtime rt = Runtime.getRuntime();
		String version = Runtime.version().toString();
		result.add("java version: " + version);
		int cpus = rt.availableProcessors();
		result.add("cpus: " + cpus);
		long fm = rt.freeMemory();
		result.add("free memory: " + fm/million + "MB");
		long maxm = rt.maxMemory();
		result.add("max memory: " + maxm/million + "MB");
		long totm = rt.totalMemory();
		result.add("total memory: " + totm/million + "MB");
		return result;
	}
	
	@CrossOrigin(origins = "http://localhost:8000") 
	@RequestMapping(value = "scaling/cpuload", method = RequestMethod.GET)
	public List<String> loadCpu() {
		List<String> result = new ArrayList<>();
		for (int i=0; i<20; i++) {
			CPULoader loader = new CPULoader();
			loaders.add(loader);
			Thread t = new Thread(loader);
			t.setPriority(Thread.MAX_PRIORITY);
			t.start();
		}
		result.add("driving cpu usage");
		return result;
	}
	
	@CrossOrigin(origins = "http://localhost:8000") 
	@RequestMapping(value = "scaling/cpuunload", method = RequestMethod.GET)
	public List<String> unloadCpu() {
		List<String> result = new ArrayList<>();
		for (CPULoader loader: loaders) {
			if (loader != null) loader.killNow();
		}
		result.add("dropping cpu usage");
		return result;
	}
	
	@CrossOrigin(origins = "http://localhost:8000") 
	@RequestMapping(value = "scaling/addheap", method = RequestMethod.GET) 
	public List<String> addHeap(@RequestParam int memInMB) {
		List<String> result = new ArrayList<>();
		int om = 1000 * 1000;
		System.err.println("memory adjustment: " + memInMB + " MB");
		long maxMem = Runtime.getRuntime().maxMemory();
		long totalMem = Runtime.getRuntime().totalMemory();
		long freeMem = Runtime.getRuntime().freeMemory();
		System.out.printf("max=%d, total=%d, free=%d%n", maxMem/om, totalMem/om, freeMem/om);
		int maxsize = 50;
		int narrs = memInMB / maxsize;
		
		heapOfBytes = new byte[narrs+1][];
		if (narrs == 0) {
			System.out.println("Creating " + 1 + " array of bytes of size: " + memInMB + " million entries");
			heapOfBytes[0] = new byte[memInMB * om];
		} else {
			System.out.println("Creating " + narrs + " arrays of bytes of size: " + maxsize + " million entries");
			System.out.println("Creating " + 1 + " array of bytes of size: " + memInMB%maxsize + " million entries");
			for (int i=0; i<narrs; i++) {
				heapOfBytes[i] = new byte[maxsize * om];
				Arrays.fill(heapOfBytes[i], (byte)127);
			}
			heapOfBytes[narrs] = new byte[memInMB%maxsize * om];
		}
		
		maxMem = Runtime.getRuntime().maxMemory();
		totalMem = Runtime.getRuntime().totalMemory();
		freeMem = Runtime.getRuntime().freeMemory();
		System.out.printf("max=%d, total=%d, free=%d%n", maxMem/om, totalMem/om, freeMem/om);
		result.add("add heap of bytes");
		return result;
	}
	
	@CrossOrigin(origins = "http://localhost:8000") 
	@RequestMapping(value = "scaling/removeheap", method = RequestMethod.GET) 
	public List<String> removeHeap() {
		List<String> result = new ArrayList<>();
		heapOfBytes = null;
		System.gc();
		result.add("remove heap of bytes");
		return result;
	}

}
