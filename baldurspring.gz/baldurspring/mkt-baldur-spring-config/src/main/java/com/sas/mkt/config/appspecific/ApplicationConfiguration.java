package com.sas.mkt.config.appspecific;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.sas.mkt.config.core.Configuration;

@Component
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false, ignoreInvalidFields = false)
public class ApplicationConfiguration extends Configuration {

	/**
	 * Do not change the following fields - used by the framework
	 */
	public String componentName;

	// passed in as environment variables in EC2 & Docker
	public String tierName;
	public String configServiceUrl;
	public String configStackName;
	
	// Kafka
	public String kafkaConsumerProperties;
	public String kafkaProducerProperties;

	// Dynamically change log levels
	public String logLevelOverride;

	public String metrics;
	public String island;
	public String getComponentName() {
		return componentName;
	}
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}
	public String getTierName() {
		return tierName;
	}
	public void setTierName(String tierName) {
		this.tierName = tierName;
	}
	public String getConfigServiceUrl() {
		return configServiceUrl;
	}
	public void setConfigServiceUrl(String configServiceUrl) {
		this.configServiceUrl = configServiceUrl;
	}
	public String getConfigStackName() {
		return configStackName;
	}
	public void setConfigStackName(String configStackName) {
		this.configStackName = configStackName;
	}
	public String getKafkaConsumerProperties() {
		return kafkaConsumerProperties;
	}
	public void setKafkaConsumerProperties(String kafkaConsumerProperties) {
		this.kafkaConsumerProperties = kafkaConsumerProperties;
	}
	public String getKafkaProducerProperties() {
		return kafkaProducerProperties;
	}
	public void setKafkaProducerProperties(String kafkaProducerProperties) {
		this.kafkaProducerProperties = kafkaProducerProperties;
	}
	public String getLogLevelOverride() {
		return logLevelOverride;
	}
	public void setLogLevelOverride(String logLevelOverride) {
		this.logLevelOverride = logLevelOverride;
	}
	public String getMetrics() {
		return metrics;
	}
	public void setMetrics(String metrics) {
		this.metrics = metrics;
	}
	public String getIsland() {
		return island;
	}
	public void setIsland(String island) {
		this.island = island;
	}

	
	
	
}
