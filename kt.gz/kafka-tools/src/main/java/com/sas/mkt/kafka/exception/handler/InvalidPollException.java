package com.sas.mkt.kafka.exception.handler;

public class InvalidPollException extends Exception {

	public InvalidPollException(String string) {
		super(string);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
