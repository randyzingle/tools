package com.sas.mkt.kafka.clients.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.RegionUtils;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.cloudwatch.AmazonCloudWatch;
import com.amazonaws.services.cloudwatch.AmazonCloudWatchAsyncClient;
import com.amazonaws.services.cloudwatch.model.Dimension;
import com.amazonaws.services.cloudwatch.model.MetricDatum;
import com.amazonaws.services.cloudwatch.model.PutMetricDataRequest;
import com.amazonaws.services.cloudwatch.model.PutMetricDataResult;
import com.amazonaws.services.cloudwatch.model.StandardUnit;

/**
 * Uploads metric to Amazon's CloudWatch.
 * 
 * razing: Deprecated Feb, 2020, sprint 2004. This functionality will be moved
 * into a more flexible metrics engine that isn't tied to CloudWatch.
 */
@Deprecated
public class CloudWatchMetricPublisher {
	// I18NOK:CLS
	private static final Logger logger = LoggerFactory.getLogger(CloudWatchMetricPublisher.class);
	private static final String NAME_SPACE = "/SAS/CI360/KafkaConsumerMetrics";
	private static final String METRIC_MAX_LAGS = "max_lags";
	private static final String DEFAULT_REGION_NAME = "us-east-1";

	private static AmazonCloudWatch cloudWatch;

	/**
	 * It is only used for unit test
	 * 
	 * @param mocked
	 */
	public static void setCloudWatch(AmazonCloudWatch mocked) {
		cloudWatch = mocked;
	}

	@SuppressWarnings("deprecation")
	public static AmazonCloudWatch getCloudWatch() {
		if (cloudWatch == null) {
			// Tried to use AmazonCloudWatchClientBuilder.defaultClient() but it is not
			// working in non-ec2 instance
			AmazonCloudWatchAsyncClient awsClient = new AmazonCloudWatchAsyncClient(
					new DefaultAWSCredentialsProviderChain());
			awsClient.setRegion(getRegion());
//			AmazonCloudWatch awsClient = AmazonCloudWatchClientBuilder.standard().withRegion(getRegion()).build();
			cloudWatch = awsClient;
		}

		return cloudWatch;
	}

	private static Region getRegion() {
		// this tries to load EC2 Metadata -> and now throws an exception if it fails
		// with the AWS SDK 1.11.714 upgrade
		Region region = null;
		try {
//			System.out.println("***** ASKING AWS FOR THE REGION");
			region = Regions.getCurrentRegion();
		} catch (Exception ex) {
			logger.warn(ex.toString());
		}
		if (region == null) {
//			System.out.println("***** USING DEFAULT REGION");
			region = RegionUtils.getRegion(DEFAULT_REGION_NAME);
		}
		return region;
	}

//	private static String getRegion() {
//		// this tries to load EC2 Metadata -> and now throws an exception if it fails
//		// with the AWS SDK 1.11.714 upgrade
//		Region region = null;
//		try {
//			region = Regions.getCurrentRegion();
//		} catch (Exception ex) {
//			logger.info(ex.toString());
//		}
//		if (region == null) {
//			return Regions.US_EAST_1.getName();
//		} else {
//			return region.getName();
//		}
//	}

	/**
	 * Publish Kafka consumer max_lags metric to AWS Cloudwatch
	 * 
	 * @param dimensionName  It is used as metric dimension name.
	 * @param dimensionValue It is used as metric dimension value.
	 * @param awsMetrics     a collection of metrics with non-negative values
	 * @return
	 */
	public static void publishKafkaMetrics(String dimensionName, String dimensionValue,
			Map<String, Double> awsMetrics) {
		if (awsMetrics == null || awsMetrics.size() < 1)
			return;

		// Fill-in the dimensions: groupName
		Collection<Dimension> dimensions = new ArrayList<>(1);

		Dimension groupDim1 = new Dimension();
		groupDim1.setName(dimensionName);
		groupDim1.setValue(dimensionValue);
		dimensions.add(groupDim1);

		Map<String, Collection<Dimension>> dimensionMap = new HashMap<>();
		for (Map.Entry<String, Double> entry : awsMetrics.entrySet()) {
			dimensionMap.put(entry.getKey(), dimensions);
		}

		publishKafkaMetrics(dimensionMap, awsMetrics);
	}

	public static void publishKafkaMetrics(Map<String, Collection<Dimension>> dimensionMap,
			Map<String, Double> awsMetrics) {
		StandardUnit unit = StandardUnit.Count;

		for (Map.Entry<String, Double> entry : awsMetrics.entrySet()) {
			String key = entry.getKey();
			publishCloudWatchMetric(dimensionMap.get(key), key, entry.getValue(), unit);
		}
	}

	/**
	 * Util function to publish a metric to AWS Cloudwatch
	 * 
	 */
	public static PutMetricDataResult publishCloudWatchMetric(Collection<Dimension> dimensions, String metricName,
			double metricValue, StandardUnit unit) {
		// Create the Metric data, as a Request for CloudWatch
		PutMetricDataRequest metricReq = new PutMetricDataRequest();
		metricReq.setNamespace(NAME_SPACE);

		// Fill-in the data point in the metricData collection
		MetricDatum dataPoint = new MetricDatum();
		dataPoint.setMetricName(metricName);
		dataPoint.setValue(metricValue);
		dataPoint.setUnit(unit);

		dataPoint.setDimensions(dimensions);

		Collection<MetricDatum> metricData = new ArrayList<>(1);
		metricData.add(dataPoint);
		metricReq.setMetricData(metricData);

		try {
			// Publish the metric data point (success/failure) to CloudWatch
			PutMetricDataResult metricResult = getCloudWatch().putMetricData(metricReq);

			if (logger.isDebugEnabled()) {
				logger.debug("A CloudWatch Metric value (" + metricValue + ") has been published for " + metricName
						+ " in dimensions " + dimensions.toString());
			}
			return metricResult;
		} catch (Exception e) {
			logger.error("Failed to publish a cloudwatch metric", e);
			return null;
		}
	}

}
