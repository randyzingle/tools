--liquibase formatted sql

--changeset razing:1
create table dogs (name varchar(20));
--rollback drop table dogs;

--changeset razing:2
insert into dogs (name) values ('baldur');
