package com.sas.mkt.config.health;

public interface HealthCheckTarget {
	
	public boolean isHealthy();

}
