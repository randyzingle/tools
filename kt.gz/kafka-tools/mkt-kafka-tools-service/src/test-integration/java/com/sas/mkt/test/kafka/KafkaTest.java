package com.sas.mkt.test.kafka;

import java.net.URI;
import java.net.URISyntaxException;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.BufferExhaustedException;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.errors.InterruptException;
import org.apache.kafka.common.errors.SerializationException;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.SocketUtils;

import com.palantir.docker.compose.DockerComposeRule;
import com.palantir.docker.compose.configuration.ProjectName;
import com.palantir.docker.compose.connection.DockerMachine;
import com.palantir.docker.compose.connection.DockerPort;
import com.palantir.docker.compose.connection.waiting.HealthChecks;
import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.core.BaseUtils;
import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.domain.TestEvent;
import com.sas.mkt.kafka.tools.KafkaAdminApplication;
import com.sas.mkt.kafka.tools.topics.data.RecordDTO;
import com.sas.mkt.kafka.tools.topics.data.RecordSetDTO;
import com.sas.mkt.kafka.tools.topics.data.TopicInfoDTO;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = KafkaAdminApplication.class)
@TestPropertySource(locations = "classpath:integration-test.properties")
public class KafkaTest {
	
	private static int BROKER_PORT;
	static {
    	BROKER_PORT = SocketUtils.findAvailableTcpPort();
	}
    private static final String BROKER = "broker";
    private static final int SCHEMA_REGISTRY_PORT = 8081;
    private static final String SCHEMA_REGISTRY = "schema_registry";
    private static final int ZOOKEEPER_PORT = 2181;
    private static final String ZOOKEEPER = "zookeeper";
    
    private static final String topic = "baldur-test-events";
    private static final int nmessages = 200;
    
    private static KafkaConnectionUtils kcu;
    private static final String consumerGroupID = "baldur-mkt-kafka-tools";
    
    @Autowired
    ApplicationConfiguration appConfig;
    
    @Autowired
    TestRestTemplate webClient;
    
    @LocalServerPort
    int randomServerPort;
    
    private static String sessionCookie = null;
    
    private static final DockerMachine dockerMachine = DockerMachine.localMachine()
    		.withAdditionalEnvironmentVariable("KAFKA_PORT", Integer.toString(BROKER_PORT)).build();
	
    @ClassRule
    public static DockerComposeRule docker = DockerComposeRule.builder()
    		.machine(dockerMachine)
            .file("src/test-integration/resources/min-kafka-cluster.yml")
            .projectName(ProjectName.random())
            .waitingForService(BROKER, HealthChecks.toHaveAllPortsOpen())
            .waitingForService(SCHEMA_REGISTRY, HealthChecks.toHaveAllPortsOpen())
            .waitingForService(ZOOKEEPER, HealthChecks.toHaveAllPortsOpen())
            .waitingForService(SCHEMA_REGISTRY, HealthChecks.toRespondOverHttp(SCHEMA_REGISTRY_PORT, (port) -> port.inFormat("http://$HOST:$EXTERNAL_PORT")))
            .saveLogsTo("build/dockerLogs/dockerComposeRuleTest")
            .build();
    
    @BeforeClass
    public static void initialize() {
    	setupPorts();
    	loadData();
    }
    
    public String getSessionCookie() {
    	if (sessionCookie != null) return sessionCookie;
    	String cookie = null;
    	URI uri = getURI("/topics/count");
		HttpHeaders headers = webClient.headForHeaders(uri);
    	List<String> cookies = headers.get(HttpHeaders.SET_COOKIE);
    	if (cookies != null) {
    		cookie = cookies.get(0);
    		sessionCookie = cookie;
    	} 
    	return cookie;
    }
    
    public static void setupPorts() {

        DockerPort broker = docker.containers()
                .container(BROKER)
                .port(BROKER_PORT);
        String brokerEndpoint = String.format("%s:%s", broker.getIp(), broker.getExternalPort());
        System.out.println("broker: " + brokerEndpoint);
        System.setProperty("sas.mkt.kafka.cluster", brokerEndpoint);
        
        DockerPort zookeeper = docker.containers()
                .container(ZOOKEEPER)
                .port(ZOOKEEPER_PORT);
        String zookeeperEndpoint = String.format("%s:%s", zookeeper.getIp(), zookeeper.getExternalPort());
        System.out.println("zookeeper: " + zookeeperEndpoint);
        System.setProperty("sas.mkt.kafka.zookeeper", zookeeperEndpoint);
        
        DockerPort schemaRegistry = docker.containers()
                .container(SCHEMA_REGISTRY)
                .port(SCHEMA_REGISTRY_PORT);
        String schemaRegistryEndpoint = String.format("%s:%s", schemaRegistry.getIp(), schemaRegistry.getExternalPort());
        System.out.println("schema-registry: http://" + schemaRegistryEndpoint);
        System.setProperty("sas.mkt.kafka.schema.registry", schemaRegistryEndpoint);
    }
    
    public static void loadData() {
    	System.out.println("... loading data ...");
		
		try {
			kcu = KafkaConnectionUtils.getInstance(null);
		} catch (Exception ex) {
			System.out.println(ex.toString());
			return;
		}
		
		Properties props = kcu.getKafkaProducerProperties("dev", "mkt-kafka-tools");
		Producer<String, SpecificRecordBase> producer = new KafkaProducer<>(props);
		System.out.println("created producer with props: " + props.toString());
		TestRecordGenerator werg = new TestRecordGenerator();
		int cnt = 0;
		int nloops = 5;
		int nrecords = nmessages;
		List<TestEvent> weblist = null;

		for (int i=0; i<nloops; i++) {
			weblist = werg.getTestEventList(nrecords/nloops, 1000);
			for (TestEvent we: weblist) {
				cnt++;
				ProducerRecord<String, SpecificRecordBase> record = new ProducerRecord<>(topic, we.getTenant(), we);
				try {
					producer.send(record);
				} catch (SerializationException|BufferExhaustedException|InterruptException ex) {
					ex.printStackTrace();
				}
				if (cnt%(nrecords/nloops)==0) {
					System.out.println(record);
					System.out.println("sent message " + cnt);
				}
			}
		}
		System.out.printf("Produced %d records...", cnt);
		
		// give the buffer a chance to empty out
		producer.flush();
		long sleep = 1000L;
		producer.close(sleep, TimeUnit.MILLISECONDS);

    }
    
    private URI getURI(String path) {
    	URI uri = null;
    	String url = "http://localhost:"+randomServerPort+"/marketingKafkaTools"+path;
    	try {
			uri = new URI(url);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
    	return uri;
    }
    
    @Test
    public void testSessionState() {
    	String cookie = getSessionCookie();
    	int expectedCount = 3;
    	int count = 0;
    	for (int j=0; j<expectedCount; j++) {
	    	HttpHeaders headers = new HttpHeaders();
	    	headers.add(HttpHeaders.COOKIE, cookie);
	    	URI uri = getURI("/topics/count");
	    	RequestEntity  request = new RequestEntity(headers, HttpMethod.GET, uri);
	    	ResponseEntity<Integer> entity = webClient.exchange(request, Integer.class);
	    	count = entity.getBody();
    	}
    	Assert.assertTrue(count == expectedCount);
    }
    
    @Test
    public void getTopicList() {
    	String cookie = getSessionCookie();
    	HttpHeaders headers = new HttpHeaders();
    	headers.add(HttpHeaders.COOKIE, cookie);
    	URI uri = getURI("/topics/list");
    	RequestEntity  request = new RequestEntity(headers, HttpMethod.GET, uri);
    	ResponseEntity<List> entity = webClient.exchange(request, List.class);
    	List<String> topicList = entity.getBody();
    	boolean baldur = topicList.contains(topic);
    	Assert.assertTrue(baldur);
    }
    
    @Test
    public void getTopicInfo() {
    	String cookie = getSessionCookie();
    	HttpHeaders headers = new HttpHeaders();
    	headers.add(HttpHeaders.COOKIE, cookie);
    	URI uri = getURI("/topics/topicinfo?topic="+topic);
    	RequestEntity<TopicInfoDTO>  request = new RequestEntity<>(headers, HttpMethod.GET, uri);
    	ResponseEntity<TopicInfoDTO> entity = webClient.exchange(request, TopicInfoDTO.class);
    	TopicInfoDTO topicInfo = entity.getBody();
    	System.out.println(topicInfo);
    	Assert.assertTrue(topicInfo.topic.equals(topic));
    	Assert.assertTrue(topicInfo.schemaName.equals("TestEvent"));
    	Assert.assertTrue(topicInfo.valueType.equals(TopicInfoDTO.ValueType.AvroType));
    	Assert.assertTrue(topicInfo.numberMessages == nmessages);
    	Assert.assertTrue(topicInfo.numberPartitions == 10);
    }
    
    @Test
    public void getClusterInfo() {
    	String cookie = getSessionCookie();
    	HttpHeaders headers = new HttpHeaders();
    	headers.add(HttpHeaders.COOKIE, cookie);
    	URI uri = getURI("/topics/clusterinfo");
    	RequestEntity  request = new RequestEntity(headers, HttpMethod.GET, uri);
    	ResponseEntity<String> entity = webClient.exchange(request, String.class);
    	String s = entity.getBody();
    	boolean baldur = (s !=null && s.contains("clusterId") && s.contains("bootStrapServers"));
    	Assert.assertTrue(baldur);
    }
    
    @Test
    public void getRecords() {
    	String cookie = getSessionCookie();
    	HttpHeaders headers = new HttpHeaders();
    	headers.add(HttpHeaders.COOKIE, cookie);
    	URI uri = getURI("/topics/records");
    	RecordSetDTO recordSetDTO = new RecordSetDTO();
    	recordSetDTO.topic = topic;
    	recordSetDTO.valueType = TopicInfoDTO.ValueType.AvroType;
    	recordSetDTO.requestedPartition = -1;
    	recordSetDTO.requestedStartTime = System.currentTimeMillis() - 6000 * 1000;
    	recordSetDTO.requestedEndTime = System.currentTimeMillis();
    	HttpEntity<RecordSetDTO> entity = new HttpEntity<>(recordSetDTO, headers);
    	ResponseEntity<RecordSetDTO> response = webClient.exchange(uri, HttpMethod.POST, entity, RecordSetDTO.class);
    	recordSetDTO = response.getBody();
    	List<RecordDTO> rlist = recordSetDTO.recordList;
    	int size = rlist.size();
    	Assert.assertTrue(size == nmessages);
    }
    
    @Test 
    @Ignore // this isn't closing properly and is hanging 
    public void getConsumerGroups() {
//    	SimpleConsumerThread simpleConsumer = new SimpleConsumerThread();
//    	Thread runner = new Thread(simpleConsumer, "test-consumer-thread");
//    	runner.start();
//    	try {Thread.sleep(2000l);} catch (InterruptedException e) {}
    	
    	
//    	String cookie = getSessionCookie();
//    	HttpHeaders headers = new HttpHeaders();
//    	headers.add(HttpHeaders.COOKIE, cookie);
//    	String requestString = String.format("/topics/consumers?topic=%s&forceRefresh=false", topic);
//    	URI uri = getURI(requestString);
//    	RequestEntity  request = new RequestEntity(headers, HttpMethod.GET, uri);
//    	ResponseEntity<List> entity = webClient.exchange(request, List.class);
//    	List<ConsumerGroupDTO> list = (List<ConsumerGroupDTO>)entity.getBody();
//    	Object dto = list.get(0);
//    	LinkedHashMap<String, String> map = (LinkedHashMap<String, String>)dto;
    	
    	
//    	System.out.println(appConfig);
//    	ConsumerGroupUtils cgus = new ConsumerGroupUtils(appConfig);
//    	cgus.init();
//    	List<ConsumerGroupDTO> list = cgus.getConsumerGroupListForTopic(topic);
//    	try {
//	    	ConsumerGroupDTO cgdto = list.get(0);
//	    	String groupID = cgdto.groupId;
//	    	Assert.assertTrue(list.size() == 1);
//	    	Assert.assertTrue(groupID.equals(KafkaTest.consumerGroupID));
//    	} catch (Exception ex) {
//    		Assert.assertTrue(false);
//    	}
//    	simpleConsumer.shutdown();
//    	cgus.destroy();
    }
    
    private class SimpleConsumerThread implements Runnable {
    	
    	boolean shutdown = false;
    	KafkaConsumer<String, SpecificRecordBase> consumer = null;
    	

		@Override
		public void run() {

	    	Properties props = kcu.getKafkaConsumerProperties("dev", "mkt-kafka-tools");
	    	props.put(ConsumerConfig.GROUP_ID_CONFIG, consumerGroupID);
			consumer = new KafkaConsumer<>(props);
			consumer.subscribe(Arrays.asList(topic));
			while (!shutdown) {
				ConsumerRecords<String, SpecificRecordBase> records = consumer.poll(Duration.ofSeconds(2l));
				for (ConsumerRecord<String, SpecificRecordBase> record: records) {
					System.out.println(record);
				}
			}
			BaseUtils.bigPrint("Shutting Down Consumer");
			consumer.close();
		}
		
		public void shutdown() {
			shutdown = true;
		}
    	
    }
 

}
