package com.sas.mkt.config.core.configserver;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.sas.mkt.config.core.configserver.ConfigProperty;


public class ConfigPropertyTest {
	
	private ConfigProperty configProperty;
	
	@Before
	public void setUp() {
		configProperty = new ConfigProperty();
		configProperty.id = "12345";
		configProperty.name = "hello";
		configProperty.value = "world";
		configProperty.componentNm = "comp1";
		configProperty.tierNm = "tier1";
		configProperty.date = "03/03/2018";
	}
	
	@Test
	public void testGetters() {
		assertEquals(1, configProperty.version);
		assertEquals("12345", configProperty.id);
		assertEquals(null, configProperty.description);
		assertEquals("03/03/2018", configProperty.date);
		assertEquals(null, configProperty.tierId);
		configProperty.tierDesc = "tier desc";
		assertEquals("tier desc", configProperty.tierDesc);
		assertEquals(null, configProperty.componentId);
		assertEquals(null, configProperty.componentDesc);
	}
	
	@Test
	public void testHashCode() {
		assertEquals(-32771571, configProperty.hashCode());
		
		ConfigProperty tempProp1 = new ConfigProperty();
		assertEquals(28629152, tempProp1.hashCode());
	}
	
	@Test
	public void testEquals() {
		assertTrue(configProperty.equals(configProperty));
		assertFalse(configProperty.equals(null));
		assertFalse(configProperty.equals(new Object()));
		
		ConfigProperty tempProp1 = new ConfigProperty();
		ConfigProperty tempProp2 = new ConfigProperty();
		assertFalse(configProperty.equals(tempProp1));
		
		assertFalse(tempProp1.equals(configProperty));
		assertTrue(tempProp1.equals(tempProp2));
		
		tempProp1.componentNm = "comp1";
		assertFalse(configProperty.equals(tempProp1));
		
		tempProp2.componentNm = "comp1";
		tempProp2.name = "hello1";
		assertFalse(tempProp1.equals(tempProp2));
		
		tempProp1.name = "hello1";
		tempProp2.tierNm = "tier2";
		assertFalse(tempProp1.equals(tempProp2));
		
		tempProp1.tierNm = "tier1";
		assertFalse(tempProp1.equals(tempProp2));
		
		tempProp1.tierNm = "tier2";
		assertTrue(tempProp1.equals(tempProp2));
		
		tempProp2.value = "value2";
		assertFalse(tempProp1.equals(tempProp2));
		
		tempProp1.value = "value1";
		assertFalse(tempProp1.equals(tempProp2));
		
		tempProp1.value = "value2";
		assertTrue(tempProp1.equals(tempProp2));
		
		tempProp1.version = 10;
		tempProp2.version = 12;
		
		assertFalse(tempProp1.equals(tempProp2));
	}

	@Test
	public void testToString() {
		
		String toString = configProperty.toString();
		String matchString = "ConfigProperty [version=1, id=12345, name=hello, value=world, description=null, date=03/03/2018, tierId=null, tierNm=tier1, tierDesc=null, componentId=null, componentNm=comp1, componentDesc=null]";
		
		assertEquals(matchString, toString);
	}
}
