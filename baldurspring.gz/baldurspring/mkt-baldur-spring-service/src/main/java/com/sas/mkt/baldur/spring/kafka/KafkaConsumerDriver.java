package com.sas.mkt.baldur.spring.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class KafkaConsumerDriver {
	
	@Autowired
	SampleConsumer consumer;
	
	Thread consumerThread;
	
	public void start() {
		// configure Kafka Consumer with props and fire it up
		consumerThread = new Thread(consumer);
		consumerThread.start();
	}
	
	public void stop() {
		consumer.stop();
	}

}