package com.sas.mkt.kafka.clients.producers.utils;

import java.io.File;
import java.io.FileInputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class TextCache {
	
	private static final Logger logger = LoggerFactory.getLogger(TextCache.class);
	private int maxSize = 1000;
	
	private static TextCache instance = null;
	private byte[] byteCache = null;
	private static final String textFile = "src/main/resources/data/alice.txt";

	public static void main(String[] args) {
		TextCache tc = TextCache.getInstance();
		String s = tc.getText(5000);
		System.out.println(s.length());
		System.out.println(s);
	}
	
	public static synchronized TextCache getInstance() {
		if (instance == null) {
			instance = new TextCache();
			instance.loadCache();
			
		}
		return instance;
	}
	
	public String getText(int numberBytes) {
		int bytesRead = 0;
		StringBuilder sb = new StringBuilder();
		while (bytesRead < numberBytes) {
			int remaining = numberBytes - bytesRead;
			String s = null;
			if (remaining > maxSize) {
				s = new String(byteCache, 0, maxSize);
				bytesRead += s.length();
			} else {
				s = new String(byteCache, 0, remaining);
				bytesRead += s.length();
			}
			sb.append(s);
			
		}
		return sb.toString();
	}
	
	private void loadCache() {
		try {
			File file = new File(textFile);
			if (!file.exists()) {
				
			} else {
				int size = (int)file.length();
				maxSize = size;
				byteCache = new byte[size];
				FileInputStream fis = new FileInputStream(file);
				fis.read(byteCache);
				fis.close();
				logger.info("Read {} bytes from {}", maxSize, textFile);
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage());
		}
	}
	

}
