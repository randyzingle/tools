package com.sas.mkt.kafka.tools.s3connect;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonIgnoreProperties(ignoreUnknown=true)
@JsonInclude(Include.NON_NULL)
public class StatusTasks {
	public StatusTasks() {}
	@JsonProperty("state")
	public String state;
	@JsonProperty("id")
	public String id;
	@JsonProperty("worker_id")
	public String workerId;
	@JsonProperty("trace")
	public String trace;
	
	@Override
	public String toString() {
		return "StatusTasks [state=" + state + ", id=" + id + ", workerId=" + workerId + ", trace=" + trace + "]";
	}
	
}
