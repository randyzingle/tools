# GitLab Project for CI360 Template Docker Microservice.

```
git clone git@gitlab.sas.com:CustomerIntelligence/DevOps/mkt-template-docker.git
```

Builds are performed by Jenkins (bci2jml01): http://bci2jml01.unx.sas.com:8080/job/MKT_DevOps/


| Stage Build | Deploy Build | Code Coverage |
| ----------- | ------------ | ------------- |
| [![Build Status](http://bci2jml01.unx.sas.com:8080/buildStatus/icon?job=MKT_DevOps/mkt-template-docker/staging)](http://bci2jml01.unx.sas.com:8080/job/MKT_DevOps/job/mkt-template-docker/job/staging/) | [![Build Status](http://bci2jml01.unx.sas.com:8080/buildStatus/icon?job=MKT_DevOps/mkt-template-docker/master)](http://bci2jml01.unx.sas.com:8080/job/MKT_DevOps/job/mkt-template-docker/job/master/) | [![Quality Gate](http://dev-sonar.cidev.sas.us/api/badges/measure?key=com.sas.mkt.template.docker:com.sas.mkt.template.docker&metric=line_coverage)](http://dev-sonar.cidev.sas.us/dashboard/index/com.sas.mkt.template.docker:com.sas.mkt.template.docker) |


If you do not have Developer (committer) rights to the repo, you will need to Fork the repo and create a Merge Request from that forked repo (source) to the target repo, so your changes can be reviewed and accepted by the team that owns the target repo.

For more information, take a look at: http://sww.sas.com/saspedia/CI_TNG_CDP


## Project: com.sas.mkt.template.microservice

Source projects go here as a single level of nodes in a Gradle multiproject build.
Each subproject should generate at most one type of artifact, like one JAR or a Zip fileset.

**Note:** The packages inside the JAR should match the project names like:

`package com.sas.mkt.{island}.{service}.{subproject}.*` for `mkt-{island}-{service}-{subproject}`

> @@@TEMPLATE@@@
>
> But for the templates, we're reusing `package com.sas.mkt.example.*` across all templates.


## Builds:
To build and deploy the code to AWS using the latest verified Base AMI, run:
> `gradlew all -Dstack=<stack_prefix> -DbuildType=<personal | team> -Downer=<user_id> -DadminEmail=<first.last@sas.com> -DconfigStack=<config stack name>`

For example, to create a new personal Dev micro-stack with a specific Base AMI, run:
> `gradlew all -Dstack=mydev -DbuildType=personal -DbaseAMI=<`[CI360_BakedAMI](http://sww.sas.com/saspedia/CI360_BakedAMI)`> -Downer=<user_id> -DadminEmail=<first.last@sas.com>`

For example, to build and test your code locally, but don't upload or deploy to AWS (buildType will default to personal for local builds):
> `gradlew`
or to clean and rebuild locally:
> `gradlew rebuild`

To build, test, upload (CloudFormation and CodeDeploy artifacts to S3), deploy (CloudFormation update and CodeDeploy) and run smoke tests against your local code with the latest Base AMI to an **existing** micro-stack in AWS:
> `getawskey.py`
>
> `gradlew all -Dstack=<my_user_id>`

To generate Swagger documentation:
> `gradlew asciidoctor`

The output files are in the following formats: ADoc, JSON, mark-down, HTML5 and PDF
Look for the documentation output here:
> `ls -R  mkt-template-microservice-service/build/asciidoc/`


## Logging
All logs must be written to the **console appender**. The docker infrastructure will pick up all logs written to the console and push them to Cloudwatch / Elasticsearch. See the logback-spring.xml file in the mkt-template-docker-service file. **Do not write logs to a file system appender**.

## Developing/Debugging from Eclipse
General notes on developing and debugging micro-services on your local desktop can be found here:
* [Eclipse Development Notes](doc/eclipse_dev_notes.md)

## Localization
Notes on localizing your microservice can be found here:
* [I18N Notes](doc/i18n_notes.md)


## Markdown Markup:

Please use markdown markup in the README.md files to maintain formatting for the GitLab UI.
> Example [Markdown guide from GitLab](https://docs.gitlab.com/ee/user/markdown.html)

## Getting Started Tutorial

### Base your project on the mkt-docker-template project

#### Initial Setup

Setup a new project in your gitlab island and copy all of the files in mkt-template-docker (except the .git directory) to it

In this example well use **mkt-myisland** as the island name (no that's not your actual island name, don't use it), and **mkt-myproject** as the project name (see previous comment).

change all reference from mkt-myisland to mkt-myisland and all references to mkt-docker-template to mkt-tenant-spitter, you'll have to update the following files:
* build.gradle files
* cloudformation.json
* environments.yaml
* gradle.properties
* settings.gradle

change the cloudGroup name in gradle.properties to cloudGroup=MyIsland

change the Mappings/Constants/InstanceValues/ECRImageName to mkt-myisland/mkt-myproject

edit the Dockerfile and update the maintainer name and the context-root in the HEATHCHECK CMD

    ARG REPO
    ARG RELEASE=latest
    FROM ${REPO}mkt-docker/alpine-jdk8-min:${RELEASE}
    ARG RELEASE=unknown
    ARG VERSION=unknown
    ARG PROJECT=unknown
    MAINTAINER cibuild <cibuild@sas.com>
    LABEL name=${PROJECT}                           \
      description="CI360 Template Microservice" \
      vendor="SAS Institute Inc."               \
      version=${VERSION}                        \
      revision=${REVISION}                      \
      maintainer="randall.zingle@sas.com"

    USER sassrv

    COPY service/ /install/citng/service/

    EXPOSE 8080

    HEALTHCHECK CMD /usr/bin/curl --fail http://localhost:8080/myRootContext/commons/ping || exit 1

    CMD ["java", \
    "-XX:+UnlockExperimentalVMOptions",  \
    "-XX:+UseCGroupMemoryLimitForHeap", \
    "-XX:MaxRAMFraction=1", \
    "-XshowSettings:vm", \
    "-Dlogging.config=classpath:logback-spring.xml", \
    "-jar", \
    "/install/citng/service/service.jar"]

log in to our Amazon Docker Registry (ECR)

    $ aws ecr get-login --no-include-email --region us-east-1 | /bin/bash

create the initial repository for your image:

    $ gradlew ecrInit

this will create an ECR repository named <island-name/project-name> which in this case will be mkt-myisland/mkt-myproject, check it out in the aws console

#### Build the Application and create a docker image

build an image from the Dockerfile

just run:

    $ gradlew build

if you've built docker images before, and want to map that knowledge to what the gradlew build is doing, you can do it manually

    $ cd mkt-myproject-service/build/docker
    $ export PROJECT=mkt-myproject
    $ export VERSION=2001
    $ export REPO=952478859445.dkr.ecr.us-east-1.amazonaws.com/
    docker build \
    --build-arg REPO --build-arg VERSION --build-arg PROJECT \
    -t rzingle/baldur-ts .

note you can specify --build-arg directly:
* --build-arg VERSION=2001

or you can set an environment variable and just specify the variable name:
* --build-arg VERSION (with VERSION set as an environment variable in the local shell as shown above)

check it out, you have a local docker image:

    $ docker images | grep myisland
    mkt-myisland/mkt-myproject latest e4cef8f9fabb 4 minutes ago 149MB

aws ecr list-images --repository-name mkt-myisland/mkt-myproject

You're curious and are wondering, has it been pushed to the ECR Repo yet?

    $ aws ecr list-images --repository-name mkt-myisland/mkt-myproject
    {
    "imageIds": []
    }

No it hasn't - because we are using stackPrefix=null. Once we are deploying to a cloudformation stack and ECS it will populate the ECR registry.

#### Run your application locally
Try running your image locally

    $ docker run --rm -it -p8888:8080 mkt-myisland/mkt-myproject

* **--rm** will kill the container when you hit CTRL-c
* **-it** runs the container in interactive mode -> you can see the console output
* **-p:8888:8080** maps the container's port 8080 to port 8888 on your machine
* **mkt-myisland/mkt-myproject** is your local image (reponame/imagename)

Browse to a local endpoint for your service: http://locahost:8888/myRootContext/ui/config.html

or if you love the command line:

    $ curl http://localhost:8888/myRootContext/commons/ping
    OK

So now you can run your application locally either directly from your IDE or by building the docker container and running it.

Now lets say you have an endpoint that lists our aws S3 buckets. Let's try to hit it from our app running in IntelliJ or from shell on our laptop:

    $ curl http://localhost:8080/myRootContext/s3/bucketlist
    [angularspa.ci.tc, aws-athena-query-results-952478859445-us-east-1, aws-athena-query-results-952478859445-us-west-2, aws-codestar-us-east-1-952478859445, ....

Nice there are our S3 buckets.

Lets do the same with our docker container:

    $ docker run --rm -it -p8888:8080 mkt-myisland/mkt-myproject
    $ curl http://localhost:8888/myRootContext/s3/bucketlist
    {"errorCode":0,"details":["correlator: 0f04f683-fafa-4694-a62e-bd78e0f456fd","traceId: b127c96eb2332214", ....

It doesn't work. Our docker container can't see our laptop's file system so it can't read our aws credentials in **~/.aws/credentials**. This is ok when it's running in ECS or EKS because the infrastructure will inject credentials for us. We can do this locally by mounting the credentials as a docker volume when we start the container.

    $ docker run --rm -it -p8888:8080 -v ~/.aws:/home/sassrv/.aws  mkt-myisland/mkt-myproject
    $ curl http://localhost:8888/myRootContext/s3/bucketlist
    [angularspa.ci.tc, aws-athena-query-results-952478859445-us-east-1, aws-athena-query-results-952478859445-us-west-2,

Now it works! The flag **-v ~/.aws:/home/sassrv/.aws** mounts our laptop's home folder/.aws folder under a folder in the container named /home/sassrv/.aws. We're running our application as user sassrv so the aws sdk looks here when running through the credential lookup chain.

#### Run your application in ECS
Now we can do a full build and deploy to ECS and our application will run as a docker container on one of our ECS environments. You can either kick this off as a Jenkins job or via gradle with something like this:

    $ gradlew all -Dstack=baldur -DbuildType=personal -Downer=razing -DadminEmail=randall.zingle@sas.com -x test -x integrationTest

Your cloudformation.json file has a parameter named ECSStackName which tells you which ECS environment your container will be deployed to.

# Base Application Changes

## Environment Variables
Some of your application's configuration is environment specific (TierName, ConfigServerUrl, etc.) and needs to be injected as environment variables. This is configured in the cloudformation.json script in your <yourproject>-cloudformation subproject.

There are a base set of environment variables that need to be passed into every application. These are passed in via cloudformation in the Resources->TaskDefinition->Properties->ContainerDefinitions->Environment section of the cloudformation.json file. If you need any application specific variable **that change based on the account/tier deployed to** add them here.

The base set of environment variables are listed below. Their names are based on the **canonical names** of the variables which equals the name of the service that creates them. So, for example, there is a variable named **ConfigServiceUrl** with spelling dictated by the config server stack outputs/ssm parameters.

<table>
<tr><th> Name </th><th> Sample Value </th><th> Source </th></tr>
<tr><td> ProjectName </td><td> mkt-template-docker </td><td> cloudformation mapping constant </td></tr>
<tr><td> ConfigStackName </td><td> dev-mkt-config </td><td> cloudformation parameter </td></tr>
<tr><td> ConfigServiceUrl </td><td> http://configservice-dev.cidev.sas.us:8080/ </td><td> Config Server cloudformation stack output </td></tr>
<tr><td> TierName </td><td> dev </td><td> cloudformation parameter </td></tr>
<tr><td> ServiceUrl </td><td> http://templatedocker-dev.cidev.sas.us:8080/templateService </td><td> constructed from cloudformation DNS resource </td></tr>
</table>

These variables are converted into the property names expected by the config client expected by the core shared library (mkt-shared-infra-client) and by the framework used in some of the DataHub / Events Island projects. This conversion is done by the **PreContextLoadedConfiguration.java** class included in the template. For this to work the application needs to be started like this:

```
@SpringBootApplication
@EnableMetrics
@ComponentScan({ "com.sas.mkt.template.*", "com.sas.mkt.config.*" })
public class TemplateDockerApplication {
	public static void main(String[] args) throws Throwable {
		SpringApplication application = new SpringApplication(TemplateDockerApplication.class);
		application.addListeners(new PreContextLoadedConfiguration());
		application.run(args);
	}
}
```
This provides the environment variables needed by the mkt-shared-infra-client, but to fully enable it follow the instructions here:
* [Enable Shared Config Client](mkt-template-docker-service/README.md)

# Working with a relational database

Instruction for working with one of the AWS RDS databases can be found here:
* [Database Setup info](doc/liquibase-rds.md)


## Copyright

Copyright © 2018 by SAS Institute Inc., Cary, NC, USA. All Rights Reserved.

This software is protected by copyright laws and international treaties.

U.S. GOVERNMENT RESTRICTED RIGHTS

Use, duplication or disclosure of this software and related
documentation by the United States government is subject to the
license terms of the Agreement with SAS Institute Inc. pursuant to,
as applicable, FAR 12.212, DFAR 227.7202-1(a), DFAR 227.7202-3(a)
and DFAR 227.7202-4 and, to the extent required under United
States federal law, the minimum restricted rights as set out
in FAR 52.227-19 (DEC 2007).
