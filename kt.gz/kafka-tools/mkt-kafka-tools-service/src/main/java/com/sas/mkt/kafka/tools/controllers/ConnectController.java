package com.sas.mkt.kafka.tools.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.Bucket;

@RestController
@RequestMapping("/connect")
public class ConnectController {
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/bucketinfo", method = RequestMethod.GET)
	public CInfo getS3BucketInfo(@RequestParam(value="name", defaultValue="ci-360-test-dev-us-east-1") String name) {
		System.out.println(name);
		CInfo cinfo = new CInfo();
		cinfo.name = name;
		System.out.println(System.getenv());
		try {
			listBuckets();
			cinfo.exists = getBucketInfo(name);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cinfo;
	}
	
	private AmazonS3 s3;
	
	private AmazonS3 getS3() {
		if (s3 == null) {
//			s3 = AmazonS3ClientBuilder.standard().withRegion(Regions.US_EAST_1).build();	
			s3 = AmazonS3ClientBuilder.standard().build();
		}
		return s3;
	}
	
	private boolean getBucketInfo(String name) throws Exception {
		AmazonS3 s3 = getS3();
		boolean exists = s3.doesBucketExist(name);
		boolean existsv2 = s3.doesBucketExistV2(name);
		System.out.println("exists " + exists);
		System.out.println("existsv2 " + existsv2);
		return exists;
	}
	
	private void listBuckets() throws Exception {
		AmazonS3 s3 = getS3();
		List<Bucket> buckets = s3.listBuckets();
		System.out.println("Your Amazon S3 buckets are:");
		for (Bucket b : buckets) {
		    System.out.println("* " + b.getName());
		}
	}
	
	public class CInfo {
		public String name;
		public boolean exists;
	}

}
