package com.sas.mkt.kafka.tools.topics.data;

import java.util.List;

public class ConsumerGroupDTO {
	
	public String groupId;
	public String state;
	public String partitionAssignor;
	public List<ConsumerDTO> consumers;
	
	public ConsumerGroupDTO(String groupId, String state, String partitionAssignor, List<ConsumerDTO> consumers) {
		this.groupId = groupId;
		this.state = state;
		this.partitionAssignor = partitionAssignor;
		this.consumers = consumers;
	}
	
	public boolean readsTopic(String topic) {
		boolean readsTopic = false;
		for (ConsumerDTO dto: consumers) {
			if(dto.topic.equals(topic)) return true;
		}
		return readsTopic;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ConsumerGroupDTO [groupId=").append(groupId).append(", state=").append(state)
				.append(", partitionAssignor=").append(partitionAssignor).append(", consumers=").append(consumers)
				.append("]");
		return builder.toString();
	}

}