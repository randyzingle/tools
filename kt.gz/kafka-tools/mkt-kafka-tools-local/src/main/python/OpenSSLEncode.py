'''
Source code located in GitLab:
    https://gitlab.sas.com/CustomerIntelligence/mkt-infra

@author Brad Williams <brad.williams@sas.com>
'''

from __future__ import print_function

import argparse
import logging
from subprocess import Popen, PIPE
from pipes import quote

logging.basicConfig()
logger = logging.getLogger('OpenSSLEncode')
logger.setLevel(logging.INFO)


def executeOpenSSL(password, params):
    p1 = Popen(['echo', '-n', password], stdout=PIPE)
    p2 = Popen(params, stdin=p1.stdout, stdout=PIPE)
    p1.stdout.close()

    output = p2.communicate()[0]
    result = output.strip()

    if ('stdin' in result):
        result = result.split()[1]

    return result


def handler(event=None, context=None):
    encoding = event['encoding'].lower()
    instring = event['instring']

    if('salt' in event):
        salt = event['salt']
    else:
        salt = None

    if (len(instring) == 0):
        return None

    password = quote(instring)

    if (encoding == 'md5'):
        params = ['openssl', 'dgst', '-md5']
    elif (encoding == 'base64'):
        params = ['openssl', 'enc', '-base64']
    elif (encoding == 'passwd'):
        if (salt is None):
            params = ['openssl', 'passwd', '-stdin']
        else:
            params = ['openssl', 'passwd', '-stdin', '-salt', salt]
    else:
        return None

    encodedStr = executeOpenSSL(password, params)

    logger.debug(encodedStr)
    return {'value': encodedStr}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='OpenSSL Encoder')
    parser.add_argument('--encoding', '-e', help='Encoding to use.', choices=['md5', 'base64', 'passwd'], default='md5')
    parser.add_argument('--instring', '-i', help='Input string to encode.', required=True)
    parser.add_argument('--debug', '-d', action='store_true', help='Print debug messages to console')

    args = parser.parse_args()

    if args.debug:
        logger.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.WARN)

    handler({'encoding': args.encoding, 'instring': args.instring}, None)
