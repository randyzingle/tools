package com.sas.mkt.kafka.clients.utils;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Timer;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.DescribeClusterResult;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.Node;
import org.apache.kafka.common.PartitionInfo;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;

//tag
/**
 *
 * A singleton that has all the required configuration parameters needed to
 * interact with Kafka.
 * <p>
 * The singleton can be used to return a configured KafkaConsumer,
 * KafkaProducer, or configured properties for the Producer, Consumer, or
 * KafkaStreams:
 * <ul>
 * <li>KafkaConsumer {@link #getKafkaConsumer(String, String)
 * getKafkaConsumer(String topic, String groupID)}</li>
 * <li>KafkaProducer {@link #getKafkaProducer(String) getKafkaProducer(String
 * topic)}</li>
 * <li>Properties for KafkaConsumer {@link #getKafkaConsumerProperties()
 * getKafkaConsumerProperties()}</li>
 * <li>Properties for KafkaProducer {@link #getKafkaProducerProperties(String)
 * getKafkaProducerProperties(clientID)}</li>
 * <li>Properties for KafkaStreams {@link #getKafkaStreamsProperties(String)
 * getKafkaStreamsProperties(String applicationID)}</li>
 * </ul>
 * <p>
 * The configuration parameters are pulled from the <b>mkt-kafka</b> component
 * in the global tier of the configuration server. You can override the
 * parameters either with environment variables or with system properties passed
 * to the java executable. Properties will take precedence in this order (from
 * highest precedence to lowest):
 * <ul>
 * <li>system properties</li>
 * <li>environment variables</li>
 * <li>config server properties</li>
 * </ul>
 * <p>
 * The following table shows the properties defined in the config server, with
 * their environment variable names.
 * <table>
 * <thead>
 * <tr>
 * <th>Config Server Property</th>
 * <th>Environment Variable Name</th>
 * </tr>
 * </thead> <tbody>
 * <tr>
 * <td>sas.mkt.kafka.cluster</td>
 * <td>SAS_MKT_KAFKA_CLUSTER</td>
 * </tr>
 * <tr>
 * <td>sas.mkt.kafka.schema.registry</td>
 * <td>SAS_MKT_KAFKA_SCHEMA_REGISTRY</td>
 * </tr>
 * <tr>
 * <td>sas.mkt.kafka.connect.distributed</td>
 * <td>SAS_MKT_KAFKA_CONNECT_DISTRIBUTED</td>
 * </tr>
 * <tr>
 * <td>sas.mkt.kafka.client.auth.required</td>
 * <td>SAS_MKT_KAFKA_CLIENT_AUTH_REQUIRED</td>
 * </tr>
 * <tr>
 * <td>sas.mkt.kafka.zookeeper</td>
 * <td>SAS_MKT_KAFKA_ZOOKEEPER</td>
 * </tr>
 * </tbody>
 * </table>
 * <p>
 * To override a system property use the config server property name. For
 * example, to override the property <br/>
 * <code>sas.mkt.kafka.cluster</code> <br/>
 * use <br/>
 * <code>java -Dsas.mkt.kafka.cluster=myclusterurl:port</code>.
 *
 * @author razing
 * @since 1707
 */
public class KafkaConnectionUtils {
	private static Logger logger = LoggerFactory.getLogger(KafkaConnectionUtils.class);

	// Config Server Tier Global
	public static final String CONFIG_SERVER_TIER_GLOBAL = "tier_global";

	// connection properties
	public static final String SAS_MKT_KAFKA_CLUSTER = "sas.mkt.kafka.cluster";
	public static final String SAS_MKT_KAFKA_BROKER_JMX_PORT = "sas.mkt.kafka.broker.jmx.port";
	public static final String SAS_MKT_KAFKA_SCHEMA_REGISTRY = "sas.mkt.kafka.schema.registry";
	public static final String SAS_MKT_KAFKA_CLIENT_AUTH_REQUIRED = "sas.mkt.kafka.client.auth.required";
	public static final String SAS_MKT_KAFKA_CONNECT_DISTRIBUTED = "sas.mkt.kafka.connect.distributed";

	// ZooKeeper
//	public static final String SAS_MKT_KAFKA_ZOOKEEPER = "sas.mkt.kafka.zookeeper";

	// tuning
	public static final String SAS_MKT_KAFKA_LINGER_MS = "sas.mkt.kafka.linger.ms";
	public static final String SAS_MKT_KAFKA_BATCH_SIZE = "sas.mkt.kafka.batch.size";
	public static final String SAS_MKT_KAFKA_COMPRESSION_TYPE = "sas.mkt.kafka.compression.type";

	// consumer initialization
	public static final String SAS_MKT_KAFKA_AUTO_OFFSET_RESET = "sas.mkt.kafka.auto.offset.reset";
	
	// config server url
	private static String CONFIG_SERVER_URL;

	// base kafka properties
	private HashMap<String, String> kafkaProperties;

//	public static void main(String[] args) {
//		String configServiceURL = "http://configservice-dev.cidev.sas.us:8080/";
//		try {
//			KafkaConnectionUtils.getInstance(configServiceURL);
//		} catch (Exception ex) {
//			ex.printStackTrace();
//		}
//	}

	private static KafkaConnectionUtils instance;
	private static Consumer mockedConsumer;
	private static Map<String, URLConnection> testConnectionByURL = null;

	private KafkaConnectionUtils() {
	}

	/**
	 * Resets any data currently associated with the singleton. Provided for testing
	 * purposes and not intended for production usage.
	 *
	 **/
	public static void resetInstance() {
		logger.info("Resetting the current instance.");
		instance = null;
		mockedConsumer = null;
	}

	public static void setTestConsumer(Consumer consumer) {
		mockedConsumer = consumer;
	}

	public static void setTestConnectionByURL(String url, URLConnection connection) {
		if (null == testConnectionByURL)
			testConnectionByURL = new HashMap<String, URLConnection>();

		if (null == connection)
			testConnectionByURL.remove(url);
		else
			testConnectionByURL.put(url, connection);
	}

	public static URLConnection getConnection(URL serverURL) throws IOException {

		URLConnection conn = null;

		String key = serverURL.toString();
		// are we testing and do we have a test connection?
		if (null != testConnectionByURL && testConnectionByURL.containsKey(key)) {
			conn = testConnectionByURL.get(key);
			if (null != conn)
				return conn;
		}

		return (URLConnection) serverURL.openConnection();
	}

	/**
	 * Simple helper method which returns all of the Kafka configuration information
	 * that the KafkaConnectionUtils class uses to communicate with the Kafka
	 * brokers and schema registry.
	 *
	 * @return String which contains all of the Kafka configuration information.
	 */
	public String getConnectionDetails() {
		return instance.kafkaProperties.toString();
	}

	public HashMap<String, String> getKafkaProperties() {
		return instance.kafkaProperties;
	}

	public synchronized int getNumberOfBrokers() {
		int numberBrokers = 1;
		try {
			String brokerList = instance.getKafkaProperties().get(SAS_MKT_KAFKA_CLUSTER);
			Properties props = new Properties();
			props.setProperty("bootstrap.servers", brokerList);
			AdminClient adminClient = AdminClient.create(props);
			DescribeClusterResult result = adminClient.describeCluster();
			Collection<Node> nodes = result.nodes().get();
			numberBrokers = nodes.size();
			adminClient.close();
		} catch (Exception ex) {
			logger.warn(ex.getMessage());
		}
		return numberBrokers;
	}

	/**
	 * Simple helper method which can be used by the gitlab based code which
	 * implements the EventStream's Configuration subproject. This subproject will
	 * have searched the config server for a configuration named kafkaTopicPrefix
	 * for the tier the application is spun up under. It will have searched the
	 * global component and the specific component. The specific component will
	 * override the global component.
	 * 
	 * This method simple does this: topicPrefix + "-" + baseTopicName if the
	 * kafkaTopicPrefix does not end with "-" or this: topicPrefix + baseTopicName
	 * if the kafkaTopicPrefix does end with "-";
	 *
	 * @return String which is the full name of a Kafka Topic
	 */
	public String getFullTopicName(String kafkaTopicPrefix, String baseTopicName) {
		if (kafkaTopicPrefix.endsWith("-")) {
			return kafkaTopicPrefix + baseTopicName;
		} else {
			return kafkaTopicPrefix + "-" + baseTopicName;
		}
	}

	/**
	 * Returns a singleton instance that has all the required configuration
	 * parameters needed to interact with Kafka. If it can't establish a valid
	 * connection it will throw an exception.
	 * <p>
	 * This method works with the
	 * {@link com.sas.mkt.kafka.clients.utils.KafkaProperties KafkaProperties} class
	 * to setup the required Kafka properties.
	 *
	 * @param configServiceURL The URL for the micro-service config server
	 *                         (e.g.http://configservice-dev.cidev.sas.us:8080/)
	 * @return a singleton instance of KafkaConnectionUtils which is configured with
	 *         Kafka connection parameters
	 * @throws Exception This will throw an exception if a valid connection to Kafka
	 *                   can't be established
	 */
	public static synchronized KafkaConnectionUtils getInstance(String configServiceURL) throws Exception {
		if (instance == null) {
			if (configServiceURL != null && !configServiceURL.endsWith("/"))
				configServiceURL = configServiceURL + "/";
			CONFIG_SERVER_URL = configServiceURL;// yes this is a mess!!!
			logger.info("Setting up Kafka connection parameters using " + configServiceURL);
			KafkaProperties kp = KafkaProperties.getInstance(configServiceURL);
			HashMap<String, String> kafkaProperties = kp.getKafkaProperties();
			if (kafkaProperties == null || kafkaProperties.isEmpty()) {
				String message = "KafkaConnectionsUtils needs to be initialized with a set of Kafka Properties.";
				logger.error(message);
				throw new Exception(message);
			}
			instance = new KafkaConnectionUtils();
			instance.kafkaProperties = kafkaProperties;
			if (!instance.validateConnectionInfo()) {
				// reset the instance
				instance = null;
				KafkaProperties.resetInstance();

				String message = "Kafka Connection Failure, brokers and or Schema Registry connection info missing or services are down.";
				logger.error(message);
				throw new Exception(message);
			}
		}
		logger.info("Kafka Connection Details: " + instance.getConnectionDetails());
		return instance;
	}

	/**
	 * Deprecated Feb 2020 / sprint 2004. Use getInstance(String configServiceURL)
	 */
	@Deprecated
	public static synchronized KafkaConnectionUtils getInstance(String configServiceURL, String tierName)
			throws Exception {
		// noop - configure your application to hit a custom Kafka cluster by setting
		// appropriate environment variables
		return getInstance(configServiceURL);
	}

	private boolean validateConnectionInfo() {
		// Broker list and schema registry are required
		// do we have the cluster broker list?
		if (!kafkaProperties.containsKey(SAS_MKT_KAFKA_CLUSTER)) {
			logger.error("Cound not find SAS_MKT_KAFKA_CLUSTER connection information");
			return false;
		}
		// do we have the schema registry connection info?
		if (!kafkaProperties.containsKey(SAS_MKT_KAFKA_SCHEMA_REGISTRY)) {
			logger.error("could not find SAS_MKT_KAFKA_SCHEMAREGISTRY connection information");
			return false;
		}
		// verify and normalize the SR information
		if (!isValidSchemaRegistry(kafkaProperties)) {
			String message = "Invalid Schema Registry Information: "
					+ kafkaProperties.get(SAS_MKT_KAFKA_SCHEMA_REGISTRY);
			logger.error(message);
			return false;
		}

		// check to see if client auth is required - Eventually we will require ACLs
		String kafkaClientAuthRequired = "false";
		if (kafkaProperties.containsKey(SAS_MKT_KAFKA_CLIENT_AUTH_REQUIRED)) {
			kafkaClientAuthRequired = kafkaProperties.get(SAS_MKT_KAFKA_CLIENT_AUTH_REQUIRED);
		}
		boolean isClientAuthRequired = Boolean.parseBoolean(kafkaClientAuthRequired);
		// we can't do client auth on a non-ssl channel
		if (isClientAuthRequired) {
			String message = "We aren't supporting client authentication yet.";
			logger.error(message);
			return false;
		}

		// All properties seem to be valid - try to open a connection:
		Properties props = getKafkaConsumerProperties();
		props.put(ConsumerConfig.GROUP_ID_CONFIG, "connection-test-group");
		props.put(ConsumerConfig.REQUEST_TIMEOUT_MS_CONFIG, 30000);

		try {
			Consumer<String, SpecificRecordBase> consumer = null;
			// the way we hijack with mocked one for test purpose
			if (mockedConsumer != null)
				consumer = mockedConsumer;
			else
				consumer = new KafkaConsumer<>(props);

			Map<String, List<PartitionInfo>> topicMap = consumer.listTopics();
			logger.info("Connected to Kafka cluster, found topics: " + topicMap.keySet());
		} catch (Exception ex) {
			logger.error("CAN NOT hit the SAS_MKT_KAFKA_CLUSTER at: " + kafkaProperties.get(SAS_MKT_KAFKA_CLUSTER));
			logger.error("Client Authentication required: " + kafkaProperties.get(SAS_MKT_KAFKA_CLIENT_AUTH_REQUIRED));
			logger.error(ex.getMessage());
			return false;
		}
		return true;
	}

	private boolean isValidSchemaRegistry(HashMap<String, String> props) {
		boolean valid = false;
		String sr = props.get(SAS_MKT_KAFKA_SCHEMA_REGISTRY);
		String[] s = sr.split(",");
		String value = "";
		for (int i = 0; i < s.length; i++) {
			if (!s[i].startsWith("http"))
				s[i] = "http://" + s[i];
			try {
				// test the connection to the schema registry
				URL url = new URL(s[i]);
				URLConnection uc = getConnection(url);
				uc.setConnectTimeout(2000);
				uc.connect();
				// only add the connection if it was valid
				value = value + s[i] + ",";
				// we've found at least one valid connection
				valid = true;
			} catch (Exception ex) {
				String message = "failed to connect to schema registry at: " + s[i];
				logger.error(message);
				logger.error(ex.getMessage());
			}
		}
		if (value.endsWith(","))
			value = value.substring(0, value.length() - 1);
		logger.info("found working schema registry(s): " + value);
		props.put(SAS_MKT_KAFKA_SCHEMA_REGISTRY, value);
		return valid;
	}

	private long getBufferMemoryConfig() {
		MemoryMXBean mbean = ManagementFactory.getMemoryMXBean();
		MemoryUsage heap = mbean.getHeapMemoryUsage();
		String s = String.format("Memory committed=%d, init=%d, max=%d, used=%d%n", heap.getCommitted(), heap.getInit(),
				heap.getMax(), heap.getUsed());
		logger.info(s);
		// we'll use 50% of the available heap for the producer's buffer (up to 200MB
		// max)
		// heap.getMax() can be undetermined in which case it will return -1
		double ab = (heap.getMax() - heap.getUsed()) * 0.50;
		double thmeg = 200.0e6;
		if (ab > thmeg)
			ab = thmeg;
		long bufferSize = 33554432L; // default value for Kafka producer buffer
		bufferSize = Math.max((long) ab, bufferSize); // don't want the buffer too small if app is temporarily spiking
														// mem
		logger.info(bufferSize / 1.0e6 + " MBytes used for Kafka Producer Buffer");
		return bufferSize;
	}

	/**
	 * Get a Properties instance with all required KafkaProducer configuration
	 * properties set.
	 * <p>
	 * This can be used to setup a KafkaProducer. Use this if you want to customize
	 * the Producer by overriding some of the default properties. For example if you
	 * want the brokers to send acks on message reception get the configured
	 * properties instance: <br/>
	 * <code>Properties props = getKafkaProducerProperties("myclientID")</code>
	 * <p>
	 * then configure the props to request acks: <br/>
	 * <code>props.put(ProducerConfig.ACKS_CONFIG, "1")</code>
	 * <p>
	 * Then create the producer with: <br/>
	 * <code>Producer<String, SpecificRecordBase> producer = new KafkaProducer<>(props);</code>
	 *
	 * @param clientID an identifier for the producer. This is just used for logging
	 *                 and metrics.
	 * @return Properties key value pairs which contain the Producer configuration
	 *         properties.
	 * @deprecated as of 2101 use getKafkaProducerProperties(String tierName, String componentName) instead
	 */
	private Properties getKafkaProducerProperties(String clientID) {

		Properties props = new Properties();
		// Mandatory fields
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.get(SAS_MKT_KAFKA_CLUSTER));
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
				org.apache.kafka.common.serialization.StringSerializer.class);
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
				io.confluent.kafka.serializers.KafkaAvroSerializer.class);
		props.put(KafkaAvroDeserializerConfig.SCHEMA_REGISTRY_URL_CONFIG,
				kafkaProperties.get(SAS_MKT_KAFKA_SCHEMA_REGISTRY));

		props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "PLAINTEXT");

		// Optional fields
		long bufferSize = getBufferMemoryConfig(); // want the producer to use as much of the heap as possible
		props.put(ProducerConfig.BUFFER_MEMORY_CONFIG, bufferSize);
		props.put(ProducerConfig.CLIENT_ID_CONFIG, clientID); // used to log logical application name vs just IP/port

		// Optimal settings based on Performance Runs:
		// http://sww.sas.com/saspedia/CI360_Kafka_Performance
		props.put("acks", "1");
//		props.put("compression.type", "lz4");
		props.put("batch.size", 65536);
		props.put("max.in.flight.requests.per.connection", 1);
		props.put("retries", 1);
		props.put("linger.ms", 40);

		// optional setting, only add if present and valid
		// otherwise kafka will provide default
		if (kafkaProperties.containsKey(SAS_MKT_KAFKA_LINGER_MS)) {
			String prop = kafkaProperties.get(SAS_MKT_KAFKA_LINGER_MS);

			if (null != prop && prop.length() > 0)
				props.put("linger.ms", prop);
		}

		if (kafkaProperties.containsKey(SAS_MKT_KAFKA_BATCH_SIZE)) {
			String prop = kafkaProperties.get(SAS_MKT_KAFKA_BATCH_SIZE);

			if (null != prop && prop.length() > 0)
				props.put("batch.size", prop);
		}

		if (kafkaProperties.containsKey(SAS_MKT_KAFKA_COMPRESSION_TYPE)) {
			String prop = kafkaProperties.get(SAS_MKT_KAFKA_COMPRESSION_TYPE);

			if (null != prop && prop.length() > 0)
				props.put("compression.type", prop);
		}

		return props;
	}
	
	/**
	 * THIS IS WHAT EVERYONE SHOULD BE USING POST 2101
	 * Supply your tierName (for example dev) and your componentName (for example mkt-kafka-tools) and this will lookup
	 * the default KafkaProducer properties then overlay the component_global and component specific properties for the tier, 
	 * in that order. 
	 * 
	 * Detailed documentation on how to use this method can be found here: 
	 * https://gitlab.sas.com/CustomerIntelligence/Shared/mkt-kafka/-/blob/staging/mkt-kafka-shared/README.md
	 * 
	 * @param tierName
	 * @param componentName
	 * @return properties used to configure a KafkaProducer
	 * @since January 2021
	 */
	public Properties getKafkaProducerProperties(String tierName, String componentName) {
		Properties props = getKafkaProducerProperties(tierName + "-" + componentName);
		// overlay tier/component specific values from the config server
		KafkaProperties kp = new KafkaProperties();
		Properties specific = kp.parseConfigServerKafkaProperties(
				KafkaConnectionUtils.CONFIG_SERVER_URL, tierName, componentName, KafkaProperties.KAFKA_PRODUCER_PROPERTIES);
		for (Object key: specific.keySet()) {
			props.put(key, specific.get(key));
		}
		return props;
	}
	
	/**
	 * THIS IS WHAT EVERYONE SHOULD BE USING POST 2101
	 * Supply your tierName (for example dev) and your componentName (for example mkt-kafka-tools) and this will lookup
	 * the default KafkaConsumer properties then overlay the component_global and component specific properties for the tier, 
	 * in that order. 
	 * 
	 * Detailed documentation on how to use this method can be found here: 
	 * https://gitlab.sas.com/CustomerIntelligence/Shared/mkt-kafka/-/blob/staging/mkt-kafka-shared/README.md
	 * 
	 * @param tierName
	 * @param componentName
	 * @return properties used to configure a KafkaConsumer
	 * @since Jan 2021
	 */
	public Properties getKafkaConsumerProperties(String tierName, String componentName) {
		Properties props = getKafkaConsumerProperties();
		props.put(ConsumerConfig.GROUP_ID_CONFIG, tierName+"-"+componentName);
		// overlay tier/component specific values from the config server
		KafkaProperties kp = new KafkaProperties();
		Properties specific = kp.parseConfigServerKafkaProperties(
				KafkaConnectionUtils.CONFIG_SERVER_URL, tierName, componentName, KafkaProperties.KAFKA_CONSUMER_PROPERTIES);
		for (Object key: specific.keySet()) {
			System.out.println("### overwriting: " + key + " with: " + specific.get(key));
			props.put(key, specific.get(key));
		}
		return props;
	}

	/**
	 * Get a Properties instance with all required KafkaConsumer configuration
	 * properties set.
	 * <p>
	 * This can be used to setup a KafkaConsumer. Use this if you want to customize
	 * the Consumer by overriding some of the default properties. For example if you
	 * want to change the auto.offset.reset from latest (the default) to earliest
	 * and we wanted to change the auto-commit rules to false we would do the
	 * following: <br/>
	 * <code>Properties props = getKafkaConsumerProperties()</code> <br/>
	 * override the default properties (note we also have to manually set the
	 * groupID): <br/>
	 * <code>props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false")</code>
	 * <code>props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest")</code>
	 * <code>props.put(ConsumerConfig.GROUP_ID_CONFIG, groupID)</code> <br/>
	 * Then create the consumer with: <br/>
	 * <code>KafkaConsumer<String, SpecificRecordBase> consumer = new KafkaConsumer<>(props)</code>
	 *
	 * @return Properties key value pairs which contain the Consumer configuration
	 *         properties.
	 * @deprecated as of 2101 use getKafkaConsumerProperties(String tierName, String componentName) instead
	 */
	private Properties getKafkaConsumerProperties() {

		Properties props = new Properties();
		// Mandatory fields
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.get(SAS_MKT_KAFKA_CLUSTER));
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
				org.apache.kafka.common.serialization.StringDeserializer.class);
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
				io.confluent.kafka.serializers.KafkaAvroDeserializer.class);
		props.put(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, true);
		props.put(KafkaAvroDeserializerConfig.SCHEMA_REGISTRY_URL_CONFIG,
				kafkaProperties.get(SAS_MKT_KAFKA_SCHEMA_REGISTRY));

		props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "PLAINTEXT");

		// Optional fields
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
		props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "1000");
		props.put(ConsumerConfig.REQUEST_TIMEOUT_MS_CONFIG, "600000");

		String auto_offset_reset = "latest";
		if (kafkaProperties.containsKey(SAS_MKT_KAFKA_AUTO_OFFSET_RESET)) {
			String prop = kafkaProperties.get(SAS_MKT_KAFKA_AUTO_OFFSET_RESET);

			if (null != prop && prop.length() > 0)
				auto_offset_reset = prop;
		}

		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, auto_offset_reset);

		// if a heartbeat isn't sent within this time the consumer will be considered
		// dead and will be removed from the group
		props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "20000");
		return props;
	}

	/**
	 * Get a Kafka Producer configured with default connection/configuration
	 * parameters.
	 *
	 * @param clientID Identifies the producer for logging and metrics purposes.
	 * @return Producer which writes messages with a String <b>key</b> and an Avro
	 *         serialized <b>value</b>.
	 * @deprecated use Properties getKafkaProducerProperties(String tierName, String componentName)
	 */
	private Producer<String, SpecificRecordBase> getKafkaProducer(String clientID) {
		Properties props = getKafkaProducerProperties(clientID);
		Producer<String, SpecificRecordBase> producer = new KafkaProducer<>(props);
		return producer;
	}

	/**
	 * @param topic   name of the topic to consume messages from
	 * @param groupID name of the consumer group this consumer will join.
	 * @return Consumer which reads messages with a String <b>key</b> and an Avro
	 *         serialized <b>value</b>
	 * @deprecated use Properties getKafkaConsumerProperties(String tierName, String componentName)
	 */
	private Consumer<String, SpecificRecordBase> getKafkaConsumer(String topic, String groupID) {
		Properties props = getKafkaConsumerProperties();
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		KafkaConsumer<String, SpecificRecordBase> consumer = new KafkaConsumer<>(props);
		consumer.subscribe(Arrays.asList(topic));
		return consumer;
	}

	/**
	 * Schedule to retrieve the consumer group metrics and upload to AWS Cloudwatch
	 *
	 * @param consumer the Kafka Consumer object
	 * @param groupID  the name of the consumer group this consumer has joined. It
	 *                 is used as metric dimension value
	 * @param delayInS initial delay (in seconds) after timer starts
	 * @param timerInS interval of metric collection (in seconds)
	 * @return the Timer object
	 */
	@SuppressWarnings("rawtypes")
	public static Timer scheduleMetricsTimer(Consumer consumer, String groupID, int delayInS, int timerInS) {
		return scheduleMetricsTimer(consumer, "ConsumerGroup", groupID, delayInS, timerInS);
	}

	/**
	 * Schedule to retrieve the consumer group metrics and upload to AWS Cloudwatch
	 *
	 * @param consumer       the Kafka Consumer object
	 * @param dimensionName  metric dimension name
	 * @param dimensionValue metric dimension value
	 * @param delayInS       initial delay (in seconds) after timer starts
	 * @param timerInS       interval of metric collection (in seconds)
	 * @return the Timer object
	 */
	@SuppressWarnings("rawtypes")
	public static Timer scheduleMetricsTimer(Consumer consumer, String dimensionName, String dimensionValue,
			int delayInS, int timerInS) {
		if (delayInS < 0 || timerInS <= 0) {
			logger.error("Invalid parameter when starting Kafka metrics timer");
			return null;
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Scheduling Metrics Timer...");
			logger.debug("Delay " + delayInS + " seconds. Timer interval: " + timerInS + " seconds.");
		}
		ConsumerMetricsTimerTask task = new ConsumerMetricsTimerTask(consumer, dimensionName, dimensionValue);
		Timer timer = new Timer();

		timer.scheduleAtFixedRate(task, 1000 * delayInS, 1000 * timerInS);
		return timer;
	}

	/**
	 * Schedule to retrieve the producer metrics and upload to AWS Cloudwatch
	 *
	 * @param producer       the Producer object
	 * @param dimensionName  metric dimension name
	 * @param dimensionValue metric dimension value
	 * @param delayInS       initial delay (in seconds) after timer starts
	 * @param timerInS       interval of metric collection (in seconds)
	 * @return the Timer object
	 */
	@SuppressWarnings("rawtypes")
	public static Timer scheduleMetricsTimer(Producer producer, String dimensionValue, int delayInS, int timerInS) {
		if (delayInS < 0 || timerInS <= 0) {
			logger.error("Invalid parameter when starting Kafka metrics timer");
			return null;
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Scheduling Metrics Timer...");
			logger.debug("Delay " + delayInS + " seconds. Timer interval: " + timerInS + " seconds.");
		}
		ProducerMetricsTimerTask task = new ProducerMetricsTimerTask(producer, "Producer", dimensionValue);
		Timer timer = new Timer();

		timer.scheduleAtFixedRate(task, 1000 * delayInS, 1000 * timerInS);
		return timer;
	}

	/**
	 * Get the Properties required to configure a KafkaStreams instance.
	 *
	 * @param applicationID name of the (potentially distributed) application this
	 *                      KafkaStreams will join
	 * @return Properties used to configure a
	 *         <code>org.apache.kafka.streams.KafkaStreams</code>
	 * @deprecated
	 */
	private Properties getKafkaStreamsProperties(String applicationID) {
		Properties props = new Properties();
		props.put(StreamsConfig.APPLICATION_ID_CONFIG, applicationID);
		props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.get(SAS_MKT_KAFKA_CLUSTER));
		props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
		props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
		return props;
	}
	
	/**
	 * THIS IS WHAT EVERYONE SHOULD BE USING POST 2101
	 * Supply your tierName (for example dev) and your componentName (for example mkt-kafka-tools) and this will lookup
	 * the default Cluster Bootstrap Servers Config property then overlay the component_global and component specific property for the server list;
	 * for the tier, in that order. 
	 * 
	 * Detailed documentation on how to use this method can be found here: 
	 * https://gitlab.sas.com/CustomerIntelligence/Shared/mkt-kafka/-/blob/staging/mkt-kafka-shared/README.md
	 * StreamsConfig.APPLICATION_ID_CONFIG
	 * StreamsConfig.BOOTSTRAP_SERVERS_CONFIG
	 * StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG
	 * StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG
	 * @param tierName
	 * @param componentName
	 * @return properties used to configure the Kafka Cluster URL dynamically and base properties for streams including:
	 * 
	 * @since March 2021
	 */
	public Properties getKafkaStreamsProperties(String tierName, String componentName) {
		Properties cluster = getKafkaProducerProperties(tierName, componentName);
		Properties props = new Properties();
		props.put(StreamsConfig.APPLICATION_ID_CONFIG, tierName + "-" + componentName);
		props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
		props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
		String clusterUrl = cluster.getProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG);
		props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, clusterUrl);
		return props;
	}

}
