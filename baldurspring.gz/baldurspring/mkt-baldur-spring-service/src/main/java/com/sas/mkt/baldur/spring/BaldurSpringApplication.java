package com.sas.mkt.baldur.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.ryantenney.metrics.spring.config.annotation.EnableMetrics;
import com.sas.mkt.baldur.spring.utils.PreContextLoadedConfiguration;

@SpringBootApplication
@EnableMetrics
@ComponentScan({ "com.sas.mkt.baldur.*", "com.sas.mkt.config.*" })
public class BaldurSpringApplication {
	public static void main(String[] args) throws Throwable {
		SpringApplication application = new SpringApplication(BaldurSpringApplication.class);
		application.addListeners(new PreContextLoadedConfiguration());
		application.run(args);
	}
}
