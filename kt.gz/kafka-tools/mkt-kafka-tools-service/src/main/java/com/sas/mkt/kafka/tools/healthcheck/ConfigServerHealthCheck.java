package com.sas.mkt.kafka.tools.healthcheck;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.codahale.metrics.health.HealthCheck;
import com.sas.mkt.config.core.configserver.ConfigServerClient;

/**
 * Check Redis
 * 
 * @author razing
 */
@Configuration
public class ConfigServerHealthCheck extends HealthCheck {
	
	@Autowired
	ConfigServerClient client;

	@Override
	protected Result check() throws Exception {
		if (client != null && client.isHealthy()) {
			return Result.healthy("ConfigurationServer Connection is Healthy.");
		}
		return Result.unhealthy("Failed to Connect to ConfigurationServer.");	
	}

}