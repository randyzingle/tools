package com.sas.mkt.kafka.clients.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.util.*;

import com.sas.mkt.kafka.domain.common.*;
import com.sas.mkt.kafka.domain.internal.events.*;
import com.sas.mkt.kafka.domain.system.KeyValueDataProviderRepObject;
import com.sas.mkt.kafka.domain.system.StoredProcessDataRequestResponse;
import org.apache.avro.Schema;
import org.apache.avro.Schema.Field;
import org.apache.avro.specific.SpecificData;
import org.apache.avro.specific.SpecificRecord;
import org.junit.Test;

import com.sas.mkt.kafka.domain.events.EnhancedEvent;

public class TestSerde {

	public static void main(String[] args) {
		TestSerde ts = new TestSerde();
		ts.testDeSerialization();
	}

	public EnhancedEvent buildEnhancedEvent() {
		Number number;
		EnhancedEvent enhanceEvt = EnhancedEvent.newBuilder().build();

		enhanceEvt.setEventDesignedId("eventDesignedId");
		enhanceEvt.setIdentityId("identityId");
		enhanceEvt.setIpAddress("eventIpAddress");
		enhanceEvt.setEventType("eventType");
		enhanceEvt.setCustomGroupName("testGroupName");

		// make sure internalSearch builds with all default types
		InternalSearch.newBuilder().build();

//		number = 9999999999.111111111111D;
//		try {
//			ByteBuffer buffer = ByteBuffer.wrap(ByteBuffer.allocate(8).putDouble(number.doubleValue()).array());
//			enhanceEvt.setCustomRevenueDeprecated(buffer);
//
//		} catch (Exception e) {
//			System.out.println("Failed to convert " + number + " to ByteBuffer");
//		}

		Field f;
		ByteBuffer bb;
		//BigDecimal bd;

		// enhanced
//		f = EnhancedEvent.getClassSchema().getField("customRevenueDeprecated");
//		LogicalTypesUtil lt = LogicalTypesUtil.getInstance();
//		bb = lt.getByteBufferFromDecimal(number.toString(), f);
		//enhanceEvt.setCustomRevenueDeprecated(bb);

		App app = enhanceEvt.getApp();

		if (null == app) {
			app = App.newBuilder().build();
			enhanceEvt.setApp(app);
		}

		app.setAppLanguage("language");

		DateTime dt = enhanceEvt.getDate();

		if (null == dt) {
			dt = DateTime.newBuilder().build();
			enhanceEvt.setDate(dt);
		}

		Long now = System.currentTimeMillis();
		dt.setGeneratedTimestamp(now);
		dt.setReceivedTimestamp(now);
		dt.setSentTimestamp(now);
		// dt.setTimezone("EST");
		dt.setUtcOffset(4);

		Location loc = enhanceEvt.getIpInfo();

		if (null == loc) {
			loc = new Location();
			enhanceEvt.setIpInfo(loc);
		}

		loc.setCity("testCityName");
		loc.setCountry("testCountryName");
		loc.setRegion("testCountryRegion");

		Browser b = enhanceEvt.getBrowser();
		if (null == b) {
			b = new Browser();
			enhanceEvt.setBrowser(b);
		}

		b.setUserAgent("testUserAgent");
		b.setName("browserName");
		b.setBrowserLanguage("browserLanguage");
		b.setBrowserVersion("browserVersion");

		DeviceInfo di = enhanceEvt.getDeviceInfo();

		if (null == di) {
			di = new DeviceInfo();
			enhanceEvt.setDeviceInfo(di);
		}

		di.setDeviceType("deviceInfoType");
		di.setPlatform("deviceInfoPlatform");
		di.setDeviceLanguage("language");

		Identity id = enhanceEvt.getIdentity();

		if (null == id) {
			id = Identity.newBuilder().build();
			enhanceEvt.setIdentity(id);
		}

		id.setIdentityEventName("identityEventName");

		Visit v = enhanceEvt.getVisit();

		if (null == v) {
			v = new Visit();
			enhanceEvt.setVisit(v);
		}

		v.setVisitorState("testVisitorState");

		// to be deprecated in 1801
		// v.setReturningVisitorFlag(true);

		URI vUri = v.getReferrer();

		if (null == vUri) {
			vUri = URI.newBuilder().build();
			v.setReferrer(vUri);
		}

		vUri.setUri("visitReferrerUri");

		Page p = enhanceEvt.getPage();

		if (null == p) {
			p = new Page();
			enhanceEvt.setPage(p);
		}

		// to be deprecated in 1801
		// p.setPageLoadTimestamp(System.currentTimeMillis());

		p.setPageId("pageId");
		p.setPageLanguage("language");

		URI uri = p.getReferrerUri();

		if (null == uri) {
			uri = new URI();
			p.setReferrerUri(uri);
		}

		uri.setUri("pageReferrerUri");
		
		Media m = enhanceEvt.getMedia();
		
		if(null == m)
		{
			m = new Media();
			enhanceEvt.setMedia(m);
		}

		Product prod = enhanceEvt.getProduct();

		if (null == prod) {
			prod = Product.newBuilder().build();
			enhanceEvt.setProduct(prod);
		}

//		number = 1001.43D;
//		try {
//			ByteBuffer buffer = ByteBuffer.wrap(ByteBuffer.allocate(8).putDouble(number.doubleValue()).array());
//			prod.setUnitPriceDeprecated(buffer);
//
//		} catch (Exception e) {
//			System.out.println("Failed to convert " + number + " to ByteBuffer");
//		}

		Session session = Session.newBuilder().build();

		enhanceEvt.setSession(session);
		session.setPreviousSessionId("previousId");
		
		
		Journey journey = Journey.newBuilder().build();
		journey.setErrorTimestamp(System.currentTimeMillis());
		enhanceEvt.setJourney(journey);

		Map<String, String> initialProperties = enhanceEvt.getProperties();

		if (null == initialProperties) {
			initialProperties = new HashMap<String, String>();
			enhanceEvt.setProperties(initialProperties);
		}

		initialProperties.put("event", "testEventType");
		initialProperties.put("referrer.social", "testRefferrerSocial");
		initialProperties.put("referrer.search", "testRefferrerSeach");

		initialProperties.put("login_event_type", "testLogonEventType");
		initialProperties.put("login_event", "testLogonEventType");

		initialProperties.put("geo.test.underscore", "testGeoUnderscore");

		return enhanceEvt;
	}

	private void writeString(String string, String file) {
		try {
			FileWriter writer = new FileWriter(file, false);
			BufferedWriter bufferedWriter = new BufferedWriter(writer);

			bufferedWriter.write(string);
			bufferedWriter.close();
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

//	public void serializeEnhancedEvent(EnhancedEvent ee, String folder, String version) {
//
//		if(null == ee)
//			ee = buildEnhancedEvent();
//
//		serializeSpecificEvent(ee, ee.getSchema(), folder + "enhanced.schema." + version, folder + "enhanced." + version);
//	}

	public void serializeEvent(String folder, String name, String version, Schema schema, SpecificRecord event) {

		serializeSpecificEvent(event, schema, folder + name + ".schema." + version, folder + name + "." + version);
	}

	private void serializeSpecificEvent(SpecificRecord sr, Schema schema, String schemaName, String eventName)
	{
		try {
			SpecificDataSerDe sdsd = new SpecificDataSerDe();

			writeString(schema.toString(), schemaName);

			byte[] bytes = sdsd.serializeSpecificData(sr, schema);

			FileOutputStream fos = new FileOutputStream(eventName);
			fos.write(bytes);
			fos.close();

		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	/*
	* Test case demonstrating the order of map keys can change during serialization / deserialization
	* List of reps should maintain order
	* Test can be disabled if problematic
	* Or improved to further validate the needs for StoredProcessDataRequestResponse
	* */
	@Test
	public void testOrderedList()
	{
		StoredProcessDataRequestResponse storedProcessDataRequestResponse = StoredProcessDataRequestResponse.newBuilder().build();

		Map<String, String> stringMap = new LinkedHashMap<>();

		stringMap.put("100", "OneHundred");
		stringMap.put("200", "TwoHundred");
		stringMap.put("300", "ThreeHundred");
		stringMap.put("400", "FourHundred");
		stringMap.put("500", "FiveHundred");
		stringMap.put("600", "SixHundred");
		stringMap.put("700", "700Hundred");
		stringMap.put("800", "800Hundred");
		stringMap.put("900", "NineHundred");
		stringMap.put("1000", "TenHundred");

		List<KeyValueDataProviderRepObject> repObjects = new ArrayList<>();
		for(Map.Entry<String, String> entry:stringMap.entrySet())
		{
			KeyValueDataProviderRepObject repObject = KeyValueDataProviderRepObject.newBuilder().setKey(entry.getKey()).setValue(entry.getValue()).build();

			repObjects.add(repObject);
		}

		storedProcessDataRequestResponse.setKeyValueDataProviderRepList(repObjects);

		storedProcessDataRequestResponse.setKeyValueDataProviderRep(stringMap);

		try {
			SpecificDataSerDe sdsd = new SpecificDataSerDe();
			byte[] bytes = sdsd.serializeSpecificData(storedProcessDataRequestResponse, StoredProcessDataRequestResponse.getClassSchema());

			StoredProcessDataRequestResponse storedProcessDataRequestResponse2 = sdsd.deserializeSpecificData(bytes, StoredProcessDataRequestResponse.class, StoredProcessDataRequestResponse.getClassSchema());

			//this will show that the order has changed for the map since we are not deserialized as a LinkedHashMap
			//but should not have changed for the list of KeyValueDataProviderRepObject
			//no assertion to show the change in order but can use the debugger
			assertNotNull(storedProcessDataRequestResponse2);

			List<KeyValueDataProviderRepObject> deserializedRepObjects = storedProcessDataRequestResponse2.getKeyValueDataProviderRepList();
			assertNotNull(deserializedRepObjects);
			assertEquals(stringMap.size(), deserializedRepObjects.size());

			int index = 0;

			for(Map.Entry<String, String> entry:stringMap.entrySet())
			{
				//should be in the order they went in so validate the indexes match
				assertEquals(entry.getKey(), deserializedRepObjects.get(index).getKey());
				index++;

			}

		}
		catch (Exception ex)
		{
			fail(ex.getMessage());
		}
	}

	@Test
	public void testIASetSVSerialization()
	{
		Map<String, String> eventVars = new HashMap<>();
		Map<String, String> tags = new HashMap<String, String>();
		List<IASetSVTagUpdates> tagUpdatesList = new ArrayList<IASetSVTagUpdates>();

		tags.put("event", "expressionId");
		//tags = IAUtil.removeNullValues(tags);
		//tags = IAUtil.normalizeKeysAndValues(tags);

		IASetSVTagUpdates iaSetSVTagUpdates = IASetSVTagUpdates.newBuilder().setAction(IASetSVActions.add).setTagValues(tags).build();

		tagUpdatesList.add(iaSetSVTagUpdates);

		eventVars.put("key", "value");
		eventVars.put("keyNullValue", null);
		//eventVars.put(null, "test");

		TriggerContext context = new TriggerContext();
		context.setTaskId("taskId");
		context.setTaskType("executionContext");
		context.setEventVars(eventVars);

		IASetSV avroEvent = IASetSV.newBuilder().setIdentityId("identityId").setTriggerContext(context).setInternalTenantId(1001).setTtl(900).setTagUpdates(tagUpdatesList).build();

		try {
			SpecificDataSerDe sdsd = new SpecificDataSerDe();
			byte[] bytes = sdsd.serializeSpecificData(avroEvent, IASetSV.getClassSchema());
		}
		catch (Exception ex)
		{
			fail(ex.getMessage());
		}
	}

	@Test
	public void testNewerIASetSVSchemaDeserializedToOlder()
	{

		// Steps
		// Make your schema changes and build from command line
		// Create an object using that schema, reference the new fields and save the event and schema
		// Stash your schema changes and rebuild so you have the older schema again
		// Deserialize the newer object to the older schema to validate changes are compatible
		// Can also do the same with saving events from current schema then updating schema
		// and deserializing against that to ensure compatibility


		SpecificDataSerDe sdsd = new SpecificDataSerDe();

		IASetSV sv;

//		try {
//
//			Map<String,String> tagValues = new HashMap<>();
//			tagValues.put("key", "value");
//			List<IASetSVTagUpdates> tagUpdatesList = new ArrayList<>();
//			IASetSVTagUpdates tagUpdates = IASetSVTagUpdates.newBuilder().setSuperTag("test").setAction(IASetSVActions.add).setTagValues(tagValues).build();
//			tagUpdatesList.add(tagUpdates);
//
//			sv = IASetSV.newBuilder().setTagUpdates(tagUpdatesList).build();
//			sv.setGuid("test-guid");
//
//			Trace trace = Trace.newBuilder().build();
//			sv.setTrace(trace);
//
//			TracePoint tp = TracePoint.newBuilder().build();
//			tp.setTracePointIpAddress("testIp");
//			tp.setTracePointTimestamp(System.currentTimeMillis());
//			List<TracePoint> tps = new ArrayList<>();
//			tps.add(tp);
//
//			trace.setTraceId("trace-Id");
//			trace.setTracePoints(tps);
//
//			List<String> contributingGuids = new ArrayList<>();
//			contributingGuids.add("contributing-guid-1");
//
//			trace.setContributingEventGuids(contributingGuids);
//
//			sv.setIdentityId("Identity-Id-1");
//			sv.setEventTimestamp(System.currentTimeMillis());
//
//			Map<String, String> eventVars = new HashMap<>();
//			Map<String, String> tags = new HashMap<String, String>();
//
//			tags.put("event", "expressionId");
//			//tags = IAUtil.removeNullValues(tags);
//			//tags = IAUtil.normalizeKeysAndValues(tags);
//
//			IASetSVTagUpdates iaSetSVTagUpdates = IASetSVTagUpdates.newBuilder().setAction(IASetSVActions.add).setTagValues(tags).build();
//
//			tagUpdatesList.add(iaSetSVTagUpdates);
//
//			eventVars.put("key", "value");
//			eventVars.put("keyNullValue", null);
//			//eventVars.put(null, "test");
//
//			TriggerContext context = new TriggerContext();
//			context.setTaskId("taskId");
//			context.setTaskType("executionContext");
//			context.setEventVars(eventVars);
//
//
//			List<TriggerContext> triggerContextList = new ArrayList<>();
//			triggerContextList.add(context);
//
//			context = new TriggerContext();
//			context.setTaskId("taskId2");
//			context.setTaskType("executionContext2");
//			context.setEventVars(eventVars);
//			triggerContextList.add(context);
//
//			sv.setTriggerContextList(triggerContextList);
//
//			List<String> eventList = new ArrayList<>();
//			eventList.add("test1");
//			eventList.add("test2");
//			sv.setAppendEventList(eventList);
//
//			List<ImpressionCount> impressionCounts = new ArrayList<>();
//
//			ImpressionCount ic = ImpressionCount.newBuilder().setCreativeId("creative1").setTaskId("taskId1").setVariantId("variant1").build();
//			impressionCounts.add(ic);
//
//			ic = ImpressionCount.newBuilder().setCreativeId("creative2").setTaskId("taskId2").setVariantId("variant2").build();
//			impressionCounts.add(ic);
//
//			sv.setImpressionCountList(impressionCounts);
//
//			serializeEvent("e:\\temp\\", "iasetsv", "2106", sv.getSchema(), sv);
//		}
//		catch (Exception ex)
//		{
//			fail(ex.getMessage());
//		}

		try {

			InputStream is;
			byte[] data;
			Schema schema;
			Schema.Parser parser;

			parser = new Schema.Parser();

			is = TestSerde.class.getClassLoader().getResourceAsStream("iasetsv.2106");
			data = readBytesFromInputStream(is);
			is.close();

			is = TestSerde.class.getClassLoader().getResourceAsStream("iasetsv.schema.2106");
			schema = parser.parse(is);
			is.close();

			sv = sdsd.deserializeSpecificData(data, IASetSV.class, schema, IASetSV.getClassSchema());

			assertNotNull(sv);

			//sv.setIdentityId("Identity-Id-1");
			assertEquals("Identity-Id-1", sv.getIdentityId());
//			sv.setEventTimestamp(System.currentTimeMillis());
			assertTrue(sv.getEventTimestamp() > 0);

			assertEquals("test-guid", sv.getGuid());

			Trace trace = sv.getTrace();
			assertNotNull(trace);

			List<String> contributing = trace.getContributingEventGuids();

			assertEquals(1, contributing.size());
			assertEquals("contributing-guid-1", contributing.get(0));

		} catch (Exception e) {
			fail(e.getMessage());
		}

	}


	@Test
	public void testNewerEnhancedSchemaDeserializedToOlder()
	{
		// Steps
		// Make your schema changes and build from command line
		// Create an object using that schema, reference the new fields and save the event and schema
		// Stash your schema changes and rebuild so you have the older schema again
		// Deserialize the newer object to the older schema to validate changes are compatible
		// Can also do the same with saving events from current schema then updating schema
		// and deserializing against that to ensure compatibility

		SpecificDataSerDe sdsd = new SpecificDataSerDe();

		EnhancedEvent ee;

//		ee = buildEnhancedEvent();
//
//		ee.setGuid("test-guid");
//
//		Email email =  ee.getEmail();
//
//		if(null == email)
//		{
//			email = Email.newBuilder().build();
//			ee.setEmail(email);
//		}
//
//		email.setReason("TestReason");
//
//		//serializeEnhancedEvent("e:\\temp\\", "v2102");
//		serializeEvent("e:\\temp\\", "enhancedEvent", "2103", ee.getSchema(), ee);

		try {
			InputStream is;
			byte[] data;
			//Schema schemaOlder;
			Schema schema;
			Schema.Parser parser;

			parser = new Schema.Parser();


//			is = TestSerde.class.getClassLoader().getResourceAsStream("enhanced.schema.v1805_preUpdate");
//			schemaOlder = parser.parse(is);
//			is.close();

			is = TestSerde.class.getClassLoader().getResourceAsStream("enhancedEvent.2103");
			data = readBytesFromInputStream(is);
			is.close();

			is = TestSerde.class.getClassLoader().getResourceAsStream("enhancedEvent.schema.2103");
			schema = parser.parse(is);
			is.close();

			ee = sdsd.deserializeSpecificData(data, EnhancedEvent.class, schema, EnhancedEvent.getClassSchema());

			assertNotNull(ee);
			assertEquals("test-guid", ee.getGuid());

			Email email = ee.getEmail();
			assertNotNull(email);

			assertEquals("TestReason", email.getReason());

		} catch (IOException e) {
			fail(e.getMessage());
		}

	}

	@Test
	public void testDeSerialization() {

		// uncomment when we need to generate a new event / schema
		//serializeEnhancedEvent("e:\\temp\\", "v1805");

		// test building
		buildEnhancedEvent();
		SpecificDataSerDe sdsd = new SpecificDataSerDe();

		try {

			EnhancedEvent ee;
			InputStream is;
			byte[] data;
			Schema schema;
			Schema.Parser parser;

			parser = new Schema.Parser();
			is = TestSerde.class.getClassLoader().getResourceAsStream("enhanced.schema.v1805_preUpdate");
			schema = parser.parse(is);
			is.close();

			is = TestSerde.class.getClassLoader().getResourceAsStream("enhanced.v1805_preUpdate");
			data = readBytesFromInputStream(is);
			is.close();

			ee = sdsd.deserializeSpecificData(data, EnhancedEvent.class, schema, EnhancedEvent.getClassSchema());
			validateEnhancedEvent(ee, 1805);
			
			parser = new Schema.Parser();
			is = TestSerde.class.getClassLoader().getResourceAsStream("enhanced.schema.v1801_preUpdate");
			schema = parser.parse(is);
			is.close();

			is = TestSerde.class.getClassLoader().getResourceAsStream("enhanced.v1801_preUpdate");
			data = readBytesFromInputStream(is);
			is.close();

			ee = sdsd.deserializeSpecificData(data, EnhancedEvent.class, schema, EnhancedEvent.getClassSchema());
			validateEnhancedEvent(ee, 1801);

			parser = new Schema.Parser();
			is = TestSerde.class.getClassLoader().getResourceAsStream("enhanced.schema.v1713_preUpdate");
			schema = parser.parse(is);
			is.close();

			is = TestSerde.class.getClassLoader().getResourceAsStream("enhanced.v1713_preUpdate");
			data = readBytesFromInputStream(is);
			is.close();

			// ee = sdsd.deserializeSpecificData(data, EnhancedEvent.class, schema,
			// EnhancedEvent.getClassSchema());
			// validateEnhancedEvent(ee, 1714);

			parser = new Schema.Parser();
			is = TestSerde.class.getClassLoader().getResourceAsStream("enhanced.schema.v1713");
			schema = parser.parse(is);
			is.close();

			is = TestSerde.class.getClassLoader().getResourceAsStream("enhanced.v1713");
			data = readBytesFromInputStream(is);
			is.close();

			// ee = sdsd.deserializeSpecificData(data, EnhancedEvent.class, schema,
			// EnhancedEvent.getClassSchema());
			// validateEnhancedEvent(ee, 1713);

			parser = new Schema.Parser();
			is = TestSerde.class.getClassLoader().getResourceAsStream("enhanced.schema.v1712");
			// is = TestSerde.class.getResourceAsStream("./enhanced.schema.v1712");
			schema = parser.parse(is);
			is.close();

			is = TestSerde.class.getClassLoader().getResourceAsStream("enhanced.v1712");
			// is = TestSerde.class.getResourceAsStream("./enhanced.v1712");
			data = readBytesFromInputStream(is);
			is.close();

			// ee = sdsd.deserializeSpecificData(data, EnhancedEvent.class, schema,
			// EnhancedEvent.getClassSchema());
			// validateEnhancedEvent(ee, 1712);

			parser = new Schema.Parser();
			is = TestSerde.class.getClassLoader().getResourceAsStream("enhanced.schema.v1711");
			schema = parser.parse(is);
			is.close();

			is = TestSerde.class.getClassLoader().getResourceAsStream("enhanced.v1711");
			data = readBytesFromInputStream(is);
			is.close();

			// ee = sdsd.deserializeSpecificData(data, EnhancedEvent.class, schema,
			// EnhancedEvent.getClassSchema());
			// validateEnhancedEvent(ee, 1711);

			parser = new Schema.Parser();
			is = TestSerde.class.getClassLoader().getResourceAsStream("enhanced.schema.v1710");
			schema = parser.parse(is);
			is.close();

			is = TestSerde.class.getClassLoader().getResourceAsStream("enhanced.v1710");
			data = readBytesFromInputStream(is);
			is.close();

			// ee = sdsd.deserializeSpecificData(data, EnhancedEvent.class, schema,
			// EnhancedEvent.getClassSchema());
			// validateEnhancedEvent(ee, 1710);

		} catch (IOException e) {
			fail(e.getMessage());
		}
	}

	private void validateEnhancedEvent(EnhancedEvent ee, int level) {
		assertNotNull(ee);

		assertEquals("eventDesignedId", ee.getEventDesignedId());
		assertEquals("identityId", ee.getIdentityId());
		assertEquals("eventIpAddress", ee.getIpAddress());
		assertEquals("eventType", ee.getEventType());

		App app = ee.getApp();

		assertNotNull(app);

		assertEquals("language", app.getAppLanguage());

		DateTime dt = ee.getDate();
		assertNotNull(dt);
		assertTrue(0 < dt.getGeneratedTimestamp());
		assertTrue(0 < dt.getReceivedTimestamp());
		assertTrue(0 < dt.getSentTimestamp());

		Location loc = ee.getIpInfo();

		assertNotNull(loc);

		assertEquals("testCityName", loc.getCity());
		assertEquals("testCountryName", loc.getCountry());
		assertEquals("testCountryRegion", loc.getRegion());

		loc.setCity("testCityName");
		loc.setCountry("testCountryName");
		loc.setCountry("testCountryRegion");

		Browser b = ee.getBrowser();
		assertNotNull(b);

		assertEquals("testUserAgent", b.getUserAgent());
		assertEquals("browserName", b.getName());
		assertEquals("browserLanguage", b.getBrowserLanguage());

		DeviceInfo di = ee.getDeviceInfo();

		assertNotNull(di);

		assertEquals("deviceInfoType", di.getDeviceType());
		assertEquals("deviceInfoPlatform", di.getPlatform());
		assertEquals("language", di.getDeviceLanguage());

		Identity id = ee.getIdentity();

		assertNotNull(id);

		assertEquals("identityEventName", id.getIdentityEventName());

		Visit v = ee.getVisit();

		assertNotNull(id);

		assertEquals("testVisitorState", v.getVisitorState());

		URI vUri = v.getReferrer();

		assertNotNull(vUri);

		assertEquals("visitReferrerUri", vUri.getUri());

		Page p = ee.getPage();

		assertNotNull(p);

		assertEquals("pageId", p.getPageId());
		assertEquals("language", p.getPageLanguage());

		URI uri = p.getReferrerUri();

		assertNotNull(uri);

		assertEquals("pageReferrerUri", uri.getUri());

		Map<String, String> initialProperties = ee.getProperties();

		assertNotNull(initialProperties);

		assertEquals("testEventType", initialProperties.get("event"));
		assertEquals("testRefferrerSocial", initialProperties.get("referrer.social"));
		assertEquals("testRefferrerSeach", initialProperties.get("referrer.search"));

		assertEquals("testLogonEventType", initialProperties.get("login_event_type"));
		assertEquals("testLogonEventType", initialProperties.get("login_event"));

		assertEquals("testGeoUnderscore", initialProperties.get("geo.test.underscore"));

//		if (level > 1712) {
//			LogicalTypesUtil lt = LogicalTypesUtil.getInstance();
//			Field f;
//			BigDecimal bd;
//
//			Product prod = ee.getProduct();
//
//			Double number = 1001.43D;
//			Double unitP = prod.getUnitPriceDeprecated().getDouble(0);
//
//			// f = Product.getClassSchema().getField("unitPrice");
//			// bd = lt.getDecimalFromByteBuffer(prod.getUnitPrice(), f);
//			// Double unitP = bd.doubleValue();
//			assertEquals(number, unitP);
//
//			number = 9999999999.11D;
//			// Double rev = ee.getRevenue().getDouble(0);
//
//			f = EnhancedEvent.getClassSchema().getField("customRevenueDeprecated");
//			bd = lt.getDecimalFromByteBuffer(ee.getCustomRevenueDeprecated(), f);
//			Double rev = bd.doubleValue();
//			assertEquals(number, rev);
//
//			// validate we can read it more than once.
//			// bd = lt.getDecimalFromByteBuffer(ee.getCustomRevenueDeprecated(), f);
//			// rev = bd.doubleValue();
//			// assertEquals(number, rev);
//
//		}

		if (level > 1713) {
			assertEquals("testGroupName", ee.getCustomGroupName());
			assertEquals("deviceInfoType", di.getDeviceType());

			assertEquals("browserLanguage", b.getBrowserLanguage());
			assertEquals("browserVersion", b.getBrowserVersion());
		}

		if (level >= 1801) {
			assertNotNull(ee.getSession());
			assertEquals("previousId", ee.getSession().getPreviousSessionId());
		}
		
		if(level >= 1805)
		{
			Journey journey = ee.getJourney();
			
			assertNotNull(journey);
			assertNotNull(journey.getErrorTimestamp());
		}

	}

	private byte[] readBytesFromInputStream(InputStream is) {
		try {
			ByteArrayOutputStream buffer = new ByteArrayOutputStream();

			int nRead;
			byte[] data = new byte[16384];

			while ((nRead = is.read(data, 0, data.length)) != -1) {
				buffer.write(data, 0, nRead);
			}

			buffer.flush();

			byte[] allData = buffer.toByteArray();

			is.close();

			return allData;

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}

		return null;
	}

}
