package com.sas.mkt.baldur.spring.metrics;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.metrics.MeterRegistryCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sas.mkt.baldur.spring.utils.PreContextLoadedConfiguration;

import io.micrometer.cloudwatch2.CloudWatchConfig;
import io.micrometer.cloudwatch2.CloudWatchMeterRegistry;
import io.micrometer.core.instrument.Clock;
import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.Meter.Id;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.config.MeterFilter;
import io.micrometer.prometheus.PrometheusConfig;
import io.micrometer.prometheus.PrometheusMeterRegistry;
import io.micrometer.statsd.StatsdConfig;
import io.micrometer.statsd.StatsdFlavor;
import io.micrometer.statsd.StatsdMeterRegistry;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.cloudwatch.CloudWatchAsyncClient;

@Component
public class MetricRegistryConfiguration {

	private final static Logger logger = LoggerFactory.getLogger(MetricRegistryConfiguration.class);
	
	// metric exporters
	public static final String StatsdMeterRegistry = "StatsdMeterRegistry";
	public static final String JmxMeterRegistry = "JmxMeterRegistry";
	public static final String PrometheusMeterRegistry = "PrometheusMeterRegistry";
	public static final String CloudWatchMeterRegistry = "CloudWatchMeterRegistry";
	
	private final long CLOUDWATCH_STEP_SIZE_SECS = 60l; // broadcast stats to CW every 60 secs

	@Autowired
	PreContextLoadedConfiguration pclc;
	
	private boolean isRegistryEnabled(RegistryConfig rc) {
		if (rc != null && rc.enabled != null && rc.enabled.equals("true")) return true;
		return false;
	}
	
	private void setupFilters(RegistryConfig rc, final MeterRegistry registry) {
		if (rc !=null && rc.filters != null) {
			List<RegistryFilter> filters = rc.filters;
			for (RegistryFilter filter : filters) {
				registry.config().meterFilter(MeterFilter.accept(new BooleanTagFilter(filter.name)));
			}
		}
		registry.config().meterFilter(MeterFilter.deny()); // deny any not specifically added
	}

	
	@Bean(name="metricConfigMap")
	Map<String, RegistryConfig> getMap() throws JsonMappingException, JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		
		Map<String, RegistryConfig> testmap = mapper.readValue(PreContextLoadedConfiguration.METRIC_CONFIG,
				new TypeReference<Map<String, RegistryConfig>>() {});
		String mcs = mapper.writeValueAsString(testmap);
		System.out.println(mcs);
		return testmap;
	}

	@Bean
	MeterRegistryCustomizer<MeterRegistry> configureComposite() {
		return registry -> {
			logger.info("configuring: {}", registry.getClass());
			List<Tag> tags = new ArrayList<>();			
			// Pass in your TierName and ComponentName using whatever mechanism you use to determine them
			// ... you can use the following if you're using the PreContextLoadedConfiguration.java class.
			tags.add(Tag.of("service", PreContextLoadedConfiguration.COMPONENT));
			tags.add(Tag.of("region", PreContextLoadedConfiguration.REGION));
			tags.add(Tag.of("env", PreContextLoadedConfiguration.TIER));
			registry.config().commonTags(tags);
			// add your island prefix to all your meter names, should be in application.properties: application.island=do
			registry.config().meterFilter(new IslandNaming());
		};
	}
	
	private class IslandNaming implements MeterFilter {
		@Override
		public Meter.Id map(Meter.Id id) {
			return id.withName(PreContextLoadedConfiguration.ISLAND_PREFIX + "." + id.getName());
		}
	}

//	@Bean
//	@DependsOn({"metricConfigMap"})
//	JmxMeterRegistry jmxMeterRegistry(Map<String, RegistryConfig> metricConfigMap) {
//		RegistryConfig rc = metricConfigMap.get(JmxMeterRegistry);
//		boolean enabled = isRegistryEnabled(rc);
//		JmxConfig config = new JmxConfig() {
//			@Override
//			public String get(String key) {
//				return null;
//			}		
//		};
//		final JmxMeterRegistry registry = new JmxMeterRegistry(config, Clock.SYSTEM);
//		if (enabled) {
//			logger.info("configuring: {}", registry.getClass());
//			setupFilters(rc, registry);
//		} else {
//			registry.close();
//		}
//		return registry;
//	}

	@Bean
	@DependsOn({"metricConfigMap"})
	PrometheusMeterRegistry prometheusMeterRegistry(Map<String, RegistryConfig> metricConfigMap) {
		RegistryConfig rc = metricConfigMap.get(PrometheusMeterRegistry);
		boolean enabled = isRegistryEnabled(rc);
		final PrometheusMeterRegistry registry = new PrometheusMeterRegistry(PrometheusConfig.DEFAULT);
		if (enabled) {
			logger.info("configuring: {}", registry.getClass());
			setupFilters(rc, registry);	
		} else {
			registry.close();
		}
		
		return registry;
	}
	

	@Bean
	@DependsOn({"metricConfigMap"})
	public StatsdMeterRegistry statsdMeterRegistry(Map<String, RegistryConfig> metricConfigMap) {
		RegistryConfig rc = metricConfigMap.get(StatsdMeterRegistry);
		boolean enabled = isRegistryEnabled(rc);
		StatsdConfig config = new StatsdConfig() {

			@Override
			public boolean enabled() {
				logger.info("StatsdMeterRegistry enabled: {}", enabled);
				return enabled;
			}

			@Override
			public String get(String k) {
				return null;
			}

			@Override
			public String host() {
				// container network gateway
				return "172.17.0.1";
			}

			@Override
			public StatsdFlavor flavor() {
				return StatsdFlavor.DATADOG;
			}
			
			@Override
			public Duration pollingFrequency() {
		        return Duration.ofSeconds(10); // default is 10 sec
		    }
		};
		final StatsdMeterRegistry registry = new StatsdMeterRegistry(config, Clock.SYSTEM);
		if (enabled) {
			logger.info("configuring: {}", registry.getClass());
			setupFilters(rc, registry);
		} else {
			registry.close();
		}
		return registry;
	}
	
	@Bean
	@DependsOn({"metricConfigMap"})
	CloudWatchMeterRegistry cloudWatchMeterRegistry(Map<String, RegistryConfig> metricConfigMap) {
		RegistryConfig rc = metricConfigMap.get(CloudWatchMeterRegistry);
		boolean enabled = isRegistryEnabled(rc);
		HashMap<String, String> configmap = new HashMap<>();
		// Your metrics should go to: SAS/CI360/<TierName>/<ComponentName> in CloudWatch
		// Pass in your TierName and ComponentName using whatever mechanism you use to determine them
		String nameSpace = String.format("SAS/CI360/%s/%s",
				PreContextLoadedConfiguration.TIER, PreContextLoadedConfiguration.COMPONENT);
		configmap.put("cloudwatch.namespace", nameSpace);
		logger.info("CloudWatchMeterRegistry enabled: {}", enabled);
		configmap.put("cloudwatch.step", Duration.ofSeconds(CLOUDWATCH_STEP_SIZE_SECS).toString());
		CloudWatchConfig config = new CloudWatchConfig() {
			
			@Override
			public boolean enabled() {
				logger.info("CloudWatchMeterRegistry enabled: {}", enabled);
				return enabled;
			}
			
			@Override
			public String get(String key) {
				return configmap.get(key);
			}
			
		};
		CloudWatchAsyncClient awsClient =  CloudWatchAsyncClient.builder()
				.region(Region.of(PreContextLoadedConfiguration.REGION))
				.build();
		final CloudWatchMeterRegistry registry = new CloudWatchMeterRegistry(config, Clock.SYSTEM, awsClient);
		if (enabled) {
			logger.info("configuring: {}", registry.getClass());
			setupFilters(rc, registry);
		} else {
			registry.close();
		}
		return registry;
	}

	private class BooleanTagFilter implements java.util.function.Predicate<Meter.Id> {

		private String tagName;

		public BooleanTagFilter(String tagName) {
			this.tagName = tagName;
		}

		@Override
		public boolean test(Id t) {
			String info = t.getTag(tagName);
			if (info != null && info.equals("true"))
				return true;
			return false;
		}
	}
	
	private void details() {
//		System.out.println("configuring: " + registry.getClass().getSimpleName());
//		System.out.println("    closed -> " + registry.isClosed());
//		System.out.println("    enabled -> " + enabled);
	}

}