package com.sas.mkt.kafka.tools.controllers;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.codahale.metrics.annotation.Timed;
import com.sas.mkt.kafka.tools.topics.data.ClusterInfoDTO;
import com.sas.mkt.kafka.tools.topics.data.ConsumerGroupDTO;
import com.sas.mkt.kafka.tools.topics.data.RecordSetDTO;
import com.sas.mkt.kafka.tools.topics.data.TopicInfoDTO;
import com.sas.mkt.kafka.tools.topics.utils.ConsumerGroupUtils;
import com.sas.mkt.kafka.tools.topics.utils.TopicUtils;

/*
 * Note we've set the following in application.properties
 * server.connection-timeout=3600000 (1 hour)
 * server.session.timeout=3600 (1 hour)
 * and we've set the ELB connection timeout to 3600 sec (1 hour)
 */
@RestController
@RequestMapping("/topics")
public class TopicController {
	
//	@Autowired 
//	private HttpSession httpSession;
	
	@Resource
	TopicUtils topicUtils;
	
	@Resource
	ConsumerGroupUtils consumerGroupUtils;
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public List<String> getTopicList() {
		return topicUtils.getTopics();
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/topicinfo", method = RequestMethod.GET)
	public TopicInfoDTO getTopicInfo(@RequestParam String topic) {
		return topicUtils.getTopicInfo(topic);
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/refreshTimeWindow", method = RequestMethod.POST)
	public TopicInfoDTO refreshTimeWindow(@RequestBody TopicInfoDTO topicInfoDTO) {
//		System.out.println(topicInfoDTO);
		topicInfoDTO = topicUtils.getFirstAndLastTimestamp(topicInfoDTO);
		return topicInfoDTO;
	}
	
	@Timed(name="kafka.getrecords", absolute=true)
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/records", method = RequestMethod.POST)
	public RecordSetDTO getRecords(@RequestBody RecordSetDTO recordSetDTO) {
		recordSetDTO = topicUtils.getRecords(recordSetDTO);
		return recordSetDTO;
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/badrecords", method = RequestMethod.POST)
	public RecordSetDTO getBadRecords(@RequestBody TopicInfoDTO topicInfoDTO) {
		RecordSetDTO recordSetDTO = topicUtils.getBadRecords(topicInfoDTO);
		return recordSetDTO;
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/clusterinfo", method = RequestMethod.GET)
	public ClusterInfoDTO getClusterInfo() {
		return topicUtils.getClusterInfo();
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/consumers", method = RequestMethod.GET)
	public List<ConsumerGroupDTO> getConsumerGroups(@RequestParam String topic, @RequestParam boolean forceRefresh) {
		if (forceRefresh) consumerGroupUtils.forceRefresh();
		return consumerGroupUtils.getConsumerGroupListForTopic(topic);
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/count", method = RequestMethod.GET)
	public int count() {
		 return topicUtils.count();
	}

}
