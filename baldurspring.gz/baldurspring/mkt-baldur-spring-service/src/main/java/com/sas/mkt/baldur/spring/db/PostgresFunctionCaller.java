package com.sas.mkt.baldur.spring.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.sas.mkt.baldur.spring.utils.PreContextLoadedConfiguration;
import com.zaxxer.hikari.HikariDataSource;

@Component
public class PostgresFunctionCaller {

	public static final String S3_LOAD_STATUS_FAILED = "s3 load failed";
	public static final String S3_LOAD_STATUS_SUCCESS = "s3 load successful";

	@Autowired
	JdbcTemplate template;

	// you need to be the super user to install extensions and you can't grant super
	// user privileges
	// to new users in AWS RDS so we'll need to do this as dbmsowner
	public DataSource getDataSource() {

		HikariDataSource ds = new HikariDataSource();
		ds.setJdbcUrl(System.getProperty("spring.datasource.url"));
		ds.setUsername("dbmsowner");
		ds.setPassword(System.getProperty("spring.datasource.password"));
		ds.setDriverClassName("org.postgresql.Driver");
		ds.setMaximumPoolSize(1);
		ds.setMinimumIdle(0);
		ds.setMaxLifetime(20 * 60 * 1000l); // 20 minutes
		return ds;

	}

	public void installAwsS3Extension() {
		Connection conn = null;
		try {
			conn = getDataSource().getConnection();
			Statement stmt = conn.createStatement();

			// have we installed the extension yet?
			ResultSet rs = stmt.executeQuery("select count(*) from pg_extension where extname='aws_s3'");
			if (rs.next() && rs.getInt("count") == 1) {
				stmt.close();
				conn.close();
				return;
			} else {
				// looks like we haven't - install as super user
				conn.setAutoCommit(false);
				stmt.execute("CREATE EXTENSION if not exists aws_s3 CASCADE");
				// make sure our user can find and execute the required functions
				String user = System.getProperty("spring.datasource.username");
				stmt.execute("grant usage on schema aws_s3 to \"" + user + "\"");
				stmt.execute("grant all privileges on all functions in schema aws_s3 to \"" + user + "\"");
				conn.commit();
				stmt.close();
				conn.close();
			}

		} catch (Exception ex) {
			System.out.println("*** Failed to create/grant privs on extension***");
			if (conn != null) {
				try {
					conn.rollback();
					conn.close();
				} catch (Exception dbex) {
					// log this or do something intelligent
					dbex.printStackTrace();
				}
			}
		}
	}

	public String loadS3Data(String bucket, String file, String tablename) {
		String message = PostgresFunctionCaller.S3_LOAD_STATUS_FAILED;
		installAwsS3Extension();
		// 1. tablename, 2. bucket, 3. file, 4. region, 5. accessKeyId, 6.
		// secretAccessKey, 7. sessionToken
//		String importString = "SELECT aws_s3.table_import_from_s3(\n" + 
//				"  'tablename',\n" + 
//				"  '',\n" + 
//				"  '(format csv)',\n" + 
//				"  aws_commons.create_s3_uri('bucket', 'file', 'us-east-1'), \n" + 
//				"  aws_commons.create_aws_credentials('accessKeyId', 'secretAccessKey', 'sessionToken')\n" + 
//				");";
		String sql = "SELECT aws_s3.table_import_from_s3(" + "  ?," + "  ''," + "  '(format csv)',"
				+ "  aws_commons.create_s3_uri(?, ?, ?)," + "  aws_commons.create_aws_credentials(?, ?, ?)" + ");";

		AwsKeysDTO awskeys = new AwsKeys().getAwsKey();

		try (Connection conn = template.getDataSource().getConnection()) {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, tablename);
			pst.setString(2, bucket);
			pst.setString(3, file);
			pst.setString(4, PreContextLoadedConfiguration.REGION);
			pst.setString(5, awskeys.AccessKeyId);
			pst.setString(6, awskeys.SecretAccessKey);
			pst.setString(7, awskeys.Token);
			pst.executeQuery();
			message = PostgresFunctionCaller.S3_LOAD_STATUS_SUCCESS;
			pst.close();
		} catch (Exception ex) {
			// log / deal with this
			ex.printStackTrace();
		}
		return message;
	}



}
