package com.sas.mkt.baldur.spring.kafka;

import java.util.Map;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.core.PropertyDetails;
import com.sas.mkt.config.core.events.ApplicationConfigurationEvent;
import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;


@Component
public class KafkaConfig {
	
	public static String BALDUR_TOPIC = "baldur2-test-events";
	public static String FINNR_TOPIC = "finnr-test-events";
	
//	private KafkaConnectionUtils kcutils;
//	private ObjectMapper objectMapper = new ObjectMapper();
//	
//	public Properties producerProps;
//	public Properties consumerProps;
//	
//	
//	@Autowired
//	ApplicationConfiguration appConfig;
//	
//	public KafkaConfig() {
//		try {
//			kcutils = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
//			producerProps = kcutils.getKafkaProducerProperties(appConfig.getTierName()+"-"+appConfig.getComponentName());
//			// add customizations from application.properties, environment variables, system properties, and config server for given tier/component and tier/component_global
//    		try {
//    			Map<String, Object> map 
//    			  = objectMapper.readValue(appConfig.getKafkaProducerProperties(), new TypeReference<Map<String,Object>>(){});
//				for (String key: map.keySet()) {
//					System.out.println("key: " + key + ", value: " + map.get(key));
//					producerProps.put(key, map.get(key));
//				}
//				
//			} catch (JsonProcessingException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//    		// TODO do the same for consumer properties
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
	


}
