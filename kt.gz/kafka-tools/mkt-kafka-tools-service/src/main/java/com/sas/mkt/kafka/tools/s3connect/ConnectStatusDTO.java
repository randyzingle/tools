package com.sas.mkt.kafka.tools.s3connect;

import java.util.Arrays;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
public class ConnectStatusDTO {
	
	@JsonProperty("name")
	public String name;
	
	@JsonProperty("connector")
	public StatusConnector connector;
	
	@JsonProperty("tasks")
	public StatusTasks[] tasks;
	
	@JsonProperty("type")
	public String type;

	@Override
	public String toString() {
		return "ConnectStatusDTO [name=" + name + ", connector=" + connector + ", tasks=" + Arrays.toString(tasks)
				+ ", type=" + type + "]";
	}

}
