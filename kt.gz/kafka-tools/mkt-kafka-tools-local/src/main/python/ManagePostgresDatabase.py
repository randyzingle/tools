'''
Create a WebACL and RateBasedRule and associate to ALB

Source code located in GitLab:
    // TODO - put in layers project https://gitlab.sas.com/CustomerIntelligence/DevOps/mkt-infra

Configuration:
"Handler": "ManagePostgresDatabase.handler"
"Runtime": "python3.6"
"Timeout": "300"

July 8, 2019
@author: razing
'''
import json
from urllib.request import urlopen, Request, HTTPError, URLError
from urllib.parse import urlencode
from psycopg2 import connect, Error
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
import PostgresUtils as pgu
import boto3
import re
import time

# ===============================================================================
#  Sample CloudFormation events
# ===============================================================================
'''
Create event:
{
  "RequestType": "Create",
  "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-UDZOW2HK3IWD",
  "ResponseURL": "https://cloudformation-custom-resource-response-useast1.s3.amazonaws.com",
  "StackId": "arn:aws:cloudformation:us-east-1:952478859445:stack/razing-custom/40d839f0-8cd3-11e7-a3f6-50faeaabf0d1",
  "RequestId": "5f078456-de85-4775-9441-9347eaac6407",
  "LogicalResourceId": "WAFInfo",
  "ResourceType": "AWS::CloudFormation::CustomResource",
  "ResourceProperties": {
    "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-UDZOW2HK3IWD",
    "RateLimit": "2000",
    "Description": "Lambda will return ID of: WebACL, RateBasedRule",
    "Region": "us-east-1",
    "ALBArn": "arn:aws:elasticloadbalancing:us-east-1:952478859445:loadbalancer/app/razing-ELB-17401GTSWCHZC/f2fe45278d0d859e",
    "StackName": "razing-custom"
  }
}

Update event:
{
  "RequestType": "Update",
  "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-XRSHVD5NRA7I",
  "ResponseURL": "https://cloudformation-custom-resource-response-useast1.s3.amazonaws.com",
  "StackId": "arn:aws:cloudformation:us-east-1:952478859445:stack/razing-custom/afb9dbe0-8cd7-11e7-bd36-500c219ab02a",
  "RequestId": "7310f283-36ce-43b8-a88e-2f022103ba7c",
  "LogicalResourceId": "WAFInfo",
  "PhysicalResourceId": "None",
  "ResourceType": "AWS::CloudFormation::CustomResource",
  "ResourceProperties": {
    "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-XRSHVD5NRA7I",
    "RateLimit": "2000",
    "Description": "Lambda will return ID of: WebACL, RateBasedRule",
    "Region": "us-east-1",
    "ALBArn": "arn:aws:elasticloadbalancing:us-east-1:952478859445:loadbalancer/app/razing-ELB-17401GTSWCHZC/f2fe45278d0d859e",
    "StackName": "razing-custom"
  },
  "OldResourceProperties": {
    "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-XRSHVD5NRA7I",
    "RateLimit": "2500",
    "Description": "Lambda will return ID of: WebACL, RateBasedRule",
    "Region": "us-east-1",
    "ALBArn": "arn:aws:elasticloadbalancing:us-east-1:952478859445:loadbalancer/app/razing-ELB-17401GTSWCHZC/f2fe45278d0d859e",
    "StackName": "razing-custom"
  }
}

Delete event:
{
  "RequestType": "Delete",
  "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-13C1UUQ66AQ0P",
  "ResponseURL": "https://cloudformation-custom-resource-response-useast1.s3.amazonaws.com",
  "StackId": "arn:aws:cloudformation:us-east-1:952478859445:stack/razing-custom/09cdd3e0-8cdb-11e7-b660-503acac41e35",
  "RequestId": "4f6ae1d6-0a71-4bf5-bd7e-3c2f4b8c62ec",
  "LogicalResourceId": "WAFInfo",
  "PhysicalResourceId": "None",
  "ResourceType": "AWS::CloudFormation::CustomResource",
  "ResourceProperties": {
    "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-13C1UUQ66AQ0P",
    "RateLimit": "2000",
    "Description": "Lambda will return ID of: WebACL, RateBasedRule",
    "Region": "us-east-1",
    "ALBArn": "arn:aws:elasticloadbalancing:us-east-1:952478859445:loadbalancer/app/razing-ELB-17401GTSWCHZC/f2fe45278d0d859e",
    "StackName": "razing-custom"
  }
}
'''

# ===============================================================================
#  Constants
# ===============================================================================
STATUS_FAILED = 'FAILED'
STATUS_SUCCESS = 'SUCCESS'

# ===============================================================================
#  Entry Point for Lambda
# ===============================================================================
def handler(event, context):
    print(event)
    rtype = event['RequestType']

    if rtype == 'Create':
        create_resources(event, context)
    elif rtype == 'Update':
        update_resources(event, context)
    elif rtype == 'Delete':
        delete_resources(event, context)
    else:
        print(rtype, ' :Not a proper request-type, should be one of [Create|Update|Delete]')

# ===============================================================================
#  Postgresql Database Utilities
# ===============================================================================

'''
def connectToDatabase(hostName, portNumber, userName, passwd, databaseName):
    print('Connecting to postgres database on: ' + hostName + ':' + str(portNumber) + ':' + userName + ':***:' + databaseName)

    try:
        conn = connect(host=hostName, port=portNumber, user=userName, password=passwd,
                       database=databaseName, connect_timeout=15, options='-c statement_timeout=60000')
    except Error as e:
        reason = e.message.strip()
        print('Unable to connect to database: ' + reason)
        raise PostgresConnectionError('Unable to connect to database!', reason)

    return conn


def testDBConnection(connection):
    print('Testing database connection')
    cursor = executeSQL(connection, "SELECT VERSION()")
    result = cursor.fetchone()
    cursor.close()
    print("Database version: %s" % result)
    connection.commit()

    if (result[0].startswith('PostgreSQL')):
        return True

    return False

'''

# ===============================================================================
#  Utility Functions
# ===============================================================================

def get_rds_parameters(event):
    try:
        rdsStackName = event['ResourceProperties']['RDSStackName']
        print(rdsStackName)
        cfclient = boto3.client('cloudformation')
        rds_info = cfclient.describe_stacks(StackName=rdsStackName)
        stack, = rds_info['Stacks']
        outputs = stack['Outputs']
        print(outputs)
        print('===========')
        outputMap = {}
        for o in outputs:
            key = o['OutputKey']
            outputMap[key] = o['OutputValue']

        outputMap['AdminDatabase'] = outputMap['JdbcURL'].split('/')[3]
        stackPrefix = event['ResourceProperties']['StackPrefix']
        projectName = event['ResourceProperties']['ProjectName']
        outputMap['UserName'] = projectName
        outputMap['DatabaseName'] = stackPrefix + '-' + projectName
        print(json.dumps(outputMap, indent=2))
        event['rdsParameters'] = outputMap
    except Exception as ex:
        event['error'] = ex

def call_password_decoder(password):
    lambda_client = boto3.client('lambda')
    print('Calling PasswordDecoder lambda')
    response = lambda_client.invoke(FunctionName='PasswordDecoder', Payload=json.dumps({'password': password}))
    streamingBody = response['Payload']
    stringData = streamingBody.read()
    data = json.loads(stringData)
    return data

# ===============================================================================
#  Pure PostgreSQL Functions
# ===============================================================================

def create_user(rdsParameters, connection):
    print('creating user....')
    query = 'CREATE USER "' + rdsParameters['UserName'] + '"'
    query += " WITH PASSWORD '" + rdsParameters['DecodedPassword'] + "'"
    executeSQL(connection, query)
    connection.commit()

def create_database(rdsParameters, connection):
    print('creating database....')
    query = 'CREATE DATABASE "' + rdsParameters['DatabaseName'] + '"'
    executeSQLWithAutoCommit(connection, query)
    query = 'GRANT ALL PRIVILEGES ON DATABASE "' + rdsParameters['DatabaseName'] + '" TO "' + rdsParameters['UserName'] + '"';
    executeSQLWithAutoCommit(connection, query)

def delete_database(rdsParameters, connection):
    print('deleting database....')
    # Don't allow any new connections
    query = 'ALTER DATABASE "' + rdsParameters['DatabaseName'] + '" WITH ALLOW_CONNECTIONS false'
    executeSQL(connection, query)
    connection.commit()
    # Drop all existing connections
    query = "SELECT pg_terminate_backend (pg_stat_activity.pid) FROM pg_stat_activity WHERE pg_stat_activity.datname = '" + rdsParameters['DatabaseName'] + "'"
    executeSQL(connection, query)
    connection.commit()
    # Drop the database
    query = 'DROP DATABASE IF EXISTS "' + rdsParameters['DatabaseName'] + '"'
    executeSQLWithAutoCommit(connection, query)

def delete_user(rdsParameters, connection):
    print('deleting user....')
    query = 'DROP ROLE IF EXISTS "' + rdsParameters['UserName'] + '"'
    executeSQL(connection, query)
    connection.commit()

def executeSQL(connection, sql):
    print('Executing query: ' + sql)
    cursor = connection.cursor()
    cursor.execute(sql)
    return cursor

def executeSQLWithAutoCommit(connection, sql):
    print('Enabling AutoCommit')

    level = connection.isolation_level

    # This must be set to create a database...
    connection.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)

    cursor = executeSQL(connection, sql)
    cursor.close()

    print('Disabling AutoCommit')
    connection.set_isolation_level(level)

# ===============================================================================
#  Functions that response to Create, Update, and Delete CF Events
# ===============================================================================
def create_resources(event, context):
    print('create_resources...')
    get_rds_parameters(event)
    if 'error' in event:
        print(event)
        send_response(event, STATUS_FAILED)
        return

    rdsParameters = event['rdsParameters']
    decodedPassword = call_password_decoder(rdsParameters['RDSEncodedPassword'])['value']
    print('DecodedPassword = ', decodedPassword)
    rdsParameters['DecodedPassword'] = decodedPassword

    # connect to database
    connection = pgu.connectToDatabase(rdsParameters['RdsDNSEndpointAddress'], 5432, 'dbmsowner', decodedPassword, rdsParameters['AdminDatabase'])
    #connection = pgu.connectToDatabase(RdsDNSEndpointAddress, 5432, 'baldur', decodedPassword, 'baldurdb')
    live = pgu.testDBConnection(connection)

    # lookup user
    user = rdsParameters['UserName']
    userexists = pgu.valueExistsInCatalog(connection, 'user', user)
    print('user ', user, ' exists = ', userexists)
    if not userexists:
        create_user(rdsParameters, connection)

    # lookup database
    database = rdsParameters['DatabaseName']
    dbexists = pgu.valueExistsInCatalog(connection, 'database', database)
    print('database ', database, ' exists = ', dbexists)
    if not dbexists:
        create_database(rdsParameters, connection)

    # clean up
    connection.close()
    # we were successful
    send_response(event, STATUS_SUCCESS)


def update_resources(event, context):
    print('update_resources...') # should be do nothing unless password changes (shouldn't have a tiername or projectname change)
    print(event)
    if (event['WebACLId'] is not None and event['RuleId'] is not None):
        old_rate = event['OldResourceProperties']['RateLimit']
        new_rate = event['ResourceProperties']['RateLimit']
        if old_rate == new_rate:
            print("Nothing to update, old rate %s equals new rate %s" % (old_rate, new_rate))
            send_response(event, STATUS_SUCCESS)
        else:
            send_response(event, STATUS_SUCCESS)
    else:
        event['Update'] = True
        delete_resources(event, context)
        create_resources(event, context)


def delete_resources(event, context):
    print('delete_resources...')
    get_rds_parameters(event)
    if 'error' in event:
        print(event)
        send_response(event, STATUS_FAILED)
        return

    rdsParameters = event['rdsParameters']

    decodedPassword = call_password_decoder(rdsParameters['RDSEncodedPassword'])['value']
    rdsParameters['DecodedPassword'] = decodedPassword

    # connect to database
    connection = pgu.connectToDatabase(rdsParameters['RdsDNSEndpointAddress'], 5432, 'dbmsowner', decodedPassword, rdsParameters['AdminDatabase'])
    live = pgu.testDBConnection(connection)

    # lookup database
    database = rdsParameters['DatabaseName']
    dbexists = pgu.valueExistsInCatalog(connection, 'database', database)
    print('database ', database, ' exists = ', dbexists)
    if dbexists:
        delete_database(rdsParameters, connection)

    # lookup user
    user = rdsParameters['UserName']
    userexists = pgu.valueExistsInCatalog(connection, 'user', user)
    print('user ', user, ' exists = ', userexists)
    if userexists:
        delete_user(rdsParameters, connection)

    # clean up
    connection.close()
    # we were successful
    send_response(event, STATUS_SUCCESS)


# ===============================================================================
#  Cloudformation HTTP PUT response indicating SUCCESS or FAILURE of lambda
# ===============================================================================
def send_response(event, responseStatus):
    print('sending response to CloudFormation')
    '''
    data = {}
    data['WebACLId'] = event.get('WebACLId', 'None')
    data['RuleId'] = event.get('RuleId', 'None')
    responseBody = {
        'Status': responseStatus,
        'Reason': 'See the details in CloudWatch Log Stream',
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'Data': data
    }

    # PhysicalResourceId only sent with Update and Delete requests
    responseBody['PhysicalResourceId'] = event.get('PhysicalResourceId', 'None')

    # print(responseBody)
    edata = json.dumps(responseBody)
    edata = edata.encode('utf-8')
    headers = {'Content-Length': len(edata), 'Content-Type': ''}
    # print(headers)
    req = Request(
        event['ResponseURL'],
        headers=headers,
        data=edata,
        method='PUT')
    req.get_method = lambda: 'PUT'
    try:
        urlopen(req)
    except Exception as e:
        print(e)
    '''

# ===============================================================================
#  Test Code for runs from the command line
# ===============================================================================
if __name__ == "__main__":
    print('in __main__ function')

    event = '''
    {
      "RequestType": "Create",
      "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-XRSHVD5NRA7I",
      "ResponseURL": "http://localhost:8080/service",
      "StackId": "arn:aws:cloudformation:us-east-1:952478859445:stack/razing-custom/afb9dbe0-8cd7-11e7-bd36-500c219ab02a",
      "RequestId": "7310f283-36ce-43b8-a88e-2f022103ba7c",
      "LogicalResourceId": "WAFInfo",
      "PhysicalResourceId": "None",
      "ResourceType": "AWS::CloudFormation::CustomResource",
      "ResourceProperties": {
        "StackPrefix": "baldur",
        "ProjectName": "mkt-docker",
        "Description": "Lambda will manage Postgresql DB lifecycle",
        "RDSStackName": "baldur-rds"
      },
      "OldResourceProperties": {
        "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-XRSHVD5NRA7I",
        "RateLimit": "2000",
        "Description": "Lambda will return ID of: WebACL, RateBasedRule",
        "Region": "us-east-1",
        "ALBArn": "arn:aws:elasticloadbalancing:us-east-1:952478859445:loadbalancer/app/razing-ELB-17401GTSWCHZC/f2fe45278d0d859e",
        "StackName": "razing-custom"
      }
    }
    '''
    context = {}
    handler(json.loads(event), context)
