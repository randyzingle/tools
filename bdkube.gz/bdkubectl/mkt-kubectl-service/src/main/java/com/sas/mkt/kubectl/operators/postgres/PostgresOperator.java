package com.sas.mkt.kubectl.operators.postgres;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.AWSLambdaClientBuilder;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sas.mkt.kubectl.data.TemplateData;
import com.sas.mkt.kubectl.operators.KubernetesOperator;




public class PostgresOperator extends KubernetesOperator {

	private Logger logger = LoggerFactory.getLogger(PostgresOperator.class);
	private TemplateData td;

	@Override
	protected void customizeTemplate(TemplateData templateData) {
		td = templateData;
		if (td.lifecycle.equalsIgnoreCase("create")) {
			// we need a lot more rigorous logic here - does the service already exist?
			setupPassword(); 
		} else if (td.lifecycle.equalsIgnoreCase("update")) {
			// need more logic here too - are we just trying to change a database password?
			// this will update the secret but won't change the db password - we'd need to run sql for that.
			// once we've create the encoded password should we store it in a config and always return that?
			setupPassword();
			return;
		}
		String jdbcUrl = String.format("jdbc:postgresql://%s-%s.%s:5432/postgres",
				td.parameters.get("dnsname"),
				td.parameters.get("tiername"),
				td.parameters.get("dnszone")
			);
		String dnsEndpoint = String.format("%s-%s.%s",
				td.parameters.get("dnsname"),
				td.parameters.get("tiername"),
				td.parameters.get("dnszone")
			);
		td.results.outputParameters.put("JdbcURL", jdbcUrl);
		td.results.outputParameters.put("RdsDNSEndpointAddress", dnsEndpoint);
		td.results.outputParameters.put("RdsDatabaseEndpointAddress", dnsEndpoint);
		td.results.outputParameters.put("RdsSecurityGroup", "");
		td.results.outputParameters.put("SecureParams", "");
	}

	private void setupPassword() {
		
		String password = td.parameters.get("postgres-password");
		String base64password = "";
		String encodedPassword =  null;
			
		try {
			// SAS-encode the password using the lambda PasswordEncoder
			// AWS SDK 2.x
//			LambdaClient client = LambdaClient.create();
//			String json = "{ \"password\": \"" + password + "\" }";			
//			SdkBytes payload = SdkBytes.fromUtf8String(json);
//			InvokeRequest request = InvokeRequest.builder().functionName("PasswordEncoder").payload(payload).build();
//			InvokeResponse response = client.invoke(request);
//			String value = response.payload().asUtf8String();
//			ObjectMapper objectMapper = new ObjectMapper();
//			EncoderResults results = objectMapper.readValue(value, EncoderResults.class);
//			for (PasswordMethod pm: results.results) {
//				if (pm.method.equalsIgnoreCase("sas002")) {
//					encodedPassword = pm.encodedString;
//				}
//			}
//			client.close();
			
			// AWS SDK 1.x
			encodedPassword = encryptPassword(password);

			td.results.outputParameters.put("RDSEncodedPassword", encodedPassword);
			
			// Base64 encoded password for kubernetes Secret
			base64password = Base64.getEncoder().encodeToString(password.getBytes());
			td.parameters.put("postgres-password", base64password);		

		} catch (Exception ex) {
			td.response.append(ex.getMessage());
			logger.error(ex.getMessage());
		}
//		System.out.println(password);
//		System.out.println(encodedPassword);
//		System.out.println(base64password);

	}
	
	private String encryptPassword(String password) {
		String encodedPassword = "";
		String json = "{ \"password\": \"" + password + "\" }";
		InvokeRequest invokeRequest = new InvokeRequest().withFunctionName("PasswordEncoder").withPayload(json);
		InvokeResult invokeResult = null;
		try {
			String region = getRegion();
			AWSLambda lambda = AWSLambdaClientBuilder.standard().withRegion(region).build();
			invokeResult = lambda.invoke(invokeRequest);
			String value = new String(invokeResult.getPayload().array(), StandardCharsets.UTF_8);
			ObjectMapper objectMapper = new ObjectMapper();
			EncoderResults results = objectMapper.readValue(value, EncoderResults.class);
			for (PasswordMethod pm: results.results) {
				if (pm.method.equalsIgnoreCase("sas002")) {
					encodedPassword = pm.encodedString;
				}
			}
		} catch (Exception ex) {
			logger.error(ex.toString());
		}
		return encodedPassword;
	}

	private String getRegion() {
		String name = Regions.US_EAST_1.getName();
		Region region = Regions.getCurrentRegion();
		if (region != null)
			name = region.getName();
		return name;
	}

	static class EncoderResults {
		public PasswordMethod[] results;
	}
	static class PasswordMethod {
		public String encodedString;
		public String method;
	}


}
