package com.sas.mkt.kafka.clients.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.RemovalCause;
import com.google.common.cache.RemovalListener;
import com.google.common.cache.RemovalNotification;

//tag
public class KafkaTopicUtils implements RemovalListener<String, Map<String, Map<String, Map<String, ConfigProperty>>>> {
	private static Logger logger = LoggerFactory.getLogger(KafkaTopicUtils.class);

	/*
	 * This will eventually be changed to include the business topic name with
	 * wildcard
	 */
	protected static final String BUSINESS_EVENT_TOPIC = "business-events";
	protected static final String ENHANCED_EVENT_TOPIC = "enhanced-events";
	protected static final String ON_PREM_AGENT_NO_AVRO_TOPIC = "on-prem-agentNoAVRO";

	protected static final String CONFIG_SERVER_KAFKA_COMPONENTNM = "mkt-kafka";
	protected static final String CONFIG_SERVER_TIER_GLOBAL = "tier_global";
	protected static final String CONFIG_SERVER_COMPONENT_GLOBAL = "component_global";

	protected static final String CONFIG_SERVER_KAFKA_TOPIC_PREFIX = "kafkaTopicPrefix";

	protected Map<String, Map<String, Map<String, ConfigProperty>>> kp;

	protected String configServiceURL = null;
	protected Cache<String, Map<String, Map<String, Map<String, ConfigProperty>>>> configProperties = null;
	protected int DEFAULT_PROPERTY_CACHE_TIMEOUT = 60;

	private ObjectMapper mapper;

//	public static void main(String[] args) {
//		String configServiceURL = "http://configservice-dev.cidev.sas.us:8080/";
//		KafkaTopicUtils ktu = new KafkaTopicUtils(configServiceURL);
//		String topicRoot = "business-events";
//		String tierName = "anavisstaging";
//		String componentName = "";
//		String prefixOverride = "";
//		String prefixDefault = "";
//		String fullTopic = ktu.getTopicWithPrefix(topicRoot, tierName, componentName, prefixOverride, prefixDefault);
//		System.out.println(fullTopic);
//	}

	/**
	 * Helper to lookup properties and determine topic names including prefixes.
	 *
	 * @param configServiceURL endpoint for the config service.
	 */
	public KafkaTopicUtils(String configServiceURL) {
		this.configServiceURL = configServiceURL;
		createCache(DEFAULT_PROPERTY_CACHE_TIMEOUT);
		mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	}

	/**
	 * Returns the base topic name consumer should subscribe to for onprem-no-avro
	 * events
	 */
	public String getConsumerOnPremNoAvroEventTopic() {
		// TODO: lookup value in config once we define property name, etc.
		return ON_PREM_AGENT_NO_AVRO_TOPIC;
	}

	/**
	 * Returns the base topic name consumer should subscribe to for onprem-no-avro
	 * events
	 */
	public String getProducerOnPremNoAvroEventTopic() {
		// TODO: lookup value in config once we define property name, etc.

		return ON_PREM_AGENT_NO_AVRO_TOPIC;
	}

	/**
	 * Returns the base topic name consumer should subscribe to for business events
	 */
	public String getConsumerBusinessEventTopic() {
		// TODO: lookup value in config once we define property name, etc.

		return BUSINESS_EVENT_TOPIC;
	}

	/**
	 * Returns the base topic name consumer should subscribe to for business events
	 */
	public String getConsumerEnhancedEventTopic() {
		// TODO: lookup value in config once we define property name, etc.

		return ENHANCED_EVENT_TOPIC;
	}

	/**
	 * Returns the base topic name publisher should subscribe to for business events
	 */
	public String getProducerBusinessEventTopic(String tenantMoniker) {
		// TODO: lookup value in config once we define property name, etc.

		// TODO: append the tenantMoniker when we have tenant specific topics, confirm
		// we will use tenant moniker and not internal id, etc.)

		// Might just publish to enhanced event topic and not have to worry about tenant
		// / business events

		// currently we do not plan to support per tenant business event topics so just
		// return the root
		return BUSINESS_EVENT_TOPIC;
	}

	/**
	 * Returns the base topic name publisher should subscribe to for business events
	 */
	public String getProducerEnhancedEventTopic(String tenantMoniker) {
		// TODO: lookup value in config once we define property name, etc.

		// TODO: append the tenantMoniker when we have tenant specific topics, confirm
		// we will use tenant moniker and not internal id, etc.)

		// Might just publish to enhanced event topic and not have to worry about tenant
		// / business events

		return ENHANCED_EVENT_TOPIC;
	}

	protected void getConfigServicePropertiesByPropertyName(String configServiceURL, String propertyName) {

		String url = buildURL(configServiceURL, propertyName);

		// reset results based on cache
		kp = configProperties.getIfPresent(url);

		if (null == kp)
			getConfigServiceProperties(url);
	}

	protected String buildURL(String configServiceURL, String propertyName) {
		return configServiceURL + ConfigProperty.COLLECTION_NAME + "?name=" + propertyName;
	}

	private void getConfigServiceProperties(String url) {
		List<ConfigProperty> allProps = getPropsByUrl(url);

		if (null != allProps) {
			initializeKafkaProperties(allProps);
		}

		if (null != kp) {
			configProperties.put(url, kp);

			String message = String.format("Kafka Configuration from config service [%s]:%n%s", url, kp.toString());
			logger.info(message);
		}
	}

	protected Map<String, Map<String, Map<String, ConfigProperty>>> initializeKafkaProperties(
			List<ConfigProperty> props) {
		kp = null;

		if (null == props)
			return null;

		// Top level key is the propertyName
		// Second level it the tier
		// Third level is the component
		kp = new HashMap<String, Map<String, Map<String, ConfigProperty>>>();

		for (ConfigProperty prop : props) {

			Map<String, Map<String, ConfigProperty>> propByTier = kp.get(prop.name);

			if (null == propByTier) {
				propByTier = new HashMap<String, Map<String, ConfigProperty>>();
				kp.put(prop.name, propByTier);
			}

			Map<String, ConfigProperty> propByComponent = propByTier.get(prop.tierNm);

			if (null == propByComponent) {
				// use tree map to provide order based upon components.
				// when there is not component match then the first
				// record found will be returned
				// want some consistency on the ordering
				propByComponent = new TreeMap<String, ConfigProperty>();
				propByTier.put(prop.tierNm, propByComponent);
			}

			propByComponent.put(prop.componentNm, prop);

		}

		return kp;
	}

	/**
	 * @deprecated in 1804 replaced with api specifying tier_global,
	 *             component_global and wildcard component match options
	 * 
	 *             Looks up a property and provides the best match between tier and
	 *             tier_global based upon the component if provided. Defaults to
	 *             match tier_global, component_global and any component name if
	 *             previous matches fail.
	 *
	 * @param propertyName
	 * @param tierName
	 * @param propertyComponent
	 */
	@Deprecated
	public String lookupProperty(String propertyName, String tierName, String propertyComponent) {
		return lookupProperty(propertyName, tierName, propertyComponent, true, true, true);
	}

	/**
	 * Looks up a property and provides the best match between tier and tier_global
	 * based upon the component if provided
	 *
	 * @param propertyName
	 * @param tierName
	 * @param propertyComponent
	 * @param matchTierGlobal
	 * @param matchGlobalComponent
	 * @param matchAnyComponent
	 */
	public String lookupProperty(String propertyName, String tierName, String propertyComponent,
			boolean matchTierGlobal, boolean matchGlobalComponent, boolean matchAnyComponent) {
		if (!configServiceURL.endsWith("/"))
			configServiceURL = configServiceURL + "/";
		getConfigServicePropertiesByPropertyName(configServiceURL, propertyName);

		return getProperty(propertyName, tierName, propertyComponent, matchTierGlobal, matchGlobalComponent,
				matchAnyComponent);

	}

	private String getProperty(String name, String tier, String component, boolean matchTierGlobal,
			boolean matchGlobalComponent, boolean matchAnyComponent) {
		if (name == null)
			return null;

		if (tier == null)
			tier = "";

		if (component == null)
			component = "";

		if (null == kp) {
			logger.error("Invalid property map");
			return null;
		}

		Map<String, Map<String, ConfigProperty>> propByTier = kp.get(name);

		if (null == propByTier)
			return null;

		Map<String, ConfigProperty> propByComponent = propByTier.get(tier);

		// if null != propByComponent
		// check to see if we have a match with our component
		// if not then check to see if any other component for
		// this tier is listed

		if (null != propByComponent) {
			ConfigProperty prop = propByComponent.get(component);

			// this is the one!
			if (null != prop) {
				if (logger.isDebugEnabled())
					logger.debug("Found property: " + name + " tier: " + tier + " component: " + component);

				return prop.value;
			}
		}

		// is there a component global setting for this tier?
		if (matchGlobalComponent) {
			if (null != propByComponent) {
				ConfigProperty prop = propByComponent.get(CONFIG_SERVER_COMPONENT_GLOBAL);

				// this is the one!
				if (null != prop) {
					if (logger.isDebugEnabled())
						logger.debug("Found property: " + name + " tier: " + tier + " component: " + component);

					return prop.value;
				}
			}
		}

		// otherwise check to see if tier_global has a component match
		Map<String, ConfigProperty> propByGlobalComponent = propByTier.get(CONFIG_SERVER_TIER_GLOBAL);

		if (matchTierGlobal) {
			if (null != propByGlobalComponent) {
				ConfigProperty prop = propByGlobalComponent.get(component);

				// this is a match with tier_global
				if (null != prop) {
					if (logger.isDebugEnabled())
						logger.debug("Found property: " + name + " tier: " + CONFIG_SERVER_TIER_GLOBAL + " component: "
								+ component);

					return prop.value;
				}
			}
		}

		// ok, neither our tier or tier_global had a match for the specified component
		// so see if any component for our tier has it and return the first one

		// next see if we should match any component

		if (matchAnyComponent) {
			if (null != propByComponent) {
				Set<Entry<String, ConfigProperty>> props = propByComponent.entrySet();

				for (Entry<String, ConfigProperty> configEntry : props) {
					ConfigProperty property = configEntry.getValue();

					if (logger.isDebugEnabled())
						logger.debug(
								"Found property: " + name + " tier: " + tier + " component: " + configEntry.getKey());

					return property.value;
				}
			}
		}

		if (matchTierGlobal) {

			// still not found so see if any component at tier_global has it
			if (null != propByGlobalComponent) {
				Set<Entry<String, ConfigProperty>> props = propByGlobalComponent.entrySet();

				for (Entry<String, ConfigProperty> configEntry : props) {
					ConfigProperty property = configEntry.getValue();

					if (logger.isDebugEnabled())
						logger.debug("Found property: " + name + " tier: " + CONFIG_SERVER_TIER_GLOBAL + " component: "
								+ configEntry.getKey());

					return property.value;
				}
			}
		}

		// nothing...

		if (logger.isDebugEnabled())
			logger.debug("Property: " + name + " not found");

		return null;
	}

	/**
	 * 
	 * @deprecated in 1804 replaced with api specifying component name.
	 * 
	 *             Helper to lookup the prefix, if needed, and prepend with the
	 *             topic root
	 *
	 * @param topicRoot      - The root name of the topic
	 * @param tierName       - The tier, if any, this request is associated with
	 * @param prefixOverride - Supply your own value for the prefix (Note an empty
	 *                       string is same as none)
	 *
	 * @return the topic name with the prefix (if any) prepended
	 * @throws Exception
	 *
	 */
	@Deprecated
	public String getTopicWithPrefix(String topicRoot, String tierName, String prefixOverride) {
		String prefix = getTopicPrefix(tierName, null, prefixOverride, null);

		if (null != prefix) {
			String topic = prefix + topicRoot;

			logger.info("Returning topic: " + topic);

			return topic;
		}

		logger.info("Returning topic: " + topicRoot);
		return topicRoot;
	}

	/**
	 * Helper to lookup the prefix, if needed, and prepend with the topic root
	 *
	 * @param topicRoot      - The root name of the topic
	 * @param tierName       - The tier, if any, this request is associated with
	 * @param componentName  - The component to match if specified. If exact match
	 *                       isn't found global component will be used if present.
	 *                       If no component is provided then any component will be
	 *                       matched after global component.
	 * @param prefixOverride - Supply your own value for the prefix and skip
	 *                       configuration lookup (Note an empty string is same as
	 *                       none)
	 * @param prefixDefault  - Supply a default value if none is found in
	 *                       configuration
	 *
	 * @return the topic name with the prefix (if any) prepended
	 * @throws Exception
	 *
	 */
	public String getTopicWithPrefix(String topicRoot, String tierName, String componentName, String prefixOverride,
			String prefixDefault) {
		String prefix = getTopicPrefix(tierName, componentName, prefixOverride, prefixDefault);

		if (null != prefix) {
			if (!prefix.endsWith("-"))
				prefix += "-";

			String topic = prefix + topicRoot;

			logger.info("Returning topic: " + topic);

			return topic;
		}

		logger.info("Returning topic: " + topicRoot);
		return topicRoot;
	}

	/**
	 * Helper to lookup the prefix, if needed, and prepend with the topic root
	 *
	 * @param tierName       - The tier, if any, this request is associated with
	 * @param prefixOverride - Supply your own value for the prefix (Note an empty
	 *                       string is same as none)
	 *
	 * @return the prefix (if any)
	 * @throws Exception
	 *
	 */
	@Deprecated
	public String getTopicPrefix(String tierName, String prefixOverride) {
		// since the old method matched tier_global we want to preserve that from the
		// deprecated method
		return getTopicPrefix(tierName, null, true, prefixOverride, null);
	}

	/**
	 * Helper to lookup the prefix, if needed, and prepend with the topic root. If
	 * the component is specified it will look for exact component match or global
	 * component. If no component it will look for global then any component for
	 * that tier.
	 *
	 * @param tierName       - The tier, if any, this request is associated with
	 * @param componentName  The component this prefix is associated with
	 * @param prefixOverride - Supply your own value for the prefix and skip
	 *                       configuration lookup (Note an empty string is same as
	 *                       none)
	 * @param prefixDefault  - Supply a default value if none is found in
	 *                       configuration
	 *
	 * @return the prefix (if any)
	 * @throws Exception
	 *
	 */
	public String getTopicPrefix(String tierName, String componentName, String prefixOverride, String prefixDefault) {
		// new api should not use tier_global
		return getTopicPrefix(tierName, componentName, false, prefixOverride, prefixDefault);
	}

	protected String getTopicPrefix(String tierName, String componentName, boolean matchTierGlobal,
			String prefixOverride, String prefixDefault) {
		// With the addition of kafkaTopicPrefix to CloudFormation
		// and the new directive all topics should be prefixed
		// "" empty string is no longer considered a valid prefix
		// so the check for prefixOverride length will be added back again
		if (null != prefixOverride && prefixOverride.length() > 0)
			return prefixOverride;

		// look up the topic prefix
		// TODO: pass matchTierGlobal = false to disable the tier_global match for topic
		// prefix
		String prefix = lookupProperty(CONFIG_SERVER_KAFKA_TOPIC_PREFIX, tierName, componentName, matchTierGlobal, true,
				null == componentName ? true : false /* if the component name is null then match any component */);

		if (null != prefix && prefix.length() > 0)
			logger.info("Found topic prefix: " + prefix);
		else {
			if (null != prefixDefault) {
				prefix = prefixDefault;
				logger.info("Using defaultPrefix: ", prefix);
			} else {
				prefix = tierName + "-";
				logger.info("Using tier name as prefix: " + prefix);
			}
		}

		// doesn't matter if null or empty
		return prefix;
	}

	protected void createCache(int timeout) {
		if (null == configProperties) {
			// synchronized(KafkaTopicUtils.class)
			{
				// if(null == configProperties)
				{
					// Use concurrency 1 to to restrict access to one thread at a time
					configProperties = CacheBuilder.newBuilder().expireAfterWrite(timeout, TimeUnit.SECONDS)
							/* .maximumSize(10000) */.concurrencyLevel(1).removalListener(this).build();
				}
			}
		}
	}

	public void onRemoval(
			RemovalNotification<String, Map<String, Map<String, Map<String, ConfigProperty>>>> notification) {
		// if(logger.isDebugEnabled())
		// logger.debug("Event type is being removed for : "+ notification.getKey());

		if (notification.getCause() == RemovalCause.EXPIRED) {
			if (logger.isDebugEnabled())
				logger.debug("Item removed due to timeout: " + notification.getKey());
		} else {
			if (logger.isDebugEnabled())
				logger.debug("Item removed intentionally.");
		}

	}

	private List<ConfigProperty> getPropsByUrl(String surl) {
		int pageSize = 200;
		int pageStart = 0;
		boolean nextPage = true;
		List<ConfigProperty> allProps = null;

		while (nextPage) {
			String pagedURL = surl + "&start=" + pageStart + "&limit=" + pageSize;

			try {
				URL url = new URL(pagedURL);
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				con.setRequestMethod("GET");
				// set headers
				con.setRequestProperty("Accept", "application/json");
				con.setRequestProperty(ConfigProperty.AUDIT_COMPONENT_HEADER, "baldursoft");

				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				String inputLine;
				StringBuffer content = new StringBuffer();
				while ((inputLine = in.readLine()) != null) {
					content.append(inputLine);
				}
				in.close();
				con.disconnect();
				// initialize mapper in constructor - expensive object to build.
				ResourceCollection rc = mapper.readValue(content.toString(), ResourceCollection.class);
				List<ConfigProperty> props = rc.items;

				if (null == allProps) {
					allProps = props;
				} else
					allProps.addAll(props);

				if (null == props || (props.size() < pageSize))
					nextPage = false;
				else {
					pageStart += props.size();
				}

			} catch (Exception rce) {
				nextPage = false;
			}
		}
		return allProps;
	}

}
