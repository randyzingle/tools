package com.sas.mkt.kafka.clients.utils;


import org.junit.Test;

import com.sas.mkt.kafka.domain.system.MessageNotification;

public class MessageNotificationTest {
	
	@Test
	public void testCreateMessageNotifications() {

		MessageNotification built = MessageNotification.newBuilder().build();
		MessageNotification msg = new MessageNotification();
	}

}
