package com.sas.mkt.kafka.examples.config;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.TreeSet;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class SimpleConfigServerClient {

	private String configUrl = "http://configservice-dev.cidev.sas.us:8080/";
	private static String tierNm = "dev";
	private static String componentNm = "mkt-extapigw";
	private static String name = "";
	private static String value = "";

	private ObjectMapper mapper;

	public static void main(String[] args) {
		SimpleConfigServerClient scsc = new SimpleConfigServerClient();
		try {
			List<ConfigProperty> props = scsc.getProperties(tierNm, componentNm, name, value);
			// getComponents(props);
			printProps(props);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void printProps(List<ConfigProperty> props) {
		for (ConfigProperty prop : props) {
			System.out.println(prop);
		}

	}

	private static void getComponents(List<ConfigProperty> props) {
		TreeSet<String> set = new TreeSet();
		for (ConfigProperty prop : props) {
			set.add(prop.componentNm);
		}

		System.out.println("Found " + set.size() + " unique components");

		for (String s : set) {
			System.out.println(s);
		}
	}

	private SimpleConfigServerClient() {
		mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	}

	public List<ConfigProperty> getProperties(String tierName, String componentName, String name, String value)
			throws Exception {
		ConfigProperty cps = new ConfigProperty(tierName, componentName, name, null);
		List<ConfigProperty> props = getPagedProperties(cps);
		return props;
	}

//	private List<ConfigProperty> getProperties(ConfigProperty conf) throws Exception {
//
//		String surl = configUrl + ConfigProperty.COLLECTION_NAME + "?tierNm=" + tierNm + "&componentNm=" + componentNm
//				+ "&name=" + name + "&value=" + value + "&start=0&limit=500";
//
//		URL url = new URL(surl);
//		HttpURLConnection con = (HttpURLConnection) url.openConnection();
//		con.setRequestMethod("GET");
//		// set headers
//		con.setRequestProperty("Accept", "application/json");
//		con.setRequestProperty(ConfigProperty.AUDIT_COMPONENT_HEADER, "baldursoft");
//
//		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
//		String inputLine;
//		StringBuffer content = new StringBuffer();
//		while ((inputLine = in.readLine()) != null) {
//			content.append(inputLine);
//		}
//		in.close();
//		con.disconnect();
//
//		ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//
//		ResourceCollection rc = mapper.readValue(content.toString(), ResourceCollection.class);
//		List<ConfigProperty> props = rc.items;
//
//		return props;
//
//	}

	private List<ConfigProperty> getPagedProperties(ConfigProperty conf) throws Exception {

		String surl = configUrl + ConfigProperty.COLLECTION_NAME + "?tierNm=" + tierNm + "&componentNm=" + componentNm
				+ "&name=" + name + "&value=" + value;
		return getPropsByUrl(surl);

	}

	private List<ConfigProperty> getPropsByUrl(String surl) {
		int pageSize = 400;
		int pageStart = 0;
		boolean nextPage = true;
		List<ConfigProperty> allProps = null;

		while (nextPage) {
			String pagedURL = surl + "&start=" + pageStart + "&limit=" + pageSize;

			try {
				URL url = new URL(pagedURL);
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				con.setRequestMethod("GET");
				// set headers
				con.setRequestProperty("Accept", "application/json");
				con.setRequestProperty(ConfigProperty.AUDIT_COMPONENT_HEADER, "baldursoft");

				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				String inputLine;
				StringBuffer content = new StringBuffer();
				while ((inputLine = in.readLine()) != null) {
					content.append(inputLine);
				}
				in.close();
				con.disconnect();
				// initialize mapper in constructor - expensive object to build.
				ResourceCollection rc = mapper.readValue(content.toString(), ResourceCollection.class);
				List<ConfigProperty> props = rc.items;

				if (null == allProps) {
					allProps = props;
				} else
					allProps.addAll(props);

				if (null == props || (props.size() < pageSize))
					nextPage = false;
				else {
					pageStart += props.size();
				}

			} catch (Exception rce) {
				nextPage = false;
			}
		}
		return allProps;
	}

}