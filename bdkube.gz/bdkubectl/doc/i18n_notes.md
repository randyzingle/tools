# I18N Demo Notes

## Introduction
The I18N demo controller shows how to localize text using the Spring/Java localization mechanisms
and SAS Global English standards.


## Configuration
The WebMvcConfig.java file has been enhanced to configure the Spring localization behavior.
The location of the localized resource bundles is specified as being under the **/com/sas/mkt/example/messages/** sub-directory
in the resources directory and having the base-name of **L10nMessages**.

The default locale is specified as 'en' in the case that no locale can be determined on the web session.

Finally, a global optional URL parameter is defined, **lang=**, that can be used to force locale.  This
is useful when your browser is declaring one locale but you wish to get another locale's results.


## Message Digests
The localized message digest files are located under the mkt-template-microservice-service sub-project's
resources/directory. The localized files are under the **/com/sas/mkt/example/messages/** sub-directory and have files for default, English, US-English and German.

There is also a non-localized message digest file located under the **noi18n** sub-directory.


## Demo Controller
A new Spring Controller has been written that utilizes the localization mechanism: I18NDemoController.java.
This Controller will use both the localized and non-localized message bundles.  The non-localized message
bundle is loaded in the ```init()``` method.

The I18N demo URL declares an ```echo=``` parameter that will be sent back un-localized in the response.
The ```lang=``` parameter is not shown in the Swagger documentation but is processed on this URL.


## Using the Demo Controller
The following examples show the I18N demo controller in action:

US English locale automatically determined: http://localhost:8080/templateService/api/i18ndemo?echo=Hi%20there!

Output:

```
Our current locale: en_US
Our selected message file is: I18n_Messages_en_US.properties
We are echoing this back to you: Hi there!

Java string externalization: http://sww.sas.com/saspedia/Java_string_externalization
String key guidelines: http://sww.sas.com/saspedia/String_key_guidelines
Global English review process: http://sww.sas.com/saspediawiki/index.php?title=Global_English_review_process&redirect=no
Internationalization guidelines for writing messages: http://sww.sas.com/saspedia/Internationalization_guidelines_for_writing_messages
Placeholders in Messages: Standards and Examples: http://sww.sas.com/blogs/wp/sukoch/2016/09/15/placeholders-in-messages-standards-and-examples/
```

English forced by **lang=** parameter: http://localhost:8080/templateService/api/i18ndemo?echo=Hi%20there!&lang=en

Output:

```
Our current locale: en
Our selected message file is: I18n_Messages_en.properties
We are echoing this back to you: Hi there!

Java string externalization: http://sww.sas.com/saspedia/Java_string_externalization
String key guidelines: http://sww.sas.com/saspedia/String_key_guidelines
Global English review process: http://sww.sas.com/saspediawiki/index.php?title=Global_English_review_process&redirect=no
Internationalization guidelines for writing messages: http://sww.sas.com/saspedia/Internationalization_guidelines_for_writing_messages
Placeholders in Messages: Standards and Examples: http://sww.sas.com/blogs/wp/sukoch/2016/09/15/placeholders-in-messages-standards-and-examples/
```

German forced by **lang=** parameter: http://localhost:8080/templateService/api/i18ndemo?echo=Hi%20there!&lang=de

Output:

```
Unser aktueller Standort: de
Unsere ausgew?hlte Nachrichtendatei ist: I18n_Messages_de.properties
Wir geben Ihnen das zuruck: Hi there!

Java-String-Externalisierung: http://sww.sas.com/saspedia/Java_string_externalization
Stringschlussel-Richtlinien: http://sww.sas.com/saspedia/String_key_guidelines
Globaler englischer Review-Prozess: http://sww.sas.com/saspediawiki/index.php?title=Global_English_review_process&redirect=no
Internationalisierungsrichtlinien fur das Schreiben von Nachrichten: http://sww.sas.com/saspedia/Internationalization_guidelines_for_writing_messages
Platzhalter in Nachrichten: Standards und Beispiele: http://sww.sas.com/blogs/wp/sukoch/2016/09/15/placeholders-in-messages-standards-and-examples/
```

Invalid locale forced by **lang=** parameter, defaulting to en_US: http://localhost:8080/templateService/api/i18ndemo?echo=Hi%20there!&lang=george

Output:

```
Our current locale: george
Our selected message file is: I18n_Messages_en_US.properties
We are echoing this back to you: Hi there!

Java string externalization: http://sww.sas.com/saspedia/Java_string_externalization
String key guidelines: http://sww.sas.com/saspedia/String_key_guidelines
Global English review process: http://sww.sas.com/saspediawiki/index.php?title=Global_English_review_process&redirect=no
Internationalization guidelines for writing messages: http://sww.sas.com/saspedia/Internationalization_guidelines_for_writing_messages
Placeholders in Messages: Standards and Examples: http://sww.sas.com/blogs/wp/sukoch/2016/09/15/placeholders-in-messages-standards-and-examples/
```


