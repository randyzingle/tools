package com.sas.mkt.kafka.admin.topics.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;

import org.apache.avro.Schema;
import org.apache.avro.Schema.Field;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndTimestamp;
import org.apache.kafka.common.PartitionInfo;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.common.utils.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;

public class TopicUtils {
	
	private Logger logger = LoggerFactory.getLogger(TopicUtils.class);
	
	private static final int MAX_RECORDS = 2000;
	private static final List<String> noFilter = Arrays.asList("null", "map", "record");
	private Consumer<String, SpecificRecordBase> consumer;
	private Consumer<String, String> stringConsumer;
	private ApplicationConfiguration appConfig = new ApplicationConfiguration();
	
	// cached data
	List<String> topicList;
	Map<String, TopicInfo> topicInfoMap = new HashMap<>();
	
	private long countRecords(Map<TopicPartition, Long> startoff, Map<TopicPartition, Long> endoff) {
		long count = 0;
		Set<TopicPartition> endkeys = endoff.keySet();
		for (TopicPartition tp: endkeys) {
			count += endoff.get(tp) - startoff.get(tp);
		}
		return count;
	}
	
	/**
	 * Will return the a map with the TopicPartition as key and the first offset found after the supplied
	 * timestamp. If no offsets are found at or after the timestamp, for a partition, no data will be returned
	 * for that partition. 
	 * 
	 * @param consumer
	 * @param topic
	 * @param timestamp
	 * @return
	 */
	public Map<TopicPartition, OffsetAndTimestamp> offsetsForTimestamp(String topic, long timestamp, String keyFilter,
			Map<String, String> valueFilter) {
		Map<TopicPartition, OffsetAndTimestamp> offsetMap = null;
		Map<TopicPartition, Long> timestampsToSearch = new HashMap<>();

		// If we have a keyFilter just get the partition for that key:
		if (keyFilter != null && !keyFilter.isEmpty()) {
			StringSerializer stringSerializer = new StringSerializer();
	        byte[] keyBytes = stringSerializer.serialize(topic, keyFilter);
	        stringSerializer.close();
	        int numPartitions = consumer.partitionsFor(topic).size();
	        int partition = Utils.toPositive(Utils.murmur2(keyBytes)) % numPartitions;
	        TopicPartition tp = new TopicPartition(topic, partition);
	        timestampsToSearch.put(tp, timestamp);
		} else {
        // Otherwise get all the partitions
			List<PartitionInfo> partitionList = consumer.partitionsFor(topic);
			for (PartitionInfo pi: partitionList) {
				TopicPartition tp = new TopicPartition(pi.topic(), pi.partition());
				timestampsToSearch.put(tp, timestamp);
			}
		}

		offsetMap = consumer.offsetsForTimes(timestampsToSearch);
		TreeMap<TopicPartition, OffsetAndTimestamp> sortedMap = new TreeMap<>(Comparator.comparing(TopicPartition::partition));
		for (TopicPartition tp: offsetMap.keySet()) {
			if (offsetMap.get(tp) != null) {
				sortedMap.put(tp, offsetMap.get(tp));
			}
		}
		return sortedMap;
	}
	
	public TopicInfo getTopicInfo(String topic) {
		System.out.println(topic);
		TopicInfo topicInfo = null;
		long numberMessages = getNumberOfRecordsForTopic(topic);
		
		// if we don't have any messages we can't determine anything about the topic
		if (numberMessages == 0) {
			topicInfo = new TopicInfo(topic, TopicInfo.ValueType.Unknown, 0, null, null);
			return topicInfo;
		} 

		// we have messages - try to get Avro info
		consumer.subscribe(Arrays.asList(topic));
		boolean done = false;
		while (!done) {	
			try {
				// Try reading it as an Avro message (superclass SpecificRecordBase)
				ConsumerRecords<String, SpecificRecordBase> records = consumer.poll(1000);
				for (ConsumerRecord<String, SpecificRecordBase> record: records) {
					Schema schema = record.value().getSchema();
					List<FieldDTO> fieldList = getAvroFieldInfo(schema);
					topicInfo = new TopicInfo(topic, TopicInfo.ValueType.AvroType, numberMessages, schema.getName(), fieldList);
					done = true;
					break;
				}
			} catch (Exception ex) {		
				// it wasn't an Avro message
				topicInfo = new TopicInfo(topic, TopicInfo.ValueType.Unknown, numberMessages, null, null);
				done = true;
				break;
			}
		}
		consumer.unsubscribe();
		return topicInfo;
	}
	
	public List<FieldDTO> getAvroFieldInfo(Schema schema) {
		List<FieldDTO> fieldList = new ArrayList<>(); 
		List<Field> fields = schema.getFields();
		System.out.printf("Name: %s, FullName: %s%n",schema.getName(), schema.getFullName());
		for (Field f: fields) {
			List<Schema> typeList = f.schema().getTypes();
			String ftype = null;
			String s2 = "";
			List<String> enumList = null;
			for (Schema fschema: typeList) {
				ftype = fschema.getType().getName();
				if (ftype.equals("null")) {
					continue;
				}
				if (ftype.equals("enum")) {
					enumList = fschema.getEnumSymbols();
					s2 = enumList.toString();
				}
			}
			if (!noFilter.contains(ftype)) {
				System.out.println(f.name() + ": " + ftype + " " + s2);
				fieldList.add(new FieldDTO(f.name(), null, ftype, enumList));
			}
		}
		return fieldList;
	}
	
	public List<String> getTopics() {
		List<String> topicList = new ArrayList<>();
		Map<String, List<PartitionInfo>> topicMap = consumer.listTopics();
		Set<String> keySet = topicMap.keySet();
		topicList.addAll(keySet);
		return topicList;
	}
	
	public long getNumberOfRecordsForTopic(String topic) {
		long number = 0;

		List<PartitionInfo> pinfo = consumer.partitionsFor(topic);
		List<TopicPartition> plist = new ArrayList<>();
		for (PartitionInfo pi: pinfo) {
			TopicPartition tp = new TopicPartition(pi.topic(), pi.partition()); 
			plist.add(tp);
		}
		Map<TopicPartition, Long> startoff = consumer.beginningOffsets(plist);
		Map<TopicPartition, Long> endoff = consumer.endOffsets(plist);
		number = countRecords(startoff, endoff);
	
		return number;
	}
	
	public Map<String, Long> getNumberOfRecordsForAllTopics() {
		Map<String, Long> topicMap = new HashMap<>();
		List<String> topics = getTopics();
		for (String topic: topics) {
			long nrecords = getNumberOfRecordsForTopic(topic);
			topicMap.put(topic, nrecords);
		}
		return topicMap;
	}
	
	public RecordSetDTO readMessagesInTimeRange(String topic, long startTime, long endTime, String keyFilter,
			Map<String, String> valueFilter) {
		if (consumer == null) init();
		// should throw exceptions in this method rather than returning null...
		if (startTime > endTime) return null;
		String s = String.format("looking for message from %s to %s%n", new Date(startTime).toString(), new Date(endTime).toString());
		logger.debug(s);
		boolean done = false;
		
		List<RecordDTO> recordList = new ArrayList<>(MAX_RECORDS);
		RecordSetDTO srs = new RecordSetDTO();
		// this will return an empty map if no offsets are found
		Map<TopicPartition, OffsetAndTimestamp> startOffsets = offsetsForTimestamp(topic, startTime, keyFilter, valueFilter);
		if (startOffsets == null || startOffsets.isEmpty())
			return null;
		Set<TopicPartition> tpSet = startOffsets.keySet();
		consumer.assign(tpSet);
		for (TopicPartition tp : startOffsets.keySet()) {
			consumer.seek(tp, startOffsets.get(tp).offset());
		}
		int cnt = 0;
		long first = Long.MAX_VALUE;
		long last = Long.MIN_VALUE;
		Set<TopicPartition> doneList = new HashSet<>(startOffsets.size());
		int emptyPolls = 0;
		while (!done) {
			ConsumerRecords<String, SpecificRecordBase> records = consumer.poll(1000);
			if (records.isEmpty()) {
				emptyPolls++;
			} else {
				emptyPolls = 0;
			}
			if (emptyPolls > 2) {
				System.out.println("Too many empty loops, timing out....");
				done = true;
				break;
			}
			for (ConsumerRecord<String, SpecificRecordBase> record : records) {
				boolean valid = true;
				long timestamp = record.timestamp();
				cnt++;
				if (timestamp > endTime) {
					cnt--;
					doneList.add(new TopicPartition(record.topic(), record.partition()));
					consumer.pause(doneList);
					if (doneList.size() == startOffsets.size()) {
						System.out.println("Partitions all drained for time window....");
						done = true;
						break;
					} else {
						continue;
					}
				}
				if (cnt > MAX_RECORDS) {
					System.out.println("Hit max records limit....");
					done = true;
					break;
				}
				if (timestamp < first) {
					first = timestamp;
				}
				if (timestamp > last) {
					last = timestamp;
				}
				// more than one key may be serialized to the same partition, make sure this record has the right key
				if (keyFilter !=null && !keyFilter.isEmpty()) {
					if (!record.key().equals(keyFilter)) {		
						valid = false;
						cnt--;
					} 
				}
				if (valid && valueFilter != null && !valueFilter.isEmpty()) {
					Set<String> keySet = valueFilter.keySet();
					for (String key: keySet) {
						String filter = valueFilter.get(key);
						String value = record.value().get(key).toString();
						if (!filter.equals(value)) {
							valid = false;
							cnt--;
						}
					}
				}	
				if (valid) {
					RecordDTO sr = new RecordDTO();
					sr.key = record.key();
					sr.offset = record.offset();
					sr.partition = record.partition();
					sr.timestamp = record.timestamp();
					Map<String, String> vmap = new HashMap<>();
					vmap.put("value", record.value().toString());
					sr.value = vmap;
					recordList.add(sr);
				}
			}

		}

		System.out.printf("%d messages in messageList%n", recordList.size());
		System.out.println("first message: " + new Date(first).toString());
		System.out.println("last message: " + new Date(last).toString());
		done = false;
		srs.firstTimeStamp = first;
		srs.lastTimeStamp = last;
		srs.requestedStartTime = startTime;
		srs.requestedEndTime = endTime;
		srs.topic = topic;
		srs.recordList = recordList;
		return srs;
	}
	
	public void init() {
		consumer = getConsumer();
		topicList = getTopics();
		System.out.printf("found %d topics%n", topicList.size());
	}
	
	public void destroy() {
		System.out.println("Shutting down...");
		if (consumer != null) {
			consumer.unsubscribe();
			consumer.close();
		}
		if (stringConsumer != null) {
			stringConsumer.unsubscribe();
			stringConsumer.close();
		}
	}

	public Consumer<String, SpecificRecordBase> getConsumer() {
		KafkaConnectionUtils kcu;
		try {
			kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			return null;
		}
		String groupID = appConfig.getTierName() + "-" + appConfig.getComponentName();
		Properties props = kcu.getKafkaConsumerProperties();
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
		consumer = new KafkaConsumer<>(props);
		return consumer;
	}
	
	public Consumer<String, String> getStringConsumer() {
		KafkaConnectionUtils kcu;
		try {
			kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			return null;
		}
		String groupID = appConfig.getTierName() + "-" + appConfig.getComponentName();
		Properties props = kcu.getKafkaConsumerProperties();
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, org.apache.kafka.common.serialization.StringDeserializer.class);
		stringConsumer = new KafkaConsumer<>(props);
		return stringConsumer;
	}

}
