'''
Configure an Event Notification for an S3 bucket

Source code located in GitLab:
    https://gitlab.sas.com/CustomerIntelligence/Shared/mkt-kafka-tools

Configuration:
"Handler": "KafkaConnectBucketNotification.handler"
"Runtime": "python3.6"
"Timeout": "300"

Jan 2, 2019
@author: razing
'''
import json
from urllib.request import urlopen, Request, HTTPError, URLError
from urllib.parse import urlencode
import boto3

# ===============================================================================
#  Constants
# ===============================================================================
STATUS_FAILED = 'FAILED'
STATUS_SUCCESS = 'SUCCESS'

# ===============================================================================
#  Entry Point for Lambda
# ===============================================================================
def handler(event, context):
    print('event')
    print(event)
    print('context')
    print(context)
    request_type = event['RequestType']

    if request_type == 'Create':
        create_resources(event, context)
    elif request_type == 'Update':
        update_resources(event, context)
    elif request_type == 'Delete':
        delete_resources(event, context)
    else:
        print(request_type, ':Not a proper request-type, should be one of [Create|Update|Delete]')

# ===============================================================================
#  Functions that response to Create, Update, and Delete CF Events
# ===============================================================================
def create_resources(event, context):
    print('creating resource')
    notification = construct_notification(event)
    print(notification)
    bucket_name = event['ResourceProperties']['BucketName']
    try:
        put_notification(bucket_name, notification)
        send_response(event, STATUS_SUCCESS)
    except Exception as e:
        send_response(event, STATUS_FAILED)
        print(e)


def update_resources(event, context):
    print('updating resource')
    create_resources(event, context)

def delete_resources(event, context):
    print('deleting resources')
    send_response(event, STATUS_SUCCESS)

def construct_notification(event):
    sns_topic_arn = event['ResourceProperties']['TopicArn']
    notification_configuration = {
        'TopicConfigurations': [
            {
                'Id': 'kafka-connect',
                'TopicArn': sns_topic_arn,
                'Events': ['s3:ObjectCreated:*'],
                'Filter': {
                    'Key': {
                        'FilterRules': [
                            {
                                'Name': 'prefix',
                                'Value': 'topics/'
                            },
                        ]
                    }
                }
            },
        ]
    }
    return notification_configuration

def put_notification(bucket_name, notification):
    print('put notification')
    s3 = boto3.resource('s3')
    bucket_notification = s3.BucketNotification(bucket_name)
    response = bucket_notification.put(NotificationConfiguration=notification)

# ===============================================================================
#  Cloudformation HTTP PUT response indicating SUCCESS or FAILURE of lambda
# ===============================================================================
def send_response(event, responseStatus):
    print('send CF response')
    data = {}
    data['BucketName'] = event.get('BucketName', 'None')
    data['TopicArn'] = event.get('TopicArn', 'None')
    responseBody = {
        'Status': responseStatus,
        'Reason': 'See the details in CloudWatch Log Stream',
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'Data': data
    }
    responseBody['PhysicalResourceId'] = event.get('PhysicalResourceId', 'None')
    edata = json.dumps(responseBody)
    edata = edata.encode('utf-8')
    headers = {'Content-Length': len(edata), 'Content-Type': ''}
    req = Request(
        event['ResponseURL'],
        headers=headers,
        data=edata,
        method='PUT')
    req.get_method = lambda: 'PUT'
    try:
        urlopen(req)
    except Exception as e:
        print(e)
