package com.sas.mkt.baldur.spring.metrics;

public class RegistryFilter {
	public String name;
	public String value;
}
