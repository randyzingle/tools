package com.sas.mkt.baldur.spring.startup;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.event.EventListener;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import com.sas.mkt.baldur.spring.kafka.KafkaConfig;
import com.sas.mkt.baldur.spring.kafka.KafkaConsumerDriver;
import com.sas.mkt.baldur.spring.kafka.KafkaProducerDriver;
import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.core.ApplicationConstants;
import com.sas.mkt.config.core.BaseUtils;
import com.sas.mkt.config.core.PropertyDetails;
import com.sas.mkt.config.core.events.ApplicationConfigurationEvent;

@Component
public class KafkaStartupRunner implements ApplicationRunner, Ordered {

	private final static Logger logger = LoggerFactory.getLogger(KafkaStartupRunner.class);
	
	@Autowired
	KafkaProducerDriver kafkaProducerDriver;

	@Autowired
	KafkaConsumerDriver kafkaConsumerDriver;
	
	@Autowired
	ApplicationConfiguration appConfig;
	
	public KafkaStartupRunner(KafkaConfig kafkaConfig, KafkaProducerDriver kafkaProducerDriver) {
		this.kafkaProducerDriver = kafkaProducerDriver;
	}

	@Override
	public int getOrder() {
		return ApplicationConstants.CONFIG_SERVICE_RUNNER_ORDER + 20;
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
//		BaseUtils.bigPrint("Firing Up Kafka Workers!");
//		logger.info("Firing Up Kafka Workers!");
//		kafkaProducerDriver.start();
//		kafkaConsumerDriver.start();
	}
	
//	@EventListener
//    public void handleApplicationConfigurationChanged(ApplicationConfigurationEvent ace) { 
//        for (PropertyDetails pd: ace.getOverrideList()) {
//        	if (pd.getName().equals("kafkaProducerProperties")) {
//        		kafkaProducerDriver.restart();
//        	} else if (pd.getName().equals("kafkaConsumerProperties")) {
//        		kafkaConsumerDriver.restart();
//        	} else {
//        		// I don't care - this wasn't a property I'm interested in
//        		System.out.println("who cares...");
//        	}
//        }
//    }

}
