package com.sas.mkt.kafka.tools.s3connect;

import org.springframework.stereotype.Component;

@Component
public class AlertManager {
	
//	private final static Logger logger = LoggerFactory.getLogger(AlertManager.class);
//	
//	private int mercyCounter = 0;
//	private long lastAlert = 0;
//	private static final int ONE_HOUR = 3600000;
//	
////	public static void main(String[] args) {
////		AlertManager am = new AlertManager();
////		am.sendAlert("alert@!");
////	}
//	
//	public void sendAlert(String alert) {
//		if (mercyCounter < 10) {
//			lastAlert = System.currentTimeMillis();
//			mercyCounter++;
//		} else {
//			long timeSinceLastAlert = System.currentTimeMillis() - lastAlert;
//			if (timeSinceLastAlert < ONE_HOUR * 24) {
//				// give it a break
//				return;
//			} else {
//				mercyCounter = 0;
//			}
//		} 
//		BaseUtils.bigPrint(alert);
//		String topicArn = getTopicArn();
//		BaseUtils.bigPrint("topic arn: " + topicArn);
//
//		Region region = getRegion(topicArn);
//		AmazonSNSClientBuilder builder = AmazonSNSClientBuilder.standard().withRegion(region.getName());
//		AmazonSNS snsClient = builder.build();
//		
//		PublishRequest request = new PublishRequest(topicArn, alert);
//		String key = "event";
//		MessageAttributeValue value = new MessageAttributeValue();
//		value.setDataType("String.Array");
//		value.setStringValue("[\"alarm\"]");
//		request.addMessageAttributesEntry(key, value);
//		PublishResult result = snsClient.publish(request);
//		System.out.println(result.toString());
//		logger.info(result.toString());
//	}
//	
//	private String getTopicArn() {
//		String arn = null;
//		AWSSimpleSystemsManagement ssmClient = AWSSimpleSystemsManagementClientBuilder.defaultClient();
//		GetParameterRequest request = new GetParameterRequest();
//		request.setName("/dev-mkt-config/tier_global/mkt-kafka/sas.mkt.kafka.connect.s3.topic");
//		GetParameterResult ssmResult = ssmClient.getParameter(request);
//		arn = ssmResult.getParameter().getValue();
//		return arn;
//	}
//	
//    private Region getRegion(String arn) {
//    	// try to parse the region from the topic arn - will only need this in the dev envs
//    	Region region = null;
//    	String[] temp = arn.split("kafka-s3connect-");
//    	if (temp != null && temp.length == 2) {
//    		String s = temp[1];
//    		int idx = s.indexOf("-");
//    		if (idx != -1) {
//    			String sr = s.substring(idx+1);
//    			region = RegionUtils.getRegion(sr);
//    			if (region != null) return region;
//    		}
//    		
//    	} 
//    	// we failed to parse the region from the sns topic, try the local region
//    	region = Regions.getCurrentRegion();
//    	if (region == null) {
//    		region = RegionUtils.getRegion("us-east-1");
//    	}
//    	return region;
//    }

}
