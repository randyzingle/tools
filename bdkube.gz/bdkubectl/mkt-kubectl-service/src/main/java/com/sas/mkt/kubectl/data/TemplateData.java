package com.sas.mkt.kubectl.data;

import java.util.Map;

public class TemplateData {

	public String template;
	public String version;
	public boolean apply;
	public boolean abort;
	public String lifecycle;
	public Map<String, String> parameters;
	public Results results = new Results();
	public StringBuilder response = new StringBuilder();
	@Override
	public String toString() {
		return "TemplateData [template=" + template + ", version=" + version + ", apply=" + apply + ", lifecycle="
				+ lifecycle + ", parameters=" + parameters + ", results=" + results + ", response=" + response + "]";
	}
		
}
