package com.sas.mkt.kafka.harness;

import java.util.Arrays;
import java.util.Properties;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;
import org.springframework.beans.factory.annotation.Autowired;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;

public class SimpleConsumerAssign implements WakeableConsumer {

	private ApplicationConfiguration appConfig;
	private boolean done = false;
	
	@Autowired
	public Consumer<String, SpecificRecordBase> consumer;
	
	@Autowired
	public SimpleConsumerAssign(ApplicationConfiguration appConfig) {
		this.appConfig = appConfig;
	}
	
	public void init() {
		KafkaConnectionUtils kcu = null;
		try {
			kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return;
		}
		Properties consumerProperties = kcu.getKafkaConsumerProperties(appConfig.getTierName(), appConfig.getComponentName());
		String groupID = appConfig.getTierName() + "-" + appConfig.getComponentName() + System.currentTimeMillis();
		consumerProperties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		consumerProperties.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		consumer = new KafkaConsumer<>(consumerProperties);
	}
	
	public void consumeWithAssign() {
		System.out.println("Consuming messages with assign...");
		String topic = "baldur-test-events";
        TopicPartition topicPartition = new TopicPartition(topic, 0);
        consumer.assign(Arrays.asList(topicPartition));

		// Consume Messages
		try {
			while (!done) {	
				ConsumerRecords<String, SpecificRecordBase> records = consumer.poll(100);
				for (ConsumerRecord<String, SpecificRecordBase> record: records) {
					System.out.println(record.value());
				}	
			}
		} catch (WakeupException wex) {
			wex.getMessage();
		} finally {
			consumer.close();
		}
	}
	
	@Override
	public void wakeUp() {
		done = true;
	}

}
