package com.sas.mkt.config.metrics;

import java.net.Inet4Address;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.codahale.metrics.ConsoleReporter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Slf4jReporter;
import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.core.PropertyDetails;
import com.sas.mkt.config.core.events.ApplicationConfigurationEvent;

@Component
public class MetricReporterRegistry {
	private final static Logger logger = LoggerFactory.getLogger(MetricReporterRegistry.class);
	private final static int DEFAULT_REPORT_FREQUENCY_SECONDS = 300; // five minutes

	@Autowired
	ApplicationConfiguration appConfig;

	@Autowired
	MetricRegistry metricRegistry;

	public Map<String, Boolean> reporterMap = new HashMap<>();
	public static final String CONSOLE_REPORTER = "console-reporter";
	public static final String LOG_REPORTER = "log-reporter";
	public static final String CLOUDWATCH_REPORTER = "cloudwatch-reporter";

	private List<String> configList = Arrays.asList("cloudWatchMetricsFilters", "cloudWatchMetricsReporterRateSec",
			"cloudWatchMetricsReporterActivated", "consoleMetricsFilters", "consoleMetricsReporterRateSec",
			"consoleMetricsReporterActivated", "loggerMetricsFilters", "loggerMetricsReporterRateSec",
			"loggerMetricsReporterActivated");
	private CloudWatchReporter cloudWatchReporter;
	private ConsoleReporter consoleReporter;
	private Slf4jReporter logReporter;

	public SortedSet<String> getMetricNames() {
		return metricRegistry.getNames();
	}

	public SortedSet<String> getActiveReporters() {
		SortedSet<String> activeSet = new TreeSet<>();
		Set<String> keySet = reporterMap.keySet();
		for (String key : keySet) {
			if (reporterMap.get(key) == true) {
				activeSet.add(key);
			}
		}
		return activeSet;
	}

	@EventListener
	public void handleApplicationConfigurationChanged(ApplicationConfigurationEvent ace) {
		System.out.println("Config change notice in MetricReporterRegistry");
		logger.debug("application configuration changed: {}", ace.getOverrideList().toString());
		for (PropertyDetails pd : ace.getOverrideList()) {
			if (configList.contains(pd.getName())) {
				System.out.println("Config change in MetricReporterRegistry ... restarting reporters");
				restart();
			}
		}
	}

	private void restart() {
		// Let's do this the lazy way!
		if (cloudWatchReporter != null)
			cloudWatchReporter.stop();
		if (consoleReporter != null)
			consoleReporter.stop();
		if (logReporter != null)
			logReporter.stop();
		init();
	}

	// TODO and start stop config change listeners
	public void init() {

//		// CloudWatch Reporter
//		if (appConfig.cloudWatchMetricsReporterActivated) {
//			cloudWatchReporter = getCloudWatchReporter();
//			cloudWatchReporter.start(appConfig.cloudWatchMetricsReporterRateSec, TimeUnit.SECONDS);
//		}
//
//		// Console Reporter
//		if (appConfig.consoleMetricsReporterActivated) {
//			consoleReporter = getConsoleReporter();
//			consoleReporter.start(appConfig.consoleMetricsReporterRateSec, TimeUnit.SECONDS);
//		}

		// Log Reporter only writes if the logger is at INFO level or above
//		if (appConfig.isLoggerMetricsReporterActivated()) {
//			logReporter = getSlf4jReporter();
//			logReporter.start(appConfig.getLoggerMetricsReporterRateSec(), TimeUnit.SECONDS);
//		}

	}

//	private CloudWatchReporter getCloudWatchReporter() {
//		CustomMetricFilter cloudWatchMetricFilter = new CustomMetricFilter(appConfig.cloudWatchMetricFilters);
//		String nameSpace = String.format("SAS/CI360/%s/%s", appConfig.tierName, appConfig.componentName);
//		String host = this.getHost();
//		Map<String, String> baseDimensions = new HashMap<>();
//		baseDimensions.put("host", host);
//		cloudWatchReporter = CloudWatchReporter.forRegistry(metricRegistry).filter(cloudWatchMetricFilter)
//				.withNameSpace(nameSpace).withName(CLOUDWATCH_REPORTER).withBaseDimensions(baseDimensions).build();
//		reporterMap.put(CLOUDWATCH_REPORTER, true);
//		return cloudWatchReporter;
//	}
//
//	private ConsoleReporter getConsoleReporter() {
//		CustomMetricFilter customMetricFilter = new CustomMetricFilter(appConfig.consoleMetricsFilters);
//		consoleReporter = ConsoleReporter.forRegistry(metricRegistry).filter(customMetricFilter)
//				.convertRatesTo(TimeUnit.SECONDS).convertDurationsTo(TimeUnit.MILLISECONDS).build();
//		reporterMap.put(CONSOLE_REPORTER, true);
//		return consoleReporter;
//	}

	private String getHost() {
		String host = "unknown";
		try {
			host = Inet4Address.getLocalHost().getHostAddress();
		} catch (UnknownHostException e) {
			logger.warn("failed to get host IP Address: {}", e.getMessage());
		}
		return host;
	}

}
