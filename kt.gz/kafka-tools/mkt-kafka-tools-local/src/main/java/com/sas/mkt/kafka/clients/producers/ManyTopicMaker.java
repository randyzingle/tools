package com.sas.mkt.kafka.clients.producers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.Metric;
import org.apache.kafka.common.MetricName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.clients.producers.utils.TestRecordGenerator;
import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.domain.TestEvent;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;


public class ManyTopicMaker {
	
	private static final Logger logger = LoggerFactory.getLogger(ManyTopicMaker.class);

	ApplicationConfiguration appConfig = new ApplicationConfiguration();

	public static void main(String[] args) {
		ManyTopicMaker app = new ManyTopicMaker();
		app.appConfig.setConfigServiceUrl("http://configservice-dev.cidev.sas.us:8080/");
		app.fireAndForget();
	}
	
	private void fireAndForget() {
		KafkaConnectionUtils kcu;
		try {
			kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			System.out.println(ex.toString());
			return;
		}
		
		String clientID = appConfig.getTierName() + "-" + appConfig.getComponentName();
		Properties props = kcu.getKafkaProducerProperties(clientID);
		Producer<String, SpecificRecordBase> producer = new KafkaProducer<>(props);
		TestRecordGenerator werg = new TestRecordGenerator();
		
		
		for (int kk=0; kk<20; kk++) {
			String topic = "mymir"+kk+"-test-events";
			// create the ProducerRecord and send ignoring the returned RecordMetadata
			int cnt = 0;
			int nloops = 50;
			int nrecords = 1 * 5000;
	
			List<TestEvent> weblist = null;
			List<String> tenants = new ArrayList<>();
			int ntenants = 100;
			for (int i=0; i<ntenants; i++) {
				tenants.add("baldursoftinc"+i);
			}
			for (int i=0; i<nloops; i++) {
				weblist = werg.getTestEventList(nrecords/nloops, 5000);
				for (TestEvent we: weblist) {
					int index = (int) (Math.random() * 100);
					we.setTenant(tenants.get(index));
					cnt++;
					ProducerRecord<String, SpecificRecordBase> record = new ProducerRecord<>(topic, we.getTenant(), we);
					// note, send() actually places the message in a buffer which is read and sent by a separate thread
					producer.send(record);
					if (cnt%(nrecords/nloops)==0) {
						System.out.println(record.key());
						System.out.println(cnt + "\n");
						logger.info("sent message " + cnt);
					}
				}
			}
			System.out.printf("Produced %d records...", cnt);
			
			// give the buffer a chance to empty out
			producer.flush();
		
		
		}
		long sleep = 2000L;
		producer.close(sleep, TimeUnit.MILLISECONDS);
	}
}
