#!/bin/bash

#
# Gather up markdown files and put into 1 Saspedia mediawiki file.
#
# NOTE: If you don't know what this script is...DO NOT RUN IT!
#

# Swagger dir
swaggerDir=../mkt-template-microservice-service/build/asciidoc/generated/swagger_adoc

# Output mediawiki file
outputFile=./mediawiki.txt

# Saspedia category
wikiCategory="[[Category:TNG CI Development]]"

#
# = Top Section =
#
# == Second Level ==
#


# Mainly developer info
frontDevPageDoc=../README.md

# mkt-config
configSvcDoc=./config_service.md

# Liquibase
liquibaseDoc=./liquibase.md

# Eclipse notes
eclipseDoc=./eclipse_dev_notes.md

# I18N notes
i18NotesDoc=./i18n_notes.md

# Swagger docs
swaggerOverviewDoc=./swagger/overview.md
swaggerDefinitionsDoc=./swagger/definitions.md
swaggerPathsDoc=./swagger/paths.md

# Pandoc untility
PANDOC="pandoc --from=markdown --to=mediawiki --output=$outputFile"

function main {
  rm -f "$outputFile"

  if [[ -f $swaggerDir/overview.md ]] ; then
    cp $swaggerDir/*.md ./swagger/.
  else
    echo "Cannot find swagger markdown files!"
    exit 1
  fi

  $PANDOC \
    $frontDevPageDoc \
    $configSvcDoc \
    $liquibaseDoc \
    $eclipseDoc \
    $i18NotesDoc \
    $swaggerOverviewDoc \
    $swaggerDefinitionsDoc \
    $swaggerPathsDoc

  echo "$wikiCategory" >> $outputFile


}

main "$@"
