package com.sas.mkt.template.docker.TEMPLATESAMPLE.data;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface WidgetRepository extends JpaRepository<Widget, Long>{
	List<Widget> findByCompany(String company);
	Widget findById(long id);
}

