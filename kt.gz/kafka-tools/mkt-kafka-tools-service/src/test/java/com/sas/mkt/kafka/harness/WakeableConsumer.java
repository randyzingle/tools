package com.sas.mkt.kafka.harness;

public interface WakeableConsumer {
	
	public void wakeUp();

}
