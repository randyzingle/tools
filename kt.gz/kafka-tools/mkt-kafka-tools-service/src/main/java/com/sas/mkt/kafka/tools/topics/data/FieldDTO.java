package com.sas.mkt.kafka.tools.topics.data;

import java.io.Serializable;
import java.util.List;

public class FieldDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private String name;
	private String value;
	private String type;
	private List<String> enumValues;
	
	public FieldDTO() {}
	
	public FieldDTO(String name, String value, String type, List<String> enumValues) {
		super();
		this.name = name;
		this.value = value;
		this.type = type;
		this.enumValues = enumValues;
	}
	
	public String getName() {
		return name;
	}
	public String getValue() {
		return value;
	}
	public String getType() {
		return type;
	}
	public List<String> getEnumValues() {
		return enumValues;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("FieldDTO [name=").append(name).append(", value=").append(value).append(", type=").append(type)
				.append(", enumValues=").append(enumValues).append("]");
		return builder.toString();
	}

}
