# Level 0 healthchecks

The current mkt-test-pipeline.zip built from the Test/mkt-test-pipeline repo is download from
S3 for the current release, extracted and the <Island>/<repo>.robot tests tagged with the
"lev0" tag are executed as part of this subproject to verify that the deployed stack is
functional.

