/**
 * 
 */
package com.sas.mkt.kafka.clients.files;

import java.io.File;

import org.apache.avro.file.DataFileReader;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.DatumReader;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sas.mkt.kafka.domain.events.EnhancedEvent;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;

/**
 * @author razing
 *
 */
public class KafkaFileSource {

    private String fileName;
    private ApplicationConfiguration appConfig = new ApplicationConfiguration();

    public static void main(String[] args) {
        KafkaFileSource kfs = new KafkaFileSource();
        try {
        	String fileBase = "baldur-enhanced-events";
        	kfs.fileName = "src/main/resources/data/"+fileBase+".avro";
        	kfs.generic();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void generic() throws Exception {
        File avroFile = new File(fileName);
        DatumReader<GenericRecord> reader = new GenericDatumReader<GenericRecord>();
        DataFileReader<GenericRecord> fileReader = new DataFileReader<GenericRecord>(avroFile, reader);
        GenericRecord record = new GenericData.Record(fileReader.getSchema());
//        ObjectMapper mapper = new ObjectMapper();
        int cnt = 0;
        while (fileReader.hasNext()) {
        	cnt++;
            fileReader.next(record);   
            String newRec = record.toString();
//            EnhancedEvent event = mapper.readValue(newRec, EnhancedEvent.class); 
            System.out.println(cnt + ": " + newRec);

        }
        fileReader.close();
        System.out.println("Found " + cnt  + " records");
    }


}
