package com.sas.mkt.baldur.spring.kafka;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.producer.BufferExhaustedException;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.Metric;
import org.apache.kafka.common.MetricName;
import org.apache.kafka.common.errors.InterruptException;
import org.apache.kafka.common.errors.SerializationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.clients.utils.KafkaGauges;
import com.sas.mkt.kafka.domain.TestEvent;

@Component
public class SampleProducer implements Runnable {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	List<String> producerMetrics = Arrays.asList("record-error-rate", "request-latency-avg", "outgoing-byte-rate",
			"record-send-rate", "request-rate", "record-queue-time-avg", "records-per-request-avg");

	@Autowired
	ApplicationConfiguration appConfig;
	
	private AtomicBoolean stop = new AtomicBoolean(false);

	private static int nrecords = 5 * 1000;
	private static int npasses = 500 * 1000;
	private int total = 0;
	private Producer<String, SpecificRecordBase> producer;

	TestRecordGenerator recordGenerator = new TestRecordGenerator();
	
	public void stop() {
		stop.set(true);
		producer.flush();
		producer.close();
	}

	private Producer<String, SpecificRecordBase> getProducer() {
		// get the Fire-And-Forget Producer from our utility class
		KafkaConnectionUtils kcu;
		try {
			kcu = KafkaConnectionUtils.getInstance(appConfig.configServiceUrl);
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			return null;
		}
		Properties producerProps = kcu.getKafkaProducerProperties(appConfig.tierName, appConfig.componentName);
		System.out.println("PRODUCER-KEYSET++++");
		Set<Object> keys = producerProps.keySet();
		List<String> list = new ArrayList<>();
		for (Object o : keys) {
			list.add(o.toString());
		}
		Collections.sort(list);
		for (String s : list) {
			System.out.println(s + ": " + producerProps.get(s));
		}
		System.out.println("END-KEYSET+++++++++");
		Producer<String, SpecificRecordBase> p = new KafkaProducer<>(producerProps);
		return p;
	}

	@Override
	public void run() {
		stop.set(false);
		producer = getProducer();
		this.examineMetrics(producer, "PHASE1********");
		this.registerMetrics(producer);
		for (int i = 0; i < npasses; i++) {
			sendMessages(producer, recordGenerator.getTestEventList(nrecords));
			if (stop.get()) break;
		}
		producer.close();
	}

	public void sendMessages(Producer<String, SpecificRecordBase> producer, List<TestEvent> testRecords) {
		if (producer == null)
			return;
//		System.out.println("Sending: " + testRecords.size() + " messages.");
		// create the ProducerRecord and send ignoring the returned RecordMetadata
		int cnt = 0;
		for (TestEvent tr : testRecords) {
			cnt++;
			total++;
			ProducerRecord<String, SpecificRecordBase> record1 = new ProducerRecord<>(KafkaConfig.BALDUR_TOPIC,
					tr.getTenant(), tr);
//			ProducerRecord<String, SpecificRecordBase> record2 = new ProducerRecord<>(KafkaConfig.FINNR_TOPIC,
//					tr.getTenant(), tr);
			// note, send() actually places the message in a buffer which is read and sent
			// by a separate thread
			try {
				producer.send(record1);
//				producer.send(record2);
				// NEED TO REGISTER METRICS ONE TIME HERE AFTER FIRST SEND TO PICK UP GROUPS:
				// producer-topic-metrics
				// producer-node-metrics
			} catch (SerializationException | BufferExhaustedException | InterruptException ex) {
				logger.warn("producer failed: {}", ex.getMessage());
			}
			if (cnt % 5000 == 0) {
				logger.info("sent message " + total);
//				examineMetrics(producer, "looping");
				System.out.println(total + "-producer: " + record1.value().toString());
//				try {
//					Thread.sleep(500l);
//				} catch (InterruptedException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
			}
		}
		// give the buffer a chance to empty out
		long sleep = Math.max(1000L, nrecords / 25L);

		logger.info("Sleeping for " + sleep + " msec to let buffers drain");
		try {
			Thread.sleep(sleep);
		} catch (Exception ex) {
			logger.warn(ex.getMessage());
		}
//		producer.close();

	}
	
	private void registerMetrics(Producer<String, SpecificRecordBase> producer) {	
		KafkaGauges.getKafkaGauges().registerProducerMetricsAsGauges(producer);
	}

	private void examineMetrics(Producer<String, SpecificRecordBase> producer, String message) {
		
		Map<MetricName, ? extends Metric> map = producer.metrics();
		Set<MetricName> mset = map.keySet();
		for (MetricName mn : mset) {
			Metric metric = map.get(mn);
			if (metric.metricName().group().equals("producer-metrics") && this.producerMetrics.contains(metric.metricName().name())) {
				System.out.printf("group: %s, name: %s, value: %s%n", metric.metricName().group(),
						metric.metricName().name(), metric.metricValue());
			}
		}

		Map<String, Integer> groups = new HashMap<>();
		for (MetricName name : mset) {
			Metric metric = map.get(name);
			String group = metric.metricName().group();
			if (groups.containsKey(group)) {
				groups.put(group, groups.get(group) + 1);
			} else {
				groups.put(group, 1);
			}
		}
		System.out.println(message);
		for (String gname : groups.keySet()) {
			System.out.printf("    %s: %d%n", gname, groups.get(gname));
		}
	}

	public class TestRecordGenerator {

		public List<TestEvent> getTestEventList(int nrecords) {

			Random rnd = new Random();
			List<TestEvent> elist = new ArrayList<TestEvent>(nrecords);
			int seq = 1;
			for (int i = 0; i < nrecords; i++) {
				long time = System.currentTimeMillis();
				String site = "www.razing.com";
				String ip = "192.168.2." + rnd.nextInt(255);
				String tenant = null;
				int nexti = rnd.nextInt(5);
				if (nexti == 0)
					tenant = "baldursoft" + rnd.nextInt(50);
				if (nexti == 1)
					tenant = "mymir-ai" + rnd.nextInt(50);
				if (nexti == 2)
					tenant = "butters" + rnd.nextInt(50);
				if (nexti == 3)
					tenant = "gabriel" + rnd.nextInt(50);
				if (nexti == 4)
					tenant = "rafael" + rnd.nextInt(50);
				TestEvent.Builder bdr = TestEvent.newBuilder();
				bdr.setIp(ip).setSite(site).setTime(time).setDogs(com.sas.mkt.kafka.domain.DogNames.Baldur);
				// mimic mixing old and new data sources where tenant is a new field and has a
				// default value
				if (tenant != null)
					bdr.setTenant(tenant);
				if (seq != 0)
					bdr.setSequence(seq);
				long timestamp = System.currentTimeMillis();
				bdr.setTimeStamp(timestamp);
				seq++;
				elist.add(bdr.build());
			}

			return elist;
		}

	}
}
