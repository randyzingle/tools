package com.sas.mkt.config.core.configserver;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;


public class ConfigServerClientTest {

	@SuppressWarnings("unchecked")
	@Test
	public void testConfigServerClientDelete() {
		
		try
		{
			RestTemplate rt = Mockito.mock(RestTemplate.class);
			ApplicationConfiguration mockConfig = Mockito.mock(ApplicationConfiguration.class);
			ConfigProperty cp = Mockito.mock(ConfigProperty.class);
			ResponseEntity re = Mockito.mock(ResponseEntity.class);
			cp.id = "testID";
			
			Mockito.doReturn("testURL").when(mockConfig).getConfigServiceUrl();
			//Mockito.doReturn("testID").when(cp).getId();
			Mockito.doReturn(re).when(rt).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), Mockito.any(Class.class));
			Mockito.doReturn("body").when(re).getBody();
			
			ConfigServerClientTestImpl client = new ConfigServerClientTestImpl(rt, mockConfig);
			
			client.deleteProperty(cp);
			
			Mockito.verify(rt, Mockito.times(1)).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), Mockito.any(Class.class));
			
		}
		catch(Exception ex)
		{
			fail(ex.getMessage());
		}
	}
	
	@Test(expected = RestClientException.class)
	public void testDeleteProperty() {
		ConfigProperty cp = new ConfigProperty();
		ApplicationConfiguration appConfig = new ApplicationConfiguration();
		ConfigServerClient client = new ConfigServerClient(appConfig);
		client.deleteProperty(cp);
	}
	
	@Test(expected = RestClientException.class)
	public void testUpdateProperty() {
		ConfigProperty cp = new ConfigProperty();
		ApplicationConfiguration appConfig = new ApplicationConfiguration();
		ConfigServerClient client = new ConfigServerClient(appConfig);
		client.updateProperty(cp);
	}
	
	@Test(expected = RestClientException.class)
	public void testGetProperty() {
		ConfigProperty cp = new ConfigProperty();
		ApplicationConfiguration appConfig = new ApplicationConfiguration();
		ConfigServerClient client = new ConfigServerClient(appConfig);
		List<ConfigProperty> cplist = new ArrayList<>();
		cplist.add(cp);
		client.printPropertyIds(cplist);
		client.getProperty(cp);
	}
	
	@Test
	public void testConfigServerClientUpdate() {
		try
		{
			RestTemplate rt = Mockito.mock(RestTemplate.class);
			ApplicationConfiguration mockConfig = Mockito.mock(ApplicationConfiguration.class);
			ConfigProperty cp = Mockito.mock(ConfigProperty.class);
			cp.id = "testID";
			
			Mockito.doReturn("testURL").when(mockConfig).getConfigServiceUrl();
			//Mockito.doReturn("testID").when(cp).id;
			
			
			ConfigServerClientTestImpl client = new ConfigServerClientTestImpl(rt, mockConfig);
			
			client.updateProperty(cp);
			
			Mockito.verify(rt, Mockito.times(1)).put(Mockito.anyString(), Mockito.any(HttpEntity.class), Mockito.any(Class.class));
			
		}
		catch(Exception ex)
		{
			fail(ex.getMessage());
		}
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testConfigServerClientCreateProperty() {
		
		try
		{
			RestTemplate rt = Mockito.mock(RestTemplate.class);
			ApplicationConfiguration mockConfig = Mockito.mock(ApplicationConfiguration.class);
			//ResourceCollection<ConfigProperty> rc = new ResourceCollection<>();
			//List<ConfigProperty> cps = new ArrayList<>();
			ConfigProperty cp = new ConfigProperty();
			//cps.add(cp);
			//rc.items = cps;
			
			Mockito.doReturn("testURL").when(mockConfig).getConfigServiceUrl();
			
			Mockito.doReturn(cp).when(rt).postForObject(Mockito.anyString(), Mockito.any(HttpEntity.class), Mockito.any(Class.class));
			
			
			ConfigServerClientTestImpl client = new ConfigServerClientTestImpl(rt, mockConfig);
						
			client.createProperty("tier", "component", "name", "value");
			
			Mockito.verify(rt, Mockito.times(1)).postForObject(Mockito.anyString(), Mockito.any(HttpEntity.class), Mockito.any(Class.class));
			
			
		}
		catch(Exception ex)
		{
			fail(ex.getMessage());
		}
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testConfigServerClientGetProperties() {
		
		try
		{
			RestTemplate rt = Mockito.mock(RestTemplate.class);
			ApplicationConfiguration mockConfig = Mockito.mock(ApplicationConfiguration.class);
			ResponseEntity re = Mockito.mock(ResponseEntity.class);
			
			ResourceCollection<ConfigProperty> rc = new ResourceCollection<>();
			List<ConfigProperty> cps = new ArrayList<>();
			ConfigProperty cp = new ConfigProperty();
			cps.add(cp);
			rc.items = cps;
			
			Mockito.doReturn("testURL").when(mockConfig).getConfigServiceUrl();
			Mockito.doReturn(re).when(rt).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), Mockito.any(ParameterizedTypeReference.class));
			Mockito.doReturn(re).when(re).getBody();
				
			ConfigServerClientTestImpl client = new ConfigServerClientTestImpl(rt, mockConfig);
						
			client.getProperties("tier", "component", "name", "value");
			
			Mockito.verify(rt, Mockito.times(1)).exchange(Mockito.anyString(), Mockito.any(HttpMethod.class), Mockito.any(HttpEntity.class), Mockito.any(ParameterizedTypeReference.class));
	
			
			
			
		}
		catch(Exception ex)
		{
			fail(ex.getMessage());
		}
	}

}
