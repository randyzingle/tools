## Paths
### getRootResponse
```
GET /
```

#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|OK|Api|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|
|404|Not Found|No Content|


#### Consumes

* application/json

#### Produces

* application/json
* application/vnd.sas.api+json

#### Tags

* root-controller

### getRootResponse
```
HEAD /
```

#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|OK|Api|
|204|No Content|No Content|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|


#### Consumes

* application/json

#### Produces

* application/json
* application/vnd.sas.api+json

#### Tags

* root-controller

### Get the base I18N Demo
```
GET /api/i18ndemo
```

#### Description

Get the base I18N demo, customized to determined or default Locale

#### Parameters
|Type|Name|Description|Required|Schema|Default|
|----|----|----|----|----|----|
|QueryParameter|echo|echo|false|string||


#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|Successful retrieval of demo message|string|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|
|404|Not Found|No Content|
|500|Internal server error|string|
|503|Service not ready|string|


#### Consumes

* application/json

#### Produces

* text/plain

#### Tags

* i-18-n-demo-controller

### Get the base I18N Demo
```
GET /api/i18ndemo/
```

#### Description

Get the base I18N demo, customized to determined or default Locale

#### Parameters
|Type|Name|Description|Required|Schema|Default|
|----|----|----|----|----|----|
|QueryParameter|echo|echo|false|string||


#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|Successful retrieval of demo message|string|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|
|404|Not Found|No Content|
|500|Internal server error|string|
|503|Service not ready|string|


#### Consumes

* application/json

#### Produces

* text/plain

#### Tags

* i-18-n-demo-controller

### GetUsers
```
GET /api/users
```

#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|OK|Iterable«User»|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|
|404|Not Found|No Content|


#### Consumes

* application/json

#### Produces

* */*

#### Tags

* user-controller

### CreateUser
```
POST /api/users
```

#### Parameters
|Type|Name|Description|Required|Schema|Default|
|----|----|----|----|----|----|
|BodyParameter|user|user|true|User||


#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|OK|User|
|201|Created|No Content|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|
|404|Not Found|No Content|


#### Consumes

* application/json

#### Produces

* */*

#### Tags

* user-controller

### GetUser
```
GET /api/users/{id}
```

#### Parameters
|Type|Name|Description|Required|Schema|Default|
|----|----|----|----|----|----|
|PathParameter|id|id|true|integer (int64)||


#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|OK|User|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|
|404|Not Found|No Content|


#### Consumes

* application/json

#### Produces

* */*

#### Tags

* user-controller

### DeleteUser
```
DELETE /api/users/{id}
```

#### Parameters
|Type|Name|Description|Required|Schema|Default|
|----|----|----|----|----|----|
|PathParameter|id|id|true|integer (int64)||


#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|OK|object|
|204|No Content|No Content|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|


#### Consumes

* application/json

#### Produces

* */*

#### Tags

* user-controller

### getDiagnostics
```
GET /commons/diagnostics
```

#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|OK|object|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|
|404|Not Found|No Content|


#### Consumes

* application/json

#### Produces

* */*

#### Tags

* admin-metrics-controller

### getHealth
```
GET /commons/healthcheck
```

#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|OK|Health|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|
|404|Not Found|No Content|


#### Consumes

* application/json

#### Produces

* */*

#### Tags

* admin-metrics-controller

### getMetrics
```
GET /commons/metrics
```

#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|OK|MetricRegistry|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|
|404|Not Found|No Content|


#### Consumes

* application/json

#### Produces

* */*

#### Tags

* admin-metrics-controller

### ping
```
GET /commons/ping
```

#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|OK|string|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|
|404|Not Found|No Content|


#### Consumes

* application/json

#### Produces

* */*

#### Tags

* admin-metrics-controller

### index
```
GET /hello
```

#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|OK|string|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|
|404|Not Found|No Content|


#### Consumes

* application/json

#### Produces

* */*

#### Tags

* hello-controller

### getName
```
GET /hello/name
```

#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|OK|string|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|
|404|Not Found|No Content|


#### Consumes

* application/json

#### Produces

* */*

#### Tags

* hello-controller

