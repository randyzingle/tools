'''
Source code located in GitLab:
    https://gitlab.sas.com/CustomerIntelligence/mkt-infra

@author Brad Williams <brad.williams@sas.com>
'''

import logging
import OpenSSLEncode as opensslEncoder
from psycopg2 import connect, Error
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT

logging.basicConfig()
logger = logging.getLogger('PostgresUtils')
logger.setLevel(logging.INFO)

pgCatalogMap = {
    'database': {
        'table': 'pg_database',
        'column': 'datname'
    },
    'user': {
        'table': 'pg_user',
        'column': 'usename'
    }
}


class PostgresConnectionError(Exception):
    def __init__(self, message, reason):
        self.message = message
        self.reason = reason


class PostgresUnableToLoginError(Exception):
    def __init__(self, message):
        self.message = message


def enableDebugLogging():
    logger.setLevel(logging.DEBUG)


def disableDebugLogging():
    logger.setLevel(logging.INFO)


def connectToDatabase(hostName, portNumber, userName, passwd, databaseName):
    logger.debug('Connecting to postgres database on: ' + hostName + ':' + str(portNumber) + ':' + userName + ':***:' + databaseName)

    try:
        conn = connect(host=hostName, port=portNumber, user=userName, password=passwd,
                       database=databaseName, connect_timeout=15, options='-c statement_timeout=60000')
    except Error as e:
        reason = e.message.strip()
        logger.error('Unable to connect to database: ' + reason)
        raise PostgresConnectionError('Unable to connect to database!', reason)

    return conn


def testDBConnection(connection):
    logger.debug('Testing database connection')
    cursor = executeSQL(connection, "SELECT VERSION()")
    result = cursor.fetchone()
    cursor.close()
    logger.debug("Database version: %s" % result)
    connection.commit()

    if (result[0].startswith('PostgreSQL')):
        return True

    return False


def valueExistsInCatalog(connection, lookup, value):
    logger.debug('Checking for ' + lookup + ': ' + value)

    global pgCatalogMap
    exists = False

    query = "SELECT 1 FROM "
    query += pgCatalogMap[lookup]['table']
    query += " WHERE "
    query += pgCatalogMap[lookup]['column']
    query += " = '"
    query += value
    query += "'"

    try:
        cursor = executeSQL(connection, query)
        result = cursor.fetchone()
        cursor.close()
    except Exception:
        logger.warn('Value: ' + value + ' does not exist in catalog: ' + pgCatalogMap[lookup]['table'])
        connection.commit()
        return exists

    if (result is None):
        logger.debug(lookup.capitalize() + ': ' + value + ' does not exist!')
    elif (result[0] == 1):
        logger.debug(lookup.capitalize() + ': ' + value + ' exists!')
        exists = True
    else:
        logger.error('Houston, we have a problem!')

    connection.commit()
    return exists


def executeSQL(connection, sql):
    logger.debug('Executing query: ' + sql)
    cursor = connection.cursor()
    cursor.execute(sql)
    return cursor


def executeSQLWithAutoCommit(connection, sql):
    logger.debug('Enabling AutoCommit')

    level = connection.isolation_level

    # This must be set to create a database...
    connection.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)

    cursor = executeSQL(connection, sql)
    cursor.close()

    logger.debug('Disabling AutoCommit')
    connection.set_isolation_level(level)


def createUser(connection, username, password=None):
    logger.info('Creating user: ' + username)

    query = 'CREATE USER "' + username + '"'

    if (password is not None):
        if(password.startswith('md5')):
            encodedPassword = password
        else:
            encodedPassword = generateEncodedPassword(username, password)

        query += " WITH ENCRYPTED PASSWORD '" + encodedPassword + "'"

    executeSQL(connection, query)
    connection.commit()


def generateEncodedPassword(username, password):
    logger.info('Generating encoded password for user: ' + username)
    pgPasswordString = password + username
    encodedStr = opensslEncoder.handler({'encoding': 'md5', 'instring': pgPasswordString}, None)
    return "md5" + encodedStr['value']


def createUserIfNotExists(connection, username, password=None):
    if (not valueExistsInCatalog(connection, 'user', username)):
        createUser(connection, username, password)


def dropUser(connection, username):
    if (valueExistsInCatalog(connection, 'user', username)):
        logger.info('Deleting user: ' + username)
        query = 'DROP USER "' + username + '"'
        executeSQL(connection, query)
        connection.commit()


def updateUserPassword(connection, username, password):
    logger.info('Updating password for user: ' + username)

    query = 'ALTER USER "' + username + '"'

    if (password is not None and len(password) > 0):
        if(password.startswith('md5')):
            encodedPassword = password
        else:
            encodedPassword = generateEncodedPassword(username, password)

        query += " WITH ENCRYPTED PASSWORD '" + encodedPassword + "'"

        executeSQL(connection, query)
        connection.commit()
    else:
        logger.warn('Unable to update password: value must be set and length greater than 0')


def createDatabase(connection, database):
    logger.info('Creating database: ' + database)
    query = 'CREATE DATABASE "' + database + '"'
    executeSQLWithAutoCommit(connection, query)


def createDatabaseIfNotExists(connection, database):
    if (not valueExistsInCatalog(connection, 'database', database)):
        createDatabase(connection, database)


def dropDatabase(connection, database):
    if (valueExistsInCatalog(connection, 'database', database)):
        logger.info('Dropping database: ' + database)
        query = 'DROP DATABASE "' + database + '"'
        executeSQLWithAutoCommit(connection, query)


def changeDatabaseOwner(connection, database, username):
    if (valueExistsInCatalog(connection, 'database', database) and valueExistsInCatalog(connection, 'user', username)):
        logger.info('Changing owner of database: ' + database + ' to user: ' + username)
        query = 'ALTER DATABASE "' + database + '" OWNER TO "' + username + '"'
        executeSQL(connection, query)
        connection.commit()


def grantAllPrivilegesToUserOnDatabase(connection, username, database):
    if (valueExistsInCatalog(connection, 'user', username) and valueExistsInCatalog(connection, 'database', database)):
        logger.info('Granting ALL privileges to user: ' + username + ' on database: ' + database)
        query = 'GRANT ALL PRIVILEGES ON DATABASE "' + database + '" TO "' + username + '"'
        executeSQL(connection, query)
        connection.commit()


def canUserLogin(host, port, username, password=None, database='postgres'):
    logger.debug('Entering: canUserLogin')

    try:
        connection = connectToDatabase(host, port, username, password, database)
    except PostgresConnectionError as e:
        logger.warn('User unable to log in: ' + e.reason)
        raise PostgresUnableToLoginError('Unable to connect to database: ' + e.reason)

    return connection
