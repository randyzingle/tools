package com.sas.mkt.kafka.tools.healthcheck;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.codahale.metrics.health.HealthCheck;
import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.kafka.tools.topics.utils.TopicUtils;

/**
 * Check Kafka Suite
 * 
 * @author razing
 */
@Configuration
public class KafkaHealthCheck extends HealthCheck {
	
	@Autowired
	ApplicationConfiguration appConfig;
	
	@Autowired
	TopicUtils topicUtils;

	@Override
	protected Result check() throws Exception {
		if (topicUtils != null && topicUtils.isHealthy()) {
			return Result.healthy("Kafka Connection is Healthy.");
		}
		return Result.unhealthy("Failed to Connect to Kafka");
	}

}
