# Upgrading from Java8 to 13

## x-service/src/main/docker/Dockerfile changes

### change the base image in your service's Dockerfile
```sh
# change this
FROM ${REPO}mkt-docker/alpine-jdk8-min:${RELEASE}

# to this
FROM ${REPO}mkt-docker/alpine-zulu13-jre:${RELEASE}
```

### change the run command in your service's Dockerfile
```sh
# change this
CMD ["java", \
"-XX:+UnlockExperimentalVMOptions",  \
"-XX:+UseContainerSupport", \
"-XX:MaxRAMPercentage=80.0", \
"-XshowSettings:vm", \
"-Dlogging.config=classpath:logback-spring.xml", \
"-jar", \
"/install/citng/service/service.jar"]

# to this (Java 9+ innately understands containers)
CMD ["java", \
"-XshowSettings:vm", \
"-Dlogging.config=classpath:logback-spring.xml", \
"-jar", \
"/install/citng/service/service.jar"]
```

## gradle.properties changes
```sh
# change this
javaSourceCompatibility=8
javaTargetCompatibility=8

# to this
javaSourceCompatibility=13
javaTargetCompatibility=13
```
## top level build.gradle changes
Disable sonarcube - we don't really use it and it doesn't support Java 13

```
# change this (around line 444)
if (System.getProperty ('sonar.login') == null && System.getenv ('SONAR_AUTH_TOKEN') == null) {
# to this
//if (System.getProperty ('sonar.login') == null && System.getenv ('SONAR_AUTH_TOKEN') == null) {
if (true) { // disable for Java 13 build
```
## Run your build locally

Note I use sdkman both on my box and in the build tool to switch between java versions

### build directly on my laptop
```sh
razing mkt-kafka-tools $ java -version
openjdk version "13.0.4" 2020-07-14
OpenJDK Runtime Environment Zulu13.33+25-CA (build 13.0.4+8-MTS)
OpenJDK 64-Bit Server VM Zulu13.33+25-CA (build 13.0.4+8-MTS, mixed mode, sharing)
razing mkt-kafka-tools $ gradlew build
```

### build with the build tool
```sh
razing mkt-kafka-tools $ awsecr
Login Succeeded
razing mkt-kafka-tools $ bti
root@3d959f4c9254:/project# java13
==== BROADCAST =================================================================
* 2020-09-11: Micronaut 2.0.2 released on SDKMAN! #micronautfw
* 2020-09-11: Gradle 6.7-rc-1 released on SDKMAN! #gradle
* 2020-09-11: jbang 0.45.0 @jbangdev https://git.io/JUWYs
================================================================================

Using java version 13.0.4-zulu in this shell.
root@3d959f4c9254:/project# gradlew build
```

### build with Jenkins

We'll need to add **jdkInstallation** information to our Jenkinsfile.

* Running the build tool starting at v2012 will automatically update the Jenkinsfile to use the correct JDK to build (based on the source and target compatibilities set in gradle.properties)

* Prior to v2012 you can update the Jenkinsfile manually:

  * You'll need to make the changes in this commit: https://gitlab.sas.com/CustomerIntelligence/DevOps/mkt-template-docker/-/commit/78042bcf5286dbc038c1d66fbbd9baedc434a393

  * Once you've made the changes in the link just do a git push and Jenkins will build using the proper JDK.
