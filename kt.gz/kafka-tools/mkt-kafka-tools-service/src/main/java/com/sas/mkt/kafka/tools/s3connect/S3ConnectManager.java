package com.sas.mkt.kafka.tools.s3connect;

import org.springframework.stereotype.Component;


@Component
public class S3ConnectManager {//implements ExternalDependency {
	
//	private final static Logger logger = LoggerFactory.getLogger(S3ConnectManager.class);
//	private String schemaRegistryUrl;
//	private String connectDistributedUrl;
//	private ConnectBaseDTO baseDTO;
//	private String connectorFileBase = "config/";
//	private long statusCheckInitialDelayMs = 1000 * 60 * 10; // 10 min
//	private long statusCheckPeriodMs = 1000 * 60 * 30; // 30 min
//	private static final String DEFAULT_CONFIG_FILE = "baldur-connect-config.json";
//	private ApplicationConfiguration appConfig;
//	private GlobalConfiguration globalConfig;
//	private AlertManager alertManager;
//	private boolean healthy = false;
//	private Timer timer;
//	
//	@Autowired
//	public S3ConnectManager(ApplicationConfiguration appConfig, GlobalConfiguration globalConfig, AlertManager alertManager) {
//		this.appConfig = appConfig;
//		this.globalConfig = globalConfig;
//		this.alertManager = alertManager;
//	}
//
//	@Override
//	public boolean isHealthy() {
//		return healthy;
//	}
//
//	@Override
//	public void init() {
//	
//		if (!appConfig.isS3ConnectManagerEnabled() || appConfig.getIsProduction()==0) {
//			logger.debug("S3 Connection Manager is disabled");
//			return;
//		}
//		BaseUtils.bigPrint("Initializing S3 Connection Manager");
//		schemaRegistryUrl = getUrl(globalConfig.getSasMktKafkaSchemaRegistry());
//		connectDistributedUrl = getUrl(globalConfig.getSasMktKafkaConnectDistributed());
//		String baseJson = httpReadRequest("");
//		baseDTO = parseBase(baseJson);
//		if (baseDTO == null || baseDTO.version == null || baseDTO.version.isEmpty()) {
//			healthy = false;
//			return;
//		}
//		checkConnectorConfigurations();
//		scheduleStatusCheck();
//
//	}
//
//	@Override
//	public void restart() {
//		if (timer != null) timer.cancel();
//		init();
//	}
//	
//    @EventListener
//    public void handleApplicationConfigurationChanged(ApplicationConfigurationEvent ace) {
//        System.out.println("got a configuration change notice - checking for properties that S3ConnectionManager cares about...");
//        
//        // Get all the property changes
//        for (PropertyDetails pd: ace.getOverrideList()) {
//        	String name = pd.getName();
//        	if (name != null) {
//	        	if (name.equals("s3ConnectManagerEnabled")){
//	        		BaseUtils.bigPrint("changing S3 connection manager status");
//	        		this.restart();
//	        	}
//        	}
//        }
//    }
//	
//	private void scheduleStatusCheck() {  
//		BaseUtils.bigPrint("scheduled status check");
//		StatusCheckTimerTask task = new StatusCheckTimerTask();
//		boolean isDaemon = true;
//		timer = new Timer(isDaemon);
//		timer.scheduleAtFixedRate(task, statusCheckInitialDelayMs, statusCheckPeriodMs);
//	}
//	
//	private String getUrl(String base) {
//		String url = null;
//		if (base != null) {
//			String[] parts = base.split(",");
//			url = parts[0];
//			if (!url.startsWith("http://")) url = "http://" + url;
//		}
//		return url;
//	}
//
//	
//	private void checkConnectorStatus() {
//		// Possible states for connector and tasks: ["RUNNING", "FAILED"]
//		List<String> connectorList = getConnectors("/connectors/");
//		for (String connector: connectorList) {
//			boolean running = true;
//			ConnectStatusDTO status = getStatus("/connectors/"+connector+"/status");
//			if (status.connector.state != null && status.connector.state.trim().equals("FAILED")) running = false;
//			StringBuilder taskStatus = new StringBuilder("[");		
//			boolean first = true;
//			for (StatusTasks st: status.tasks) {
//				if (!first) taskStatus.append(", ");
//				first = false;
//				taskStatus.append("task id ");
//				taskStatus.append(st.id);
//				taskStatus.append(": ");
//				taskStatus.append(st.state);
//				if (st.state != null && st.state.trim().equals("FAILED")) running = false;
//				if (st.trace != null && !st.trace.isEmpty()) {
//					taskStatus.append(", trace: ");
//					taskStatus.append(st.trace);
//				}
//			}
//			taskStatus.append("]");
//			String fullStatus = status.name + ": " + status.connector.state + " " + taskStatus.toString();
//			if(!running) {
//				sendAlert(fullStatus);
//			}
//			logger.debug(fullStatus);
//		}
//	}
//	
//	private void sendAlert(String alert) {
//		alertManager.sendAlert(alert);
//		logger.error(alert);
//	}
//	
//	private void checkConnectorConfigurations() {
//		// get the master list of connectors - what we are saying should be running
//		ConnectConfigDTO[] masterList = getConnectorConfigList();
//		addGlobalAndDefaultValues(masterList);
//		
//		// query the connect distributed cluster for the list of running connectors
//		List<String> connectorList = getConnectors("/connectors/");
//		
//		for (ConnectConfigDTO ccdto: masterList) {
//			if (connectorList.contains(ccdto.name)) {
//				// there's a connector with this name currently running, check to see if the config has changed
//				String sconfig = httpReadRequest("/connectors/"+ccdto.name+"/config");
//				ConnectConfigDTO oldConfig = parseConfig(sconfig);
//				if (ccdto.equals(oldConfig)) {
//					System.out.printf("The configuration hasn't changed for %s%n", ccdto.name);
//					logger.info("The configuration hasn't changed for {}", ccdto.name);
//				} else {
//					logger.info("The configuration has changed for {} ... updating", ccdto.name);
//					updateConnector(ccdto);
//				}
//			} else {
//				// this is a new connector
//				createConnector(ccdto);
//			}
//		}
//	}
//	
//	private void addGlobalAndDefaultValues(ConnectConfigDTO[] masterList) {
//		for (ConnectConfigDTO ccdto: masterList) {
//			
//			// Add values from tier_global configuration server
//			ccdto.valueConverterSchemaRegistryUrl = schemaRegistryUrl;
//			ccdto.s3BucketName = globalConfig.getSasMktKafkaConnectS3Bucket();
//			
//			// Construct topic-based values from topic name
//			ccdto.errorsDeadletterqueueTopicName = ccdto.topics + "-s3deadletter";
//			ccdto.topicsRegex = "\\w*-" + ccdto.topics;
//			ccdto.name = "s3-" + ccdto.topics;
//			ccdto.topics = null; // you can only use one of [topics.regex, topics] not both
//			
//			// Add default values (same across all connectors)
//			ccdto.connectorClass = "io.confluent.connect.s3.S3SinkConnector";
//			ccdto.enhancedAvroSchemaSupport = "true";
//			ccdto.errorsDeadletterqueueContextHeadersEnable = "true";
//			ccdto.errorsLogEnable = "true";
//			ccdto.errorsLogIncludeMessages = "true";
//			ccdto.errorsRetryTimeout = "0"; // 0 means no retries will be attempted
//			ccdto.errorsToleranceRateDurationMs = "all";
//			ccdto.keyConverter = "org.apache.kafka.connect.storage.StringConverter";
//			ccdto.locale = "en";
//			ccdto.partitionDurationMs = "100";
//			ccdto.partitionerClass = "io.confluent.connect.storage.partitioner.TimeBasedPartitioner";
//			ccdto.pathFormat = "YYYY/MM/dd/HH";
//			ccdto.s3PartSize = "5242880";
//			ccdto.schemaCompatibility = "NONE";
//			ccdto.schemaGeneratorClass = "io.confluent.connect.storage.hive.schema.TimeBasedSchemaGenerator";
//			ccdto.storageClass = "io.confluent.connect.s3.storage.S3Storage";
//			ccdto.timestampExtractor = "Record";
//			ccdto.timezone = "UTC";
//			ccdto.topicsDir = "topics";
//			ccdto.fileDelim = "-";
//			
//			// Derive and set the aws region
//			ccdto.s3Region = getRegion();
//
//		}
//	}
//	
//    private static String getRegion() {
//    	Region region = Regions.getCurrentRegion();
//    	if (region == null)
//    		region = RegionUtils.getRegion("us-east-1");
//    	return region.getName();
//    }
//	
//	private void updateConnector (ConnectConfigDTO ccdto) {
//		System.out.println("updating connector ...");
//		String path = "/connectors/"+ccdto.name+"/config";
//		ccdto.name = null; 
//		ObjectMapper mapper = new ObjectMapper();
//		String body = null;
//		try {
//			body = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(ccdto);
//			System.out.println(body);
//		} catch (JsonProcessingException e) {
//			e.printStackTrace();
//		}
//		if (body != null) {
//		// PUT the connector
//			httpWriteRequest(path, body, HttpMethod.PUT);
//		}
//	}
//	
//	private void createConnector(ConnectConfigDTO ccdto) {
//		ConnectorPostDTO cpdto = new ConnectorPostDTO();
//		cpdto.name = ccdto.name;
//		ccdto.name = null;
//		cpdto.connectConfigDTO = ccdto;
//		System.out.println("Creating connector:");
//		ObjectMapper mapper = new ObjectMapper();
//		String body = null;
//		try {
//			body = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(cpdto);
//			System.out.println(body);
//		} catch (JsonProcessingException e) {
//			e.printStackTrace();
//		}
//		// POST the connector
//		httpWriteRequest("/connectors", body, HttpMethod.POST);
//	}
//	
//	private InputStream getConnectorConfigFile() {
//		InputStream is = null;
//		String fileName = this.connectorFileBase + "prod-connect-config.json";
//		// The following returns null if the resource can't be found
//		is = this.getClass().getClassLoader().getResourceAsStream(fileName);
////		System.out.printf("loading %s%n", fileName);
//		logger.info("loading {}", fileName);
//		if (is == null) {
//			System.out.printf("couldn't find %s%n", fileName);
//			System.out.printf("loading %s%n", DEFAULT_CONFIG_FILE);
//			logger.info("couldn't find {}", fileName);
//			logger.info("loading {}", DEFAULT_CONFIG_FILE);
//			is = this.getClass().getClassLoader().getResourceAsStream(DEFAULT_CONFIG_FILE);
//		}
//		return is;
//	}
//	
//	private ConnectConfigDTO[] getConnectorConfigList() {
//		InputStream configStream = getConnectorConfigFile();
//		if (configStream == null) return null;
//		ObjectMapper mapper = new ObjectMapper();
//		ConnectConfigDTO[] obj = null;
//		try {
//			obj = mapper.readValue(configStream, ConnectConfigDTO[].class);
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		return obj;
//	}
//	
//	private ConnectConfigDTO parseConfig(String configJson) {
//		ConnectConfigDTO config = null;
//		ObjectMapper mapper = new ObjectMapper();
//		try {
//			config = mapper.readValue(configJson, ConnectConfigDTO.class);
//		} catch (Exception ex) {
//			logger.warn(ex.getMessage());
//		}
//		return config;
//	}
//	
//	private ConnectBaseDTO parseBase(String baseJson) {
//	
//		ConnectBaseDTO config = null;
//		ObjectMapper mapper = new ObjectMapper();
//		try {
//			config = mapper.readValue(baseJson, ConnectBaseDTO.class);
//		} catch (Exception ex) {
//			logger.warn(ex.getMessage());
//		}
//		return config;
//	}
//	
//	private List<String> getConnectors(String path) {
//		List<String> list = new ArrayList<>();
//		String rawlist = httpReadRequest(path);
//		ObjectMapper mapper = new ObjectMapper();
//		try {
//			String[] clist = mapper.readValue(rawlist, String[].class);
//			list = Arrays.asList(clist);
//			System.out.println(list);
//		} catch (JsonParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (JsonMappingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return list;
//	}
//	
//	private ConnectStatusDTO getStatus(String path) {
//		String statusJson = httpReadRequest(path);
//		// null check this
//		ObjectMapper mapper = new ObjectMapper();
//		ConnectStatusDTO config = null;
//		try {
//			config = mapper.readValue(statusJson, ConnectStatusDTO.class);
//			System.out.println(config);
//		} catch (JsonParseException e) {
//			e.printStackTrace();
//		} catch (JsonMappingException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		return config;
//	}
//	
//	private String httpReadRequest(String path) {
//		String body = null;
//		boolean rebalancing = true;
//		int maxTries = 5;
//		int sleepTimeSec = 5;
//		while (rebalancing && maxTries >= 0) {
//			try {
//				maxTries--;
//				RestTemplate restTemplate = new RestTemplate();
//				String url = connectDistributedUrl + path;
//				HttpHeaders headers = new HttpHeaders();
//				headers.set("Accept", "application/json");
//				HttpEntity<String> entity = new HttpEntity<String>(headers);
//				ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
//				body = responseEntity.getBody();
//				rebalancing = false;
//			} catch (Exception ex) {
//				if (ex.getMessage() != null && ex.getMessage().startsWith("409 Conflict")) {
//					// Cluster is re-balancing and will return a 409 until it completes
//					try {
//						Thread.sleep(sleepTimeSec * 1000);
//					} catch (InterruptedException e) {
//						logger.error(e.getMessage());
//					}
//				}
//			}
//		}
//		if (maxTries == 0) logger.warn("Cluster failed to stabilize in {} secs", sleepTimeSec * maxTries);
//		return body;
//	}
//	
//	private ResponseEntity<ConnectorPostDTO> httpWriteRequest(String path, String body, HttpMethod method) {
//		ResponseEntity<ConnectorPostDTO> response = null;
//		try {
//			RestTemplate restTemplate = new RestTemplate();
//			String url = connectDistributedUrl + path;
//			HttpHeaders headers = new HttpHeaders();
//			headers.set("Accept", "application/json");
//			headers.set("Content-Type", "application/json");
//			HttpEntity<String> entity = new HttpEntity<String>(body, headers);
//			response = restTemplate.exchange(url, method, entity, ConnectorPostDTO.class);
//		} catch (Exception ex) {
//			ex.printStackTrace();
//		}
//		return response;
//	}
//
//	private class StatusCheckTimerTask extends TimerTask {
//
//		@Override
//		public void run() {
//			checkConnectorStatus();
//		}
//		
//	}


}
