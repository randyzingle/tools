package com.sas.mkt.template.docker.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sas.mkt.template.docker.TEMPLATESAMPLE.data.Customer;
import com.sas.mkt.template.docker.TEMPLATESAMPLE.data.CustomerRepository;

@Controller
public class CustomerHandler {
	
	@Autowired
	private CustomerRepository repository;
	
	@RequestMapping(value = "/rds/hello", method = RequestMethod.GET)
	public @ResponseBody String sayHello() {
		return "hello";
	}
	
	@RequestMapping(value = "/rds/base", method = RequestMethod.GET)
	public @ResponseBody String storeCustomers() {
		repository.save(new Customer("Harry", "Potter"));
		repository.save(new Customer("Hermione", "Granger"));
		repository.flush();
		return "stored 2 customers, store more with syntax: /rds/store?name='Baldur Zingle'";
	}
	
	@RequestMapping(value = "/rds/store", method = RequestMethod.GET)
	public @ResponseBody String storeCustomers(@RequestParam String name) {
		if (name != null) {
			String[] s = name.split(" ");
			if (s.length == 2) {
				repository.save(new Customer(s[0], s[1]));
				repository.flush();
				return "Stored: " + name;
			}
		}	
		return "failed to store: " + name;
	}
	
	@RequestMapping(value ="rds/customer", method = RequestMethod.GET) 
	public @ResponseBody List<Customer> getCustomers(@RequestParam String lastName) {
		List<Customer> customers = repository.findByLastName(lastName);
		return customers;
	}

}
