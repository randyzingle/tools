package com.sas.mkt.kafka.clients.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.Timer;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.producer.BufferExhaustedException;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.annotation.InterfaceStability;
import org.apache.kafka.common.errors.InterruptException;
import org.apache.kafka.common.errors.SerializationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.domain.TestEvent;

//tag
/**
 * @author razing
 *
 */
@InterfaceStability.Unstable
public class SampleFireAndForgetProducer {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	private String topic = "baldur-test-events";
	private static int nrecords = 500;
	private String configServiceURL = "http://configservice-dev.cidev.sas.us:8080/";
	private String tierName = "finnr";
	private String componentName="mkt-baldur-spring";

	public static void main(String[] args) {
		SampleFireAndForgetProducer bp = new SampleFireAndForgetProducer();
		Producer<String, SpecificRecordBase> producer = bp.getProducer();
		TestRecordGenerator werg = bp.new TestRecordGenerator();
		bp.fireAndForget(producer, werg.getTestEventList(nrecords));
	}

	private Producer<String, SpecificRecordBase> getProducer() {
		// get the Fire-And-Forget Producer from our utility class
		KafkaConnectionUtils kcu;
		try {
			kcu = KafkaConnectionUtils.getInstance(configServiceURL);
			HashMap<String, String> map = kcu.getKafkaProperties();
			System.out.println("KEYSET+++++++++++++");
			for (String s: map.keySet()) {
				System.out.println(s + ": " + map.get(s));
			}
			System.out.println("KEYSET+++++++++++++");
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			return null;
		}
		Properties producerProps = kcu.getKafkaProducerProperties(tierName, componentName);
		Producer<String, SpecificRecordBase> p = new KafkaProducer<>(producerProps);
		return p;
	}

	/**
	 * This will send the TestEvent(s) weblist to the brokers and will ignore the
	 * returned RecordMetadata object so we won't know if the message was properly
	 * received by the broker. We will still get any exceptions that deal with
	 * failed attempts to send the message to the broker.
	 *
	 * This is useful for messages of low importance as it gives us the highest
	 * throughput.
	 *
	 * @param weblist The list of messages to be sent. The message class must be a
	 *                subclass of SpecificRecordBase
	 */
	public void fireAndForget(Producer<String, SpecificRecordBase> producer, List<TestEvent> weblist) {
		if (producer == null)
			return;

		// create the ProducerRecord and send ignoring the returned RecordMetadata
		int cnt = 0;
		for (TestEvent we : weblist) {
			cnt++;
			ProducerRecord<String, SpecificRecordBase> record = new ProducerRecord<>(topic, we.getTenant(), we);
			// note, send() actually places the message in a buffer which is read and sent
			// by a separate thread
			try {
				producer.send(record);
//				Thread.sleep(5l);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (cnt % 100 == 0) {
				logger.info("sent message " + cnt);
			}
		}
		// give the buffer a chance to empty out
		long sleep = Math.max(1000L, nrecords / 25L);

		logger.info("Sleeping for " + sleep + " msec to let buffers drain");
		try {
			Thread.sleep(sleep);
		} catch (Exception ex) {
			logger.warn(ex.getMessage());
			;
		}
		producer.close();

	}

	public class TestRecordGenerator {

		public List<TestEvent> getTestEventList(int nrecords) {

			Random rnd = new Random();
			List<TestEvent> elist = new ArrayList<TestEvent>(nrecords);
			int seq = 1;
			for (int i = 0; i < nrecords; i++) {
				long time = System.currentTimeMillis();
				String site = "www.razing.com";
				String ip = "192.168.2." + rnd.nextInt(255);
				String tenant = null;
				int nexti = rnd.nextInt(5);
				if (nexti == 0)
					tenant = "baldursoft" + rnd.nextInt(50);
				if (nexti == 1)
					tenant = "mymir-ai" + rnd.nextInt(50);
				if (nexti == 2)
					tenant = "butters" + rnd.nextInt(50);
				if (nexti == 3)
					tenant = "gabriel" + rnd.nextInt(50);
				if (nexti == 4)
					tenant = "rafael" + rnd.nextInt(50);
				TestEvent.Builder bdr = TestEvent.newBuilder();
				bdr.setIp(ip).setSite(site).setTime(time).setDogs(com.sas.mkt.kafka.domain.DogNames.Baldur);
				// mimic mixing old and new data sources where tenant is a new field and has a
				// default value
				if (tenant != null)
					bdr.setTenant(tenant);
				if (seq != 0)
					bdr.setSequence(seq);
				long timestamp = System.currentTimeMillis();
				bdr.setTimeStamp(timestamp);
				seq++;
				elist.add(bdr.build());
			}

			return elist;
		}

	}
}
