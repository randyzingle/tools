package com.sas.mkt.baldur.spring.metrics;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.Measurement;
import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Metrics;
import io.micrometer.prometheus.PrometheusMeterRegistry;

@RestController
@RequestMapping("/")
public class MetricsController {
	
	@Autowired 
	PrometheusMeterRegistry registry;
	
	/**
	 * This is what the Prometheus server will be calling - we need to keep this as is.
	 * @return text file with metric data in Prometheus format
	 */
	@RequestMapping(value = "metrics", method = RequestMethod.GET)
	public ResponseEntity<String> prometheus() {
		String metrics = registry.scrape();
		HttpHeaders responseHeaders = new HttpHeaders();
	    responseHeaders.set("content-type", "text/plain");
//	    responseHeaders.set("connection", "keep-alive");
//	    responseHeaders.set("keep-alive", "timeout=62");
		return ResponseEntity.ok()
			      .headers(responseHeaders)
			      .body(metrics);
	}

	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "metrics/getregistries", method = RequestMethod.GET)
	public String getRegistries() {
		StringBuilder sb = new StringBuilder();
		sb.append("<html><body>");
		Set<MeterRegistry> regs = Metrics.globalRegistry.getRegistries();
		for (MeterRegistry reg: regs) {
			sb.append("<h3>");
			sb.append(reg.getClass().getName());
			sb.append("</h3>");
		}
		sb.append("</body></html>");
		return sb.toString();
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "metrics/getmeters", method = RequestMethod.GET)
	public String getMeters() {
		StringBuilder sb = new StringBuilder();
		sb.append("<html><body>");
		Set<MeterRegistry> regs = Metrics.globalRegistry.getRegistries();
		for (MeterRegistry reg: regs) {
			sb.append("<h3>");
			sb.append(reg.getClass().getName());
			sb.append("</h3>");
			List<Meter> meters = reg.getMeters();
			for (Meter m: meters) {
				sb.append("-> ");
				sb.append(m.getId());
				sb.append("</br>");
			}
		}
		sb.append("</body></html>");
		return sb.toString();
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "metrics/getprometheus", method = RequestMethod.GET)
	public String getPrometheus() {
		StringBuilder sb = new StringBuilder();
		sb.append("<html><body>");
		Set<MeterRegistry> regs = Metrics.globalRegistry.getRegistries();
		for (MeterRegistry reg: regs) {
			if (reg.getClass().getSimpleName().equals("PrometheusMeterRegistry")) {
				sb.append("<h3>");
				sb.append(reg.getClass().getName());
				sb.append("</h3>");
				List<Meter> meters = reg.getMeters();
				for (Meter m: meters) {
					sb.append("-> ");
					sb.append(m.getId().getName());
					sb.append(": ");
					for (Measurement measurement : m.measure()) {
						sb.append(measurement.getValue());
						sb.append(" ");
					}
					sb.append("</br>");
				}
			}
		}
		sb.append("</body></html>");
		return sb.toString();
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "metrics/getcloudwatch", method = RequestMethod.GET)
	public String getCloudWatch() {
		StringBuilder sb = new StringBuilder();
		sb.append("<html><body>");
		Set<MeterRegistry> regs = Metrics.globalRegistry.getRegistries();
		for (MeterRegistry reg: regs) {
			if (reg.getClass().getSimpleName().equals("CloudWatchMeterRegistry")) {
				sb.append("<h3>");
				sb.append(reg.getClass().getName());
				sb.append("</h3>");
				List<Meter> meters = reg.getMeters();
				for (Meter m: meters) {
					sb.append("-> ");
					sb.append(m.getId().getName());
					sb.append(": ");
					for (Measurement measurement : m.measure()) {
						sb.append(measurement.getValue());
						sb.append(" ");
					}
					sb.append("</br>");
				}
			}
		}
		sb.append("</body></html>");
		return sb.toString();
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "metrics/getstatsd", method = RequestMethod.GET)
	public String getStatsd() {
		StringBuilder sb = new StringBuilder();
		sb.append("<html><body>");
		Set<MeterRegistry> regs = Metrics.globalRegistry.getRegistries();
		for (MeterRegistry reg: regs) {
			if (reg.getClass().getSimpleName().equals("StatsdMeterRegistry")) {
				sb.append("<h3>");
				sb.append(reg.getClass().getName());
				sb.append("</h3>");
				List<Meter> meters = reg.getMeters();
				for (Meter m: meters) {
					sb.append("-> ");
					sb.append(m.getId().getName());
					sb.append(": ");
					for (Measurement measurement : m.measure()) {
						sb.append(measurement.getValue());
						sb.append(" ");
					}
					sb.append("</br>");
				}
			}
		}
		sb.append("</body></html>");
		return sb.toString();
	}
	
	

}
