// Kafka Topic Viewer

var kafkaApp = angular.module("kafkaTools", ["ngRoute", "rzModule"]);

kafkaApp.config(function ($routeProvider) {
  $routeProvider
    .when("/topics", {
      templateUrl: "topics.html"
    })
    .when("/playback", {
      templateUrl: "playback.html"
    }).otherwise({ redirectTo: '/topics' });
});

kafkaApp.controller("MasterCtrl", function ($scope, $http, $location) {

  // --------------------
  // Initialize variables
  // --------------------
  var baseUrl = $location.$$absUrl;
  var contextPath = '/' + baseUrl.split('/')[3];
  //var contextPath = 'http://localhost:8080/marketingKafkaTools'; // local development
  console.log(contextPath);
  //$scope.topic = {};
  $scope.forceConsumerGroupRefresh = false;
  $scope.showConsumers = false;
  $scope.baldr = {};
  $scope.baldr.filterList = [];
  $scope.coverRecords = true;
  $scope.isAvro = false;

  // ---------------
  // Kafka Connect
  // ---------------
  $scope.connect = {};
  $scope.connect.s3bucket = 'coming soon...';
  $scope.getS3BucketInfo = function() {
    $http({
      method: 'GET',
      url: contextPath + '/connect/bucketinfo?name=ci-360-test-dev-us-east-1'
    }).then(function successCallback(response) {
      console.log('got S3 bucket info...');
      console.log(response);
      $scope.connect.s3bucket = response.data;
    }, function errorCallback(response) {
      console.log('failed to get S3 bucket info');
      //console.log(response);
    });
  }

  // ---------------
  // Topic data
  // ---------------
  $scope.getKafkaTopics = function () {
    $http({
      method: 'GET',
      url: contextPath + '/topics/list'
    }).then(function successCallback(response) {
      $scope.topicList = response.data;
      $scope.filteredTopicList = $scope.topicList;
    }, function errorCallback(response) {
      console.log('failed to get topics from server');
    });
  }
  $scope.getKafkaTopics();

  $scope.getTopicInfo = function (topic) {
    $http({
      method: 'GET',
      url: contextPath + '/topics/topicinfo?topic=' + topic
    }).then(function successCallback(response) {
      $scope.topicInfo = response.data;
      $scope.topicInfo.partitionSelectionList = createPartitionSelectionList($scope.topicInfo);
      if ($scope.topicInfo.errorMessage) {
    	  $scope.topicErrors = true;
      }
      console.log($scope.topicInfo);
      $scope.initializeSlider($scope.topicInfo);
      // For now only enable record search for AVRO messages
      //if ($scope.topicInfo.valueType == 'AvroType' && $scope.topicInfo.numberMessages > 0) {
      if ($scope.topicInfo.numberMessages > 0) {
        $scope.coverRecords = false;
      }
      $scope.setIsAvro($scope.topicInfo);
    }, function errorCallback(response) {
      console.log('failed to get topics from server');
    });
  }

  function createPartitionSelectionList(topicInfo) {
    plist = [];
    plist.push('all');
    if (topicInfo) {
      var p;
      for (p = 0; p < topicInfo.numberPartitions; p++) {
        plist.push(p);
      }
    }
    return plist;
  }

  // we've selected a topic - get all relevant info
  $scope.setTopic = function (topic) {
    if (topic && topic.length > 0) {
      $scope.topicErrors = false;
      $scope.coverRecords = true;
      $scope.recordSetDTO = {};
      $scope.baldr.filterList = [];
      $scope.topicInfo = {};
      console.log('selected: ', topic);
      $scope.getTopicInfo(topic);
      $scope.getConsumerGroups(topic);
    }
  }

  $scope.filterTopics = function (filter) {
    $scope.filteredTopicList = [];
    filter = filter.trim();
    // set to topicList if filter is null/empty
    if (filter.length == 0) {
      $scope.filteredTopicList = $scope.topicList;
      console.log('no filters')
    } else {
      //$scope.filteredTopicList = [];
      $scope.topicList.forEach(function (topic) {
        topic = topic.trim();
        if (topic.search(filter) !== -1) {
          $scope.filteredTopicList.push(topic);
        }
      });
    }
  }

  $scope.initializeSlider = function (topicInfo) {
    console.log('setting sliders...');
    var timeSlider = {
      minValue: 0,
      maxValue: Date.now(),
      options: {
        floor: 0,
        ceil: Date.now(),
        noSwitching: true,
        enforceStep: false,
        draggableRange: false,
        autoHideLimitLabels: true,
        translate: function (value) {
          return new Date(value).toLocaleString();
        }
      }
    }

    if (topicInfo) {
      timeSlider.minValue = topicInfo.firstTimestamp;
      timeSlider.maxValue = topicInfo.lastTimestamp;
      timeSlider.options.floor = topicInfo.firstTimestamp;
      timeSlider.options.ceil = topicInfo.lastTimestamp;
      console.log('found topicInfo');
      if ($scope.recordSetDTO) {
        $scope.recordSetDTO.requestedStartTime = timeSlider.minValue;
        $scope.recordSetDTO.requestedEndTime = timeSlider.maxValue;
        console.log('found recordSetDTO', $scope.recordSetDTO);
      }
    }

    $scope.timeSlider = timeSlider;
  }
  $scope.initializeSlider();

  $scope.getWindow = function (timespan) {
    var sec_num = timespan / 1000;
    var days = Math.floor(sec_num / (3600 * 24));
    var hours = Math.floor((sec_num - (days * 3600 * 24)) / 3600);
    var minutes = Math.floor((sec_num - (days * 3600 * 24) - (hours * 3600)) / 60);
    var seconds = Math.floor(sec_num - (days * 3600 * 24) - (hours * 3600) - (minutes * 60));
    return days + ' days, ' + hours + ' hours, ' + minutes + ' min, ' + seconds + ' sec';
  }

  $scope.getDate = function (datetime) {
    if (!datetime) {
      datetime = 0;
    }
    return new Date(datetime).toLocaleString();
  }

  $scope.$on('slideEnded', function () {
    $scope.recordSetDTO.requestedStartTime = $scope.timeSlider.minValue;
    $scope.recordSetDTO.requestedEndTime = $scope.timeSlider.maxValue;
    $scope.$apply();
    console.log($scope.timeSlider.minValue, $scope.timeSlider.maxValue);
  });
  
  $scope.setEndTimeToNow = function () {
	var date = new Date();
    var time = date.getTime();
    $scope.timeSlider.maxValue = time;
  }

  $scope.refreshTimeWindow = function() {
    if($scope.topicInfo.topic) {
      $scope.coverRecords = true;
      url = contextPath + '/topics/refreshTimeWindow';
      config = 'application/json';
      console.log('refresh time window post body:');
      console.log($scope.topicInfo);
      $http.post(url, $scope.topicInfo, config).then(function successCallback(response) {
        // update grid with data & success message
        $scope.topicInfo = response.data;
        console.log('got back topicInfoDTO: ');
        console.log($scope.topicInfo);
        console.log('recalculate slider window if needed...');
        $scope.initializeSlider($scope.topicInfo);
        $scope.coverRecords = false;
      }, function errorCallback(response) {
        // update UI with error message
        console.log(response);
        $scope.coverRecords = false;
      });
    }
  }

  // ---------------
  // Topic Records
  // ---------------

  $scope.setIsAvro = function(topicInfo) {
    if (topicInfo && topicInfo.valueType && topicInfo.valueType == 'AvroType') {
      console.log('AvroType found...');
      $scope.isAvro = false;
      //$scope.isAvro = true; Hide this until you come up with a plan for full scans ... or a timeout.
    } else {
      console.log('AvroType NOT found...');
      $scope.isAvro =  false;
    }
  }

  $scope.scanForBadRecords = function(topicInfo) {
    $scope.coverRecords = true;
    console.log('scanning for bad records');
    console.log(topicInfo);
    url = contextPath + '/topics/badrecords';
    config = 'application/json';
    $http.post(url, topicInfo, config).then(function successCallback(response) {
      // update grid with data & success message
      $scope.recordSetDTO = response.data;
      console.log('got back recordSetDTO: ');
      console.log($scope.recordSetDTO);
      if ($scope.recordSetDTO.recordList && $scope.recordSetDTO.recordList.length != 0) {
        //console.log($scope.recordSetDTO.recordList[0].value);
        valueObj = $scope.recordSetDTO.recordList[0].value;
        keys = [];
        for (var x in valueObj) {
          keys.push(x);
        }
        keys.sort();
        // headers for the values
        $scope.recordSetDTO.keys = keys;
        $scope.cleanRecords($scope.recordSetDTO);
        if ($scope.recordSetDTO.maxRecords) {
          $scope.topicInfo.maxRecords = $scope.recordSetDTO.maxRecords;
        }
      }
      $scope.coverRecords = false;
    }, function errorCallback(response) {
      // update UI with error message
      console.log(response);
      $scope.coverRecords = false;
    });
  }

  $scope.getRecords = function (recordSetDTO) {
    $scope.coverRecords = true;
    recordSetDTO.valueType = $scope.topicInfo.valueType;
    recordSetDTO.requestedStartTime = $scope.timeSlider.minValue;
    recordSetDTO.requestedEndTime = $scope.timeSlider.maxValue;
    recordSetDTO.topic = $scope.topicInfo.topic;
    recordSetDTO.firstTimestamp = 0;
    recordSetDTO.lastTimestamp = 0;
    if (recordSetDTO.requestedPartition === null || recordSetDTO.requestedPartition == 'all') {
      recordSetDTO.requestedPartition = -1;
    } else {
      recordSetDTO.requestedPartition = $scope.recordSetDTO.requestedPartition;
    }
    if (recordSetDTO.requestedStartOffset == null || recordSetDTO.requestedStartOffset != '' || isNaN(recordSetDTO.requestedStartOffset)) {
      recordSetDTO.requestedStartOffset = -1;
      recordSetDTO.requestedEndOffset = -1;
    }
    if (recordSetDTO.requestedEndOffset == null || recordSetDTO.requestedStartOffset != '' || isNaN(recordSetDTO.requestedEndOffset)) {
      recordSetDTO.requestedEndOffset = -1;
    }
    if ($scope.baldr.filterList) {
      var valueFilters = {};
      $scope.baldr.filterList.forEach(function (e) {
        // TODO check the data types here as well
        if (e.field && e.value) {
          valueFilters[e.field] = e.value;
        }
      });
      recordSetDTO.valueFilters = valueFilters;
      console.log('value filter: ', valueFilters);
    }
    console.log('POSTING request for record data: ');
    recordSetDTO.recordList = [];
    console.log(recordSetDTO);
    url = contextPath + '/topics/records';
    config = 'application/json';
    $http.post(url, recordSetDTO, config).then(function successCallback(response) {
      // update grid with data & success message
      $scope.recordSetDTO = response.data;
      console.log('got back recordSetDTO: ');
      console.log($scope.recordSetDTO);
      if ($scope.recordSetDTO.recordList && $scope.recordSetDTO.recordList.length != 0) {
        //console.log($scope.recordSetDTO.recordList[0].value);
        valueObj = $scope.recordSetDTO.recordList[0].value;
        keys = [];
        for (var x in valueObj) {
          keys.push(x);
          //console.log($scope.recordSetDTO.recordList[0].value[x] + ' ** ' + x);
        }
        keys.sort();
        // headers for the values
        $scope.recordSetDTO.keys = keys;
        $scope.cleanRecords($scope.recordSetDTO);
        if ($scope.recordSetDTO.maxRecords) {
          $scope.topicInfo.maxRecords = $scope.recordSetDTO.maxRecords;
        }
      }
      $scope.coverRecords = false;
    }, function errorCallback(response) {
      // update UI with error message
      console.log(response);
      $scope.coverRecords = false;
    });
  }

  $scope.showBadRecords = function (badRecordList) {
    if (!badRecordList || badRecordList.length == 0) {
      return false;
    }
    return true;
  }

  $scope.cleanRecords = function (recordSetDTO) {
    console.log('cleaning records...');
    console.log(recordSetDTO.showEmbedded);
    // make a pure value array of arrays
    for (var i = 0; i < $scope.recordSetDTO.recordList.length; i++) {
      var vi = [];
      var value = $scope.recordSetDTO.recordList[i].value;
      for (var j = 0; j < keys.length; j++) {
        if (recordSetDTO.showEmbedded) {
          vi.push(value[keys[j]]);
        } else {
          if ($scope.topicInfo && $scope.topicInfo.cleanFieldList) {
            if ($scope.topicInfo.cleanFieldList.indexOf(keys[j]) > -1) {
              vi.push(value[keys[j]]);
            } else {
              vi.push('[ ' + keys[j] + ']');
            }
          }
        }

      }
      $scope.recordSetDTO.recordList[i].varray = vi;
    }
  }

  $scope.addFilterCriteria = function () {
    console.log('adding filtering criteria');
    var fc = {};
    $scope.baldr.filterList.push(fc);
    $scope.baldr.filterList.forEach(function (e) {
      console.log(e);
    });
    console.log($scope.topicInfo);
    console.log($scope.topicInfo.valueType);
  }

  $scope.removeFilterCriteria = function (index) {
    console.log($scope.baldr.filterList, index);
    $scope.baldr.filterList.splice(index, 1);
    $scope.baldr.filterList.forEach(function (e) {
      console.log(e);
    });
  }

  // --------------------
  // ConsumerGroup data
  // --------------------

  $scope.getConsumerGroups = function (topic) {
    $scope.coverRecords = true;
    console.log('scope.showConsumers: ', $scope.showConsumers);
    if (!$scope.showConsumers || !topic) return;
    console.log('getting the consumer groups');
    $scope.consumerGroups = [];
    $scope.consumers = [];
    $http({
      method: 'GET',
      url: contextPath + '/topics/consumers?topic=' + topic + '&forceRefresh=' + $scope.forceConsumerGroupRefresh
    }).then(function successCallback(response) {
      $scope.consumerGroups = response.data;
      console.log($scope.consumerGroups);
      $scope.coverRecords = false;
    }, function errorCallback(response) {
      console.log('failed to get consumer groups from server');
      $scope.coverRecords = false;
    });
  }

  $scope.getConsumers = function (consumerGroup) {
    if (!$scope.showConsumers) return;
    $scope.consumers = consumerGroup.consumers;
    console.log(consumerGroup.consumers);
  }

  $scope.showConsumersChanged = function (showConsumers) {
    console.log('show consumers change to: ', showConsumers);
    $scope.showConsumers = showConsumers;
    if (showConsumers && $scope.topicInfo && $scope.topicInfo.topic) {
      $scope.getConsumerGroups($scope.topicInfo.topic);
    }
  }

}); // End TopicCtrl

kafkaApp.controller("ProducerCtrl", function ($scope, $http, $location) {

  $scope.sampleRecords = {};

  $scope.sendMessages = function () {
    console.log('sending records...');
    console.log($scope.sampleRecords);
  }

  $scope.selectedTopic = function (topicName) {
    console.log('selected: ', topicName);
  }

}); // End ProducerCtrl
