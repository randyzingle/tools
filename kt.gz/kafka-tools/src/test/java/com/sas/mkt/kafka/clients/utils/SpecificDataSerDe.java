package com.sas.mkt.kafka.clients.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.apache.avro.Schema;
import org.apache.avro.io.BinaryDecoder;
import org.apache.avro.io.BinaryEncoder;
import org.apache.avro.io.DatumReader;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.io.DecoderFactory;
import org.apache.avro.io.EncoderFactory;
import org.apache.avro.specific.SpecificDatumReader;
import org.apache.avro.specific.SpecificDatumWriter;
//tag
public class SpecificDataSerDe
{
	public <T>byte[] serializeSpecificData(T data, Schema schema) throws IOException
	{
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		BinaryEncoder encoder = EncoderFactory.get().binaryEncoder(out, null);
		DatumWriter<T> writer = new SpecificDatumWriter<T>(schema);

		writer.write(data, encoder);
		encoder.flush();
		out.close();
		byte[] serializedBytes = out.toByteArray();

		return serializedBytes;
	}

	public <T>T deserializeSpecificData(byte[] serializedBytes, Class<T> type, Schema schema) throws IOException
	{
		SpecificDatumReader<T> reader = new SpecificDatumReader<T>(schema);
		BinaryDecoder decoder = DecoderFactory.get().binaryDecoder(serializedBytes, null);

		T obj = reader.read(null, decoder);

		return obj;
	}

	public <T>T deserializeSpecificData(byte[] serializedBytes, Class<T> type, Schema schemaFrom, Schema schemaTo ) throws IOException
	{
		DatumReader<T> reader = new SpecificDatumReader<>(schemaFrom, schemaTo);
		BinaryDecoder decoder = DecoderFactory.get().binaryDecoder(serializedBytes, null);

		T obj = reader.read(null, decoder);

		return obj;
	}

}
