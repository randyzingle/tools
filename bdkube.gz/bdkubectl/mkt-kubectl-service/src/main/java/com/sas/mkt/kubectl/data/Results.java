package com.sas.mkt.kubectl.data;

import java.util.HashMap;
import java.util.Map;

/** 
 * This gets serialized as JSON and sent back to the caller
 * status: SUCCESS | FAILURE
 * message: what was built/deleted | error message
 * outputParameters: name-value pairs for CF Output fields, value is value, description
 * @author razing
 *
 */
public class Results {
	
	public String status; // SUCCESS, FAILURE
	public String message;
	public Map<String, String> outputParameters = new HashMap<>();
	@Override
	public String toString() {
		return "Results [status=" + status + ", message=" + message + ", outputParameters=" + outputParameters + "]";
	}
	
	
}
