package com.sas.mkt.kafka.clients.producers;

import java.time.Duration;
import java.util.Arrays;
import java.util.Properties;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.clients.utils.ProducerMetricsTimerTask;

public class BusinessEventsReplicator {
	
	private String configUrl = "http://configservice-dev.cidev.sas.us:8080/";
	private Consumer<String, SpecificRecordBase> consumer;
	private int runTimeMin = 30;
	private boolean done = false;
	private long maxRecords = 5 * 1000 * 1000;

	public static void main(String[] args) {
		try {
			BusinessEventsReplicator ber = new BusinessEventsReplicator();
			ber.run();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
	
	private void run() throws Exception {
		
		KafkaConnectionUtils kcu;
		try {
			kcu = KafkaConnectionUtils.getInstance(configUrl);
		} catch (Exception ex) {
			ex.printStackTrace();
			return;
		}
		
		// create the consumer
		String groupID = "replicator-" + System.currentTimeMillis();
		Properties cprops = kcu.getKafkaConsumerProperties();
		cprops.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		cprops.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		consumer = new KafkaConsumer<>(cprops);
		String readTopic = "dev-business-events";
        consumer.subscribe(Arrays.asList(readTopic));
        
        // create the producer
        String clientID = "replicator-" + System.currentTimeMillis();
		Properties pprops = kcu.getKafkaProducerProperties(clientID);
		Producer<String, SpecificRecordBase> producer = new KafkaProducer<>(pprops);
		String writeTopic = "baldur-business-events";
		
		// Test the metrics code
		TestProducerMetrics pmetrics = new TestProducerMetrics(producer, "/SAS/CI360/KafkaConsumerMetrics", "baldur");
		pmetrics.run();
        
        // start the kill switch
        Thread t = new Thread(new KillSwitch());
        t.start();
        
        // read the messages
        long cnt = 0;
        while (!done) {
        	ConsumerRecords<String, SpecificRecordBase> records = consumer.poll(Duration.ofMillis(1000l));
        	for (ConsumerRecord<String, SpecificRecordBase> record : records) {
        		cnt++;
        		if (cnt > maxRecords) break;
        		if (cnt % 5000 == 0) System.out.printf("%d records processed%n", cnt);
        		Thread.sleep(50L);
        		ProducerRecord<String, SpecificRecordBase> precord = 
        				new ProducerRecord<>(writeTopic, record.key(), record.value());
        		producer.send(precord);
        	}
        }
        producer.flush();
        producer.close();
        consumer.close();
		
	}
	
	public class KillSwitch implements Runnable {

		@Override
		public void run() {
			try {
				Thread.sleep(runTimeMin * 60 * 1000);
				done = true;
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			
		}
		
	}

}
