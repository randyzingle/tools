'''

Source code located in GitLab:
// TODO put in proper URL

Configuration:
"Handler": "KubectlManager.handler"
"Runtime": "python3.7"
"Timeout": "300"

July 7, 2020
@author: razing
'''
import json
import urllib
from urllib.request import urlopen, Request, HTTPError, URLError
from urllib.parse import urlencode
import random
import string
import time

import PostgresManager as pg_manager

# ===============================================================================
#  Constants
# ===============================================================================
STATUS_FAILED = 'FAILED'
STATUS_SUCCESS = 'SUCCESS'
MAX_PING_ATTEMPTS = 8 # maximum number of attempts to ping the container - exponential backoff

# ===============================================================================
#  Entry Point for Lambda
# ===============================================================================
def handler(event, context):
    print('++++++ Entry Point ++++++')
    print(event)
    parse_values(event)
    rtype = event.get('RequestType')

    event['PingUrl'] = 'http://mkt-kubectl.cidev.sas.us/mktKubectl/commons/ping'
    event['ServiceUrl'] = 'http://mkt-kubectl.cidev.sas.us/mktKubectl/kubectl'

    if rtype == 'Create':
        create_resource(event, context)
    elif rtype == 'Update':
        update_resource(event, context)
    elif rtype == 'Delete':
        delete_resource(event, context)
    else:
        message = rtype + ' :Not a proper request-type, should be one of [Create|Update|Delete]'
        event['message'] = message
        send_response(event, STATUS_FAILED)

# ===============================================================================
#  Create, Update, and Delete
# ===============================================================================

def create_resource(event, context):
    print('creating resource')
    event['message'] = 'parsing input parameters'
    status = post_kubectl_request(event)
    send_response(event, status)

def update_resource(event, context):
    print('updating resource')
    #status = post_kubectl_request(event)
    send_response(event, STATUS_SUCCESS)

def delete_resource(event, context):
    print('deleting resource')
    status = post_kubectl_request(event)
    send_response(event, status)

def parse_values(event):
    # these will change from template to template - we need to dynamically generate this
    parameters = {
        'dnsname' : event['ResourceProperties']['parameters']['dnsname'],
        'tiername' : event['ResourceProperties']['parameters']['tiername'],
        'dnszone' : event['ResourceProperties']['parameters']['dnszone'],
        'storage-gb' : event['ResourceProperties']['parameters']['storage-gb'],
        'postgres-version' : event['ResourceProperties']['parameters']['postgres-version']
    }
    rtype = event.get('RequestType')
    if rtype == 'Create':
        event['ResourceProperties']['lifecycle'] = 'create'
    elif rtype == 'Update':
        event['ResourceProperties']['lifecycle'] = 'update'
    elif rtype == 'Delete':
        event['ResourceProperties']['lifecycle'] = 'delete'

    values = {
       'template' : event['ResourceProperties']['template'],
       'version' : event['ResourceProperties']['version'],
       'lifecycle' : event['ResourceProperties']['lifecycle'],
       'parameters' : parameters
    }

    edata = json.dumps(values)
    print(edata)
    edata = edata.encode('utf-8')
    event['values'] = edata
    event['data'] = {}

# ===============================================================================
#  HTTP Communication with the mkt-kubectl service
# ===============================================================================

def post_kubectl_request(event):
    print('posting request')

    headers = {'Content-Length': len(event['values']), 'Content-Type': 'application/json;charset=UTF-8'}
    #print(headers)
    req = Request(
        event['ServiceUrl'],
        headers=headers,
        data=event['values'],
        method='POST')
    req.get_method = lambda: 'POST'
    try:
        response = urlopen(req)
        status = response.read()
        s = status.decode('UTF-8')
        data = json.loads(s)
        pg_manager.setOutputParameters(event, data)
        #print(event['data'])
        return event['status']
    except Exception as e:
        print(e)
        return STATUS_FAILED

# ===============================================================================
#  Cloudformation HTTP PUT response indicating SUCCESS or FAILURE of lambda
# ===============================================================================
def send_response(event, responseStatus):
    message = str(event.get('message', ''))
    print('sending response to CloudFormation')
    data = event['data']
    data['RequestType'] =  event['RequestType']
    data['message'] = event.get('message', '')
    responseBody = {
        'Status': responseStatus,
        'Reason': message,
        'StackId': event.get('StackId', ''),
        'RequestId': event.get('RequestId', ''),
        'LogicalResourceId': event.get('LogicalResourceId', ''),
        'Data': data
    }
    print(responseBody)

    # Bail if we aren't being invoked via CF but construct the above first for debugging runs
    if 'StackId' not in event:
        print('no stack id - running locally so will not respond to CF')
        return

    # PhysicalResourceId only sent with Update and Delete requests
    responseBody['PhysicalResourceId'] = event.get('PhysicalResourceId', 'None')

    #print(responseBody)
    edata = json.dumps(responseBody)
    edata = edata.encode('utf-8')
    headers = {'Content-Length': len(edata), 'Content-Type': ''}
    #print(headers)
    req = Request(
        event['ResponseURL'],
        headers=headers,
        data=edata,
        method='PUT')
    req.get_method = lambda: 'PUT'
    try:
        urlopen(req)
    except Exception as e:
        print(e)


# ===============================================================================
#  Test Code for runs from the command line
# ===============================================================================
if __name__ == "__main__":
    print('in __main__ function')

    event = '''
    {
      "RequestType": "Create",
      "ResourceProperties": {
        "template": "postgres-template",
        "version": "1.0",
        "parameters": {
          "dnsname": "persistence",
          "tiername": "finnr",
          "dnszone": "cidev.sas.us",
          "storage-gb": "20",
          "postgres-version": "9.6.6"
        }
      }
    }
    '''
    context = {}
    handler(json.loads(event), context)
