package com.sas.mkt.config.metrics;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.RegionUtils;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.cloudwatch.AmazonCloudWatchAsync;
import com.amazonaws.services.cloudwatch.AmazonCloudWatchAsyncClientBuilder;
import com.amazonaws.services.cloudwatch.model.Dimension;
import com.amazonaws.services.cloudwatch.model.MetricDatum;
import com.amazonaws.services.cloudwatch.model.PutMetricDataRequest;
import com.amazonaws.services.cloudwatch.model.PutMetricDataResult;
import com.codahale.metrics.Counter;
import com.codahale.metrics.Gauge;
import com.codahale.metrics.Histogram;
import com.codahale.metrics.Meter;
import com.codahale.metrics.Metric;
import com.codahale.metrics.MetricFilter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.ScheduledReporter;
import com.codahale.metrics.Snapshot;
import com.codahale.metrics.Timer;

/**
 * Based off Slf4jReporter from Dropwizard folks
 * 
 * @since 1812
 * @author razing
 *
 */
// TODO Mark this with external dependency interface (health, start, stop etc)
public class CloudWatchReporter extends ScheduledReporter {
	private final static Logger logger = LoggerFactory.getLogger(CloudWatchReporter.class);
	private static final String DEFAULT_REGION_NAME = "us-east-1"; // local runs
	final AmazonCloudWatchAsync awsClient;

	private String nameSpace;
	private Map<String, String> baseDimensions;

	protected CloudWatchReporter(MetricRegistry registry, String name, MetricFilter filter, String nameSpace, Map<String, String> baseDimensions) {
		super(registry, name, filter, TimeUnit.SECONDS, TimeUnit.SECONDS);
		this.nameSpace = nameSpace;
		this.baseDimensions = baseDimensions;
		awsClient = AmazonCloudWatchAsyncClientBuilder.standard().withRegion(getRegion()).build();
	}

	public static Builder forRegistry(MetricRegistry registry) {
		return new Builder(registry);
	}
	
	public static class Builder {
		
		private MetricRegistry registry;
		private MetricFilter filter;
		private String nameSpace;
		private String name;
		private Map<String, String> baseDimensions;
		
		private Builder(MetricRegistry registry) {
			this.registry = registry;
		}
		
		public Builder filter(MetricFilter filter) {
			this.filter = filter;
			return this;
		}
		
		public Builder withNameSpace(String nameSpace) {
			this.nameSpace = nameSpace;
			return this;
		}
		
		public Builder withName(String name) {
			this.name = name;
			return this;
		}
		
		public Builder withBaseDimensions(Map<String, String> baseDimensions) {
			this.baseDimensions = baseDimensions;
			return this;
		}
		
		public CloudWatchReporter build() {
			return new CloudWatchReporter(registry, name, filter, nameSpace, baseDimensions);
		}
	}

	// Limits:
	// 20 metrics per call
	// 40 KB total payload
	// 10 dimension max per metric
	@SuppressWarnings("rawtypes")
	@Override
	public void report(SortedMap<String, Gauge> gauges, SortedMap<String, Counter> counters,
			SortedMap<String, Histogram> histograms, SortedMap<String, Meter> meters, SortedMap<String, Timer> timers) {

		// Master metric list, publish in batches of 20 
		List<MetricDatum> masterList = new ArrayList<>();
		
		// Do the Gauges first, all custom metrics will be Gauges
		Set<Entry<String, Gauge>> gaugeSet = gauges.entrySet();
		for (Entry<String, Gauge> entry : gaugeSet) {
			Double value = getDoubleValueFromObject(entry.getValue().getValue());
			MetricDatum metricDatum = getGaugeMetricData(entry.getValue(), entry.getKey(), value);
			masterList.add(metricDatum); 
		}
		
		// Counters
		Set<Entry<String, Counter>> counterSet = counters.entrySet();
		for (Entry<String, Counter> entry: counterSet) {
			Counter counter = entry.getValue();
			String key = entry.getKey();
			MetricDatum metricDatum = getCounterMetricData(counter, key);
			masterList.add(metricDatum);
		}
		
		// Histograms
		Set<Entry<String, Histogram>> histogramSet = histograms.entrySet();
		for (Entry<String, Histogram> entry: histogramSet) {
			// do we need this - noop due to lazyness?
		}
		
		// Meters
		Set<Entry<String, Meter>> meterSet = meters.entrySet();
		for (Entry<String, Meter> entry: meterSet) {
			Meter meter = entry.getValue();
			String key = entry.getKey();
			List<MetricDatum> metricDatumList = getMeterMetricData(meter, key);
			masterList.addAll(metricDatumList);
		}
		
		// Timers
		Set<Entry<String, Timer>> timerSet = timers.entrySet();
		for (Entry<String, Timer> entry: timerSet) {
			Timer timer = entry.getValue();
			String key = entry.getKey();
			List<MetricDatum> metricDatumList = getTimerMetricData(timer, key);
			masterList.addAll(metricDatumList);
		}
		
		// Publish the Metrics
		publish(masterList);
	}
	
	private void publish(List<MetricDatum> masterList) {
		int size = masterList.size();
		int fromIndex = 0;
		int toIndex = 0;
		System.out.println("Total number of metrics: " + masterList.size());
		while (toIndex < size) {
			fromIndex = toIndex;
			toIndex = Math.min(fromIndex+20, size); 
			List<MetricDatum> subList = masterList.subList(fromIndex, toIndex);
			System.out.printf("Publishing %d metrics%n", subList.size());
			PutMetricDataRequest request = new PutMetricDataRequest().withNamespace(nameSpace).withMetricData(subList);
			Future<PutMetricDataResult> future = awsClient.putMetricDataAsync(request);
			try {
				PutMetricDataResult result = future.get();
			} catch (InterruptedException | ExecutionException e) {
				e.printStackTrace();
			}		
		}
	}
	
	private List<MetricDatum> getMeterMetricData(Meter meter, String compositeName) {
		// need to convert all times from nanoseconds to milliseconds
		double scale = 0.000001;	
		List<MetricDatum> list = new ArrayList<>();
		
		String name = null;
		Double value = null;
		MetricDatum datum = null;
		Map<String, String> cmap = null;
		
		name = "count";
		value = Double.parseDouble(Long.toString(meter.getCount()));
		cmap = new HashMap<>();
		cmap.put("unit", "number-of-events");
		datum = getGaugeMetricData(meter, compositeName + "." + name, value, cmap);
		list.add(datum);
		
		name = "mean-rate";
		value = meter.getMeanRate();
		cmap = new HashMap<>();
		cmap.put("unit", "rate/sec");
		datum = getGaugeMetricData(meter, compositeName + "." + name, value, cmap);
		list.add(datum);
		
		name = "five-minute-rate";
		value = meter.getFiveMinuteRate();
		cmap = new HashMap<>();
		cmap.put("unit", "rate/sec");
		datum = getGaugeMetricData(meter, compositeName + "." + name, value, cmap);
		list.add(datum);
		
		name = "fifteen-minute-rate";
		value = meter.getFifteenMinuteRate();
		cmap = new HashMap<>();
		cmap.put("unit", "rate/sec");
		datum = getGaugeMetricData(meter, compositeName + "." + name, value, cmap);
		list.add(datum);
		
		return list;
	}
	
	private MetricDatum getCounterMetricData(Counter counter, String compositeName) {
		MetricDatum datum = null;
		double value = -1;
		try {
			value = Double.parseDouble(Long.toString(counter.getCount()));
		} catch (Exception ex) {
			logger.warn("Failed to parse Counter value: {}", ex.getMessage());
		}
		Map<String, String> cmap = new HashMap<>();
		cmap.put("unit", "number-calls");
		datum = getGaugeMetricData(counter, compositeName, value, cmap);
		
		return datum;
	}

	private List<MetricDatum> getTimerMetricData(Timer timer, String compositeName) {
		// need to convert all times from nanoseconds to milliseconds
		double scale = 0.000001;
		
		List<MetricDatum> list = new ArrayList<>();
		String name = null;
		Double value = null;
		MetricDatum datum = null;
		Map<String, String> cmap = null;
		Snapshot snapshot = timer.getSnapshot();
		
		name = "mean-rate";
		value = timer.getMeanRate();
		cmap = new HashMap<>();
		cmap.put("unit", "calls/sec");
		datum = getGaugeMetricData(timer, compositeName + "." + name, value, cmap);
		list.add(datum);
		
		name = "count";
		value = Double.parseDouble(Long.toString(timer.getCount()));
		cmap = new HashMap<>();
		cmap.put("unit", "total-calls");
		datum = getGaugeMetricData(timer, compositeName + "." + name, value, cmap);
		list.add(datum);
		
		name = "mean-time";
		value = timer.getSnapshot().getMean() * scale;
		cmap = new HashMap<>();
		cmap.put("unit", "time-milliseconds");
		datum = getGaugeMetricData(timer, compositeName + "." + name, value, cmap);
		list.add(datum);
		
		name = "max-time";
		value = timer.getSnapshot().getMax() * scale;
		cmap = new HashMap<>();
		cmap.put("unit", "time-milliseconds");
		datum = getGaugeMetricData(timer, compositeName + "." + name, value, cmap);
		list.add(datum);
		
		name = "min-time";
		value = timer.getSnapshot().getMin() * scale;
		cmap = new HashMap<>();
		cmap.put("unit", "time-milliseconds");
		datum = getGaugeMetricData(timer, compositeName + "." + name, value, cmap);
		list.add(datum);
		
		return list;
	}
	
	private Double getDoubleValueFromObject(Object value) {
		Double dval;
		try {
			dval = Double.parseDouble(value.toString());
		} catch (Exception ex) {
			logger.warn("Failed to parse Gauge value: {}", ex.getMessage());
			dval = -1.0;
		}
		return dval;
	}
	
	private void publish(MetricDatum metricDatum) {
		PutMetricDataRequest request = new PutMetricDataRequest().withNamespace(nameSpace).withMetricData(metricDatum);
		Future<PutMetricDataResult> future = awsClient.putMetricDataAsync(request);
		try {
			PutMetricDataResult result = future.get();
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
	}
	
	private MetricDatum getGaugeMetricData(Metric metric, String compositeName, Double value) {
		return getGaugeMetricData(metric, compositeName, value, null);
	}
	
	
	private MetricDatum getGaugeMetricData(Metric metric, String compositeName, Double value, Map<String, String> cmap) {
		Map<String, String> dmap = null;
		List<Dimension> dimensions = new ArrayList<>();
		MetricDatum md = new MetricDatum();
		String[] fname = compositeName.split("\\.");
		if (fname.length >= 3) {
			// we have a composite name, lets grab the last part which is the name
			String name = fname[fname.length-1];
			md.setMetricName(name);
		} else {
			md.setMetricName(compositeName);
		}		
		md.setValue(value);
		md.setTimestamp(new Date());
		
		if (metric instanceof CustomMetric) {	
			dmap = ((CustomMetric)metric).getDimensions();
		} else {
			dmap = parseCompositeName(compositeName);
		}
		
		// Add the custom dimensions
		if (cmap != null && !cmap.isEmpty()) {
			Set<String> keySet = cmap.keySet();
			for (String key: keySet) {
				Dimension dimension = new Dimension();
				dimension.setName(key);
				dimension.setValue(cmap.get(key));
				dimensions.add(dimension);
			}	
		}
		// Add the base dimensions
		if (baseDimensions != null && !baseDimensions.isEmpty()) {
			Set<String> keySet = baseDimensions.keySet();
			for (String key: keySet) {
				Dimension dimension = new Dimension();
				dimension.setName(key);
				dimension.setValue(baseDimensions.get(key));
				dimensions.add(dimension);
			}
		}
		// Add the attached dimensions
		if (dmap != null && !dmap.isEmpty()) {
			Set<String> keySet = dmap.keySet();
			for (String key: keySet) {
				Dimension dimension = new Dimension();
				dimension.setName(key);
				dimension.setValue(dmap.get(key));
				dimensions.add(dimension);
			}	
		}
		md.setDimensions(dimensions);
		return md;
	}
	
	private Map<String, String> parseCompositeName(String name) {
		Map<String, String> dmap = new HashMap<>();
		if (name != null) {
			String[] names = name.split("\\.");
			for (int i=0; i < names.length -1; i++) {
				if (i==0) {
					dmap.put("category", names[i]);
				} else if (i==1) {
					dmap.put("subcategory", names[i]);
				} else {
					dmap.put("field"+(i-1), names[i]);
				}
			}
		}
		return dmap;
	}
	
	private String getRegion() {
		// this will return the region it's running in when running in EC2, otherwise it will return null 
		// TODO see if this works in ECS as well as EC2 ...
		Region region = Regions.getCurrentRegion();
		if (region == null)
			region = RegionUtils.getRegion(DEFAULT_REGION_NAME);
		return region.getName();
	}

}
