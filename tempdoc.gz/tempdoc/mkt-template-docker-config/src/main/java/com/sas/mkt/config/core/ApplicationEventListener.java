package com.sas.mkt.config.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.appspecific.GlobalConfiguration;

/**
 * @author razing
 *
 */
@Component
public class ApplicationEventListener {
    
    private final static Logger logger = LoggerFactory.getLogger( ApplicationEventListener.class );
	

	ApplicationConfiguration appConfig;
	GlobalConfiguration globalConfig;
	
	@Autowired
	public ApplicationEventListener(ApplicationConfiguration appConfig, GlobalConfiguration globalConfig) {
		this.appConfig = appConfig;
		this.globalConfig = globalConfig;
	}

	@EventListener
    public void handleContextRefresh(ContextRefreshedEvent event) {
		BaseUtils.bigInfo("Context Refreshed", logger);
		logger.info(appConfig.toString());
		logger.info(globalConfig.toString());
    }
	
	@EventListener
	public void handleApplicationReady(ApplicationReadyEvent event) {
		BaseUtils.bigInfo("ApplicationReady", logger);
		logger.info(appConfig.toString());
		logger.info(globalConfig.toString());
	}

}
