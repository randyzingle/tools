package com.sas.mkt.kafka.clients.files;

import java.io.File;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.avro.file.DataFileReader;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.DatumReader;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.producer.BufferExhaustedException;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.errors.InterruptException;
import org.apache.kafka.common.errors.SerializationException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.domain.events.RawEvent;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;

public class FileSourceWithProducer {

    private String fileName;
    private ApplicationConfiguration appConfig = new ApplicationConfiguration();
    private static String topic;

    public static void main(String[] args) {
    	FileSourceWithProducer kfs = new FileSourceWithProducer();
        try {

        	topic = "baldurx-enhanced-events";
        	String f = "baldur-enhanced-events";
        	kfs.fileName = "src/main/resources/data/"+f+".avro";
        	kfs.generic();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    private Producer<String, SpecificRecordBase> getProducer() throws Exception {
		KafkaConnectionUtils kcu;
		kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
		String clientID = appConfig.getTierName() + "-" + appConfig.getComponentName();
		Properties props = kcu.getKafkaProducerProperties(clientID);
		Producer<String, SpecificRecordBase> producer = new KafkaProducer<>(props);
		return producer;
    }

    private void generic() throws Exception {
        File avroFile = new File(fileName);
        DatumReader<GenericRecord> reader = new GenericDatumReader<GenericRecord>();
        DataFileReader<GenericRecord> fileReader = new DataFileReader<GenericRecord>(avroFile, reader);
        GenericRecord record = new GenericData.Record(fileReader.getSchema());
        ObjectMapper mapper = new ObjectMapper();
        Producer<String, SpecificRecordBase> producer = getProducer();
        int cnt = 0;
        while (fileReader.hasNext()) {
        	cnt++;
            fileReader.next(record);   
            String newRec = record.toString();

            RawEvent event = mapper.readValue(newRec, RawEvent.class); 


            System.out.println(cnt + ": " + event);
            ProducerRecord<String, SpecificRecordBase> precord = new ProducerRecord<>(topic, event.getSessionId(), event);
            try {
				producer.send(precord);
			} catch (SerializationException|BufferExhaustedException|InterruptException ex) {
				ex.printStackTrace();
			}
        }
        fileReader.close();
 		producer.flush();
 		long sleep = 2000L;
 		producer.close(sleep, TimeUnit.MILLISECONDS);
        System.out.println("wrote " + cnt  + " records");
    }

}
