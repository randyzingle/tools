package com.sas.mkt.baldur.spring.temp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.Metrics;
import io.micrometer.core.instrument.Timer;

@Component
public class BlabberMetrics {
	
	private boolean runit = true;
	
	public void start() {
		runit = true;
		System.out.println("Starting BlabberMetrics...");
		simpleTimer();
		statsdGauge();
		simpleGauge();
		simpleCounter2();
		samCounter();
		simpleCounter();
		counterNoTags();
	}
	
	public void stop() {
		runit = false;
	}
	
	private void simpleTimer() {
		Timer timer = Metrics.timer("bs.bstimer", "info", "true");
		TimerBlabber tb = new TimerBlabber();
		tb.configure(2000l);
		tb.setMeter(timer);
		Thread t1 = new Thread(tb);
		t1.start();
	}
	
	private void statsdGauge() {
		List<String> list = new ArrayList<>(4);
		Gauge gauge = Gauge
				  .builder("bs.butters", list, List::size)
				  .tags("scaling", "false", "info", "true")
				  .register(Metrics.globalRegistry);
		GaugeBlabber cb = new GaugeBlabber(list);
		cb.configure(10000l, "bs.butters");
		cb.setMeter(gauge);
		Thread t1 = new Thread(cb);
		t1.start();
	}
	
	private void simpleGauge() {
		List<String> list = new ArrayList<>(4);
		Gauge gauge = Gauge
				  .builder("bs.finnr", list, List::size)
				  .tags("scaling", "false", "info", "true")
				  .register(Metrics.globalRegistry);
		
		GaugeBlabber cb = new GaugeBlabber(list);
		cb.configure(5000l, "bs.finnr");
		cb.setMeter(gauge);
		Thread t1 = new Thread(cb);
		t1.start();
	}
	
	private void simpleCounter2() {
		Counter c1 = Metrics.counter("bs.aldir", "scaling", "true", "info", "true");
		CounterBlabber cb = new CounterBlabber();
		cb.configure(3000l, "bs.aldir");
		cb.setMeter(c1);
		Thread t1 = new Thread(cb);
		t1.start();
	}
	
	private void samCounter() {
		Counter c1 = Metrics.counter("bs.sam", "scaling", "true", "info", "true");
		CounterBlabber cb = new CounterBlabber();
		cb.configure(1000l, "bs.sam");
		cb.setMeter(c1);
		Thread t1 = new Thread(cb);
		t1.start();
	}
	
	private void simpleCounter() {
		Counter c1 = Metrics.counter("bs.baldur", "scaling", "true", "info", "true");
		CounterBlabber cb = new CounterBlabber();
		cb.configure(6000l, "bs.baldur");
		cb.setMeter(c1);
		Thread t1 = new Thread(cb);
		t1.start();
	}

	
	private void counterNoTags() {
		Counter c1 = Metrics.counter("bs.mymir");
		CounterBlabber cb = new CounterBlabber();
		cb.configure(3000l, "bs.mymir");
		cb.setMeter(c1);
		Thread t1 = new Thread(cb);
		t1.start();
	}
	
	private class TimerBlabber implements Runnable {
		
		private Long sleepTime = 1000l;
		private Timer meter;
		private void setMeter(Timer meter) {
			this.meter = meter;
		}
		
		public void configure(long sleepTime) {
			this.sleepTime = sleepTime;
		}
		
		@Override
		public void run() {
			while (runit) {
				meter.record(() -> {
					try {
						long dt = (long) (Math.random() * 100);
						Thread.sleep(950l + dt); // 1000 ms +/- 50 ms
					} catch (Exception ex) {
						ex.printStackTrace();
					}
				});
				try {
					Thread.sleep(sleepTime);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		
	}
	
	private class CounterBlabber implements Runnable {
		
		public void configure(long sleepTime, String name) {
			this.sleepTime = sleepTime;
			this.name = name;
		}
		private String name;
		private Long sleepTime = 1000l;
		private Counter meter;
		private void setMeter(Counter meter) {
			this.meter = meter;
		}

		@Override
		public void run() {
			while(runit) {
				meter.increment();
//				System.out.println("*** incrementing counter for : " + name + " -> " + meter.count());
				try {
					Thread.sleep(sleepTime);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		
	}
	
	private class GaugeBlabber implements Runnable {
		
		List<String> list;
		
		public GaugeBlabber(List<String> list) {
			this.list = list;
		}
		
		public void configure(long sleepTime, String name) {
			this.sleepTime = sleepTime;
			this.name = name;
		}
		private String name;
		private Long sleepTime = 1000l;
		private Gauge meter;
		private void setMeter(Gauge meter) {
			this.meter = meter;
		}

		@Override
		public void run() {
			int i = 0;
			while(runit) {
				i++;
				list.add("hello");
				double val = meter.value();
//				System.out.println("*** gauge value for : " + name + " -> " + val);
				try {
					Thread.sleep(sleepTime);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if (i % 1000 == 0) {
					System.out.println("CLEARING THE LIST for GAUGES");
					list.clear();
				}
			}
			
		}
		
	}
}
