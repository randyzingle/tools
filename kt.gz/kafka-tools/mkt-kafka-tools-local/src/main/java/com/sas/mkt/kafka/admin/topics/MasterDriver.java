package com.sas.mkt.kafka.admin.topics;

import org.apache.avro.specific.SpecificRecordBase;

import com.sas.mkt.kafka.admin.topics.utils.SimpleGenericConsumer;

public class MasterDriver {

	public static void main(String[] args) {
		String avroTopic = "test-business-events";
//		String stringTopic = "test-on-prem-agentNoAVRO";
		String stringTopic = "__consumer_offsets";
		
		SimpleGenericConsumer<SpecificRecordBase> sgca = new SimpleGenericConsumer<>(SpecificRecordBase.class);
		sgca.setup(avroTopic);
		sgca.readMessages(2);
		
		SimpleGenericConsumer<String> sgcs = new SimpleGenericConsumer<>(String.class);
		sgcs.setup(stringTopic);
		sgcs.readMessages(2);

	}

}
