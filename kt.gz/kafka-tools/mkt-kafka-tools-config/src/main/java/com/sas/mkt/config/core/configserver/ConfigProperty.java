package com.sas.mkt.config.core.configserver;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author razing
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ConfigProperty
{
	public static final String MEDIA_TYPE_BASE_VALUE = "application/vnd.sas.configuration.configproperty";
    public static final String MEDIA_TYPE_JSON_VALUE = "application/vnd.sas.configuration.configproperty+json";
    public static final String COLLECTION_NAME = "configproperties";
    public static final String AUDIT_COMPONENT_HEADER = "AuditComponent";
 
    public int version = 1;
    public String id;
    public String name;
    public String value;
    public String description;
    public String date;
    public String tierId;
    public String tierNm;
    public String tierDesc;
    public String componentId;
    public String componentNm;
    public String componentDesc;
    
	public ConfigProperty() {}
    
    public ConfigProperty(String tierNm, String componentNm, String name, String value) {
    		this.tierNm = tierNm;
    		this.componentNm = componentNm;
    		this.name = name;
    		this.value = value;
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((componentNm == null) ? 0 : componentNm.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((tierNm == null) ? 0 : tierNm.hashCode());
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		result = prime * result + version;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ConfigProperty other = (ConfigProperty) obj;
		if (componentNm == null) {
			if (other.componentNm != null)
				return false;
		} else if (!componentNm.equals(other.componentNm))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (tierNm == null) {
			if (other.tierNm != null)
				return false;
		} else if (!tierNm.equals(other.tierNm))
			return false;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		if (version != other.version)
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ConfigProperty [version=").append(version).append(", id=").append(id).append(", name=")
				.append(name).append(", value=").append(value).append(", description=").append(description)
				.append(", date=").append(date).append(", tierId=").append(tierId).append(", tierNm=").append(tierNm)
				.append(", tierDesc=").append(tierDesc).append(", componentId=").append(componentId)
				.append(", componentNm=").append(componentNm).append(", componentDesc=").append(componentDesc)
				.append("]");
		return builder.toString();
	}
  
}