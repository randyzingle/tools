package com.sas.mkt.kafka.examples.connect;



import java.util.Collections;
import java.util.Map;

import org.apache.kafka.common.utils.Utils;
import org.apache.kafka.common.utils.Time;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class SimpleFileConnect {
	
	private static final Logger log = LoggerFactory.getLogger(SimpleFileConnect.class);
	private static String workerPropsFile = "Source/resources/worker-fsconfig.properties";
	private static String connectorPropsFile = "Source/resources/connector-fsconfig.properties";

	public static void main(String[] args) {
		SimpleFileConnect sfc = new SimpleFileConnect();
		try {
			sfc.run();
		} catch (Exception ex) {
			log.info(ex.toString());
		}
	}

	private void run() throws Exception {
		// load worker and connector property files
		Map<String, String> workerProps = !workerPropsFile.isEmpty() ?
                Utils.propsToStringMap(Utils.loadProps(workerPropsFile)) : Collections.<String, String>emptyMap();
        log.info("****** worker properties ******");
        for (String s: workerProps.keySet()) {
        	log.info(s + "=" + workerProps.get(s));
        }
        log.info("****** worker properties ******");
        Map<String, String> connectorProps = Utils.propsToStringMap(Utils.loadProps(connectorPropsFile));
        for (String s: connectorProps.keySet()) {
        	log.info(s + "=" + connectorProps.get(s));
        }
        // run the job

	}

}
