package com.sas.mkt.kafka.tools.startup;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.core.ApplicationConstants;
import com.sas.mkt.config.core.BaseUtils;
import com.sas.mkt.config.metrics.MetricReporterRegistry;

@Component
public class MetricsSetupRunner implements ApplicationRunner, Ordered {

	@Autowired 
	ApplicationConfiguration appConfig;
	
	@Autowired
	MetricReporterRegistry metricReporterRegistry;

	@Override
	public int getOrder() {
		return ApplicationConstants.CONFIG_SERVICE_RUNNER_ORDER + 2;
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		BaseUtils.bigPrint("MetricsSetupRunner starting");
		metricReporterRegistry.init();
	}

}
