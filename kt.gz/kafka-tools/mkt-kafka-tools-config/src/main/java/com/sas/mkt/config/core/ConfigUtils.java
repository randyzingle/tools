package com.sas.mkt.config.core;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.support.ResourcePropertySource;
import org.springframework.stereotype.Component;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.appspecific.GlobalConfiguration;
import com.sas.mkt.config.core.configserver.ConfigProperty;
import com.sas.mkt.config.core.configserver.ConfigServerClient;
import com.sas.mkt.config.health.ExternalDependency;

/**
 * @author razing
 *
 */
@Component
public class ConfigUtils implements ExternalDependency {
	private final static Logger logger = LoggerFactory.getLogger(ConfigUtils.class);

	ApplicationConfiguration appConfig;
	GlobalConfiguration globalConfig;
	PropertyMap propertyMap;
	Environment env;
	ConfigServerClient configClient;

	@Autowired
	public ConfigUtils(ApplicationConfiguration appConfig, GlobalConfiguration globalConfig, PropertyMap propertyMap,
			ConfigServerClient configClient, Environment env) {
		this.appConfig = appConfig;
		this.globalConfig = globalConfig;
		this.propertyMap = propertyMap;
		this.configClient = configClient;
		this.env = env;
	}

	public void initializePropertyMap() {
		propertyMap.initialize();
	}

	// This handles deletion from the configuration server
	public void deleteApplicationConfigServerProperty(Configuration config, PropertyDetails pd) {
		if (pd != null) {
			try {
				String nname = ConfigUtils.normalizeName(pd.getName());
				// Set value in Configuration class
				Method setMethod = pd.getSetMethod();
				this.setValue(config, setMethod, pd.getType(), pd.getValue());
				// Set property map value
				if (config instanceof ApplicationConfiguration) {
					propertyMap.propertyMap.get(PropertyMap.APPLICATION).put(nname, pd);
				}
			} catch (NullPointerException ex) {
				logger.error(ex.getMessage());
			} catch (NumberFormatException | SecurityException ex) {
				logger.error(ex.getMessage());
			} catch (Exception ex) {
				logger.error(ex.getMessage());
			}
		}
	}

	// This handles inserts and updates to the configuration server
	public Map<String, Object> updateProperties(Configuration config, List<ConfigProperty> configProp, TreeMap<String, PropertyDetails> map) {
		// Well use this below for global properties only, to see if we have a tier_global_overrides.property
		// the config server values override application.properties but do not override tier_global_overrides.properties
		ConfigurableEnvironment ce = (ConfigurableEnvironment) env;
		ResourcePropertySource tierGlobalPropertySource = (ResourcePropertySource) ce.getPropertySources().get(ApplicationConstants.PSN_TIER_GLOBAL_OVERRIDES);
		String[] tierGlobalPropNames = {};
        if(tierGlobalPropertySource != null) {
               tierGlobalPropNames = tierGlobalPropertySource.getPropertyNames();
        }

		Map<String, Object> csmap = new HashMap<>();
		String psName = null;
		if (config instanceof GlobalConfiguration) {
			psName = ApplicationConstants.PSN_CONFIG_SERVER_GLOBAL;
		} else if (config instanceof ApplicationConfiguration) {
			psName = ApplicationConstants.PSN_CONFIG_SERVER_APPLICATION;
		}
		for (ConfigProperty prop: configProp) {			
			// GlobalConfig: only use config server value if we haven't set this field locally
			if (config instanceof GlobalConfiguration) {
				boolean match = false;
				for (String s: tierGlobalPropNames) {
					s = s.replace("tier_global.", "");
					if (normalizeName(s).equals(normalizeName(prop.name))) {
						match = true;
						break;
					}
				}
				if (match) {
					match = false;
					continue;
				}
			}
			String normName = ConfigUtils.normalizeName(prop.name);
			if (map.containsKey(normName)) {
				PropertyDetails pd = map.get(normName);
				if (pd != null) {
					pd.setValue(prop.value);
					pd.setComponentNm(prop.componentNm);
					pd.setTierNm(prop.tierNm);
					pd.setPropertySourceName(psName);
					pd.setId(prop.id);			
					try {
						Method setMethod = pd.getSetMethod();
						config.getNewOverrides().put(normName, pd);
						this.setValue(config, setMethod, pd.getType(), pd.getValue());
						csmap.put(pd.getName(), pd.getValue());
					} catch (NullPointerException ex) {
						logger.error(ex.getMessage());
					} catch (NumberFormatException | SecurityException ex) {
						logger.error(ex.getMessage());
					} catch (Exception ex) {
						logger.error(ex.getMessage());
					}
				}
			}
		}
		return csmap;
	}

	private void initializeOverrides(Configuration config) {
		HashMap<String, PropertyDetails> oldOverrides = config.getOldOverrides();
		HashMap<String, PropertyDetails> newOverrides = config.getNewOverrides();
		// dump the old
		oldOverrides.clear();
		// load the old with the latest values
		Set<String> keySet = newOverrides.keySet();
		for (String key : keySet) {
			oldOverrides.put(key, new PropertyDetails(newOverrides.get(key)));
		}
		// clear out the new for this pass
		newOverrides.clear();
	}

	public void getApplicationProperties() {
		// initialize the config server overrides
		initializeOverrides(appConfig);
		// the application properties should be based on the tierNm and componentNm
		String tierName = appConfig.getTierName();
		String componentName = appConfig.getComponentName();
		String name = "";
		String auditComponent = appConfig.getComponentName();

		// get the property map
		TreeMap<String, PropertyDetails> applicationMap = propertyMap.propertyMap.get(PropertyMap.APPLICATION);

		// load for componentName=component_global
		List<ConfigProperty> cpListGlobal = configClient.getProperties(tierName,
				ApplicationConstants.GLOBAL_COMPONENT_NAME, name, auditComponent);
		Map<String, Object> csmap = this.updateProperties(appConfig, cpListGlobal, applicationMap);

		// load for the specific component and over-write and component_global values
		// with those for our specific component
		List<ConfigProperty> cpListSpecific = configClient.getProperties(tierName, componentName, name, auditComponent);
		csmap.putAll(this.updateProperties(appConfig, cpListSpecific, applicationMap));

		// load config property for replay-mkt-datahub-loader endpoint url
		List<ConfigProperty> cpListDatahubEndpoint = configClient.getProperties(tierName, ApplicationConstants.COMPONENTNM_SERVICE_DISCOVERY, "replay-mkt-datahub-loader.service_URL", auditComponent);
		csmap.putAll(this.updateProperties(appConfig, cpListDatahubEndpoint, applicationMap));

		// We'll store the values in our ApplicationConfigProperties but also as a
		// PropertySource so we can tell *where* the property came from
		ConfigurableEnvironment ce = (ConfigurableEnvironment) env;
		MutablePropertySources sources = ce.getPropertySources();

		// use addFirst() so that the config server values will override the local
		// properties
		// this will let us set feature flags in the config server that will override
		// everything in a running app
		sources.addFirst(new MapPropertySource(ApplicationConstants.PSN_CONFIG_SERVER_APPLICATION, csmap));
		logger.debug(appConfig.toString());
	}

	public void getTierGlobalProperties() {
		// initialize the config server overrides
		initializeOverrides(globalConfig);

		String tierName = "tier_global";
		String componentName = "";
		String name = "";
		String auditComponent = appConfig.getComponentName();

		// get the property map
		TreeMap<String, PropertyDetails> globalMap = propertyMap.propertyMap.get(PropertyMap.GLOBAL);

		// Get whatever Service Discovery info we need
		componentName = ApplicationConstants.COMPONENTNM_SERVICE_DISCOVERY;
		List<ConfigProperty> cpList = configClient.getProperties(tierName, componentName, name, auditComponent);

		// Get whatever Kafka info we need
		componentName = ApplicationConstants.COMPONENTNM_MKT_KAFKA;
		cpList.addAll(configClient.getProperties(tierName, componentName, name, auditComponent));

		// Get whatever Redis info we need
		componentName = ApplicationConstants.COMPONENTNM_AWS_REDIS;
		cpList.addAll(configClient.getProperties(tierName, componentName, name, auditComponent));

		// Get whatever S3 Bucket info we need
		componentName = ApplicationConstants.COMPONENTNM_AWS_S3_BUCKETS;
		cpList.addAll(configClient.getProperties(tierName, componentName, name, auditComponent));

		Map<String, Object> csmap = updateProperties(globalConfig, cpList, globalMap);

		// We'll store the values in our ApplicationConfigProperties but also as a
		// PropertySource so we can tell *where* the property came from
		ConfigurableEnvironment ce = (ConfigurableEnvironment) env;
		MutablePropertySources sources = ce.getPropertySources();

		// *NOTE ADDLAST* local properties for the global resources will override the
		// config server
		sources.addLast(new MapPropertySource(ApplicationConstants.PSN_CONFIG_SERVER_GLOBAL, csmap));
		logger.debug(globalConfig.toString());

	}

	public synchronized void setValue(Configuration config, Method setMethod, Class<?> ctype, String value) {
		String type = ctype.getName();
		try {
			if (type.equals(String.class.getName())) {
				setMethod.invoke(config, value);
			} else if (type.equals(Boolean.class.getName()) || type.equals("boolean")) {
				setMethod.invoke(config, Boolean.valueOf(value));
			} else if (type.equals(Byte.class.getName()) || type.equals("byte")) {
				setMethod.invoke(config, Byte.valueOf(value));
			} else if (type.equals(Double.class.getName()) || type.equals("double")) {
				setMethod.invoke(config, Double.valueOf(value));
			} else if (type.equals(Float.class.getName()) || type.equals("float")) {
				setMethod.invoke(config, Float.valueOf(value));
			} else if (type.equals(Integer.class.getName()) || type.equals("int")) {
				setMethod.invoke(config, Integer.valueOf(value));
			} else if (type.equals(Long.class.getName()) || type.equals("long")) {
				setMethod.invoke(config, Long.valueOf(value));
			} else if (type.equals(Short.class.getName()) || type.equals("short")) {
				setMethod.invoke(config, Short.valueOf(value));
			}
		} catch (InvocationTargetException | IllegalAccessException ex) {
			logger.error(ex.getMessage());
		}
	}

	public static synchronized String normalizeName(String s) {
		if (s == null)
			return s;
		return s.toUpperCase().replaceAll("_", "").replaceAll("-", "").replaceAll("\\.", "");
	}

	@Override
	public boolean isHealthy() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void init() {
		initializePropertyMap();
		getApplicationProperties();
		getTierGlobalProperties();
	}

	@Override
	public void restart() {
		// TODO Auto-generated method stub

	}

}