package com.sas.mkt.config.core;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.mock.env.MockEnvironment;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.appspecific.GlobalConfiguration;
import com.sas.mkt.config.core.configserver.ConfigProperty;
import com.sas.mkt.config.core.configserver.ConfigServerClient;

@RunWith(MockitoJUnitRunner.class)
public class ConfigUtilsTest {
	
	private final static Logger logger = LoggerFactory.getLogger(ConfigServerClient.class);

	ConfigUtils configUtils = null;


	private ConfigurableEnvironment env;
	private PropertyMap propertyMap;
	private ApplicationConfiguration appConfig;
	private GlobalConfiguration globalConfig;
	private ConfigServerClient configClient;

	@Mock
	ApplicationEventPublisher publisher;

	@Before
	public void setUp() {
		appConfig = new ApplicationConfiguration();
		globalConfig = new GlobalConfiguration();
		env = new MockEnvironment();
		propertyMap = new PropertyMap(appConfig, globalConfig, env);
		configClient = new ConfigServerClient(appConfig);
		configUtils = new ConfigUtils(appConfig, globalConfig, propertyMap, configClient, env);
	}
	
	@Test
	public void testNotMuch() {
		String message = "does Java still work?";
		BaseUtils.bigDebug(message, logger);
		BaseUtils.bigInfo(message, logger);
		BaseUtils.bigPrint(message);
	}
	
	@Test
	public void testBoom() {
		configUtils.getApplicationProperties();
		configUtils.getTierGlobalProperties();
	}

	@Test
	public void testDelete() {
		try {
			ApplicationConfiguration appConfig2 = new ApplicationConfiguration();
			PropertyDetails pd = new PropertyDetails("tierName", "goaway", String.class,
					ApplicationConfiguration.class.getMethod("getTierName"),
					ApplicationConfiguration.class.getMethod("setTierName", String.class));
			configUtils.deleteApplicationConfigServerProperty(appConfig2, pd);
		} catch (Exception ex) {
			fail(ex.getMessage());
		}
	}

	@Test
	public void testUpdate() {
		try {
			ApplicationConfiguration appConfig2 = new ApplicationConfiguration();
			PropertyDetails pd = new PropertyDetails("configStackName", "testStack", String.class,
					ApplicationConfiguration.class.getMethod("getConfigStackName"),
					ApplicationConfiguration.class.getMethod("setConfigStackName", String.class));
			TreeMap<String, PropertyDetails> details = new TreeMap<>();
			details.put("CONFIGSTACKNAME", pd);

			MutablePropertySources mps = new MutablePropertySources();

			Map<String, Object> csmapApp = new HashMap<>();
			Map<String, Object> csmapGlobal = new HashMap<>();
			Map<String, Object> csmapGlobalOverrides = new HashMap<>();
			mps.addFirst(new MapPropertySource(ApplicationConstants.PSN_CONFIG_SERVER_APPLICATION, csmapApp));
			mps.addLast(new MapPropertySource(ApplicationConstants.PSN_CONFIG_SERVER_GLOBAL, csmapGlobal));
			mps.addBefore(ApplicationConstants.PSN_CONFIG_SERVER_GLOBAL,
					new MapPropertySource(ApplicationConstants.PSN_TIER_GLOBAL_OVERRIDES, csmapGlobalOverrides));

			List<ConfigProperty> props = new ArrayList<ConfigProperty>();
			ConfigProperty cp = new ConfigProperty();
			cp.name = "configStackName";
			cp.value = "testStack";
			props.add(cp);
		} catch (Exception ex) {
			fail(ex.getMessage());
		}
	}

	@Test
	public void testSimpleJavaGetSet() {
		// this is very useful
		HashMap<String, PropertyDetails> map = appConfig.getOriginalProperties();
		assertNotNull(map);
		map = appConfig.getOldOverrides();
		assertNotNull(map);
	}

}
