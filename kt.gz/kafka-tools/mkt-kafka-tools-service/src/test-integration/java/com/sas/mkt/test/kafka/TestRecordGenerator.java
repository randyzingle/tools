package com.sas.mkt.test.kafka;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.sas.mkt.kafka.domain.DogNames;
import com.sas.mkt.kafka.domain.TestEvent;

public class TestRecordGenerator {

	public List<TestEvent> getTestEventList(int nrecords) {
		return getTestEventList(nrecords, 1000);
	}

	public List<TestEvent> getTestEventList(int nrecords, int textSize) {

		Random rnd = new Random();
		List<TestEvent> elist = new ArrayList<TestEvent>(nrecords);
		int seq = 1;
		for (int i = 0; i < nrecords; i++) {
			long time = System.currentTimeMillis();
			String site = "www.razing.com";
			String ip = "192.168.2." + rnd.nextInt(5);
			String tenant = null;
			int nexti = rnd.nextInt(5);
			if (nexti == 0)
				tenant = "baldursoft" + rnd.nextInt(2);
			if (nexti == 1)
				tenant = "mymir-ai" + rnd.nextInt(2);
			if (nexti == 2)
				tenant = "butters" + rnd.nextInt(2);
			if (nexti == 3)
				tenant = "gabriel" + rnd.nextInt(2);
			if (nexti == 4)
				tenant = "rafael" + rnd.nextInt(2);
			TestEvent.Builder bdr = TestEvent.newBuilder();
			bdr.setIp(ip).setSite(site).setTime(time);
			String text = "Always the same text!";
			bdr.setText(text);
			if (tenant != null)
				bdr.setTenant(tenant);
			if (seq != 0)
				bdr.setSequence(seq);
			int dogn = rnd.nextInt(4);
			if (dogn == 0) {
				bdr.setDogs(DogNames.Baldur);
			} else if (dogn == 1) {
				bdr.setDogs(DogNames.Butters);
			} else if (dogn == 2) {
				bdr.setDogs(DogNames.Mymir);
			} else {
				bdr.setDogs(null);
			}

			Double shipping = 12.22;
			bdr.setTotalShipping(shipping);
			Double tax = 1.34;
			bdr.setTotalTax(tax);
//			DateTime date = DateTime.now();
			bdr.setTimeStamp(System.currentTimeMillis());
			seq++;
			elist.add(bdr.build());
		}

		return elist;
	}
}
