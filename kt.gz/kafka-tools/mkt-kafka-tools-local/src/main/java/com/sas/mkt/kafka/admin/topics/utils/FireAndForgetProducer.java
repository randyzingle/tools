package com.sas.mkt.kafka.admin.topics.utils;

import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.producer.BufferExhaustedException;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.errors.InterruptException;
import org.apache.kafka.common.errors.SerializationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.clients.producers.utils.TestRecordGenerator;
import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.clients.utils.KafkaTopicUtils;
import com.sas.mkt.kafka.domain.TestEvent;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;


public class FireAndForgetProducer {
	
	private static final Logger logger = LoggerFactory.getLogger(FireAndForgetProducer.class);

//	private static final int ONE_MILLION = 1000000;
	ApplicationConfiguration appConfig = new ApplicationConfiguration();

	public static void main(String[] args) {
		FireAndForgetProducer app = new FireAndForgetProducer();
		app.fireAndForget();
	}
	
	private void fireAndForget() {
		KafkaConnectionUtils kcu;
		try {
			kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			return;
		}
		String topic = "baldur-test-events";
		String clientID = appConfig.getTierName() + "-" + appConfig.getComponentName();
		Properties props = kcu.getKafkaProducerProperties(clientID);
		Producer<String, SpecificRecordBase> producer = new KafkaProducer<>(props);
		TestRecordGenerator werg = new TestRecordGenerator();
		
		// create the ProducerRecord and send ignoring the returned RecordMetadata
		int cnt = 0;
		int nloops = 5;
		int nrecords = 50;

		List<TestEvent> weblist = null;
		for (int i=0; i<nloops; i++) {
			weblist = werg.getTestEventList(nrecords/nloops);
			for (TestEvent we: weblist) {
				we.setText("batch mymir");
				cnt++;
				ProducerRecord<String, SpecificRecordBase> record = new ProducerRecord<>(topic, we.getTenant(), we);
				// note, send() actually places the message in a buffer which is read and sent by a separate thread
				try {
					producer.send(record);
				} catch (SerializationException|BufferExhaustedException|InterruptException ex) {
					ex.printStackTrace();
				}
				if (cnt%(nrecords/nloops)==0) {
					logger.info("sent message " + cnt);
					System.out.println(record.value());
//					try {
//                        Thread.sleep(50);
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
				}
			}
		}
		
		// give the buffer a chance to empty out
		producer.flush();
		long sleep = 2000L;
		producer.close(sleep, TimeUnit.MILLISECONDS);
	}
}
