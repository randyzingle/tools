package com.sas.mkt.kafka.clients.utils;

import java.time.Duration;
import java.util.Arrays;
import java.util.Properties;
import java.util.Timer;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.annotation.InterfaceStability;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//tag
/**
 * @author razing
 *
 */
@InterfaceStability.Unstable
public class SampleSingleThreadConsumer {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	private String topic = "baldur-test-events";
	private String configServiceURL = "http://configservice-dev.cidev.sas.us:8080/";
	private String tierName = "finnr";
	private String componentName="mkt-baldur-spring";

	private boolean done = false;

	public static void main(String[] args) {
		SampleSingleThreadConsumer bc = new SampleSingleThreadConsumer();
		bc.simpleConsumeMessages();
	}

	private void simpleConsumeMessages() {
		// Set up the consumer
		KafkaConnectionUtils kcu;
		try {
			kcu = KafkaConnectionUtils.getInstance(configServiceURL);
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			return;
		}

		// Simple unique groupID FOR TESTING! This is not production code - use the same groupID
		// every time, preferably String groupID = tierName + "-" + componentName;
		String groupID = tierName + "-" + componentName + System.currentTimeMillis();

		Properties props = kcu.getKafkaConsumerProperties(tierName, componentName);
		// also need this to read from the beginning each time
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		KafkaConsumer<String, SpecificRecordBase> consumer = new KafkaConsumer<>(props);
		Timer timer = KafkaConnectionUtils.scheduleMetricsTimer(consumer, "baldursoft2", 60, 60);
		consumer.subscribe(Arrays.asList(topic));

		// Consume Messages
		int cnt = 0;
		SpecificRecordBase te = null;
		Thread t = new Thread(new KillSwitch());
		t.start();
		System.out.println("CONSUMING MESSAGES.....");
		while (!done) {
			ConsumerRecords<String, SpecificRecordBase> records = consumer.poll(Duration.ofSeconds(1000l));
			for (ConsumerRecord<String, SpecificRecordBase> record : records) {
				cnt++;
				te = record.value();
				if (cnt % 100 == 0) {
					try {
						Thread.sleep(500l);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					System.out.println(cnt + ": " + te);
				}
			}
		}
		System.out.println("Closing the consumer");
		consumer.close();

	}

	public class KillSwitch implements Runnable {

		@Override
		public void run() {
			try {
				Thread.sleep(5 * 60 * 1000);
				done = true;
				System.out.println("Hit killswitch");
			} catch (Exception ex) {
				ex.printStackTrace();
			}

		}

	}
}
