package com.sas.mkt.kafka.admin.topics.admin;

public class ConsumerDTO {
	public String clientId; // kafka generated
	public String consumerId; // set by team creating consumer
	public String host;
	public String topic;
	public String partitions;
	
	public ConsumerDTO(String clientId, String consumerId, String host, String topic, String partitions) {
		this.clientId = clientId;
		this.consumerId = consumerId;
		this.host = host;
		this.topic = topic;
		this.partitions = partitions;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ConsumerDTO [clientId=").append(clientId).append(", consumerId=").append(consumerId)
				.append(", host=").append(host).append(", topic=").append(topic).append(", partitions=")
				.append(partitions).append("]");
		return builder.toString();
	}
	
}
