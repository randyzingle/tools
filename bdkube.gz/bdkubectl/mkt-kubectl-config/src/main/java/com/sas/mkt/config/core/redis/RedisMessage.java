package com.sas.mkt.config.core.redis;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RedisMessage {
	//public RedisMessage() {}
	private String timestamp;
	private String eventType;
	private String id;
	private String componentNm;
	private String tierNm;
	private String name;
	private String value;
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getComponentNm() {
		return componentNm;
	}
	public void setComponentNm(String componentNm) {
		this.componentNm = componentNm;
	}
	public String getTierNm() {
		return tierNm;
	}
	public void setTierNm(String tierNm) {
		this.tierNm = tierNm;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RedisMessage [timestamp=").append(timestamp).append(", eventType=").append(eventType)
				.append(", id=").append(id).append(", componentNm=").append(componentNm).append(", tierNm=")
				.append(tierNm).append(", name=").append(name).append(", value=").append(value).append("]");
		return builder.toString();
	}
	
}
