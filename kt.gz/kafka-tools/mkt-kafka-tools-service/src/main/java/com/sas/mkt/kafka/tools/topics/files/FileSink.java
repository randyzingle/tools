package com.sas.mkt.kafka.tools.topics.files;

import java.io.File;
import java.util.Arrays;
import java.util.Properties;

import org.apache.avro.Schema;
import org.apache.avro.file.DataFileWriter;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.specific.SpecificDatumWriter;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;


/**
 * @author razing
 *
 */
public class FileSink {

	private static Logger logger = LoggerFactory.getLogger(FileSink.class);

	String configServiceUrl = "http://configservice-dev.cidev.sas.us:8080/";
	
	@Autowired
	ApplicationConfiguration appConfig;
	

	public static void main(String[] args) {
		FileSink tfd = new FileSink();
		String topic = "dev-raw-events";
		System.out.println("Reading from: " + topic);
		String fileName = "src/main/resources/data/" + topic + ".avro";
		int numberRecords = 100;
		try {
			tfd.dumpGeneric(topic, fileName, numberRecords);
		} catch (Exception ex) {
			System.out.println(ex);
			logger.error(ex.getMessage());
		}
	}

	private void dumpGeneric(String topic, String fileName, int numberRecords) throws Exception {

		long startTime = System.currentTimeMillis();
		KafkaConnectionUtils kcu = null;
		kcu = KafkaConnectionUtils.getInstance(configServiceUrl);

		// Create the Kafka Consumer
		Properties props = kcu.getKafkaConsumerProperties(appConfig.getTierName(), appConfig.getComponentName());
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
//		String groupID = appConfig.getTier() + "-" + appConfig.getComponentName() + System.currentTimeMillis();
		String groupID = "baldur-"+ System.currentTimeMillis();
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, true);
		props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, 1000);
		props.put("session.timeout.ms", "30000");
		KafkaConsumer<String, SpecificRecordBase> consumer = new KafkaConsumer<>(props);
		consumer.subscribe(Arrays.asList(topic));

		// Set up the destination file
		File file = new File(fileName);
		
		long endTime = System.currentTimeMillis();
		System.out.println("Startup time: " + (endTime - startTime));
		startTime = System.currentTimeMillis();
		int cnt = 0;
		boolean done = false;
		Schema schema = null;
		DataFileWriter<SpecificRecordBase> dataFileWriter = null;
		while (!done) {
			ConsumerRecords<String, SpecificRecordBase> records = consumer.poll(100);
			for (ConsumerRecord<String, SpecificRecordBase> record : records) {
				if (cnt == 0) {
					schema = record.value().getSchema();
					DatumWriter<SpecificRecordBase> datumWriter = new SpecificDatumWriter<>(schema);
					dataFileWriter = new DataFileWriter<>(datumWriter);
					dataFileWriter.create(schema, file);
				}
				if (schema == null) {
					done = true;
					break;
				}
				cnt++;
				if (cnt > numberRecords) {
					done = true;
					break;
				}
				dataFileWriter.append(record.value());
				if (cnt % 1 == 0) {
					System.out.println("read record " + cnt);
					System.out.printf("offset = %d, key = %s, value = %s%n", record.offset(), record.key(),
							record.value());
				}
			}
		}
		endTime = System.currentTimeMillis();
		System.out.println("Runtime: " + (endTime - startTime) / 1000.0 + " secs");
		System.out.println("Messages per sec: " + numberRecords * 1000.0 / (endTime - startTime));
		dataFileWriter.close();
		consumer.close();
	}

}

