package com.sas.mkt.kafka.clients.producers;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.kafka.clients.producer.BufferExhaustedException;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.errors.InterruptException;
import org.apache.kafka.common.errors.SerializationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;


public class StringProducer {
	
	private static final Logger logger = LoggerFactory.getLogger(FireAndForgetProducer.class);

//	private static final int ONE_MILLION = 1000000;
	ApplicationConfiguration appConfig = new ApplicationConfiguration();

	public static void main(String[] args) {
		StringProducer app = new StringProducer();
		app.fireAndForget();
	}
	
	private void fireAndForget() {
		KafkaConnectionUtils kcu;
		try {
			kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			System.out.println(ex.toString());
			return;
		}
		String topic = "baldur-business-events";
		String clientID = appConfig.getTierName() + "-" + appConfig.getComponentName();
		Properties props = kcu.getKafkaProducerProperties(clientID);
		props.put("value.serializer", org.apache.kafka.common.serialization.StringSerializer.class);
		System.out.println(props);
		
		Producer<String, String> producer = new KafkaProducer<>(props);
		
		int numberRecords = 200;
		for (int i=0; i<numberRecords; i++) {
			Dog dog = null;
			if (i%3 == 0) {
				dog = new Dog("mymir", "female", 10);
			} else if (i%2 == 0) {
				dog = new Dog("baldur", "male", 10);
			} else {
				dog = new Dog("butters", "male", 11);
			}
			ObjectMapper mapper = new ObjectMapper();
			String sdog = null;
			try {
				sdog = mapper.writeValueAsString(dog);
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ProducerRecord<String, String> record = new ProducerRecord<>(topic, dog.name, sdog);
			try {
				producer.send(record);
				System.out.println(sdog);
			} catch (SerializationException|BufferExhaustedException|InterruptException ex) {
				ex.printStackTrace();
			}
		}


		producer.flush();
		long sleep = 2000L;
		producer.close(sleep, TimeUnit.MILLISECONDS);
	}
	
	private class Dog {
		public String name;
		public String sex;
		public int age;
		Dog(String name, String sex, int age) {
			this.name = name;
			this.sex = sex;
			this.age = age;
		}

	}
}