# Sample Spring-based Java Application

## changes


1) remove context root, change from /myroot to /

this way all /ping /healthcheck /etc endpoints will be the same and easier to pick up via tooling
