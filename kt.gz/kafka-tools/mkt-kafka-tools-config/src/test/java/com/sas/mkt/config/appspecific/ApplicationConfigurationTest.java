package com.sas.mkt.config.appspecific;

import static org.junit.Assert.*;

import org.junit.Test;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;

public class ApplicationConfigurationTest {
	
	ApplicationConfiguration appConfig = new ApplicationConfiguration();
	private static final String blarg = "blarg";

	@Test
	public void testGetConfigStackName() {
		appConfig.setConfigStackName(blarg);
		assertTrue(appConfig.getConfigStackName().equals(blarg));
	}

	@Test
	public void testSetConfigStackName() {
		appConfig.setConfigStackName(blarg);
		assertTrue(appConfig.getConfigStackName().equals(blarg));
	}

	@Test
	public void testGetComponentName() {
		appConfig.getComponentName();
	}

	@Test
	public void testSetComponentName() {
		appConfig.setComponentName(blarg);
	}

	@Test
	public void testGetTierName() {
		appConfig.getTierName();
	}

	@Test
	public void testSetTierName() {
		appConfig.setTierName(blarg);
	}

	@Test
	public void testGetConfigServiceUrl() {
		appConfig.getConfigServiceUrl();
	}

	@Test
	public void testSetConfigServiceUrl() {
		appConfig.setConfigServiceUrl(blarg);
	}


}
