package com.sas.mkt.kafka.admin.topics.admin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import org.I0Itec.zkclient.ZkClient;
import org.I0Itec.zkclient.ZkConnection;
import org.apache.kafka.common.errors.TopicExistsException;
import org.apache.zookeeper.data.ACL;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.clients.utils.KafkaProperties;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;

import kafka.admin.AdminUtils;
import kafka.admin.RackAwareMode;
import kafka.utils.ZKStringSerializer$;
import kafka.utils.ZkUtils;
import scala.collection.JavaConverters;
import scala.collection.Seq;

/**
 * A Utility class the allows one to query ZooKeeper for the topics in a Kafka
 * Cluster and manipulate them.
 * <p>
 * Do NOT use this class unless you are very sure of what you are doing.
 * <p>
 * "One does not simply delete Kafka Topics" (Boromir)
 * <p>
 * 
 * @author razing
 * @since 1707
 */
public class KafkaTopicAdministrator {
	private static Logger logger = LoggerFactory.getLogger(KafkaTopicAdministrator.class);
	
	private static String[] baseTopics = { "raw-events", "enhanced-events", "business-events", "rule",
			"contextualized-eventsNoAVRO", "on-prem-agentNoAVRO", "on-prem-notifications",
			"email-customer-notifications", "iasetsv", "object-change", "publish-request", "publish-work",
			"messageNotifications" };

	private static String[] prefix = { "dev", "tst", "latest09", "eurc", "unidev", "unistage" };

	private static List<String> reservedTopicList = Arrays.asList("__confluent.support", "__confluent.support.metrics",
			"__consumer_offsets", "_schemas", "connect-configs", "connect-offsets", "connect-status", "ksql__commands");

	// timeout - how long (in seconds) the client will wait for a connection response from ZooKeeper
	private int timeout = 10;
	private int sessionTimeout = timeout * 1000;
	private int connectionTimeout = timeout * 1000;
	private String zkUrl = "";

	public static void main(String[] args) {
		String configServiceURL = "http://configservice-dev.cidev.sas.us:8080/";
		KafkaTopicAdministrator kta = new KafkaTopicAdministrator(new ApplicationConfiguration());
		try {
			List<String> topicList = kta.getAllTopics();
			System.out.printf("found %d topics%n", topicList.size());
			String topic = "baldur-raw-events";
			boolean exists = kta.topicExists(topic);
			System.out.printf("topic %s exists=%b%n", topic, exists);
			if(!exists) {
				System.out.printf("the topic %s does not exist, creating it ...%n", topic);
				kta.createTopic(topic);
				exists = kta.topicExists(topic);
				System.out.printf("topic %s exists=%b%n", topic, exists);
			} else {
				System.out.printf("the topic %s exists, deleting it ...%n", topic);
				kta.deleteTopic(topic);
				Thread.sleep(2000);
				exists = kta.topicExists(topic); 
				System.out.printf("topic %s exists=%b%n", topic, exists);
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			logger.error(ex.getMessage());
		}
	}
	
	public List<String> getReservedTopicList() {
		List<String> blackList = new ArrayList<>();
		for (String s : reservedTopicList) {
			blackList.add(s);
		}
		Collections.sort(blackList);
		return blackList;
	}
	
	public List<String> getCoreTopicList() {
		List<String> blackList = new ArrayList<>();
		for (String p : prefix) {
			for (String t : baseTopics) {
				blackList.add(p + "-" + t);
			}
		}
		for (String s : reservedTopicList) {
			blackList.add(s);
		}
		Collections.sort(blackList);
		return blackList;
	}

	/**
	 * KafkaTopicAdministrator allows one to list, create, delete, and query the
	 * existence of, Kafka topics. It requires mkt-kafka-shared jar to run as it
	 * uses the KafkaProperties class in that jar to lookup the ZooKeeper server for
	 * the cluster. The constructor requires the URL String for the configuration
	 * server for the region (for example
	 * http://configservice-dev.cidev.sas.us:8080/) and uses this configuration
	 * server to lookup the Zookeeper connection information.
	 * <p>
	 * The configuration parameters are pulled from the <b>mkt-kafka</b> component
	 * in the global tier of the configuration server. You can override the
	 * parameters either with environment variables or with system properties passed
	 * to the java executable. Properties will take precedence in this order (from
	 * highest precedence to lowest):
	 * <ul>
	 * <li>system properties</li>
	 * <li>environment variables</li>
	 * <li>config server properties</li>
	 * </ul>
	 * <p>
	 * To override the environment variable use this
	 * <code>SAS_MKT_KAFKA_ZOOKEEPER</code> as the environment variable name.
	 * <p>
	 * To override the system property use this <code>sas.mkt.kafka.zookeeper</code>
	 * as the property variable name. Note system properties can be passed during
	 * startup (java -Dsas.mkt.kafka.zookeeper=zookeeper.sas.com) or via SpringBoot
	 * application.properties properties.
	 *
	 * @param configServiceURL
	 *            The URL for the configuration service (for example:
	 *            http://configservice-dev.cidev.sas.us:8080/)
	 */
	public KafkaTopicAdministrator(ApplicationConfiguration appConfig) {
		String configServiceURL = appConfig.getConfigServiceUrl();
		KafkaProperties singleton = KafkaProperties.getInstance(configServiceURL);
		this.zkUrl = singleton.getKafkaProperties().get(KafkaConnectionUtils.SAS_MKT_KAFKA_ZOOKEEPER);
	}

	/**
	 * @param topicName:
	 *            the name of the topic to check
	 * @return boolean indicating whether or not the topic exists.
	 * @throws org.I0Itec.zkclient.exception.ZkTimeoutException
	 *             if a connection to ZooKeeper can not be made
	 */
	public boolean topicExists(String topicName) {
		ZkClient zkClient = null;
		boolean exists = false;
		try {
			zkClient = new ZkClient(zkUrl, sessionTimeout, connectionTimeout, ZKStringSerializer$.MODULE$);
			ZkUtils zkUtils = new ZkUtils(zkClient, new ZkConnection(zkUrl), false);
			exists = AdminUtils.topicExists(zkUtils, topicName);
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		} finally {
			zkClient.close();
		}
		return exists;
	}

	/**
	 * Get a list of all the topics registered for this Kafka Cluster.
	 *
	 * @return List<String> of topics names
	 * @throws org.I0Itec.zkclient.exception.ZkTimeoutException
	 *             if a connection to ZooKeeper can not be made
	 */
	public List<String> getAllTopics() {
		ZkClient zkClient = null;
		List<String> tlist = null;
		try {
			zkClient = new ZkClient(zkUrl, sessionTimeout, connectionTimeout, ZKStringSerializer$.MODULE$);
			ZkUtils zkUtils = new ZkUtils(zkClient, new ZkConnection(zkUrl), false);
			Seq<String> topics = zkUtils.getAllTopics();
			tlist = JavaConverters.seqAsJavaListConverter(topics).asJava();
			Collections.sort(tlist);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			zkClient.close();
		}
		return tlist;
	}

	/**
	 * Create a new Topic with the given topic name, 12 partitions, and 2 replicas.
	 * Calls {@link createTopic(String topicName, int partitions, int replicas)
	 * createTopic}
	 *
	 * @param topicName The name of the topic to create
	 * @throws Exception if topicName is null
	 * @throws TopicExistsException if the topic already exists
	 * @throws org.I0Itec.zkclient.exception.ZkTimeoutException if a connection to ZooKeeper can not be made
	 */
	public void createTopic(String topicName) throws Exception {
		createTopic(topicName, 12, 2);
	}

	/**
	 * Create a new Topic with the given number of partitions and broker replication
	 * factor.
	 * <p>
	 * Topic will be created only if it starts with {@link AGENT_TOPIC_BASENAME
	 * AGENT_TOPIC_BASENAME}. This restriction will be relaxed once ACLs are in
	 * place for topic creation in ZooKeeper.
	 *
	 * @param topicName The name of the new topic
	 * @param partitions The number of partitions to create for the topic
	 * @param replicas The number of Kafka brokers to replicate the topic to
	 * @throws Exception if the topicName is null
	 * @throws TopicExistsException if the topic already exists
	 * @throws org.I0Itec.zkclient.exception.ZkTimeoutException if a connection to ZooKeeper can not be made
	 */
	public void createTopic(String topicName, int partitions, int replicas) throws Exception {
		List<String> reservedTopicList = this.getCoreTopicList();
		if (reservedTopicList.contains(topicName)) throw new Exception("Create failed: trying to create a reserved topic: " + topicName);
		ZkClient zkClient = null;
		try {
			if (topicName == null) {
				throw new Exception("Need to supply a topic name");
			}
			String message = String.format(
					"attempting to create topic: %s with %d partitions and replication factor of %d%n", topicName,
					partitions, replicas);
			logger.info(message);
			zkClient = new ZkClient(zkUrl, sessionTimeout, connectionTimeout, ZKStringSerializer$.MODULE$);
			ZkUtils zkUtils = new ZkUtils(zkClient, new ZkConnection(zkUrl), false);
			Properties configs = new Properties();
			RackAwareMode rackAwareMode = RackAwareMode.Safe$.MODULE$;
			AdminUtils.createTopic(zkUtils, topicName, partitions, replicas, configs, rackAwareMode);

			message = String.format("created topic: %s with %d partitions and replication factor of %d%n", topicName,
					partitions, replicas);
			logger.info(message);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new Exception(ex);
		} finally {
			zkClient.close();
		}
	}
	
	/**
	 * Deletes a Kafka Topic. The topic will just be marked for deletion but will
	 * not be removed from Kafka until the data in the topic has expired.
	 *
	 * @param topicName
	 * @throws org.I0Itec.zkclient.exception.ZkTimeoutException if a connection to ZooKeeper can not be made
	 */
	public void deleteTopic(String topicName) throws Exception {
		List<String> reservedTopicList = this.getCoreTopicList();
		if (reservedTopicList.contains(topicName)) throw new Exception("Delete failed: trying to delete a reserved topic: " + topicName);
		ZkClient zkClient = null;
		try {
			String message = String.format("attempting to delete topic: %s%n", topicName);
			logger.info(message);
			zkClient = new ZkClient(zkUrl, sessionTimeout, connectionTimeout, ZKStringSerializer$.MODULE$);
			ZkUtils zkUtils = new ZkUtils(zkClient, new ZkConnection(zkUrl), false);
			String zkPath = ZkUtils.getDeleteTopicPath(topicName);
			List<ACL> acls = org.apache.zookeeper.ZooDefs.Ids.OPEN_ACL_UNSAFE;
			zkUtils.createPersistentPath(zkPath, "", acls);
			zkClient.close();
			message = String.format("deleted topic: %s%n", topicName);
			logger.info(message);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new Exception(ex);
		} finally {
			zkClient.close();
		}
	}

}
