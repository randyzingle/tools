package com.sas.mkt.kafka.clients.consumers.standard;

import java.util.List;
import java.util.Properties;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;

public class SimpleConsumer implements CIKafkaRecordProcessor {

	private static final Logger logger = LoggerFactory.getLogger(SimpleConsumer.class);

	private KafkaConsumer<String, SpecificRecordBase> consumer;
	private List<String> topicList;
	private int id;
	private String groupId;
	// sample only - get the configServiceURL from config/cloudformation
	private ApplicationConfiguration appConfig = new ApplicationConfiguration();

	public SimpleConsumer(int id, String groupId, List<String> topicList) {
		this.id = id;
		this.groupId = groupId;
		this.topicList = topicList;
		Properties props = null;
		try {
			KafkaConnectionUtils kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
			props = kcu.getKafkaConsumerProperties();
			props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, 1000);

			/*
			 * The following properties will set us up to start reading messages at the last
			 * offset (+1) of any consumer that shares our groudId:
			 */
			groupId = appConfig.getTierName() + "-" + appConfig.getComponentName();
			props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "latest");
			props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
			
			// start for testing
			/*
			 * For testing we often want to read the topic from the beginning each time. To
			 * do this we need a unique groupId and we need to reset to the earliest offset.
			 * 
			 * uncomment the following three lines to read from the beginning of the topic:
			 */
			groupId = appConfig.getTierName() + "-" + appConfig.getComponentName() + System.currentTimeMillis();
			props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
			props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
			// end for testing

			consumer = new KafkaConsumer<>(props);

		} catch (Exception ex) {
			logger.error(ex.getMessage());
		}

	}

	@Override
	public void run() {
		int cnt = 0;
		try {
			consumer.subscribe(topicList);
			while (true) {
				ConsumerRecords<String, SpecificRecordBase> records = consumer.poll(Long.MAX_VALUE);
				for (ConsumerRecord<String, SpecificRecordBase> record : records) {
					cnt++;
					processRecord(record);
					// for sample code purposes only 
					if (cnt % 50  == 0)
						logger.info("Read {} messages", cnt);
				}
			}
		} catch (WakeupException ex) {
			logger.info("Shutdown called - exiting Kafka consumer.poll() loop");
		}
	}

	@Override
	public void shutDown() {
		System.out.printf("Shutdown called for consumer %d-%s%n", this.id, this.groupId);
		consumer.wakeup();
	}

	@Override
	public void processRecord(ConsumerRecord<String, SpecificRecordBase> record) {
		// you'll probably do something more useful here
		System.out.println(this.id + ": " + record.value().toString());
	}

}
