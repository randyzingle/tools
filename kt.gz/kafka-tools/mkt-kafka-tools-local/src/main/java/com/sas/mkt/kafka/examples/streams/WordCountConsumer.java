package com.sas.mkt.kafka.examples.streams;

import java.util.Arrays;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;

public class WordCountConsumer {
	private static final Logger logger = LoggerFactory.getLogger(WordCountConsumer.class);

	private String topic = "test-wordcount-out";
	private String groupID = "baldur4";
	KafkaConsumer<String, Long> consumer;
	
	public static void main(String[] args) {
		WordCountConsumer bc = new WordCountConsumer();
		bc.simpleConsumeMessages();
	}
	
	private void simpleConsumeMessages() {

		// Set up the consumer
		KafkaConnectionUtils kcu;
		try {
			String configServiceURL = "http://configservice-dev.cidev.sas.us:8080/";
			kcu = KafkaConnectionUtils.getInstance(configServiceURL);
			System.out.println("VALID CONNECTION..........");
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			return;
		}
		Properties props = kcu.getKafkaConsumerProperties();
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
				org.apache.kafka.common.serialization.LongDeserializer.class);
		consumer = new KafkaConsumer<>(props);
		TopicPartition part0 = new TopicPartition(topic, 0);
		consumer.assign(Arrays.asList(part0));
		
		// Consume Messages
		int cnt = 0, maxRequestTime = 10;
		boolean done = false;
		while (!done) {
			cnt++;
			if (cnt > maxRequestTime) // we'll bail after polling at most maxRequest seconds
				done = true;
			ConsumerRecords<String, Long> records = consumer.poll(1000);
			for (ConsumerRecord<String, Long> record: records) {
				System.out.println(record.key() + ", " + record.value());
			}
		}
		consumer.close();

	}
}
