package com.sas.mkt.config.metrics;

import java.net.Inet4Address;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.common.Metric;
import org.apache.kafka.common.MetricName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.codahale.metrics.Gauge;
import com.codahale.metrics.MetricRegistry;
import com.sas.mkt.config.appspecific.ApplicationConfiguration;

@Component
public class KafkaMetricsConverter {

	@Autowired
	MetricRegistry metricRegistry;
	
	@Autowired
	ApplicationConfiguration appConfig;
	
	private String getFullName(String name, String topic, String subCategory) {
		String fname = "kafka" +  "." + subCategory + "." + topic +"." + name;
		return fname;
	}
	
	// Consumer Metrics
	public void constructConsumerMetrics(Consumer<?,?> consumer, String topic) {
		Thread consumerMetricsConstructor = new Thread(new ConsumerMetricsConstructor(consumer, topic));
		consumerMetricsConstructor.start();
	}
	
	// Producer Metrics
	public void constructProducerMetrics(Producer<?, ?> producer, String topic) {
		
		Map<String, String> producerMetrics = new HashMap<>(8);
		producerMetrics.put("record-error-rate", "error-in-sends-per-second");
		producerMetrics.put("request-latency-avg", "latency-ms");
		producerMetrics.put("outgoing-byte-rate", "bytes-per-sec");
		producerMetrics.put("record-send-rate", "records-per-second");
		producerMetrics.put("record-size-avg", "bytes");
		producerMetrics.put("compression-rate-avg", "ratio");
		
		Map<String, String> producerDimensions = null;

		Map<MetricName, ? extends Metric> metricMap = producer.metrics();
		Set<MetricName> keySet = metricMap.keySet();
		for (MetricName mname: keySet) {
			if(producerMetrics.containsKey(mname.name()) && mname.group().equals("producer-metrics")) {
				String fullName = getFullName(mname.name(), topic, "kafka-producer");
				producerDimensions = getDimensions(topic, "kafka-producer", producerMetrics.get(mname.name()));
				metricRegistry.register(fullName, new CustomKafkaMetric(Arrays.asList(metricMap.get(mname)), producerDimensions));
			}
		}
	}
	
	private Map<String, String> getDimensions(String topic, String subCategory, String units) {
		Map<String, String> dimensions = new HashMap<>();
		dimensions.put("category", "kafka");
		dimensions.put("subcategory", subCategory);
		dimensions.put("topic", topic);
		dimensions.put("units", units);
		return dimensions;
	}
	
	private class ConsumerMetricsConstructor implements Runnable {
		
		private Consumer<?,?> consumer;
		private String topic;
		
		public ConsumerMetricsConstructor(Consumer<?,?> consumer, String topic) {
			this.consumer = consumer;
			this.topic = topic;
		}

		@Override
		public void run() {
			// need to give the consumer time to join a group and get assigned partitions or else
			// the metrics won't be available yet and nothing will get registered
			try {
				Thread.sleep(30*1000);
			} catch (InterruptedException e) {
			}
			doit(consumer, topic);	
		}
		
		public void doit(Consumer<?,?> consumer, String topic) {

			Map<MetricName, ? extends Metric> metricMap = consumer.metrics();
			
			CustomKafkaMetric customKafkaMetric = null;
			Set<MetricName> keySet = metricMap.keySet();;
			Map<String, String> tags = null;
			String fullName = null;
			String category = "kafka";
			String subcategory = "kafka-consumer";
			Map<String, String> consumerDimensions = null;
	
			// we're going to roll up the latest lag of each partition for all consumed partitions
			String name = "records-lag"; 
			fullName = getFullName(name, topic, "kafka-consumer");
			consumerDimensions = getDimensions(topic, "kafka-consumer", "number-of-messages");
			customKafkaMetric = createCompoundKafkaMetric(metricMap, "consumer-fetch-manager-metrics", name, topic, consumerDimensions);
			metricRegistry.register(fullName, customKafkaMetric);
			
			// rolled up version exists, and we also have per topic/partition stats
			name = "records-lag-max"; 
			for (MetricName mname: keySet) {
				if (mname.group().equals("consumer-fetch-manager-metrics") && mname.name().equals(name)) {
					tags = mname.tags();
					if (!tags.containsKey("topic")) {
						fullName = getFullName(name, topic, "kafka-consumer");
						consumerDimensions = getDimensions(topic, "kafka-consumer", "number-of-messages");
						customKafkaMetric = new CustomKafkaMetric(Arrays.asList(metricMap.get(mname)), consumerDimensions);
						metricRegistry.register(fullName, customKafkaMetric);
						break;
					}
				}
			}
			
			name = "records-consumed-rate"; // rolled up version exists, and we also have per topic stats
			for (MetricName mname: keySet) {
				if (mname.group().equals("consumer-fetch-manager-metrics") && mname.name().equals(name)) {
					tags = mname.tags();
					if (tags.containsKey("topic")) {
						fullName = getFullName(name, topic, "kafka-consumer");
						consumerDimensions = getDimensions(topic, "kafka-consumer", "records-per-second");
						customKafkaMetric = new CustomKafkaMetric(Arrays.asList(metricMap.get(mname)), consumerDimensions);
						metricRegistry.register(fullName, customKafkaMetric);
						break;
					}
				}
			}
						
			name = "bytes-consumed-rate"; // rolled up version exists, and we also have per topic stats
			for (MetricName mname: keySet) {
				if (mname.group().equals("consumer-fetch-manager-metrics") && mname.name().equals(name)) {
					tags = mname.tags();
					if (tags.containsKey("topic")) {
						fullName = getFullName(name, topic, "kafka-consumer");
						consumerDimensions = getDimensions(topic, "kafka-consumer", "bytes-per-second");
						customKafkaMetric = new CustomKafkaMetric(Arrays.asList(metricMap.get(mname)), consumerDimensions);
						metricRegistry.register(fullName, customKafkaMetric);
					}
				}
			}
			
		}
		
	}
	
	private CustomKafkaMetric createCompoundKafkaMetric(Map<MetricName, ? extends Metric> metricMap, String group, String name, String topic, Map<String, String> consumerDimensions) {
		List<Metric> metricList = new ArrayList<>();
		Set<MetricName> keySet = metricMap.keySet();
		//group=consumer-fetch-manager-metrics
		//name=records-lag
		for (MetricName mname: keySet) {
			if (mname.group().equals(group) && mname.name().equals(name)) {
				Map<String, String> tags = mname.tags();
					if (tags.containsKey(topic) && tags.get(topic).equals(topic)) {
						metricList.add(metricMap.get(mname));
					}
			}
		}
		return new CustomKafkaMetric(metricList, consumerDimensions);
	}
	
	// Turn all of the Kafka metrics into codehale Gauges
	private class CustomKafkaMetric implements Gauge<Double>, CustomMetric {
		
		private List<Metric> metricList;
		private Map<String, String> dimensions;
		
		private CustomKafkaMetric(List<Metric> metricList) {
			this.metricList = metricList;
		}
		
		private CustomKafkaMetric(List<Metric> metricList, Map<String, String> dimensions) {
			this.metricList = metricList;
			this.dimensions = dimensions;
		}

		@Override
		public Double getValue() {
			double sum = 0.0;
			for (Metric metric: metricList) {
				sum += (double)metric.metricValue();;
			}
			return sum;
		}

		@Override
		public Map<String, String> getDimensions() {
			return dimensions;
		}
		
	}

}
