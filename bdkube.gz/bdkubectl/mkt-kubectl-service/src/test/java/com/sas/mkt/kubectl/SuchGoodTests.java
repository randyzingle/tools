package com.sas.mkt.kubectl;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class SuchGoodTests {

	@Test
	public void testGetConfigStackName() {
		boolean thisTestIsGood = true;
		assertTrue(thisTestIsGood);
	}
}
