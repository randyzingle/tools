'''
Create a WebACL and RateBasedRule and associate to ALB

Source code located in GitLab:
    https://gitlab.sas.com/CustomerIntelligence/DevOps/mkt-infra

Configuration:
"Handler": "HttpFloodProtection.handler"
"Runtime": "python3.6"
"Timeout": "300"

The ALB must already exist and the ALB ARN must be passed in with the CF event

Aug 23, 2017
@author: razing
'''
import json
from urllib.request import urlopen, Request, HTTPError, URLError
from urllib.parse import urlencode
import boto3
import re
import time

# ===============================================================================
#  Sample CloudFormation events
# ===============================================================================
'''
Create event:
{
  "RequestType": "Create",
  "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-UDZOW2HK3IWD",
  "ResponseURL": "https://cloudformation-custom-resource-response-useast1.s3.amazonaws.com",
  "StackId": "arn:aws:cloudformation:us-east-1:952478859445:stack/razing-custom/40d839f0-8cd3-11e7-a3f6-50faeaabf0d1",
  "RequestId": "5f078456-de85-4775-9441-9347eaac6407",
  "LogicalResourceId": "WAFInfo",
  "ResourceType": "AWS::CloudFormation::CustomResource",
  "ResourceProperties": {
    "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-UDZOW2HK3IWD",
    "RateLimit": "2000",
    "Description": "Lambda will return ID of: WebACL, RateBasedRule",
    "Region": "us-east-1",
    "ALBArn": "arn:aws:elasticloadbalancing:us-east-1:952478859445:loadbalancer/app/razing-ELB-17401GTSWCHZC/f2fe45278d0d859e",
    "StackName": "razing-custom"
  }
}

Update event:
{
  "RequestType": "Update",
  "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-XRSHVD5NRA7I",
  "ResponseURL": "https://cloudformation-custom-resource-response-useast1.s3.amazonaws.com",
  "StackId": "arn:aws:cloudformation:us-east-1:952478859445:stack/razing-custom/afb9dbe0-8cd7-11e7-bd36-500c219ab02a",
  "RequestId": "7310f283-36ce-43b8-a88e-2f022103ba7c",
  "LogicalResourceId": "WAFInfo",
  "PhysicalResourceId": "None",
  "ResourceType": "AWS::CloudFormation::CustomResource",
  "ResourceProperties": {
    "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-XRSHVD5NRA7I",
    "RateLimit": "2000",
    "Description": "Lambda will return ID of: WebACL, RateBasedRule",
    "Region": "us-east-1",
    "ALBArn": "arn:aws:elasticloadbalancing:us-east-1:952478859445:loadbalancer/app/razing-ELB-17401GTSWCHZC/f2fe45278d0d859e",
    "StackName": "razing-custom"
  },
  "OldResourceProperties": {
    "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-XRSHVD5NRA7I",
    "RateLimit": "2500",
    "Description": "Lambda will return ID of: WebACL, RateBasedRule",
    "Region": "us-east-1",
    "ALBArn": "arn:aws:elasticloadbalancing:us-east-1:952478859445:loadbalancer/app/razing-ELB-17401GTSWCHZC/f2fe45278d0d859e",
    "StackName": "razing-custom"
  }
}

Delete event:
{
  "RequestType": "Delete",
  "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-13C1UUQ66AQ0P",
  "ResponseURL": "https://cloudformation-custom-resource-response-useast1.s3.amazonaws.com",
  "StackId": "arn:aws:cloudformation:us-east-1:952478859445:stack/razing-custom/09cdd3e0-8cdb-11e7-b660-503acac41e35",
  "RequestId": "4f6ae1d6-0a71-4bf5-bd7e-3c2f4b8c62ec",
  "LogicalResourceId": "WAFInfo",
  "PhysicalResourceId": "None",
  "ResourceType": "AWS::CloudFormation::CustomResource",
  "ResourceProperties": {
    "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-13C1UUQ66AQ0P",
    "RateLimit": "2000",
    "Description": "Lambda will return ID of: WebACL, RateBasedRule",
    "Region": "us-east-1",
    "ALBArn": "arn:aws:elasticloadbalancing:us-east-1:952478859445:loadbalancer/app/razing-ELB-17401GTSWCHZC/f2fe45278d0d859e",
    "StackName": "razing-custom"
  }
}
'''

print('Loading function')

# ===============================================================================
#  Constants
# ===============================================================================
API_CALL_NUM_RETRIES = 3
API_CALL_NUM_RETRIES = 2
rule_name_suffix = '-RateBasedRule'
webacl_name_suffix = '-WebACL'
STATUS_FAILED = 'FAILED'
STATUS_SUCCESS = 'SUCCESS'


# ===============================================================================
#  Entry Point for Lambda
# ===============================================================================
def handler(event, context):
    global waf
    # global elb
    session = boto3.session.Session(region_name=event['ResourceProperties']['Region'])
    waf = session.client('waf-regional')
    # elb = session.client('elbv2')
    rtype = event['RequestType']

    if rtype == 'Create':
        create_resources(event, context)
    elif rtype == 'Update':
        update_resources(event, context)
    elif rtype == 'Delete':
        delete_resources(event, context)
    else:
        print(rtype, ':Not a proper request-type, should be one of [Create|Update|Delete]')


# ===============================================================================
#  Code that deals with RateBasedRules
# ===============================================================================
def get_rule_id(event):
    rule_id = None
    # get a list of the rate-based-rules
    response = waf.list_rate_based_rules()
    print(response)

    # look for the rule for the given CF stack
    rule_name = event['ResourceProperties']['StackName'] + rule_name_suffix
    rule_list = response['Rules']
    for x in rule_list:
        if x['Name'] == rule_name:
            rule_id = x['RuleId']
            print('ruleID for stack:', rule_id)

    return rule_id


def create_rate_based_rule(event):
    rule_name = event['ResourceProperties']['StackName'] + rule_name_suffix
    metric_name = re.sub('[^A-Za-z0-9]+', '', rule_name)
    print(rule_name, metric_name)
    response = waf.create_rate_based_rule(
        Name=rule_name,
        MetricName=metric_name,
        ChangeToken=waf.get_change_token()['ChangeToken'],
        RateKey='IP',
        RateLimit=int(event['ResourceProperties']['RateLimit'])
    )
    return response


def delete_rate_based_rule(event):
    response = waf.delete_rate_based_rule(
        RuleId=event['RuleId'],
        ChangeToken=waf.get_change_token()['ChangeToken']
    )
    return response


def update_rate_based_rule(event):
    rule_id = get_rule_id(event)
    print('RULEID:', rule_id)
    waf.update_rate_based_rule(
        RuleId=rule_id,
        ChangeToken=waf.get_change_token()['ChangeToken'],
        Updates=[],
        RateLimit=int(event['ResourceProperties']['RateLimit'])
    )


# ===============================================================================
#  Code that deals with WebACLs
# ===============================================================================
def get_web_acl_id(event):
    acl_id = None
    # get a list of the acls
    response = waf.list_web_acls()
    print(response)

    # look for the WebAcl for the given CF stack
    wac_name = event['ResourceProperties']['StackName'] + webacl_name_suffix
    print('Looking for:', wac_name)
    acl_list = response['WebACLs']
    for x in acl_list:
        if x['Name'] == wac_name:
            acl_id = x['WebACLId']
            print('webacl for stack: ', acl_id)

    return acl_id


def create_web_acl(event):
    wac_name = event['ResourceProperties']['StackName'] + webacl_name_suffix
    metric_name = re.sub('[^A-Za-z0-9]+', '', wac_name)
    print(wac_name, metric_name)
    response = waf.create_web_acl(
        Name=wac_name,
        MetricName=metric_name,
        ChangeToken=waf.get_change_token()['ChangeToken'],
        DefaultAction={'Type': 'ALLOW'}
    )
    return response


def associate_web_acl_with_alb(event):
    # not sure what's up here - the acl can be associated to a rule
    # but is not available for association with the ALB
    delay = 100  # sleep for a while to let the resources 'show up'
    print("wait %d secs before attempting ACL-ALB association..." % (delay))
    time.sleep(delay)
    print('done waiting - associating WebACL to ALB...')
    for _ in range(API_CALL_NUM_RETRIES):
        try:
            response = waf.associate_web_acl(
                WebACLId=event['WebACLId'],
                ResourceArn=event['ResourceProperties']['ALBArn']
            )
            return response
        except Exception as ex:
            delay = 60
            print(ex)
            print("[associate_web_acl_with_alb] failed - retrying in %d seconds..." % (delay))
            time.sleep(delay)

    # We've failed to associate the WebACL and ALB in the allotted time
    send_response(event, STATUS_FAILED)


def disassociate_web_acl(event):
    waf.disassociate_web_acl(
        ResourceArn=event['ResourceProperties']['ALBArn']
    )


def update_web_acl(event, action):
    response = waf.update_web_acl(
        WebACLId=event['WebACLId'],
        ChangeToken=waf.get_change_token()['ChangeToken'],
        Updates=[
            {
                'Action': action,
                'ActivatedRule': {
                    'Priority': 1,
                    'RuleId': event['RuleId'],
                    'Action': {
                        'Type': 'BLOCK'
                    },
                    'Type': 'RATE_BASED'
                }
            },
        ],
        DefaultAction={
            'Type': 'ALLOW'
        }
    )
    return response


def delete_web_acl(event):
    response = waf.delete_web_acl(
        WebACLId=event['WebACLId'],
        ChangeToken=waf.get_change_token()['ChangeToken'],
    )
    return response


# ===============================================================================
#  Functions that response to Create, Update, and Delete CF Events
# ===============================================================================
def create_resources(event, context):
    print('create_resources...')
    # print(event)
    wac_name = event['ResourceProperties']['StackName'] + webacl_name_suffix
    rule_name = event['ResourceProperties']['StackName'] + rule_name_suffix

    # First make sure that neither the WebACL nor the Rule already exist
    # Check WebACL
    acl_id = get_web_acl_id(event)
    if acl_id is not None:
        print('web-acl', wac_name, 'already exists, aborting')
        send_response(event, STATUS_FAILED)
        return
    # Check Rule
    rule_id = get_rule_id(event)
    if rule_id is not None:
        print('rule', rule_name, 'already exists, aborting')
        send_response(event, STATUS_FAILED)
        return

    # Both WebACL and Rule are new
    # Create the WebACL
    response = create_web_acl(event)
    print(response)
    event['WebACLId'] = response['WebACL']['WebACLId']

    # create the RateBasedRule
    response = create_rate_based_rule(event)
    print(response)
    event['RuleId'] = response['Rule']['RuleId']

    # update the WebACL with the rule
    response = update_web_acl(event, 'INSERT')

    # associate the ACL with the ALB
    response = associate_web_acl_with_alb(event)

    # we were successful
    send_response(event, STATUS_SUCCESS)


def update_resources(event, context):
    print('update_resources...')
    print(event)
    event['RuleId'] = get_rule_id(event)
    event['WebACLId'] = get_web_acl_id(event)
    if (event['WebACLId'] is not None and event['RuleId'] is not None):
        old_rate = event['OldResourceProperties']['RateLimit']
        new_rate = event['ResourceProperties']['RateLimit']
        if old_rate == new_rate:
            print("Nothing to update, old rate %s equals new rate %s" % (old_rate, new_rate))
            send_response(event, STATUS_SUCCESS)
        else:
            update_rate_based_rule(event)
            send_response(event, STATUS_SUCCESS)
    else:
        event['Update'] = True
        delete_resources(event, context)
        create_resources(event, context)


def delete_resources(event, context):
    print('delete_resources...')
    event['RuleId'] = get_rule_id(event)
    event['WebACLId'] = get_web_acl_id(event)

    if (event['WebACLId'] is not None and 'ALBArn' in event['ResourceProperties']):
        # detach WebACL from ALB
        try:
            disassociate_web_acl(event)
        except Exception as ex:
            print(ex)

    if (event['WebACLId'] is not None and event['RuleId'] is not None):
        # remove acl-rule association
        try:
            update_web_acl(event, 'DELETE')
        except Exception as ex:
            print(ex)

        # delete WebACL
        try:
            response = delete_web_acl(event)
            print(response)
        except Exception as ex:
            print(ex)

    if (event['RuleId'] is not None):
        # delete Rule
        try:
            response = delete_rate_based_rule(event)
            print(response)
        except Exception as ex:
            print(ex)

    if (event['RequestType'] == 'Delete'):
        send_response(event, STATUS_SUCCESS)


# ===============================================================================
#  Cloudformation HTTP PUT response indicating SUCCESS or FAILURE of lambda
# ===============================================================================
def send_response(event, responseStatus):
    data = {}
    data['WebACLId'] = event.get('WebACLId', 'None')
    data['RuleId'] = event.get('RuleId', 'None')
    responseBody = {
        'Status': responseStatus,
        'Reason': 'See the details in CloudWatch Log Stream',
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'Data': data
    }

    # PhysicalResourceId only sent with Update and Delete requests
    responseBody['PhysicalResourceId'] = event.get('PhysicalResourceId', 'None')

    # print(responseBody)
    edata = json.dumps(responseBody)
    edata = edata.encode('utf-8')
    headers = {'Content-Length': len(edata), 'Content-Type': ''}
    # print(headers)
    req = Request(
        event['ResponseURL'],
        headers=headers,
        data=edata,
        method='PUT')
    req.get_method = lambda: 'PUT'
    try:
        urlopen(req)
    except Exception as e:
        print(e)


# ===============================================================================
#  Test Code for runs from the command line
# ===============================================================================
if __name__ == "__main__":
    print('in __main__ function')

    event = '''
    {
      "RequestType": "Delete",
      "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-XRSHVD5NRA7I",
      "ResponseURL": "http://localhost:8080/service",
      "StackId": "arn:aws:cloudformation:us-east-1:952478859445:stack/razing-custom/afb9dbe0-8cd7-11e7-bd36-500c219ab02a",
      "RequestId": "7310f283-36ce-43b8-a88e-2f022103ba7c",
      "LogicalResourceId": "WAFInfo",
      "PhysicalResourceId": "None",
      "ResourceType": "AWS::CloudFormation::CustomResource",
      "ResourceProperties": {
        "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-XRSHVD5NRA7I",
        "RateLimit": "2000",
        "Description": "Lambda will return ID of: WebACL, RateBasedRule",
        "Region": "us-east-1",
        "ALBArn": "arn:aws:elasticloadbalancing:us-east-1:952478859445:loadbalancer/app/opdst-ELBGa-1FS3W1CRCW7R2/ffb4f6a5a5ef959f",
        "StackName": "opdstage"
      },
      "OldResourceProperties": {
        "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-XRSHVD5NRA7I",
        "RateLimit": "2000",
        "Description": "Lambda will return ID of: WebACL, RateBasedRule",
        "Region": "us-east-1",
        "ALBArn": "arn:aws:elasticloadbalancing:us-east-1:952478859445:loadbalancer/app/razing-ELB-17401GTSWCHZC/f2fe45278d0d859e",
        "StackName": "razing-custom"
      }
    }
    '''
    context = {}
    handler(json.loads(event), context)
