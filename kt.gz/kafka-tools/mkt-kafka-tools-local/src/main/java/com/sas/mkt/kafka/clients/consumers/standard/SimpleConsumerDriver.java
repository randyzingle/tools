package com.sas.mkt.kafka.clients.consumers.standard;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.clients.utils.KafkaTopicUtils;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;

public class SimpleConsumerDriver {

	private static final Logger logger = LoggerFactory.getLogger(SimpleConsumerDriver.class);
	
	private static ApplicationConfiguration appConfig = new ApplicationConfiguration();

	/*
	 * Setting up a proper Consumer groupId (see
	 * http://sww.sas.com/saspedia/CI360_Kafka_Overview#Consumer_Group_ID):
	 * 
	 * The following fields should be passed into your application via
	 * CloudFormation And/Or your application.properties file: String tierName (e.g.
	 * dev, test, eurc) String componentName / serviceName (e.g. mkt-events,
	 * mkt-execution, mkt-extapigw)
	 * 
	 * The groupId for the Consumer should always be constructed as: String groupId
	 * = tierName + "-" + componentName;
	 * 
	 */
	// ApplicationConfiguration will be @Autowired into this class in a SpringBoot environment 
	private static String tierName = appConfig.getTierName(); 
	private static String componentName = appConfig.getComponentName();
	private static String groupId = tierName + "-" + componentName;

	/*
	 * Setting up your topic and topic prefix:
	 * 
	 * Topic (see http://sww.sas.com/saspedia/CI360_Kafka_Overview#Topics) The
	 * base-name of the topics you produce to, or consume from, are specific to your
	 * application and should never change. They should be in your
	 * application.properties file and will be one of the topics referenced in the
	 * hyperlink above (e.g. raw-events, enhanced-events, business-events, etc)
	 * 
	 * Topic Prefix (see
	 * http://sww.sas.com/saspedia/CI360_Kafka_Overview#Topic_Prefixes) The
	 * kafkaTopicPrefix is dependent on the environment the application is deployed
	 * to. Examples are given in the hyperlink above, and as per that documentation
	 * you can create your full topic name by passing the base-name and the tierName
	 * to KafkaTopicUtils. 
	 * 
	 * The full name of the topic you produce to, or consume from will be:
	 * 
	 * String myTopic = kafkaTopicPrefix + "-" + baseTopicName;
	 */
//	private static String baseTopicName = appConfig.getTestTopic1();

	// number of consumers - we're spinning up one consumer thread here
	private static final int numc = 1;

	public static void main(String[] args) {
//		KafkaTopicUtils ktu = new KafkaTopicUtils(appConfig.getConfigServiceUrl());
		String myTopic = "baldur-test-event";

		ExecutorService executorService = Executors.newFixedThreadPool(numc);
		List<CIKafkaRecordProcessor> consumers = new ArrayList<>(numc);
		List<String> topicList = Arrays.asList(myTopic);
		logger.info("Firing up " + numc + " consumer threads.");
		for (int id = 0; id < numc; id++) {
			CIKafkaRecordProcessor pc = new SimpleConsumer(id, groupId, topicList);
			consumers.add(pc);
			executorService.submit(pc);
		}

		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				logger.info("In ShutdownHook - telling consumers to shutdown()");
				for (CIKafkaRecordProcessor pc : consumers) {
					pc.shutDown();
				}
				executorService.shutdown();
				try {
					executorService.awaitTermination(5, TimeUnit.SECONDS);
				} catch (Exception ex) {
					logger.error("error shutting down the kafka consumer executor");
				}
			}
		});
	}
}
