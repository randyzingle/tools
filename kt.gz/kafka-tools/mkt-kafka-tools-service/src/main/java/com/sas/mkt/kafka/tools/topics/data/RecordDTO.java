package com.sas.mkt.kafka.tools.topics.data;

import java.io.Serializable;
import java.util.Map;

import org.apache.avro.specific.SpecificRecordBase;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class RecordDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	public String key;
	public long offset;
	public int partition;
	public long timestamp;
	public Map<String, String> value;
	@JsonIgnore
	public SpecificRecordBase avroRecord;
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RecordDTO [key=").append(key).append(", offset=").append(offset).append(", partition=")
				.append(partition).append(", timestamp=").append(timestamp).append(", value=").append(value)
				.append("]");
		return builder.toString();
	}

}
