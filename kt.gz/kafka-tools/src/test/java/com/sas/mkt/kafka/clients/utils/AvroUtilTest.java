package com.sas.mkt.kafka.clients.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.sas.mkt.kafka.domain.common.Browser;
import com.sas.mkt.kafka.domain.common.ContactResponse;
import com.sas.mkt.kafka.domain.common.DeviceInfo;
import com.sas.mkt.kafka.domain.common.ECommerceAction;
import com.sas.mkt.kafka.domain.common.EventCategory;
import com.sas.mkt.kafka.domain.common.Impression;
import com.sas.mkt.kafka.domain.common.Location;
import com.sas.mkt.kafka.domain.common.Media;
import com.sas.mkt.kafka.domain.common.MediaAction;
import com.sas.mkt.kafka.domain.common.Page;
import com.sas.mkt.kafka.domain.common.PromotionRecordType;
import com.sas.mkt.kafka.domain.common.ServiceProvider;
import com.sas.mkt.kafka.domain.common.Session;
import com.sas.mkt.kafka.domain.common.URI;
import com.sas.mkt.kafka.domain.common.Visit;
import com.sas.mkt.kafka.domain.events.EnhancedEvent;

public class AvroUtilTest {

    @Test
    public void testAvroEnhancedEventCategory()
    {
        Map<String,String> sampleEvent = new HashMap<String,String>();

        AvroUtil avroUtil = new AvroUtil();

        EnhancedEvent enhanceEvt = avroUtil.eventFromMap(sampleEvent);

        assertNull(enhanceEvt.getCustomName());

        sampleEvent.put(AvroUtil.CUSTOM_EVENT_NAME, "test"+AvroUtil.CUSTOM_EVENT_NAME);

        assertNull(enhanceEvt.getCustomGroupName());

        sampleEvent.put(AvroUtil.CUSTOM_EVENT_GROUP_NAME, "test"+AvroUtil.CUSTOM_EVENT_GROUP_NAME);

        assertNull(enhanceEvt.getCustomRevenueDbl());

        sampleEvent.put(AvroUtil.CUSTOM_EVENT_REVENUE_VALUE, "1000.0");

        assertNull(enhanceEvt.getEventCategory());

        sampleEvent.put("event_category", "");

        enhanceEvt = avroUtil.eventFromMap(sampleEvent);

        assertNull(enhanceEvt.getEventCategory());

        sampleEvent.put("event_category", "bogus");

        enhanceEvt = avroUtil.eventFromMap(sampleEvent);

        assertNull(enhanceEvt.getEventCategory());

        sampleEvent.put("event_category", EventCategory.discover.toString());

        enhanceEvt = avroUtil.eventFromMap(sampleEvent);

        assertEquals(enhanceEvt.getEventCategory(), EventCategory.discover);

        sampleEvent.put("event_category", EventCategory.engage.toString());

        enhanceEvt = avroUtil.eventFromMap(sampleEvent);

        assertEquals(enhanceEvt.getEventCategory(), EventCategory.engage);

        sampleEvent.put("event_category", EventCategory.unified.toString());

        enhanceEvt = avroUtil.eventFromMap(sampleEvent);

        assertEquals(enhanceEvt.getEventCategory(), EventCategory.unified);

        sampleEvent.put("event_category", EventCategory.engageAndDiscover.toString());

        enhanceEvt = avroUtil.eventFromMap(sampleEvent);

        assertEquals(enhanceEvt.getEventCategory(), EventCategory.engageAndDiscover);

        enhanceEvt = EnhancedEvent.newBuilder().build();

        sampleEvent = avroUtil.eventFromAvro(enhanceEvt);

        assertNull(sampleEvent.get("event_category"));

        enhanceEvt = EnhancedEvent.newBuilder().build();

        enhanceEvt.setEventCategory(EventCategory.discover);

        sampleEvent = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(sampleEvent.get("event_category"), EventCategory.discover.toString());

        enhanceEvt = EnhancedEvent.newBuilder().build();

        enhanceEvt.setEventCategory(EventCategory.engage);

        sampleEvent = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(sampleEvent.get("event_category"), EventCategory.engage.toString());

        enhanceEvt = EnhancedEvent.newBuilder().build();

        enhanceEvt.setEventCategory(EventCategory.engageAndDiscover);

        sampleEvent = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(sampleEvent.get("event_category"), EventCategory.engageAndDiscover.toString());

        enhanceEvt = EnhancedEvent.newBuilder().build();

        enhanceEvt.setEventCategory(EventCategory.unified);

        sampleEvent = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(sampleEvent.get("event_category"), EventCategory.unified.toString());

    }

    @Test
    public void testAvroEventType()
    {
        Map<String,String> sampleEvent = new HashMap<String,String>();

        AvroUtil avroUtil = new AvroUtil();

        EnhancedEvent enhanceEvt = avroUtil.eventFromMap(sampleEvent);

        assertNull(enhanceEvt.getEventType());

        sampleEvent.put("event", "");

        enhanceEvt = avroUtil.eventFromMap(sampleEvent);

        assertEquals(enhanceEvt.getEventType(), "");

        sampleEvent.put("event", "bogus");

        enhanceEvt = avroUtil.eventFromMap(sampleEvent);

        assertEquals(enhanceEvt.getEventType(), "bogus");

        enhanceEvt = EnhancedEvent.newBuilder().build();

        enhanceEvt.setEventType("eventType");

        sampleEvent = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(sampleEvent.get("event"), "eventType");


    }

    @Test
    public void testAvroEnhancedEventMapping()
    {

        Map<String,String> sampleEvent = new HashMap<String,String>();

        sampleEvent.put("vid", "testVid");
        sampleEvent.put(AvroUtil.CUSTOM_EVENT_NAME, "test"+AvroUtil.CUSTOM_EVENT_NAME);
        sampleEvent.put(AvroUtil.CUSTOM_EVENT_GROUP_NAME, "test"+AvroUtil.CUSTOM_EVENT_GROUP_NAME);
        sampleEvent.put(AvroUtil.CUSTOM_EVENT_REVENUE_VALUE, "1000.0");
        sampleEvent.put("eventname", "testEventName");
        sampleEvent.put("event_uid", "testEventUID");
        sampleEvent.put("event_channel", "testEventChannel");
        sampleEvent.put("channel_user_id", "testEventChannelId");
        sampleEvent.put("session", "testEventSession");
        sampleEvent.put("extra", "testEventExtra");
        sampleEvent.put("guid", "testguid");

        sampleEvent.put("user_agent", "testUserAgent");
        sampleEvent.put("browser_device_type", "testBrowserDeviceType");
        sampleEvent.put("browser_name", "testBrowserName");
        sampleEvent.put("browser_platform", "testBrowserPlatform");
        sampleEvent.put("geo_ip", "testGeoIP");
        sampleEvent.put("http_request_header_referer", "testHttpRequestHeaderRefferer");
        sampleEvent.put("page_id", "testPageId");
        sampleEvent.put("page_view_sequence_num", "100");

        sampleEvent.put("geo_city", "testCityName");
        sampleEvent.put("geo_country", "testCountryName");
        sampleEvent.put("geo_region", "testRegionName");
        sampleEvent.put("domain", "testDomain");

        AvroUtil avroUtil = new AvroUtil();

        EnhancedEvent enhanceEvt = avroUtil.eventFromMap(sampleEvent);

        assertEquals(sampleEvent.get("vid"), enhanceEvt.getIdentityId());
        assertEquals(sampleEvent.get(AvroUtil.CUSTOM_EVENT_NAME), "test"+AvroUtil.CUSTOM_EVENT_NAME);
        assertEquals(sampleEvent.get(AvroUtil.CUSTOM_EVENT_GROUP_NAME), "test"+AvroUtil.CUSTOM_EVENT_GROUP_NAME);
        assertEquals(sampleEvent.get(AvroUtil.CUSTOM_EVENT_REVENUE_VALUE), "1000.0");
        assertEquals(sampleEvent.get("eventname"), enhanceEvt.getEventName());
        assertEquals(sampleEvent.get("event_uid"), enhanceEvt.getEventDesignedId());
        assertEquals(sampleEvent.get("event_channel"), enhanceEvt.getChannelType());
        assertEquals(sampleEvent.get("channel_user_id"), enhanceEvt.getChannelId());

        assertEquals(sampleEvent.get("session"), enhanceEvt.getSessionId());
        assertEquals(sampleEvent.get("guid"), enhanceEvt.getGuid());
        assertEquals(sampleEvent.get("account"), enhanceEvt.getExternalTenantId());

        assertEquals(sampleEvent.get("user_agent"), enhanceEvt.getBrowser().getUserAgent());
        assertEquals(sampleEvent.get("browser_device_type"), enhanceEvt.getDeviceInfo().getDeviceType());
        assertEquals(sampleEvent.get("browser_name"), enhanceEvt.getBrowser().getName());
        assertEquals(sampleEvent.get("browser_platform"), enhanceEvt.getBrowser().getBrowserPlatform());
        assertEquals(sampleEvent.get("geo_ip"), enhanceEvt.getIpAddress());
        assertEquals(sampleEvent.get("referrer"), enhanceEvt.getPage().getReferrerUri().getUri());
        assertEquals(sampleEvent.get("page_id"), enhanceEvt.getPage().getPageId());
        assertEquals(sampleEvent.get("page_view_sequence_num"), Integer.toString(enhanceEvt.getPage().getViewSequenceNum()));

        assertEquals(sampleEvent.get("geo_city"), enhanceEvt.getIpInfo().getCity());
        assertEquals(sampleEvent.get("geo_country"), enhanceEvt.getIpInfo().getCountry());
        assertEquals(sampleEvent.get("geo_region"), enhanceEvt.getIpInfo().getRegion());
        //assertEquals(sampleEvent.get("domain"), enhanceEvt.getDomain());
        assertEquals(sampleEvent.get("domain"), enhanceEvt.getPage().getUri().getHost());


        Map<String,String> extra = enhanceEvt.getProperties();//enhanceEvt.getExtraProperties();

        assertEquals(sampleEvent.get("extra"), extra.get("extra"));

        Map<String,String> convertedEvent = avroUtil.eventFromAvro(enhanceEvt);

        for(String key:sampleEvent.keySet())
        {
            assertEquals(sampleEvent.get(key), convertedEvent.get(key));
        }
    }

    @Test
    public void testNewSessionEventMapping()
    {
        EnhancedEvent enhanceEvt = EnhancedEvent.newBuilder().build();

        Visit v = enhanceEvt.getVisit();

        if(null == v)
        {
            v = new Visit();
            enhanceEvt.setVisit(v);
        }

        v.setVisitorState("new");

        Session s = enhanceEvt.getSession();
        if(null == s)
        {
            s = Session.newBuilder().build();
            enhanceEvt.setSession(s);
        }

        Map<String,String> props = s.getUserSourceMap();
        if(null == props)
        {
            props = new HashMap<>();
            s.setUserSourceMap(props);
        }

        props.put("NewUS2", "US 2 default");
        props.put("userSource1", "US 2 default");
        props.put("NewUS1", "Use Source 1 Test");


        enhanceEvt.setEventName("notPageLoad");

        Map<String,String> initialProperties = enhanceEvt.getProperties();

        if(null == initialProperties)
        {
            initialProperties = new HashMap<String,String>();
            enhanceEvt.setProperties(initialProperties);
        }

        initialProperties.put("event", "SomeEvent");


        AvroUtil avroUtil = new AvroUtil();

        Map<String,String> newProperties  = avroUtil.eventFromAvro(enhanceEvt);

        //we don't expect AvroUtil to be changing the 'event' attribute for new session
        //remove assertion.
        //assertEquals(newProperties.get("event"), "NewSession");

        //we do want to pull properties from userSourceMap into our properties map
        //going into ESP TNGDEC-2961
        assertEquals(newProperties.get("NewUS2"), "US 2 default");

    }

    @Test
    public void testMobileNewSession()
    {
        Map<String,String> event = new HashMap<String,String>();
        event.put(AvroUtil.EVENT, "newSession");
        event.put(AvroUtil.EVENT_CHANNEL, "mobile");
        event.put(AvroUtil.ACCOUNT, "test"+AvroUtil.ACCOUNT.toString());
        event.put(AvroUtil.DOMAIN, "test"+AvroUtil.DOMAIN.toString());
        event.put(AvroUtil.APP_ID, "test"+AvroUtil.APP_ID.toString());
        event.put(AvroUtil.APP_SDK_VERSION, "test"+AvroUtil.APP_SDK_VERSION.toString());
        event.put(AvroUtil.APP_LANGUAGE, "test"+AvroUtil.APP_LANGUAGE.toString());
        event.put(AvroUtil.APP_VERSION, "test"+AvroUtil.APP_VERSION.toString());
        event.put(AvroUtil.MOBILE_CARRIER_NAME, "test"+AvroUtil.MOBILE_CARRIER_NAME.toString());
        event.put(AvroUtil.MOBILE_COUNTRY_CODE, "test"+AvroUtil.MOBILE_COUNTRY_CODE.toString());
        event.put(AvroUtil.MOBILE_DEVICE_LANGUAGE, "test"+AvroUtil.MOBILE_DEVICE_LANGUAGE.toString());
        event.put(AvroUtil.MOBILE_DEVICE_MANUFACTURER, "test"+AvroUtil.MOBILE_DEVICE_MANUFACTURER.toString());
        event.put(AvroUtil.MOBILE_DEVICE_MODEL, "test"+AvroUtil.MOBILE_DEVICE_MODEL.toString());
        event.put(AvroUtil.MOBILE_DEVICE_TYPE, "test"+AvroUtil.MOBILE_DEVICE_TYPE.toString());
        event.put(AvroUtil.MOBILE_NETWORK_CODE, "test"+AvroUtil.MOBILE_NETWORK_CODE.toString());
        event.put(AvroUtil.MOBILE_PLATFORM, "test"+AvroUtil.MOBILE_PLATFORM.toString());
        event.put(AvroUtil.MOBILE_PLATFORM_VERSION, "test"+AvroUtil.MOBILE_PLATFORM_VERSION.toString());
        event.put(AvroUtil.MOBILE_SCREEN_HEIGHT, "100");
        event.put(AvroUtil.MOBILE_SCREEN_WIDTH, "100");

        AvroUtil avroUtil = new AvroUtil();
        EnhancedEvent enhancedEvent = avroUtil.eventFromMap(event);

        DeviceInfo deviceInfo = enhancedEvent.getDeviceInfo();

        assertEquals(event.get(AvroUtil.MOBILE_DEVICE_LANGUAGE), deviceInfo.getDeviceLanguage());
        assertEquals(event.get(AvroUtil.MOBILE_DEVICE_TYPE), deviceInfo.getDeviceType());
        assertEquals(event.get(AvroUtil.MOBILE_DEVICE_MANUFACTURER), deviceInfo.getManufacturer());
        assertEquals(event.get(AvroUtil.MOBILE_DEVICE_MODEL), deviceInfo.getModel());
        assertEquals(event.get(AvroUtil.MOBILE_PLATFORM), deviceInfo.getPlatform());
        assertEquals(event.get(AvroUtil.MOBILE_PLATFORM_VERSION), deviceInfo.getPlatformVersion());
        assertEquals(event.get(AvroUtil.MOBILE_SCREEN_HEIGHT), deviceInfo.getScreenHeight());
        assertEquals(event.get(AvroUtil.MOBILE_SCREEN_WIDTH), deviceInfo.getScreenWidth());

        ServiceProvider serviceProvider = enhancedEvent.getServiceProvider();

        assertEquals(event.get(AvroUtil.MOBILE_COUNTRY_CODE), serviceProvider.getMobileCountryCode());
        assertEquals(event.get(AvroUtil.MOBILE_CARRIER_NAME), serviceProvider.getName());
        assertEquals(event.get(AvroUtil.MOBILE_NETWORK_CODE), serviceProvider.getNetworkCode());

        Map<String,String> event2 = avroUtil.eventFromAvro(enhancedEvent);

        //For each of the original event attributes, remove and match from the generated event2
        for (String key : event.keySet()) {
            assertEquals(event.get(key), event2.remove(key));
        }

        //Remove and match the additional attributes
        assertEquals(event.get(AvroUtil.MOBILE_DEVICE_TYPE), event2.remove(AvroUtil.BROWSER_DEVICE_TYPE));
        assertEquals("100x100@", event2.remove(AvroUtil.SCREEN_INFO));

        //Remove null logon attributes
        assertNull(event2.remove(AvroUtil.LOGON_TYPE));
        assertNull(event2.remove(AvroUtil.LOGON_VALUE));

        //System.out.println(event2);
        //All known attributes should be removed and compared resulting in empty map
        assertEquals(0, event2.size());
    }


    @Test
    public void testAvroMediaEventMapping()
    {
        EnhancedEvent enhanceEvt = EnhancedEvent.newBuilder().build();

        Media m = enhanceEvt.getMedia();
        if(null == m)
        {
            m = Media.newBuilder().build();
            enhanceEvt.setMedia(m);
        }

        m.setMediaUrl("testURL");
        m.setMediaPlayer("testMediaPlayer");
        m.setMediaPlayerVersion("mediaPlayerVersion");
        m.setMediaLength(15F);
        m.setMediaPosition(123456789000L);
        m.setMediaAction(MediaAction.start);
        m.setMediaFirstInteractionFlag(true);

        AvroUtil avroUtil = new AvroUtil();

        Map<String,String> newProperties  = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(newProperties.get(AvroUtil.MEDIA_URL), m.getMediaUrl());
        assertEquals(newProperties.get(AvroUtil.MEDIA_PLAYER), m.getMediaPlayer());
        assertEquals(newProperties.get(AvroUtil.MEDIA_PLAYER_VERSION), m.getMediaPlayerVersion());
        assertEquals(newProperties.get(AvroUtil.MEDIA_DURATION), m.getMediaLength().toString());
        assertEquals(newProperties.get(AvroUtil.MEDIA_POSITION), m.getMediaPosition().toString());
        assertEquals(newProperties.get(AvroUtil.MEDIA_ACTION), m.getMediaAction().toString());
        assertEquals(newProperties.get(AvroUtil.MEDIA_FIRST_INTERACTION_FLAG), m.getMediaFirstInteractionFlag().toString());

        EnhancedEvent newEvt = avroUtil.eventFromMap(newProperties);
        Media newMedia = newEvt.getMedia();

        assertEquals(newProperties.get(AvroUtil.MEDIA_URL), newMedia.getMediaUrl());
        assertEquals(newProperties.get(AvroUtil.MEDIA_PLAYER), newMedia.getMediaPlayer());
        assertEquals(newProperties.get(AvroUtil.MEDIA_PLAYER_VERSION), newMedia.getMediaPlayerVersion());
        assertEquals(newProperties.get(AvroUtil.MEDIA_DURATION), newMedia.getMediaLength().toString());
        assertEquals(newProperties.get(AvroUtil.MEDIA_POSITION), m.getMediaPosition().toString());
        assertEquals(newProperties.get(AvroUtil.MEDIA_ACTION), m.getMediaAction().toString());
        assertEquals(newProperties.get(AvroUtil.MEDIA_FIRST_INTERACTION_FLAG), m.getMediaFirstInteractionFlag().toString());
    }

    @Test
    public void testAvroPageEventMapping()
    {
        EnhancedEvent enhanceEvt = EnhancedEvent.newBuilder().build();

        Page p = enhanceEvt.getPage();

        if(null == p)
        {
            p = Page.newBuilder().build();
            enhanceEvt.setPage(p);
        }

        p.setErrorLocation("line: x, column: y");
        p.setErrorDescription("errorDescription");

        Map<String,String> initialProperties = enhanceEvt.getProperties();

        if(null == initialProperties)
        {
            initialProperties = new HashMap<String,String>();
            enhanceEvt.setProperties(initialProperties);
        }

        AvroUtil avroUtil = new AvroUtil();

        Map<String,String> newProperties  = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(newProperties.get(AvroUtil.LINE), "x");
        assertEquals(newProperties.get(AvroUtil.COLUMN), "y");
        assertEquals(newProperties.get(AvroUtil.MESSAGE), p.getErrorDescription());

        EnhancedEvent newEvt = avroUtil.eventFromMap(newProperties);
        assertEquals(newEvt.getPage().getErrorLocation(), "line:x,column:y");



        p.setErrorLocation("line: x , column: y ");

        newProperties  = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(newProperties.get(AvroUtil.LINE), "x");
        assertEquals(newProperties.get(AvroUtil.COLUMN), "y");

        p.setErrorLocation("line:x, column:y");

        newProperties  = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(newProperties.get(AvroUtil.LINE), "x");
        assertEquals(newProperties.get(AvroUtil.COLUMN), "y");


        p.setErrorLocation("column:y,line:x");

        newProperties  = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(newProperties.get(AvroUtil.LINE), "x");
        assertEquals(newProperties.get(AvroUtil.COLUMN), "y");


        p.setErrorLocation("column:,line:x");

        newProperties  = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(newProperties.get(AvroUtil.LINE), "x");
        assertEquals(newProperties.get(AvroUtil.COLUMN), null);

        p.setErrorLocation("column y,line:x");

        newProperties  = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(newProperties.get(AvroUtil.LINE), "x");
        //substring doesn't find : keep everything?
        assertEquals(newProperties.get(AvroUtil.COLUMN), "column y");

        p.setErrorLocation("column y line:x,");

        newProperties  = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(newProperties.get(AvroUtil.LINE), null);
        assertEquals(newProperties.get(AvroUtil.COLUMN), null);


    }

    @Test
    public void testIdentity()
    {
        Map<String,String> event = new HashMap<String,String>();

        event.put(AvroUtil.IDENTITY_ID, AvroUtil.IDENTITY_ID+"Value");
        event.put(AvroUtil.SESSION, AvroUtil.SESSION+"Value");
        event.put(AvroUtil.IDENTITY_VISIT_ID, AvroUtil.IDENTITY_VISIT_ID+"Value");
        event.put(AvroUtil.LOGON_TYPE, AvroUtil.LOGON_TYPE+"Value");
        event.put(AvroUtil.LOGON_VALUE, AvroUtil.LOGON_VALUE+"Value");
        event.put(AvroUtil.EVENT_NAME, AvroUtil.EVENT_IDENTITY);

        AvroUtil avroUtil = new AvroUtil();
        EnhancedEvent enhanceEvt = avroUtil.eventFromMap(event);

        assertNotNull(enhanceEvt);
        assertNotNull(enhanceEvt.getIdentity());

        assertEquals(event.get(AvroUtil.IDENTITY_ID), enhanceEvt.getIdentity().getIdentityId());
        assertEquals(event.get(AvroUtil.SESSION), enhanceEvt.getIdentity().getSessionId());
        assertEquals(event.get(AvroUtil.IDENTITY_VISIT_ID), enhanceEvt.getIdentity().getVisitId());
        assertEquals(event.get(AvroUtil.LOGON_TYPE), enhanceEvt.getIdentity().getLoginType());
        assertEquals(event.get(AvroUtil.LOGON_VALUE), enhanceEvt.getIdentity().getLoginValue());
        assertEquals(event.get(AvroUtil.EVENT_NAME), enhanceEvt.getEventName());

        Map<String,String> newMap = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(event.get(AvroUtil.IDENTITY_ID), newMap.get(AvroUtil.IDENTITY_ID));
        assertEquals(event.get(AvroUtil.SESSION), newMap.get(AvroUtil.SESSION));
        assertEquals(event.get(AvroUtil.IDENTITY_VISIT_ID), newMap.get(AvroUtil.IDENTITY_VISIT_ID));
        assertEquals(event.get(AvroUtil.LOGON_TYPE), newMap.get(AvroUtil.LOGON_TYPE));
        assertEquals(event.get(AvroUtil.LOGON_VALUE), newMap.get(AvroUtil.LOGON_VALUE));
        assertEquals(event.get(AvroUtil.EVENT_NAME), newMap.get(AvroUtil.EVENT_NAME));
        assertEquals(AvroUtil.EVENT_MODE_LOGIN, newMap.get(AvroUtil.EVENT_MODE_TAG));


    }

    @Test
    public void testDeviceInfo()
    {
        String screenInfo = "99x120@300";

        EnhancedEvent enhanceEvt = EnhancedEvent.newBuilder().build();

        Map<String,String> event = new HashMap<String,String>();

        event.put(AvroUtil.SCREEN_INFO, screenInfo);

        AvroUtil avroUtil = new AvroUtil();

        enhanceEvt = avroUtil.eventFromMap(event);

        assertNotNull(enhanceEvt);
        assertNotNull(enhanceEvt.getDeviceInfo());

        assertEquals(enhanceEvt.getDeviceInfo().getScreenHeight(), "99");
        assertEquals(enhanceEvt.getDeviceInfo().getScreenWidth(), "120");
        assertEquals(enhanceEvt.getDeviceInfo().getScreenDepth(), "300");

        Map<String,String> newProps = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(screenInfo, newProps.get(AvroUtil.SCREEN_INFO));

    }

    @Test
    public void testActivity()
    {
        Map<String,String> event = new HashMap<String,String>();

        event.put(AvroUtil.ACTIVITY_ID, "activityId");
        event.put(AvroUtil.ABTEST_PATH_ID, "abTstPathId");
        event.put(AvroUtil.ACTIVITY_NAME, "activityName");
        event.put(AvroUtil.ACTIVITY_IA_TAG_VALUE, "activityIATagValue");
        event.put(AvroUtil.ACTIVITY_NODE_ID, "activityNodeId");
        event.put(AvroUtil.ACTIVITY_TASK_TYPE, "activityTaskType");
        event.put(AvroUtil.ACTIVITY_TIME_BOX, "activityTimeBox");

        AvroUtil avroUtil = new AvroUtil();
        EnhancedEvent enhanceEvt = avroUtil.eventFromMap(event);

        assertNotNull(enhanceEvt);
        assertNotNull(enhanceEvt.getActivity());

        assertEquals(event.get(AvroUtil.ACTIVITY_ID), enhanceEvt.getActivity().getActivityId());
        assertEquals(event.get(AvroUtil.ABTEST_PATH_ID), enhanceEvt.getActivity().getAbPathAssignmentId());
        assertEquals(event.get(AvroUtil.ACTIVITY_NAME), enhanceEvt.getActivity().getActivityName());
        assertEquals(event.get(AvroUtil.ACTIVITY_IA_TAG_VALUE), enhanceEvt.getActivity().getIaTagValue());
        assertEquals(event.get(AvroUtil.ACTIVITY_NODE_ID), enhanceEvt.getActivity().getActivityNodeId());
        assertEquals(event.get(AvroUtil.ACTIVITY_TASK_TYPE), enhanceEvt.getActivity().getActivityTaskType());
        assertEquals(event.get(AvroUtil.ACTIVITY_TIME_BOX), enhanceEvt.getActivity().getActivityTimebox());

        Map<String,String> newMap = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(event.get(AvroUtil.ACTIVITY_ID), newMap.get(AvroUtil.ACTIVITY_ID));
        assertEquals(event.get(AvroUtil.ABTEST_PATH_ID), newMap.get(AvroUtil.ABTEST_PATH_ID));
        assertEquals(event.get(AvroUtil.ACTIVITY_NAME), newMap.get(AvroUtil.ACTIVITY_NAME));
        assertEquals(event.get(AvroUtil.ACTIVITY_IA_TAG_VALUE), newMap.get(AvroUtil.ACTIVITY_IA_TAG_VALUE));
        assertEquals(event.get(AvroUtil.ACTIVITY_NODE_ID), newMap.get(AvroUtil.ACTIVITY_NODE_ID));
        assertEquals(event.get(AvroUtil.ACTIVITY_TASK_TYPE), newMap.get(AvroUtil.ACTIVITY_TASK_TYPE));
        assertEquals(event.get(AvroUtil.ACTIVITY_TIME_BOX), newMap.get(AvroUtil.ACTIVITY_TIME_BOX));

    }


    @Test
    public void testTrigger()
    {
        Map<String,String> event = new HashMap<String,String>();

        event.put(AvroUtil.ACTIVITY_TRIGGER_EVENT_ID, "activityTriggerEventId");
        event.put(AvroUtil.TRIGGER_EVENT_EXEC_CTX, "triggerEventExecCtx");
        event.put(AvroUtil.TRIGGER_EVENT_EXP_W_FREQ, "triggerEventExpWFreq");
        event.put(AvroUtil.TRIGGER_EVENT_EXP_ID, "triggerEventExpId");
        event.put(AvroUtil.TRIGGER_EVENT_EXP_FILTER_TOTAL, "triggerEventExpFilterTotal");


        AvroUtil avroUtil = new AvroUtil();
        EnhancedEvent enhanceEvt = avroUtil.eventFromMap(event);

        assertNotNull(enhanceEvt);
        assertNotNull(enhanceEvt.getTrigger());

        assertEquals(event.get(AvroUtil.ACTIVITY_TRIGGER_EVENT_ID), enhanceEvt.getTrigger().getTriggerEventId());
        assertEquals(event.get(AvroUtil.TRIGGER_EVENT_EXEC_CTX), enhanceEvt.getTrigger().getExecutionContext());
        assertEquals(event.get(AvroUtil.TRIGGER_EVENT_EXP_W_FREQ), enhanceEvt.getTrigger().getExpressionFrequency());
        assertEquals(event.get(AvroUtil.TRIGGER_EVENT_EXP_ID), enhanceEvt.getTrigger().getExpressionId());
        assertEquals(event.get(AvroUtil.TRIGGER_EVENT_EXP_FILTER_TOTAL), enhanceEvt.getTrigger().getExpressionFilterTotal());

        Map<String,String> newMap = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(event.get(AvroUtil.ACTIVITY_TRIGGER_EVENT_ID), newMap.get(AvroUtil.ACTIVITY_TRIGGER_EVENT_ID));
        assertEquals(event.get(AvroUtil.TRIGGER_EVENT_EXEC_CTX), newMap.get(AvroUtil.TRIGGER_EVENT_EXEC_CTX));
        assertEquals(event.get(AvroUtil.TRIGGER_EVENT_EXP_W_FREQ), newMap.get(AvroUtil.TRIGGER_EVENT_EXP_W_FREQ));
        assertEquals(event.get(AvroUtil.TRIGGER_EVENT_EXP_ID), newMap.get(AvroUtil.TRIGGER_EVENT_EXP_ID));
        assertEquals(event.get(AvroUtil.TRIGGER_EVENT_EXP_FILTER_TOTAL), newMap.get(AvroUtil.TRIGGER_EVENT_EXP_FILTER_TOTAL));

    }


    @Test
    public void testECommerce()
    {
        Map<String,String> event = new HashMap<String,String>();

        Integer itemCount = 50;
        //event.put(AvroUtil.CART_ITEM_COUNT, itemCount.toString());
        event.put(AvroUtil.CART_TYPE, "purchase");
        event.put(AvroUtil.CART_ID, "cartSnapshotIdValue");
        event.put(AvroUtil.PAYMENT_TYPE, "paymentTypeValue");
        event.put(AvroUtil.DELIVERY_TYPE, "deliveryTypeValue");
        event.put(AvroUtil.TAX, "7.5");
        event.put(AvroUtil.TOTAL_COST, "99.99");
        event.put(AvroUtil.SHIPPING_COST, "12.95");
        event.put(AvroUtil.BILLING_CITY, "Raleigh");
        event.put(AvroUtil.BILLING_COUNTRY, "USA1");
        event.put(AvroUtil.BILLING_POSTCODE, "27718");
        event.put(AvroUtil.BILLING_REGION, "Wake");
        event.put(AvroUtil.SHIPPING_CITY, "Durham");
        event.put(AvroUtil.SHIPPING_COUNTRY, "USA2");
        event.put(AvroUtil.SHIPPING_POSTCODE, "27713");
        event.put(AvroUtil.SHIPPING_REGION, "Durham County");

        try
        {
            AvroUtil avroUtil = new AvroUtil();
            EnhancedEvent enhanceEvt = avroUtil.eventFromMap(event);
            Map<String,String> newMap = avroUtil.eventFromAvro(enhanceEvt);

            //first test without item count then convert again
            event.put(AvroUtil.CART_ITEM_COUNT, itemCount.toString());
            enhanceEvt = avroUtil.eventFromMap(event);

            assertNotNull(enhanceEvt);
            assertNotNull(enhanceEvt.getECommerce());

            assertEquals(itemCount, enhanceEvt.getECommerce().getItemCount());
            assertEquals(ECommerceAction.order, enhanceEvt.getECommerce().getECommerceAction());
            assertEquals(event.get(AvroUtil.CART_ID), enhanceEvt.getECommerce().getCartId());
            assertEquals(event.get(AvroUtil.PAYMENT_TYPE), enhanceEvt.getECommerce().getPaymentType());
            assertEquals(event.get(AvroUtil.DELIVERY_TYPE), enhanceEvt.getECommerce().getDeliveryType());
            assertEquals(Double.valueOf(event.get(AvroUtil.TAX)), enhanceEvt.getECommerce().getTotalTaxDbl());
            assertEquals(Double.valueOf(event.get(AvroUtil.TOTAL_COST)), enhanceEvt.getECommerce().getTotalValueDbl());
            assertEquals(Double.valueOf(event.get(AvroUtil.SHIPPING_COST)), enhanceEvt.getECommerce().getTotalShippingDbl());
            assertEquals(event.get(AvroUtil.BILLING_CITY), enhanceEvt.getECommerce().getBillingAddress().getCity());
            assertEquals(event.get(AvroUtil.BILLING_COUNTRY), enhanceEvt.getECommerce().getBillingAddress().getCountry());
            assertEquals(event.get(AvroUtil.BILLING_POSTCODE), enhanceEvt.getECommerce().getBillingAddress().getPostalCode());
            assertEquals(event.get(AvroUtil.BILLING_REGION), enhanceEvt.getECommerce().getBillingAddress().getRegion());
            assertEquals(event.get(AvroUtil.SHIPPING_CITY), enhanceEvt.getECommerce().getShippingAddress().getCity());
            assertEquals(event.get(AvroUtil.SHIPPING_COUNTRY), enhanceEvt.getECommerce().getShippingAddress().getCountry());
            assertEquals(event.get(AvroUtil.SHIPPING_POSTCODE), enhanceEvt.getECommerce().getShippingAddress().getPostalCode());
            assertEquals(event.get(AvroUtil.SHIPPING_REGION), enhanceEvt.getECommerce().getShippingAddress().getRegion());

            newMap = avroUtil.eventFromAvro(enhanceEvt);

            assertEquals(event.get(AvroUtil.CART_TYPE), newMap.get(AvroUtil.CART_TYPE));
            assertEquals(event.get(AvroUtil.CART_ITEM_COUNT), newMap.get(AvroUtil.CART_ITEM_COUNT));
            assertEquals(event.get(AvroUtil.CART_ID), newMap.get(AvroUtil.CART_ID));
            assertEquals(event.get(AvroUtil.PAYMENT_TYPE), newMap.get(AvroUtil.PAYMENT_TYPE));
            assertEquals(event.get(AvroUtil.TAX), newMap.get(AvroUtil.TAX));
            assertEquals(event.get(AvroUtil.TOTAL_COST), newMap.get(AvroUtil.TOTAL_COST));
            assertEquals(event.get(AvroUtil.SHIPPING_COST), newMap.get(AvroUtil.SHIPPING_COST));
            assertEquals(event.get(AvroUtil.BILLING_CITY), newMap.get(AvroUtil.BILLING_CITY));
            assertEquals(event.get(AvroUtil.BILLING_COUNTRY), newMap.get(AvroUtil.BILLING_COUNTRY));
            assertEquals(event.get(AvroUtil.BILLING_POSTCODE), newMap.get(AvroUtil.BILLING_POSTCODE));
            assertEquals(event.get(AvroUtil.BILLING_REGION), newMap.get(AvroUtil.BILLING_REGION));
            assertEquals(event.get(AvroUtil.SHIPPING_CITY), newMap.get(AvroUtil.SHIPPING_CITY));
            assertEquals(event.get(AvroUtil.SHIPPING_COUNTRY), newMap.get(AvroUtil.SHIPPING_COUNTRY));
            assertEquals(event.get(AvroUtil.SHIPPING_POSTCODE), newMap.get(AvroUtil.SHIPPING_POSTCODE));
            assertEquals(event.get(AvroUtil.SHIPPING_REGION), newMap.get(AvroUtil.SHIPPING_REGION));
        }
        catch(Exception ex)
        {
            fail(ex.getMessage());
        }

    }




    @Test
    public void testImpression()
    {
        Map<String,String> event = new HashMap<String,String>();

        event.put(AvroUtil.CONTROL_GROUP, "controlGroup");
        event.put(AvroUtil.CREATIVE_ID, "creativeId");
        event.put(AvroUtil.CREATIVE_VERSION_ID, "creativeVersionId");
        event.put(AvroUtil.CREATIVE_CONTENT, "creativeContent");
        event.put(AvroUtil.GOAL_EVENT, "goalEvent");
        event.put(AvroUtil.GOAL_ID, "goalId");
        event.put(AvroUtil.SPOT_ID, "spotId");
        event.put(AvroUtil.TASK_ID, "taskId");
        event.put(AvroUtil.TASK_VERSION_ID, "taskVersionId");
        event.put(AvroUtil.VARIANT_ID, "variantId");
        event.put(AvroUtil.IMPRINT_ID, "imprintId");
        event.put(AvroUtil.OCCURRENCE_ID, "occurrenceId");
        event.put(AvroUtil.IS_CONTROL_GROUP, "true");
        event.put(AvroUtil.MERGETAG_ATTRIBUTE_NAME, "mergeTagAttributeName");
        event.put(AvroUtil.MERGETAG_IA_SAFE_ID, "mergeTagIASafeId");
        event.put(AvroUtil.MESSAGE_ID, "messageId");
        event.put(AvroUtil.MESSAGE_VERSION_ID, "messageVersionId");
        event.put(AvroUtil.SEGMENT_ID, "segmentId");
        event.put(AvroUtil.SEGMENT_VERSION_ID, "segmentVersionId");
        event.put(AvroUtil.CONTACT_RESPONSE, "contactResponseCode");
        event.put(AvroUtil.CONTACT_RESPONSE_TAG, "contactResponseTag");
        event.put(AvroUtil.RESPONSE_TRACKING_CODE, "responseTrackingCode");
        event.put(AvroUtil.RESPONSE_TYPE, "responseType");
        event.put(AvroUtil.RESPONSE_VALUE, "responseValue");

        AvroUtil avroUtil = new AvroUtil();
        EnhancedEvent enhanceEvt = avroUtil.eventFromMap(event);

        assertNotNull(enhanceEvt);
        assertNotNull(enhanceEvt.getImpression());

        assertEquals(event.get(AvroUtil.CONTROL_GROUP), enhanceEvt.getImpression().getControlGroup());
        assertEquals(event.get(AvroUtil.CREATIVE_ID), enhanceEvt.getImpression().getCreativeId());
        assertEquals(event.get(AvroUtil.CREATIVE_VERSION_ID), enhanceEvt.getImpression().getCreativeVersionId());
        assertEquals(event.get(AvroUtil.CREATIVE_CONTENT), enhanceEvt.getImpression().getCreativeContent());
        assertEquals(event.get(AvroUtil.GOAL_EVENT), enhanceEvt.getImpression().getGoalEvent());
        assertEquals(event.get(AvroUtil.GOAL_ID), enhanceEvt.getImpression().getGoalId());
        assertEquals(event.get(AvroUtil.SPOT_ID), enhanceEvt.getImpression().getSpotId());
        assertEquals(event.get(AvroUtil.TASK_ID), enhanceEvt.getImpression().getTaskId());
        assertEquals(event.get(AvroUtil.TASK_VERSION_ID), enhanceEvt.getImpression().getTaskVersionId());
        assertEquals(event.get(AvroUtil.VARIANT_ID), enhanceEvt.getImpression().getVariantId());
        assertEquals(event.get(AvroUtil.IMPRINT_ID), enhanceEvt.getImpression().getImprintId());
        assertEquals(event.get(AvroUtil.OCCURRENCE_ID), enhanceEvt.getImpression().getOccurrenceId());
        assertEquals(true, enhanceEvt.getImpression().getIsControlGroup());
        assertEquals(event.get(AvroUtil.MERGETAG_ATTRIBUTE_NAME), enhanceEvt.getImpression().getMergeTagAttributeName());
        assertEquals(event.get(AvroUtil.MERGETAG_IA_SAFE_ID), enhanceEvt.getImpression().getMergeTagIaSafeId());
        assertEquals(event.get(AvroUtil.MESSAGE_ID), enhanceEvt.getImpression().getMessageId());
        assertEquals(event.get(AvroUtil.MESSAGE_VERSION_ID), enhanceEvt.getImpression().getMessageVersionId());
        assertEquals(event.get(AvroUtil.SEGMENT_ID), enhanceEvt.getImpression().getSegmentId());
        assertEquals(event.get(AvroUtil.SEGMENT_VERSION_ID), enhanceEvt.getImpression().getSegmentVersionId());

        assertNotNull(enhanceEvt.getContactResponse());
        assertEquals(event.get(AvroUtil.CONTACT_RESPONSE), enhanceEvt.getContactResponse().getContactResponseCode());
        assertEquals(event.get(AvroUtil.CONTACT_RESPONSE_TAG), enhanceEvt.getContactResponse().getContactResponseTag());
        assertEquals(event.get(AvroUtil.RESPONSE_TRACKING_CODE), enhanceEvt.getContactResponse().getResponseTrackingCode());
        assertEquals(event.get(AvroUtil.RESPONSE_TYPE), enhanceEvt.getContactResponse().getResponseType());
        assertEquals(event.get(AvroUtil.RESPONSE_VALUE), enhanceEvt.getContactResponse().getResponseValue());

        Map<String,String> newMap = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(event.get(AvroUtil.CONTROL_GROUP), newMap.get(AvroUtil.CONTROL_GROUP));
        assertEquals(event.get(AvroUtil.CREATIVE_ID), newMap.get(AvroUtil.CREATIVE_ID));
        assertEquals(event.get(AvroUtil.CREATIVE_VERSION_ID), newMap.get(AvroUtil.CREATIVE_VERSION_ID));
        assertEquals(event.get(AvroUtil.CREATIVE_CONTENT), newMap.get(AvroUtil.CREATIVE_CONTENT));
        assertEquals(event.get(AvroUtil.GOAL_EVENT), newMap.get(AvroUtil.GOAL_EVENT));
        assertEquals(event.get(AvroUtil.GOAL_ID), newMap.get(AvroUtil.GOAL_ID));
        assertEquals(event.get(AvroUtil.SPOT_ID), newMap.get(AvroUtil.SPOT_ID));
        assertEquals(event.get(AvroUtil.TASK_ID), newMap.get(AvroUtil.TASK_ID));
        assertEquals(event.get(AvroUtil.TASK_VERSION_ID), newMap.get(AvroUtil.TASK_VERSION_ID));
        assertEquals(event.get(AvroUtil.VARIANT_ID), newMap.get(AvroUtil.VARIANT_ID));
        assertEquals(event.get(AvroUtil.IMPRINT_ID), newMap.get(AvroUtil.IMPRINT_ID));
        assertEquals(event.get(AvroUtil.OCCURRENCE_ID), newMap.get(AvroUtil.OCCURRENCE_ID));
        assertEquals(event.get(AvroUtil.IS_CONTROL_GROUP), newMap.get(AvroUtil.IS_CONTROL_GROUP));
        assertEquals(event.get(AvroUtil.MERGETAG_ATTRIBUTE_NAME), newMap.get(AvroUtil.MERGETAG_ATTRIBUTE_NAME));
        assertEquals(event.get(AvroUtil.MERGETAG_IA_SAFE_ID), newMap.get(AvroUtil.MERGETAG_IA_SAFE_ID));
        assertEquals(event.get(AvroUtil.MESSAGE_ID), newMap.get(AvroUtil.MESSAGE_ID));
        assertEquals(event.get(AvroUtil.MESSAGE_VERSION_ID), newMap.get(AvroUtil.MESSAGE_VERSION_ID));
        assertEquals(event.get(AvroUtil.SEGMENT_ID), newMap.get(AvroUtil.SEGMENT_ID));
        assertEquals(event.get(AvroUtil.SEGMENT_VERSION_ID), newMap.get(AvroUtil.SEGMENT_VERSION_ID));
        assertEquals(event.get(AvroUtil.CONTACT_RESPONSE), newMap.get(AvroUtil.CONTACT_RESPONSE));
        assertEquals(event.get(AvroUtil.CONTACT_RESPONSE_TAG), newMap.get(AvroUtil.CONTACT_RESPONSE_TAG));
        assertEquals(event.get(AvroUtil.RESPONSE_TRACKING_CODE), newMap.get(AvroUtil.RESPONSE_TRACKING_CODE));
        assertEquals(event.get(AvroUtil.RESPONSE_TYPE), newMap.get(AvroUtil.RESPONSE_TYPE));
        assertEquals(event.get(AvroUtil.RESPONSE_VALUE), newMap.get(AvroUtil.RESPONSE_VALUE));

        enhanceEvt = EnhancedEvent.newBuilder().build();
        Impression i = Impression.newBuilder().build();
        enhanceEvt.setImpression(i);

        try
        {
            //validate that an empty impression instance doesn't cause any errors
            avroUtil.eventFromAvro(enhanceEvt);
        }
        catch(Exception ex)
        {
            fail(ex.getMessage());
        }

        ContactResponse cr = ContactResponse.newBuilder().build();
        enhanceEvt.setContactResponse(cr);

        try
        {
            //validate that an empty impression instance doesn't cause any errors
            avroUtil.eventFromAvro(enhanceEvt);
        }
        catch(Exception ex)
        {
            fail(ex.getMessage());
        }

    }


    @Test
    public void testBeacon()
    {
        Map<String,String> event = new HashMap<String,String>();

        event.put(AvroUtil.BEACON_ID, "beaconId");
        event.put(AvroUtil.BEACON_MAJOR, "beaconMajor");
        event.put(AvroUtil.BEACON_MINOR, "beaconMinor");
        event.put(AvroUtil.BEACON_NAME, "beaconName");
        event.put(AvroUtil.BEACON_UUID, "beaconUUID");
        event.put(AvroUtil.BEACON_KEYWORDS, "shoes");
        event.put(AvroUtil.GEOFENCE_NAME, "fence1");
        event.put(AvroUtil.GEOFENCE_CITY, "Cary");
        event.put(AvroUtil.GEOFENCE_STATE, "disarray");
        event.put(AvroUtil.GEOFENCE_REGION, "South");
        event.put(AvroUtil.GEOFENCE_ID, "42");

        AvroUtil avroUtil = new AvroUtil();
        EnhancedEvent enhanceEvt = avroUtil.eventFromMap(event);

        assertNotNull(enhanceEvt);
        assertNotNull(enhanceEvt.getBeacon());
        assertNotNull(enhanceEvt.getGeofence());

        assertEquals(event.get(AvroUtil.BEACON_ID), enhanceEvt.getBeacon().getBeaconId());
        assertEquals(event.get(AvroUtil.BEACON_MAJOR), enhanceEvt.getBeacon().getBeaconMajor());
        assertEquals(event.get(AvroUtil.BEACON_MINOR), enhanceEvt.getBeacon().getBeaconMinor());
        assertEquals(event.get(AvroUtil.BEACON_NAME), enhanceEvt.getBeacon().getBeaconName());
        assertEquals(event.get(AvroUtil.BEACON_UUID), enhanceEvt.getBeacon().getBeaconUuid());
        assertEquals(event.get(AvroUtil.GEOFENCE_NAME), enhanceEvt.getGeofence().getGeofenceName());
        assertEquals(event.get(AvroUtil.GEOFENCE_CITY), enhanceEvt.getGeofence().getGeofenceCity());
        assertEquals(event.get(AvroUtil.GEOFENCE_STATE), enhanceEvt.getGeofence().getGeofenceState());
        assertEquals(event.get(AvroUtil.GEOFENCE_REGION), enhanceEvt.getGeofence().getGeofenceRegion());
        assertEquals(event.get(AvroUtil.GEOFENCE_ID), enhanceEvt.getGeofence().getGeofenceId());

        Map<String,String> newMap = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(event.get(AvroUtil.BEACON_ID), newMap.get(AvroUtil.BEACON_ID));
        assertEquals(event.get(AvroUtil.BEACON_MAJOR), newMap.get(AvroUtil.BEACON_MAJOR));
        assertEquals(event.get(AvroUtil.BEACON_MINOR), newMap.get(AvroUtil.BEACON_MINOR));
        assertEquals(event.get(AvroUtil.BEACON_NAME), newMap.get(AvroUtil.BEACON_NAME));
        assertEquals(event.get(AvroUtil.BEACON_UUID), newMap.get(AvroUtil.BEACON_UUID));
        assertEquals(event.get(AvroUtil.GEOFENCE_NAME), newMap.get(AvroUtil.GEOFENCE_NAME));
        assertEquals(event.get(AvroUtil.GEOFENCE_CITY), newMap.get(AvroUtil.GEOFENCE_CITY));
        assertEquals(event.get(AvroUtil.GEOFENCE_STATE), newMap.get(AvroUtil.GEOFENCE_STATE));
        assertEquals(event.get(AvroUtil.GEOFENCE_REGION), newMap.get(AvroUtil.GEOFENCE_REGION));
        assertEquals(event.get(AvroUtil.GEOFENCE_ID), newMap.get(AvroUtil.GEOFENCE_ID));

    }


    @Test
    public void testApp()
    {
        Map<String,String> event = new HashMap<String,String>();

        event.put(AvroUtil.APP_LANGUAGE, "appLanguage");
        event.put(AvroUtil.APP_VERSION, "appVersion");
        event.put(AvroUtil.APP_ID, "appId");
        event.put(AvroUtil.APP_SDK_VERSION, "appSDKVersion");


        AvroUtil avroUtil = new AvroUtil();
        EnhancedEvent enhanceEvt = avroUtil.eventFromMap(event);

        assertNotNull(enhanceEvt);
        assertNotNull(enhanceEvt.getApp());

        assertEquals(event.get(AvroUtil.APP_LANGUAGE), enhanceEvt.getApp().getAppLanguage());
        assertEquals(event.get(AvroUtil.APP_VERSION), enhanceEvt.getApp().getAppVersion());
        assertEquals(event.get(AvroUtil.APP_ID), enhanceEvt.getApp().getAppId());
        assertEquals(event.get(AvroUtil.APP_SDK_VERSION), enhanceEvt.getApp().getSdkVersion());

        Map<String,String> newMap = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(event.get(AvroUtil.APP_LANGUAGE), newMap.get(AvroUtil.APP_LANGUAGE));
        assertEquals(event.get(AvroUtil.APP_VERSION), newMap.get(AvroUtil.APP_VERSION));
        assertEquals(event.get(AvroUtil.APP_ID), newMap.get(AvroUtil.APP_ID));
        assertEquals(event.get(AvroUtil.APP_SDK_VERSION), newMap.get(AvroUtil.APP_SDK_VERSION));

    }

    @Test
    public void testPromotion()
    {
        Map<String,String> event = new HashMap<String,String>();

        event.put(AvroUtil.PROMOTION_CREATIVE, "creative");
        event.put(AvroUtil.PROMOTION_NAME, "name");
        event.put(AvroUtil.PROMOTION_PLACEMENT, "placement");
        event.put(AvroUtil.PROMOTION_RECORD_TYPE, PromotionRecordType.display.name());
        event.put(AvroUtil.PROMOTION_TRACKING_CODE, "trackingCode");
        event.put(AvroUtil.PROMOTION_TYPE, "type");

        AvroUtil avroUtil = new AvroUtil();
        EnhancedEvent enhanceEvt = avroUtil.eventFromMap(event);

        assertNotNull(enhanceEvt);
        assertNotNull(enhanceEvt.getPromotion());

        assertEquals(event.get(AvroUtil.PROMOTION_CREATIVE), enhanceEvt.getPromotion().getCreativeName());
        assertEquals(event.get(AvroUtil.PROMOTION_NAME), enhanceEvt.getPromotion().getPromotionName());
        assertEquals(event.get(AvroUtil.PROMOTION_PLACEMENT), enhanceEvt.getPromotion().getPlacementId());
        assertEquals(event.get(AvroUtil.PROMOTION_RECORD_TYPE), enhanceEvt.getPromotion().getRecordType().name());
        assertEquals(event.get(AvroUtil.PROMOTION_TRACKING_CODE), enhanceEvt.getPromotion().getTrackingCode());
        assertEquals(event.get(AvroUtil.PROMOTION_TYPE), enhanceEvt.getPromotion().getPromotionType());

        Map<String,String> newMap = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(event.get(AvroUtil.PROMOTION_CREATIVE), newMap.get(AvroUtil.PROMOTION_CREATIVE));
        assertEquals(event.get(AvroUtil.PROMOTION_NAME), newMap.get(AvroUtil.PROMOTION_NAME));
        assertEquals(event.get(AvroUtil.PROMOTION_PLACEMENT), newMap.get(AvroUtil.PROMOTION_PLACEMENT));
        assertEquals(event.get(AvroUtil.PROMOTION_RECORD_TYPE), newMap.get(AvroUtil.PROMOTION_RECORD_TYPE));
        assertEquals(event.get(AvroUtil.PROMOTION_TRACKING_CODE), newMap.get(AvroUtil.PROMOTION_TRACKING_CODE));
        assertEquals(event.get(AvroUtil.PROMOTION_TYPE), newMap.get(AvroUtil.PROMOTION_TYPE));

    }

    @Test
    public void testProduct()
    {
        Map<String,String> event = new HashMap<String,String>();

        event.put(AvroUtil.PRODUCT_AVAILABILITY_MESSAGE, AvroUtil.PRODUCT_AVAILABILITY_MESSAGE+"Value");
        event.put(AvroUtil.PRODUCT_GROUP, AvroUtil.PRODUCT_GROUP+"Value");
        event.put(AvroUtil.PRODUCT_ID, AvroUtil.PRODUCT_ID+"Value");
        event.put(AvroUtil.PRODUCT_NAME, AvroUtil.PRODUCT_NAME+"Value");
        event.put(AvroUtil.PRODUCT_QUANTITY, "5");
        event.put(AvroUtil.PRODUCT_SKU, AvroUtil.PRODUCT_SKU+"Value");
        event.put(AvroUtil.PRODUCT_UNIT_PRICE, "9.99");
        event.put(AvroUtil.PRODUCT_SAVINGS_MESSAGE, AvroUtil.PRODUCT_SAVINGS_MESSAGE+"Value");
        event.put(AvroUtil.PRODUCT_SHIPPING_MESSAGE, AvroUtil.PRODUCT_SHIPPING_MESSAGE+"Value");

        AvroUtil avroUtil = new AvroUtil();
        EnhancedEvent enhanceEvt = avroUtil.eventFromMap(event);

        assertNotNull(enhanceEvt);
        assertNotNull(enhanceEvt.getProduct());

        assertEquals(event.get(AvroUtil.PRODUCT_AVAILABILITY_MESSAGE), enhanceEvt.getProduct().getAvailabilityMsg());
        assertEquals(event.get(AvroUtil.PRODUCT_GROUP), enhanceEvt.getProduct().getProductGroup());
        assertEquals(event.get(AvroUtil.PRODUCT_ID), enhanceEvt.getProduct().getProductId());
        assertEquals(event.get(AvroUtil.PRODUCT_NAME), enhanceEvt.getProduct().getProductName());
        assertEquals(Integer.valueOf(event.get(AvroUtil.PRODUCT_QUANTITY)), enhanceEvt.getProduct().getQuantity());
        assertEquals(event.get(AvroUtil.PRODUCT_SKU), enhanceEvt.getProduct().getProductSku());
        assertEquals(Double.valueOf(event.get(AvroUtil.PRODUCT_UNIT_PRICE)), enhanceEvt.getProduct().getUnitPriceDbl());
        assertEquals(event.get(AvroUtil.PRODUCT_SAVINGS_MESSAGE), enhanceEvt.getProduct().getSavingsMsg());
        assertEquals(event.get(AvroUtil.PRODUCT_SHIPPING_MESSAGE), enhanceEvt.getProduct().getShippingMsg());

        Map<String,String> newMap = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(event.get(AvroUtil.PRODUCT_AVAILABILITY_MESSAGE), newMap.get(AvroUtil.PRODUCT_AVAILABILITY_MESSAGE));
        assertEquals(event.get(AvroUtil.PRODUCT_GROUP), newMap.get(AvroUtil.PRODUCT_GROUP));
        assertEquals(event.get(AvroUtil.PRODUCT_ID), newMap.get(AvroUtil.PRODUCT_ID));
        assertEquals(event.get(AvroUtil.PRODUCT_NAME), newMap.get(AvroUtil.PRODUCT_NAME));
        assertEquals(event.get(AvroUtil.PRODUCT_QUANTITY), newMap.get(AvroUtil.PRODUCT_QUANTITY));
        assertEquals(event.get(AvroUtil.PRODUCT_SKU), newMap.get(AvroUtil.PRODUCT_SKU));
        assertEquals(event.get(AvroUtil.PRODUCT_UNIT_PRICE), newMap.get(AvroUtil.PRODUCT_UNIT_PRICE));
        assertEquals(event.get(AvroUtil.PRODUCT_SAVINGS_MESSAGE), newMap.get(AvroUtil.PRODUCT_SAVINGS_MESSAGE));
        assertEquals(event.get(AvroUtil.PRODUCT_SHIPPING_MESSAGE), newMap.get(AvroUtil.PRODUCT_SHIPPING_MESSAGE));

    }

    @Test
    public void testInternalSearch()
    {
        Map<String,String> event = new HashMap<String,String>();

        event.put(AvroUtil.INTERNAL_SEARCH_RESULT_COUNT, "9");
        event.put(AvroUtil.INTERNAL_SEARCH_TERM, "someTerm");

        AvroUtil avroUtil = new AvroUtil();
        EnhancedEvent enhanceEvt = avroUtil.eventFromMap(event);

        assertNotNull(enhanceEvt);
        assertNotNull(enhanceEvt.getInternalSearch());

        assertEquals(Integer.valueOf(event.get(AvroUtil.INTERNAL_SEARCH_RESULT_COUNT)), enhanceEvt.getInternalSearch().getResultsDisplayed());
        assertEquals(event.get(AvroUtil.INTERNAL_SEARCH_TERM), enhanceEvt.getInternalSearch().getSearchTerm());

        Map<String,String> newMap = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(event.get(AvroUtil.INTERNAL_SEARCH_RESULT_COUNT), newMap.get(AvroUtil.INTERNAL_SEARCH_RESULT_COUNT));
        assertEquals(event.get(AvroUtil.INTERNAL_SEARCH_TERM), newMap.get(AvroUtil.INTERNAL_SEARCH_TERM));

    }

    @Test
    public void testLinkTracking()
    {
        Map<String,String> event = new HashMap<String,String>();

        event.put(AvroUtil.LINK_TRACKING_ID, "1");
        event.put(AvroUtil.LINK_TRACKING_LABEL, "label");
        event.put(AvroUtil.LINK_TRACKING_GROUP, "group");

        AvroUtil avroUtil = new AvroUtil();
        EnhancedEvent enhanceEvt = avroUtil.eventFromMap(event);

        assertNotNull(enhanceEvt);
        assertNotNull(enhanceEvt.getLinkTracking());

        assertEquals(event.get(AvroUtil.LINK_TRACKING_ID), enhanceEvt.getLinkTracking().getLinkTrackingId());
        assertEquals(event.get(AvroUtil.LINK_TRACKING_LABEL), enhanceEvt.getLinkTracking().getLinkTrackingLabel());
        assertEquals(event.get(AvroUtil.LINK_TRACKING_GROUP), enhanceEvt.getLinkTracking().getLinkTrackingGroup());

        Map<String,String> newMap = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(event.get(AvroUtil.LINK_TRACKING_ID), newMap.get(AvroUtil.LINK_TRACKING_ID));
        assertEquals(event.get(AvroUtil.LINK_TRACKING_LABEL), newMap.get(AvroUtil.LINK_TRACKING_LABEL));
        assertEquals(event.get(AvroUtil.LINK_TRACKING_GROUP), newMap.get(AvroUtil.LINK_TRACKING_GROUP));

    }

    @Test
    public void testEmail()
    {
        Map<String,String> event = new HashMap<String,String>();

        event.put(AvroUtil.EMAIL_RECIPIENT_DOMAIN, "domain");
        event.put(AvroUtil.EMAIL_RECIPIENT_EMAIL_ADDRESS, "emailAddress");
        event.put(AvroUtil.EMAIL_PROGRAM_ID, "programId");
        event.put(AvroUtil.EMAIL_REPLY_CORRELATED, "replyCorrelated");
        event.put(AvroUtil.EMAIL_SEND_AGENT_ID, "sendAgentId");
        event.put(AvroUtil.EMAIL_SUBJECT, "subject");
        event.put(AvroUtil.EMAIL_IMPRINT_URL, "https://d2b8feddltr5ik.cloudfront.net/deepdive/1d18df6a-8d32-497f-9901-41049bb81330.html");
        event.put(AvroUtil.EMAIL_REASON, "reason");

        AvroUtil avroUtil = new AvroUtil();
        EnhancedEvent enhanceEvt = avroUtil.eventFromMap(event);

        assertNotNull(enhanceEvt);
        assertNotNull(enhanceEvt.getEmail());

        assertEquals(event.get(AvroUtil.EMAIL_RECIPIENT_DOMAIN), enhanceEvt.getEmail().getRecipientDomain());
        assertEquals(event.get(AvroUtil.EMAIL_RECIPIENT_EMAIL_ADDRESS), enhanceEvt.getEmail().getRecipientEmailAddress());
        assertEquals(event.get(AvroUtil.EMAIL_PROGRAM_ID), enhanceEvt.getEmail().getEmailProgramId());
        assertEquals(event.get(AvroUtil.EMAIL_REPLY_CORRELATED), enhanceEvt.getEmail().getEmailReplyCorrelated());
        assertEquals(event.get(AvroUtil.EMAIL_SEND_AGENT_ID), enhanceEvt.getEmail().getEmailSendAgentId());
        assertEquals(event.get(AvroUtil.EMAIL_SUBJECT), enhanceEvt.getEmail().getEmailSubject());
        assertEquals(event.get(AvroUtil.EMAIL_IMPRINT_URL), enhanceEvt.getEmail().getImprintURL());
        assertEquals(event.get(AvroUtil.EMAIL_REASON), enhanceEvt.getEmail().getReason());

        Map<String,String> newMap = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(event.get(AvroUtil.EMAIL_RECIPIENT_DOMAIN), newMap.get(AvroUtil.EMAIL_RECIPIENT_DOMAIN));
        assertEquals(event.get(AvroUtil.EMAIL_RECIPIENT_EMAIL_ADDRESS), newMap.get(AvroUtil.EMAIL_RECIPIENT_EMAIL_ADDRESS));
        assertEquals(event.get(AvroUtil.EMAIL_PROGRAM_ID), newMap.get(AvroUtil.EMAIL_PROGRAM_ID));
        assertEquals(event.get(AvroUtil.EMAIL_REPLY_CORRELATED), newMap.get(AvroUtil.EMAIL_REPLY_CORRELATED));
        assertEquals(event.get(AvroUtil.EMAIL_SEND_AGENT_ID), newMap.get(AvroUtil.EMAIL_SEND_AGENT_ID));
        assertEquals(event.get(AvroUtil.EMAIL_SUBJECT), newMap.get(AvroUtil.EMAIL_SUBJECT));
        assertEquals(event.get(AvroUtil.EMAIL_IMPRINT_URL), newMap.get(AvroUtil.EMAIL_IMPRINT_URL));
        assertEquals(event.get(AvroUtil.EMAIL_REASON), newMap.get(AvroUtil.EMAIL_REASON));

    }

    @Test
    public void testVisit()
    {
        Map<String,String> event = new HashMap<String,String>();

        event.put(AvroUtil.VISIT_ID, AvroUtil.VISIT_ID);
        event.put(AvroUtil.VISITOR_STATE, AvroUtil.VISITOR_STATE);
        event.put(AvroUtil.VISITOR_REFFERAL_URI, AvroUtil.VISITOR_REFFERAL_URI + "value");
        event.put(AvroUtil.TRAFFIC_SOURCE_CREATIVE, AvroUtil.TRAFFIC_SOURCE_CREATIVE + "value");
        event.put(AvroUtil.TRAFFIC_SOURCE_NAME, AvroUtil.TRAFFIC_SOURCE_NAME + "value");
        event.put(AvroUtil.TRAFFIC_SOURCE_PLACEMENT, AvroUtil.TRAFFIC_SOURCE_PLACEMENT + "value");
        event.put(AvroUtil.TRAFFIC_SOURCE_TRACKING_CODE, AvroUtil.TRAFFIC_SOURCE_TRACKING_CODE + "value");
        event.put(AvroUtil.TRAFFIC_SOURCE_TYPE, AvroUtil.TRAFFIC_SOURCE_TYPE + "value");

        AvroUtil avroUtil = new AvroUtil();
        EnhancedEvent enhanceEvt = avroUtil.eventFromMap(event);

        assertNotNull(enhanceEvt);
        assertNotNull(enhanceEvt.getVisit());

        assertEquals(event.get(AvroUtil.VISIT_ID), enhanceEvt.getVisit().getVisitId());
        assertEquals(event.get(AvroUtil.VISITOR_STATE), enhanceEvt.getVisit().getVisitorState());
        assertEquals(event.get(AvroUtil.VISITOR_REFFERAL_URI), enhanceEvt.getVisit().getReferrer().getUri());
        assertEquals(event.get(AvroUtil.TRAFFIC_SOURCE_CREATIVE), enhanceEvt.getVisit().getTrafficSourceCreative());
        assertEquals(event.get(AvroUtil.TRAFFIC_SOURCE_NAME), enhanceEvt.getVisit().getTrafficSourceName());
        assertEquals(event.get(AvroUtil.TRAFFIC_SOURCE_PLACEMENT), enhanceEvt.getVisit().getTrafficSourcePlacement());
        assertEquals(event.get(AvroUtil.TRAFFIC_SOURCE_TRACKING_CODE), enhanceEvt.getVisit().getTrafficSourceTrackingCode());
        assertEquals(event.get(AvroUtil.TRAFFIC_SOURCE_TYPE), enhanceEvt.getVisit().getTrafficSourceType());

        Map<String,String> newMap = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(event.get(AvroUtil.VISIT_ID), newMap.get(AvroUtil.VISIT_ID));
        assertEquals(event.get(AvroUtil.VISITOR_STATE), newMap.get(AvroUtil.VISITOR_STATE));
        assertEquals(event.get(AvroUtil.VISITOR_REFFERAL_URI), newMap.get(AvroUtil.VISITOR_REFFERAL_URI));
        assertEquals(event.get(AvroUtil.TRAFFIC_SOURCE_CREATIVE), newMap.get(AvroUtil.TRAFFIC_SOURCE_CREATIVE));
        assertEquals(event.get(AvroUtil.TRAFFIC_SOURCE_NAME), newMap.get(AvroUtil.TRAFFIC_SOURCE_NAME));
        assertEquals(event.get(AvroUtil.TRAFFIC_SOURCE_PLACEMENT), newMap.get(AvroUtil.TRAFFIC_SOURCE_PLACEMENT));
        assertEquals(event.get(AvroUtil.TRAFFIC_SOURCE_TRACKING_CODE), newMap.get(AvroUtil.TRAFFIC_SOURCE_TRACKING_CODE));
        assertEquals(event.get(AvroUtil.TRAFFIC_SOURCE_TYPE), newMap.get(AvroUtil.TRAFFIC_SOURCE_TYPE));

    }

    @Test
    public void testDownload()
    {
        Map<String,String> event = new HashMap<String,String>();

        event.put(AvroUtil.DOCUMENT_URL, AvroUtil.DOCUMENT_URL + "value");

        AvroUtil avroUtil = new AvroUtil();
        EnhancedEvent enhanceEvt = avroUtil.eventFromMap(event);

        assertNotNull(enhanceEvt);
        assertNotNull(enhanceEvt.getDownload());

        assertEquals(event.get(AvroUtil.DOCUMENT_URL), enhanceEvt.getDownload().getUrlLink());

        Map<String,String> newMap = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(event.get(AvroUtil.DOCUMENT_URL), newMap.get(AvroUtil.DOCUMENT_URL));
    }

    @Test
    public void testJourney()
    {
        Map<String,String> event = new HashMap<String,String>();

        event.put(AvroUtil.BUSINESS_PROCESS_STEP_NAME, AvroUtil.BUSINESS_PROCESS_STEP_NAME + "value");
        event.put(AvroUtil.BUSINESS_PROCESS_STEP_ATTEMPTS, "10");
        event.put(AvroUtil.BUSINESS_PROCESS_ATTRIBUTE_1, AvroUtil.BUSINESS_PROCESS_ATTRIBUTE_1 + "value");
        event.put(AvroUtil.BUSINESS_PROCESS_ATTRIBUTE_2, AvroUtil.BUSINESS_PROCESS_ATTRIBUTE_2 + "value");

        AvroUtil avroUtil = new AvroUtil();
        EnhancedEvent enhanceEvt = avroUtil.eventFromMap(event);

        assertNotNull(enhanceEvt);
        assertNotNull(enhanceEvt.getJourney());

        assertEquals(event.get(AvroUtil.BUSINESS_PROCESS_STEP_NAME), enhanceEvt.getJourney().getStepName());
        assertEquals(new Integer(event.get(AvroUtil.BUSINESS_PROCESS_STEP_ATTEMPTS)), enhanceEvt.getJourney().getStepAttemptIndexInt());
        assertEquals(event.get(AvroUtil.BUSINESS_PROCESS_ATTRIBUTE_1), enhanceEvt.getProperties().get("attrib1"));
        assertEquals(event.get(AvroUtil.BUSINESS_PROCESS_ATTRIBUTE_2), enhanceEvt.getProperties().get("attrib2"));

        Map<String,String> newMap = avroUtil.eventFromAvro(enhanceEvt);

        assertEquals(event.get(AvroUtil.BUSINESS_PROCESS_STEP_NAME), newMap.get(AvroUtil.BUSINESS_PROCESS_STEP_NAME));
        assertEquals(event.get(AvroUtil.BUSINESS_PROCESS_STEP_ATTEMPTS), newMap.get(AvroUtil.BUSINESS_PROCESS_STEP_ATTEMPTS));
        assertEquals(event.get(AvroUtil.BUSINESS_PROCESS_ATTRIBUTE_1), newMap.get(AvroUtil.BUSINESS_PROCESS_ATTRIBUTE_1));
        assertEquals(event.get(AvroUtil.BUSINESS_PROCESS_ATTRIBUTE_2), newMap.get(AvroUtil.BUSINESS_PROCESS_ATTRIBUTE_2));
    }

    @Test
    public void testBrowser()
    {
        AvroUtil avroUtil = new AvroUtil();
        EnhancedEvent enhanceEvt;

        enhanceEvt = EnhancedEvent.newBuilder().build();
        Browser b = Browser.newBuilder().build();
        enhanceEvt.setBrowser(b);

        try
        {
            //validate that an empty browser instance doesn't cause any errors
            avroUtil.eventFromAvro(enhanceEvt);
        }
        catch(Exception ex)
        {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testSession()
    {
        AvroUtil avroUtil = new AvroUtil();
        EnhancedEvent enhanceEvt;

        enhanceEvt = EnhancedEvent.newBuilder().build();
        Session s = Session.newBuilder().build();
        enhanceEvt.setSession(s);

        try
        {
            //validate that an empty session instance doesn't cause any errors
            avroUtil.eventFromAvro(enhanceEvt);
        }
        catch(Exception ex)
        {
            fail(ex.getMessage());
        }
    }

    @Test
    public void testAvroESPEventDecoratorEventMapping()
    {

        EnhancedEvent enhanceEvt = EnhancedEvent.newBuilder().build();

        enhanceEvt.setCustomName("test"+AvroUtil.CUSTOM_EVENT_NAME);
        enhanceEvt.setCustomGroupName("test"+AvroUtil.CUSTOM_EVENT_GROUP_NAME);
        enhanceEvt.setCustomRevenueDbl(new Double("1000.0"));
        enhanceEvt.setEventDesignedId("eventDesignedId");
        enhanceEvt.setIdentityId("identityId");
        enhanceEvt.setIpAddress("eventIpAddress");
        enhanceEvt.setEventType("eventType");

        Location loc = enhanceEvt.getIpInfo();

        if(null == loc)
        {
            loc = new Location();
            enhanceEvt.setIpInfo(loc);
        }

        loc.setCity("testCityName");
        loc.setCountry("testCountryName");
        loc.setCountry("testCountryRegion");


        Browser b = enhanceEvt.getBrowser();
        if(null == b)
        {
            b = new Browser();
            enhanceEvt.setBrowser(b);
        }

        b.setUserAgent("testUserAgent");
        b.setName("browserName");
        b.setBrowserLanguage("browserLanguage");


        DeviceInfo di = enhanceEvt.getDeviceInfo();

        if(null == di)
        {
            di = new DeviceInfo();
            enhanceEvt.setDeviceInfo(di);
        }

        di.setDeviceType("deviceInfoType");
        di.setPlatform("deviceInfoPlatform");


        Visit v = enhanceEvt.getVisit();

        if(null == v)
        {
            v = new Visit();
            enhanceEvt.setVisit(v);
        }

        v.setVisitorState("testVisitorState");

        Page p = enhanceEvt.getPage();

        if(null == p)
        {
            p = new Page();
            enhanceEvt.setPage(p);
        }

        p.setPageId("pageId");

        URI uri = p.getReferrerUri();

        if(null == uri)
        {
            uri = new URI();
            p.setReferrerUri(uri);
        }

        uri.setUri("pageReferrerUri");


        Map<String,String> initialProperties = enhanceEvt.getProperties();

        if(null == initialProperties)
        {
            initialProperties = new HashMap<String,String>();
            enhanceEvt.setProperties(initialProperties);
        }


        initialProperties.put("event", "testEventType");
        initialProperties.put("referrer.social", "testRefferrerSocial");
        initialProperties.put("referrer.search", "testRefferrerSeach");

        initialProperties.put("login_event_type", "testLogonEventType");
        initialProperties.put("login_event", "testLogonEventType");

        initialProperties.put("geo.test.underscore", "testGeoUnderscore");


        AvroUtil avroUtil = new AvroUtil();

        Map<String,String> newProperties  = avroUtil.eventFromAvro(enhanceEvt);


        assertEquals(newProperties.get(AvroUtil.CUSTOM_EVENT_NAME), "test"+AvroUtil.CUSTOM_EVENT_NAME);
        assertEquals(newProperties.get(AvroUtil.CUSTOM_EVENT_GROUP_NAME), "test"+AvroUtil.CUSTOM_EVENT_GROUP_NAME);
        assertEquals(newProperties.get(AvroUtil.CUSTOM_EVENT_REVENUE_VALUE), "1000.0");

        assertEquals(newProperties.get("user_agent"), enhanceEvt.getBrowser().getUserAgent());
        assertEquals(newProperties.get("browser_name"), enhanceEvt.getBrowser().getName());
        assertEquals(newProperties.get("browser_language_name"), enhanceEvt.getBrowser().getBrowserLanguage());
        assertEquals(newProperties.get("browser_platform"), enhanceEvt.getBrowser().getBrowserPlatform());

        assertEquals(newProperties.get("browser_device_type"), enhanceEvt.getDeviceInfo().getDeviceType());

        assertEquals(newProperties.get("referrer"), enhanceEvt.getPage().getReferrerUri().getUri());
        assertEquals(newProperties.get("page_id"), enhanceEvt.getPage().getPageId());

        assertEquals(newProperties.get("visitor_state"), enhanceEvt.getVisit().getVisitorState());

        assertEquals(newProperties.get("event_uid"), enhanceEvt.getEventDesignedId());
        assertEquals(newProperties.get("vid"), enhanceEvt.getIdentityId());


        assertEquals(newProperties.get("geo_ip"), enhanceEvt.getIpAddress());
        assertEquals(newProperties.get("geo_city"), enhanceEvt.getIpInfo().getCity());
        assertEquals(newProperties.get("geo_country"), enhanceEvt.getIpInfo().getCountry());
        assertEquals(newProperties.get("geo_region"), enhanceEvt.getIpInfo().getRegion());

        assertEquals(newProperties.get("event"), enhanceEvt.getEventType());
        assertEquals(newProperties.get("referrer_social"), enhanceEvt.getProperties().get("referrer.social"));
        assertEquals(newProperties.get("referrer_search"), enhanceEvt.getProperties().get("referrer.search"));

        assertEquals(newProperties.get("geo_test_underscore"), enhanceEvt.getProperties().get("geo.test.underscore"));

    }

    @Test
    public void testAvroEventNameEventMapping()
    {
        //if we have different eventName and eventDesignedName we want to be able
        //to convert back and forth preserving both.

        EnhancedEvent enhanceEvt = EnhancedEvent.newBuilder().build();

        enhanceEvt.setEventDesignedName("testEventDesignedName");
        enhanceEvt.setEventName("testEventName");

        Map<String,String> map = AvroUtil.getInstance().eventFromAvro(enhanceEvt);

        EnhancedEvent enhancedEvent2 = AvroUtil.getInstance().eventFromMap(map);

        assertEquals("testEventDesignedName", enhancedEvent2.getEventDesignedName());
        enhanceEvt.setEventDesignedId("eventDesignedId"); //needed to carry eventName forward to eventDesignedId
        //confirm it doesn't cause a collision

        assertEquals("testEventName", enhancedEvent2.getEventName());

        enhanceEvt = EnhancedEvent.newBuilder().build();

        enhanceEvt.setEventDesignedName("testEventDesignedName");
        enhanceEvt.setEventName("testEventName");

        map = AvroUtil.getInstance().eventFromAvro(enhanceEvt);

        enhancedEvent2 = AvroUtil.getInstance().eventFromMap(map);

        assertEquals("testEventDesignedName", enhancedEvent2.getEventDesignedName());
        assertEquals("testEventName", enhancedEvent2.getEventName());
    }

    @Test
    public void testAvroEventNameEventMappingNoDesignName()
    {
        //if we have different eventName and eventDesignedName we want to be able
        //to convert back and forth preserving both.

        EnhancedEvent enhanceEvt = EnhancedEvent.newBuilder().build();

        enhanceEvt.setEventDesignedId("eventDesignedId"); //needed to carry eventName forward to eventDesignedId
        //enhanceEvt.setEventDesignedName("testEventDesignedName");
        enhanceEvt.setEventName("testEventName");

        Map<String,String> map = AvroUtil.getInstance().eventFromAvro(enhanceEvt);

        EnhancedEvent enhancedEvent2 = AvroUtil.getInstance().eventFromMap(map);

        assertEquals("testEventName", enhancedEvent2.getEventDesignedName());
        assertEquals("testEventName", enhancedEvent2.getEventName());
    }


}
