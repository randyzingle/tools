package com.sas.mkt.kafka.clients.producers;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.domain.internal.events.AthenaQueryResults;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;


public class AthenaProducer {
	
	private static final Logger logger = LoggerFactory.getLogger(FireAndForgetProducer.class);

	ApplicationConfiguration appConfig = new ApplicationConfiguration();

	public static void main(String[] args) {
		AthenaProducer app = new AthenaProducer();
		app.appConfig.setConfigServiceUrl("http://configservice-dev.cidev.sas.us:8080/");
		app.fireAndForget();
	}
	
	private void fireAndForget() {
		KafkaConnectionUtils kcu;
		try {
			kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			System.out.println(ex.toString());
			return;
		}
		String topic = "baldur-athena-results";
		String clientID = appConfig.getTierName() + "-" + appConfig.getComponentName();
		Properties props = kcu.getKafkaProducerProperties(clientID);
		Producer<String, SpecificRecordBase> producer = new KafkaProducer<>(props);
		
		AthenaQueryResults aqr = new AthenaQueryResults();
		aqr.setToken("baldur-token");
		aqr.setBucket("baldur-bucket");
		aqr.setKey("baldur-key.json");
		aqr.setStatus("SUCCESS");
		aqr.setResultsFound(1);


		ProducerRecord<String, SpecificRecordBase> record = new ProducerRecord<>(topic, aqr.getToken(), aqr);
		// note, send() actually places the message in a buffer which is read and sent by a separate thread
		producer.send(record);

		
		// give the buffer a chance to empty out
		producer.flush();
		long sleep = 2000L;
		producer.close(sleep, TimeUnit.MILLISECONDS);
	}
}
