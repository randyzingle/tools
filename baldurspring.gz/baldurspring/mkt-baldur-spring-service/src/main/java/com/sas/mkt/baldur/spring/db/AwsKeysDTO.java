package com.sas.mkt.baldur.spring.db;

public class AwsKeysDTO {
	
	public String RoleArn;
	public String AccessKeyId;
	public String SecretAccessKey;
	public String Token;
	public String Expiration;
	@Override
	public String toString() {
		return "AwsKeysDTO [RoleArn=" + RoleArn + ", AccessKeyId=" + AccessKeyId + ", SecretAccessKey="
				+ SecretAccessKey + ", Token=" + Token + ", Expiration=" + Expiration + "]";
	}
	


}
