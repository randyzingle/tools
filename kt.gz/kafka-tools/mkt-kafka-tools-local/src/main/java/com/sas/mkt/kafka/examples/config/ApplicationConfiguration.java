package com.sas.mkt.kafka.examples.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;


@Component
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false, ignoreInvalidFields=false)
public class ApplicationConfiguration extends Configuration {
	
	/**
	 * Do not change the following fields - used by the framework
	 */
	private String componentName;
	
	// passed in as environment variables in EC2 & Docker
	private String tierName;
	private String configServiceUrl;
	private String configStackName;
	
	// Console metrics
	private boolean consoleMetricsReporterActivated;
	private String consoleMetricsFilters;
	private int consoleMetricsReporterRateSec;
	
	// CloudWatch metrics
	private boolean cloudWatchMetricsReporterActivated;
	private String cloudWatchMetricFilters;
	private int cloudWatchMetricsReporterRateSec;
	
	// Logger metrics
	private boolean loggerMetricsReporterActivated;
	private String loggerMetricsFilter;
	private int loggerMetricsReporterRateSec;
	// END Do not change the following
	
	
	/**
	 * These are application specific and can be changed
	 */
	// AppSpecific Stuff
	private String testEventsTopic;
	private boolean kafkaProducerEnabled;
	private int maxRecords;
	private int consumerPollTimeoutMs;
	private int maxEmptyPolls;
	
	// S3 Connect Manager
	private boolean s3ConnectManagerEnabled; // enable overall module
	private boolean s3CreateConnectorsEnabled; // enable / disable connector creation
	private boolean s3MonitorConnectorsEnabled; // enable / disable connector monitoring and alarming
	public String getComponentName() {
		return componentName;
	}
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}
	public String getTierName() {
		return tierName;
	}
	public void setTierName(String tierName) {
		this.tierName = tierName;
	}
	public String getConfigServiceUrl() {
		return configServiceUrl;
	}
	public void setConfigServiceUrl(String configServiceUrl) {
		this.configServiceUrl = configServiceUrl;
	}
	public String getConfigStackName() {
		return configStackName;
	}
	public void setConfigStackName(String configStackName) {
		this.configStackName = configStackName;
	}
	public boolean isConsoleMetricsReporterActivated() {
		return consoleMetricsReporterActivated;
	}
	public void setConsoleMetricsReporterActivated(boolean consoleMetricsReporterActivated) {
		this.consoleMetricsReporterActivated = consoleMetricsReporterActivated;
	}
	public String getConsoleMetricsFilters() {
		return consoleMetricsFilters;
	}
	public void setConsoleMetricsFilters(String consoleMetricsFilters) {
		this.consoleMetricsFilters = consoleMetricsFilters;
	}
	public int getConsoleMetricsReporterRateSec() {
		return consoleMetricsReporterRateSec;
	}
	public void setConsoleMetricsReporterRateSec(int consoleMetricsReporterRateSec) {
		this.consoleMetricsReporterRateSec = consoleMetricsReporterRateSec;
	}
	public boolean isCloudWatchMetricsReporterActivated() {
		return cloudWatchMetricsReporterActivated;
	}
	public void setCloudWatchMetricsReporterActivated(boolean cloudWatchMetricsReporterActivated) {
		this.cloudWatchMetricsReporterActivated = cloudWatchMetricsReporterActivated;
	}
	public String getCloudWatchMetricFilters() {
		return cloudWatchMetricFilters;
	}
	public void setCloudWatchMetricFilters(String cloudWatchMetricFilters) {
		this.cloudWatchMetricFilters = cloudWatchMetricFilters;
	}
	public int getCloudWatchMetricsReporterRateSec() {
		return cloudWatchMetricsReporterRateSec;
	}
	public void setCloudWatchMetricsReporterRateSec(int cloudWatchMetricsReporterRateSec) {
		this.cloudWatchMetricsReporterRateSec = cloudWatchMetricsReporterRateSec;
	}
	public boolean isLoggerMetricsReporterActivated() {
		return loggerMetricsReporterActivated;
	}
	public void setLoggerMetricsReporterActivated(boolean loggerMetricsReporterActivated) {
		this.loggerMetricsReporterActivated = loggerMetricsReporterActivated;
	}
	public String getLoggerMetricsFilter() {
		return loggerMetricsFilter;
	}
	public void setLoggerMetricsFilter(String loggerMetricsFilter) {
		this.loggerMetricsFilter = loggerMetricsFilter;
	}
	public int getLoggerMetricsReporterRateSec() {
		return loggerMetricsReporterRateSec;
	}
	public void setLoggerMetricsReporterRateSec(int loggerMetricsReporterRateSec) {
		this.loggerMetricsReporterRateSec = loggerMetricsReporterRateSec;
	}
	public String getTestEventsTopic() {
		return testEventsTopic;
	}
	public void setTestEventsTopic(String testEventsTopic) {
		this.testEventsTopic = testEventsTopic;
	}
	public boolean isKafkaProducerEnabled() {
		return kafkaProducerEnabled;
	}
	public void setKafkaProducerEnabled(boolean kafkaProducerEnabled) {
		this.kafkaProducerEnabled = kafkaProducerEnabled;
	}
	public int getMaxRecords() {
		return maxRecords;
	}
	public void setMaxRecords(int maxRecords) {
		this.maxRecords = maxRecords;
	}
	public int getConsumerPollTimeoutMs() {
		return consumerPollTimeoutMs;
	}
	public void setConsumerPollTimeoutMs(int consumerPollTimeoutMs) {
		this.consumerPollTimeoutMs = consumerPollTimeoutMs;
	}
	public int getMaxEmptyPolls() {
		return maxEmptyPolls;
	}
	public void setMaxEmptyPolls(int maxEmptyPolls) {
		this.maxEmptyPolls = maxEmptyPolls;
	}
	public boolean isS3ConnectManagerEnabled() {
		return s3ConnectManagerEnabled;
	}
	public void setS3ConnectManagerEnabled(boolean s3ConnectManagerEnabled) {
		this.s3ConnectManagerEnabled = s3ConnectManagerEnabled;
	}
	public boolean isS3CreateConnectorsEnabled() {
		return s3CreateConnectorsEnabled;
	}
	public void setS3CreateConnectorsEnabled(boolean s3CreateConnectorsEnabled) {
		this.s3CreateConnectorsEnabled = s3CreateConnectorsEnabled;
	}
	public boolean isS3MonitorConnectorsEnabled() {
		return s3MonitorConnectorsEnabled;
	}
	public void setS3MonitorConnectorsEnabled(boolean s3MonitorConnectorsEnabled) {
		this.s3MonitorConnectorsEnabled = s3MonitorConnectorsEnabled;
	}
	@Override
	public String toString() {
		return "ApplicationConfiguration [componentName=" + componentName + ", tierName=" + tierName
				+ ", configServiceUrl=" + configServiceUrl + ", configStackName=" + configStackName
				+ ", consoleMetricsReporterActivated=" + consoleMetricsReporterActivated + ", consoleMetricsFilters="
				+ consoleMetricsFilters + ", consoleMetricsReporterRateSec=" + consoleMetricsReporterRateSec
				+ ", cloudWatchMetricsReporterActivated=" + cloudWatchMetricsReporterActivated
				+ ", cloudWatchMetricFilters=" + cloudWatchMetricFilters + ", cloudWatchMetricsReporterRateSec="
				+ cloudWatchMetricsReporterRateSec + ", loggerMetricsReporterActivated="
				+ loggerMetricsReporterActivated + ", loggerMetricsFilter=" + loggerMetricsFilter
				+ ", loggerMetricsReporterRateSec=" + loggerMetricsReporterRateSec + ", testEventsTopic="
				+ testEventsTopic + ", kafkaProducerEnabled=" + kafkaProducerEnabled + ", maxRecords=" + maxRecords
				+ ", consumerPollTimeoutMs=" + consumerPollTimeoutMs + ", maxEmptyPolls=" + maxEmptyPolls
				+ ", s3ConnectManagerEnabled=" + s3ConnectManagerEnabled + ", s3CreateConnectorsEnabled="
				+ s3CreateConnectorsEnabled + ", s3MonitorConnectorsEnabled=" + s3MonitorConnectorsEnabled + "]";
	}

}
