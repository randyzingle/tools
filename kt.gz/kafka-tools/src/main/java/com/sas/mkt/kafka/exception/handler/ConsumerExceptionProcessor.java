package com.sas.mkt.kafka.exception.handler;


import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.common.TopicPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * As noted by razing we could add a 'shadow' consumer with the same partitions and offsets that is configured
 * to read 1 message at a time from each partition (first read partition, if error then use shadow consumer to read
 * 1 at a time until the error offset is reached).  Good data can be returned (in order) at the end of the cycle.
 * Bad data could be read with a separate string consumer if desired...
 * 
 * For now just find partitions with errors and advance past the offsets.
 * 
 * Errors states should be dev only if we keep production topics clean.
 * 
 * @author fobabc
 *
 * @param <K>
 * @param <V>
 */
public class ConsumerExceptionProcessor<K,V> 
{
	private static Logger logger = LoggerFactory.getLogger(ConsumerExceptionProcessor.class);
	
	private static final int EXCEPTION_THRESHOLD = 20;

	private int partitionExecptionCount = 0;
	private int consecutiveExceptionCount = 0;
	private int consecutiveEmptyPollCount = 0;
	private boolean activeExceptionHandling = false;
	private int consecutiveExceptionThreshold = EXCEPTION_THRESHOLD;
	
	private boolean partitionError[] = null;
	private TopicPartition[] partitions = null;
	private int partitionIndex = -1;
	
	/**
	 * Set the number of consecutive exceptions to allow before switching to exception handling mode.
	 * 
	 * @param threshold
	 * @return
	 */
	public int setConsecutiveExceptionThreshold(int threshold)
	{
		this.consecutiveExceptionThreshold = threshold;
		return this.consecutiveExceptionThreshold;
	}
	
	/**
	 * Indicates there were no problems with the previous consumer poll call.  Will advance exception handling
	 * if enabled or reset the consecutive exceptions count.
	 * 
	 * @param consumer
	 * @param recordsSize
	 * @throws Exception
	 */
	public void validConsumerPoll(Consumer<K, V>  consumer, int recordsSize) throws InvalidPollException
	{
		//if we are in activeExceptionHandling then advance to the next partition
		if(activeExceptionHandling)
		{
			advanceExceptionHandling(consumer, true, recordsSize);
		}
		else
		{
			//otherwise reset consecutiveExceptionCount
			consecutiveExceptionCount = 0;
		}
	}
	
	/**
	 * Indicates an error with the previous consumer poll.  Will update the consecutive exception count or update
	 * exception handling to indicate this partition has an error.
	 * 
	 * @param consumer
	 * @return
	 * @throws Exception
	 */
	public boolean invalidConsumerPoll(Consumer<K, V>  consumer) throws InvalidPollException, InvalidPartitionAssignmentException
	{
		if(activeExceptionHandling)
		{
			//we are in the process of working past bad partitions
			//we got an exception for the current partition
			//so update the offset
			//or if we have all partitions paused we can't read so throw exception
			advanceExceptionHandling(consumer, false, 0);
			return true;
		}
		else
		{
			//increment consecutiveExceptionCount and see if we should enter 
			//activeExceptionHandling
			if(++consecutiveExceptionCount > consecutiveExceptionThreshold)
			{
				enterExceptionHandling(consumer);
				return true;
			}
			
		}
		
		return false;
	}
	
	private void enterExceptionHandling(Consumer<K, V> consumer) throws InvalidPartitionAssignmentException
	{
		logger.info("Entering exception handling.");
				
		//get the partitions
		Set<TopicPartition> assignedPartitions = consumer.assignment();
		
		if(null == assignedPartitions || assignedPartitions.size() <= 0)
		{
			//something is wrong if we don't have assigned partitions
			throw new InvalidPartitionAssignmentException("consumer assignment returned empyt or null value");
		}
		
		//pause processing
		consumer.pause(assignedPartitions);
		
		logger.info("Pausing partitions for {}", assignedPartitions.toString());
		
		//change our mode
		activeExceptionHandling = true;
		
		//begin evaluating
		partitionError = new boolean[assignedPartitions.size()];
		partitions = new TopicPartition[assignedPartitions.size()];		
		partitions = assignedPartitions.toArray(partitions);
		partitionExecptionCount = 0;
		
	}
	
	private void advanceExceptionHandling(Consumer<K, V> consumer, boolean validPoll, int recordsSize) throws InvalidPollException
	{
		//make sure our partitions assignments haven't changed
		if(!validatePartitions(consumer))
		{
			logger.error("Partitions have changed!! reseting the exception handler");
			reset(consumer);
		}
		else
		{
			if(!validPoll)
			{
				//if we don't have any unpaused partitions then throw an error
				if(partitionIndex < 0)
				{
					reset(consumer);
					
					throw new InvalidPollException("ConsumerExceptionProcessor: invalid poll with all partitions paused");
				}
				//otherwise indicate an error for this partition and update the offset
				partitionError[partitionIndex] = true;  //could be a count we maintain...
				if(partitionExecptionCount++ > 500)
					throw new InvalidPollException("ConsumerExceptionProcessor: partition exception count has exceeded 500");

				ArrayList<TopicPartition> partitionList = new ArrayList<>();
				partitionList.add(partitions[partitionIndex]);
				Map<TopicPartition, Long> endOffsets = consumer.endOffsets(partitionList);

				Long end = endOffsets.get(partitions[partitionIndex]);

				
				Long current = consumer.position(partitions[partitionIndex]);
				Long newIndex = current;

				if(current + 1 > end)
				{
					logger.info("Can not advance current index {} beyond the end {}", current, end);
				}
				else
				{
					newIndex = current+1;
				}
				
				logger.info("Error found for partition: {}  seeking past offset: {}", partitions[partitionIndex].partition(), current);
				
    			consumer.seek(partitions[partitionIndex], newIndex);
    			consumer.commitSync();
    			
    			current = consumer.position(partitions[partitionIndex]);

				logger.info("Update position for partition: {} offset: {} end offset is: {}", partitions[partitionIndex].partition(), current, end);
			}
			else
			{
				boolean advancePartitionIndex = true;
				
				if(partitionIndex >= 0)
				{
					ArrayList<TopicPartition> partitionList = new ArrayList<>();
					partitionList.add(partitions[partitionIndex]);
					
					Long current = consumer.position(partitions[partitionIndex]);
					
					if(recordsSize <= 0)
					{
						consecutiveEmptyPollCount++;
						
						//check our max to make sure there are more records
						Map<TopicPartition, Long> endOffsets = consumer.endOffsets(partitionList);
						
						Long end = endOffsets.get(partitions[partitionIndex]);
						
						if(end > current && consecutiveEmptyPollCount <= consecutiveExceptionThreshold)
						{
							advancePartitionIndex = false;
							
							logger.info("Zero records read for partition: {} current offset: {} end offset: {} attempting poll again", partitions[partitionIndex].partition(), current, end);
						}
					}
					else
						consecutiveEmptyPollCount = 0;
					
					
					if(advancePartitionIndex)
					{
						consumer.commitSync();
					
						//pause this last partition
					
						consumer.pause(partitionList);
					
						logger.info("Good read for partition: {} current offset: {} testing next partition", partitions[partitionIndex].partition(), current);
					}
				}
				
				if(advancePartitionIndex)
				{
					partitionIndex++;
					consecutiveEmptyPollCount = 0;
					partitionExecptionCount = 0;

					while(partitionIndex < partitions.length)
					{
						//get the current and end offsets to validate we can advance
						ArrayList<TopicPartition> partitionList = new ArrayList<>();
						partitionList.add(partitions[partitionIndex]);
						Map<TopicPartition, Long> endOffsets = consumer.endOffsets(partitionList);

						//make sure our current offset is less than the end
						Long end = endOffsets.get(partitions[partitionIndex]);
						Long current = consumer.position(partitions[partitionIndex]);

						if(current < end)
							break;

						//if the end is equal to the current then go to the next partitions
						partitionIndex++;
					}
				
					if(partitionIndex >= partitions.length)
					{
						//we have gone through each partition and had one poll without error			
						reset(consumer);
					}
					else
					{
						//unpause the next one
						ArrayList<TopicPartition> partitionList = new ArrayList<>();
						partitionList.add(partitions[partitionIndex]);
						consumer.resume(partitionList);
						
						Long current = consumer.position(partitions[partitionIndex]);
						logger.info("Resuming partition: {} current offset: {}", partitions[partitionIndex].partition(), current);
						
					}
				}
			}
			
		}
	}
	
	private boolean validatePartitions(Consumer<K, V>  consumer)
	{		
		//get the list of partitions from the consumer and match with what we
		//already have
		Set<TopicPartition> currentAssignment = consumer.assignment();
		
		if(null == currentAssignment)
			return false;
		
		if(this.partitions.length == currentAssignment.size())
		{
			
			for(TopicPartition tpc:currentAssignment)
			{
				boolean missing = true;
				for(TopicPartition tp:this.partitions)
				{
					if(tpc.partition() == tp.partition() && tp.topic().compareTo(tpc.topic()) == 0)
					{
						//found it
						missing = false;
						break;
					}
				}
				
				//we didn't find one so the assignment has changed
				if(missing)
				{
					logger.info("Error partition: {} not found in exception partition list.", tpc.partition());
					return false;
				}
			}

		}
		else
			return false;
		
		return true;
	}
	
	private void reset(Consumer<K, V>  consumer)
	{
		logger.info("Exiting execption handling state");
		
		consumer.commitSync();
		Set<TopicPartition> tps = consumer.assignment();
		//unpause all (presumes all topics were unpaused when we first got them..
		//ArrayList<TopicPartition> partitionList = new ArrayList<>(Arrays.asList(partitions));
		consumer.resume(tps);
		
		for(int index = 0; index < partitionError.length; index++)
		{
			if(partitionError[index])
				logger.info("Error was found for partition: {}", partitions[index].partition());
			
		}
		
		consecutiveExceptionCount = 0;
		partitionError = null;
		partitionIndex = -1;
		activeExceptionHandling = false;
		partitions = null;
		consecutiveEmptyPollCount = 0;
		partitionExecptionCount = 0;
	}
	
	public boolean getIsActiveExceptionHandling()
	{
		return activeExceptionHandling;
	}

}
