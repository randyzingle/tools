package com.sas.mkt.kafka.admin.topics.admin;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.ConsumerGroupDescription;
import org.apache.kafka.clients.admin.ConsumerGroupListing;
import org.apache.kafka.clients.admin.DescribeConsumerGroupsResult;
import org.apache.kafka.clients.admin.ListConsumerGroupOffsetsResult;
import org.apache.kafka.clients.admin.ListConsumerGroupsResult;
import org.apache.kafka.clients.admin.MemberAssignment;
import org.apache.kafka.clients.admin.MemberDescription;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.SerializationException;

import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;

public class ConsumerGroupMonitor {
	
	
	private Consumer<String, SpecificRecordBase> consumer;
	private String prefix = "dev";
	private String topicBase = "enhanced-events";
	private String topic = prefix + "-" + topicBase;
	private String consumerGroupId = "dev-mkt-eventgen";
	private ApplicationConfiguration appConfig = new ApplicationConfiguration();
	private static String configServiceURL = "http://configservice-dev.cidev.sas.us:8080/";
	
	private static Map<String, ConsumerGroupDTO> masterMap = new HashMap<>();
	private static KafkaConnectionUtils kcu;
	private static Properties props;

	public static void main(String[] args) {
		ConsumerGroupMonitor cgm = new ConsumerGroupMonitor();
		try {
			kcu = KafkaConnectionUtils.getInstance(configServiceURL);
			long startTime = System.currentTimeMillis();
			cgm.appConfig.setConsumerPollTimeoutMs(1000);
			cgm.appConfig.setMaxEmptyPolls(4);
//			cgm.doIt();
//			cgm.listcgs();
//			cgm.bigList();
//			cgm.getOne("dev-enhanced-events", "dev-mkt-eventgen");
			cgm.createMasterList();
			cgm.printForTopic("dev-publish-work");
			long endTime = System.currentTimeMillis();
			System.out.println("Total elapsed time (ms): " + (endTime - startTime));
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
	
	private void printForTopic(String topic) {

		List<ConsumerGroupDTO> groupList = new ArrayList<>();
		for (String groupId: masterMap.keySet()) {
			ConsumerGroupDTO cg = masterMap.get(groupId);
			if (cg.readsTopic(topic)) groupList.add(cg);
		}
		for (ConsumerGroupDTO cg: groupList) System.out.println(cg);
		System.out.printf("%d consumer groups are reading from %s%n", groupList.size(), topic);

	}
	
	private void createMasterList() throws Exception {
		masterMap.clear();
		
		long startTime = System.currentTimeMillis();
		Map<String, Set<Integer>> topicMap = new HashMap<>();
		HashMap<String, String> kafkaProperties = kcu.getKafkaProperties();
		props = new Properties();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.get(KafkaConnectionUtils.SAS_MKT_KAFKA_CLUSTER));
		AdminClient admin = AdminClient.create(props);
		Collection<ConsumerGroupListing> cglist = admin.listConsumerGroups().all().get();
		List<String> groupIds = cglist.stream()
				.map(group -> group.groupId())
				.collect(Collectors.toList());
		Map<String, ConsumerGroupDescription> cgmap = admin.describeConsumerGroups(groupIds).all().get();
		for (String groupId: cgmap.keySet()) {
			ConsumerGroupDescription cgd = cgmap.get(groupId);
			String state = cgd.state().toString();
			String partitionAssignor = cgd.partitionAssignor();
			Collection<MemberDescription> members = cgd.members();
			List<ConsumerDTO> consumerList = new ArrayList<>();
			for (MemberDescription member: members) { // This is a consumer
				String clientId = member.clientId();
				String consumerId = member.consumerId();
				String host = member.host().replaceAll("/", "");
				MemberAssignment assignment = member.assignment();
				topicMap.clear();
				for (TopicPartition tp: assignment.topicPartitions()) {
					String topic = tp.topic();
					int partition = tp.partition();
					if (topicMap.containsKey(topic)) {
						topicMap.get(topic).add(partition);
					} else {
						Set<Integer> pt = new HashSet<>();
						pt.add(partition);
						topicMap.put(topic, pt);
					}
				}
				for (String topic: topicMap.keySet()) {
					ConsumerDTO consumer = new ConsumerDTO(clientId, consumerId, host, topic, topicMap.get(topic).toString());
					consumerList.add(consumer);
				}
			}
			ConsumerGroupDTO consumerGroup = new ConsumerGroupDTO(groupId, state, partitionAssignor, consumerList);
			masterMap.put(groupId, consumerGroup);
		}

		admin.close();
		System.out.printf("found %d consumer groups%n", cgmap.size());
		long endTime = System.currentTimeMillis();
		System.out.println("Runtime: " + (endTime - startTime));

	}
	
	private void bigList() throws Exception {
		KafkaConnectionUtils kcu = KafkaConnectionUtils.getInstance(configServiceURL);
		long startTime = System.currentTimeMillis();
		HashMap<String, String> kafkaProperties = kcu.getKafkaProperties();
		Properties props = new Properties();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.get(KafkaConnectionUtils.SAS_MKT_KAFKA_CLUSTER));
		AdminClient admin = AdminClient.create(props);
		ListConsumerGroupsResult cglist = admin.listConsumerGroups();
		Collection<ConsumerGroupListing> list = cglist.all().get();	
		List<String> groupIds = list.stream()
				.map(group -> group.groupId())
//				.filter(id -> id.startsWith("dev-mkt-eventgen"))
				.collect(Collectors.toList());
		Map<String, ConsumerGroupDescription> cgmap = admin.describeConsumerGroups(groupIds).all().get();
		cgmap.keySet().stream()
			.map(key -> cgmap.get(key))
			.forEach(System.out::println);
		
		long endTime = System.currentTimeMillis();
		System.out.println("Runtime: " + (endTime - startTime));
	}
	
	private void listcgs() throws Exception {
		KafkaConnectionUtils kcu = KafkaConnectionUtils.getInstance(configServiceURL);
		long startTime = System.currentTimeMillis();
		HashMap<String, String> kafkaProperties = kcu.getKafkaProperties();
		Properties props = new Properties();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.get(KafkaConnectionUtils.SAS_MKT_KAFKA_CLUSTER));
		AdminClient admin = AdminClient.create(props);
		ListConsumerGroupsResult cglist = admin.listConsumerGroups();
		Collection<ConsumerGroupListing> list = cglist.all().get();	
		list.stream()
				.map(group -> group.groupId())
				//.filter(name -> name.startsWith("baldur"))
				.sorted()
				.forEach(System.out::println);
		long endTime = System.currentTimeMillis();
		System.out.println("Runtime: " + (endTime - startTime));
	}
	
	private void getOne(String topic, String groupId) throws Exception {
		KafkaConnectionUtils kcu = KafkaConnectionUtils.getInstance(configServiceURL);
		Properties cprops = kcu.getKafkaConsumerProperties();
		cprops.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
		consumer = new KafkaConsumer<>(cprops);
		Long startTime = System.currentTimeMillis();
		HashMap<String, String> kafkaProperties = kcu.getKafkaProperties();
		Properties props = new Properties();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.get(KafkaConnectionUtils.SAS_MKT_KAFKA_CLUSTER));
		AdminClient admin = AdminClient.create(props);

		DescribeConsumerGroupsResult dcgr = admin.describeConsumerGroups(Arrays.asList(groupId));
		Map<String, ConsumerGroupDescription> cgmap = dcgr.all().get();
		ConsumerGroupDescription cgd = cgmap.get(groupId);
		Collection<MemberDescription> members = cgd.members();
		
		Map<TopicPartition, LagData> lagMap = new HashMap<>();
	
		printConsumers(cgmap);
		ListConsumerGroupOffsetsResult ores = admin.listConsumerGroupOffsets(groupId);
		Map<TopicPartition, OffsetAndMetadata> metaMap = ores.partitionsToOffsetAndMetadata().get();
		Set<TopicPartition> keyset = metaMap.keySet();
		Map<TopicPartition, Long> endOffsets = consumer.endOffsets(keyset);
		Map<TopicPartition, Long> currentOffsets = convertMetaData(metaMap);
		System.out.println("groupId: " + groupId);
		
		for (TopicPartition tp: currentOffsets.keySet()) {
			LagData ld = new LagData();
			ld.consumerOffset = currentOffsets.get(tp);
			ld.endOffset = endOffsets.get(tp);
			lagMap.put(tp, ld);	
		}
		
		Map<TopicPartition, Duration> timeMap = getTimeOffsets(currentOffsets);
		long totalLag = 0;
		for (TopicPartition tp: timeMap.keySet()) {
			if (lagMap.containsKey(tp)) {
				LagData ld = lagMap.get(tp);
				ld.timeLagSec = timeMap.get(tp).getSeconds();
				long lag = ld.endOffset - ld.consumerOffset;
				totalLag += lag;
				System.out.printf("%s: consumer offset=%d, end offset=%d, lag=%d, timelag=%d(s)%n", tp.toString(), ld.consumerOffset, ld.endOffset, lag, ld.timeLagSec);
			}
		}
		System.out.println("Total lag="+totalLag);
		
		Map<MemberDescription, LagDataRollup> rollupMap = getRollup(members, lagMap);
		printMemberMap(rollupMap);

		consumer.close();
		Long endTime = System.currentTimeMillis();
		System.out.println("RUNTIME: " + (endTime - startTime));
	}
	
	private void printMemberMap(Map<MemberDescription, LagDataRollup> rollupMap) {
		for (MemberDescription member: rollupMap.keySet()) {
			String host = member.host();
			String consumerId = member.consumerId();
			LagDataRollup rollup = rollupMap.get(member);
			System.out.printf("host: %s%nconsumer: %s%ntotal-offset-lag: %d max-time-lag: %d(sec)%n", host, consumerId, rollup.offsetLag, rollup.timeLagMaxSec);	
		}
	}
	
	private Map<MemberDescription, LagDataRollup> getRollup(Collection<MemberDescription> members, Map<TopicPartition, LagData> lagMap) {
		Map<MemberDescription, LagDataRollup> map = new HashMap<>();
		for (MemberDescription member: members) {

			MemberAssignment assignment = member.assignment();
			long offsetLag = 0;
			long timeLagMax = Long.MIN_VALUE;
			LagDataRollup ldr = new LagDataRollup();
			for (TopicPartition tp: assignment.topicPartitions()) {
				if (lagMap.containsKey(tp)) {
					LagData ld = lagMap.get(tp);
					offsetLag += ld.endOffset - ld.consumerOffset;
					if(ld.timeLagSec > timeLagMax) timeLagMax = ld.timeLagSec;
				}
			}
			ldr.offsetLag = offsetLag;
			ldr.timeLagMaxSec = timeLagMax;
			map.put(member, ldr);
		}
		
		return map;
	}
	
	private void doIt() throws Exception {
		KafkaConnectionUtils kcu = KafkaConnectionUtils.getInstance(configServiceURL);
		consumer = kcu.getKafkaConsumer(topic, "offset-monitor");
		Long startTime = System.currentTimeMillis();
		HashMap<String, String> kafkaProperties = kcu.getKafkaProperties();
		Properties props = new Properties();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.get(KafkaConnectionUtils.SAS_MKT_KAFKA_CLUSTER));
		AdminClient admin = AdminClient.create(props);
		// don't need this if we have the groupId
		ListConsumerGroupsResult cglist = admin.listConsumerGroups();
		Collection<ConsumerGroupListing> list = cglist.all().get();
		for (ConsumerGroupListing cgl : list) {
			String groupId = cgl.groupId();
			if (!groupId.startsWith(consumerGroupId)) continue;
			// TODO clean this out
			consumerGroupId = groupId;
			DescribeConsumerGroupsResult dcgr = admin.describeConsumerGroups(Arrays.asList(groupId));
			Map<String, ConsumerGroupDescription> cgmap = dcgr.all().get();
			printConsumers(cgmap);
			ListConsumerGroupOffsetsResult ores = admin.listConsumerGroupOffsets(groupId);
			Map<TopicPartition, OffsetAndMetadata> gold = ores.partitionsToOffsetAndMetadata().get();
			Set<TopicPartition> keyset = gold.keySet();
			Map<TopicPartition, Long> endMap = consumer.endOffsets(keyset);
			Map<TopicPartition, Long> currentOffsets = convertMetaData(gold);
			System.out.println("groupId: " + groupId);
			printOffsets(gold, endMap);
			makeDataStructure(gold, endMap);
			Map<TopicPartition, Duration> timeMap = getTimeStampForOffet(currentOffsets);
			printTimeMap(timeMap);
		}
		consumer.close();
		Long endTime = System.currentTimeMillis();
		System.out.println("RUNTIME: " + (endTime - startTime));
	}
	
	private void printTimeMap(Map<TopicPartition, Duration> timeMap) {
		long now = System.currentTimeMillis();
		for (TopicPartition tp: timeMap.keySet()) {
			System.out.printf("partition=%s, timeLag=%d(sec)%n", tp.toString(), timeMap.get(tp).getSeconds());
		}
	}
	
	private TreeMap<TopicPartition, LagData> makeDataStructure(Map<TopicPartition,
			OffsetAndMetadata> gold, Map<TopicPartition, Long> endMap) {
		TreeMap<TopicPartition, LagData> tree = new TreeMap<>(new TopicPartitionSorter());
		
		return tree;
	}
	
	private void printConsumers(Map<String, ConsumerGroupDescription> cgmap) {
		ConsumerGroupDescription cgd = cgmap.get(consumerGroupId);
		Collection<MemberDescription> members = cgd.members();
		int count = 0;
		for (MemberDescription member: members) {
			count++;
			MemberAssignment ma = member.assignment();
			Set<TopicPartition> tp = ma.topicPartitions();
			String host = member.host();
			String clientId = member.clientId();
			System.out.printf("clientId=%s, host=%s, partitions=%s%n", clientId, host, tp);
		}
		System.out.printf("Found %d active consumers for group=%s%n", count, consumerGroupId);
	}
	

	
	private Map<TopicPartition, Long> convertMetaData(Map<TopicPartition, OffsetAndMetadata> metaData) {
		Map<TopicPartition, Long> currentOffsets = new HashMap<>();
		for (TopicPartition tp: metaData.keySet()) {
			currentOffsets.put(tp, metaData.get(tp).offset());
		}
		return currentOffsets;
	}
	
	private void printLag(Map<TopicPartition, Long> currentOffsets, Map<TopicPartition, Long> endOffsets) {
		Long totalLag = 0L;
		for (TopicPartition tp: currentOffsets.keySet()) {
			Long start = currentOffsets.get(tp);
			Long end = endOffsets.get(tp);
			Long lag = end - start;
			totalLag += lag;
			System.out.printf("%s: consumer offset=%d, end offset=%d, lag=%d%n", tp.toString(), start, end, lag);
		}
		System.out.println("total lag="+totalLag);
	}
	
	private void printOffsets(Map<TopicPartition, OffsetAndMetadata> gold, Map<TopicPartition, Long> endMap) {
		Set<TopicPartition> keyset = endMap.keySet();
		Long totalLag = 0L;
		for (TopicPartition tp: keyset) {
			OffsetAndMetadata oam = gold.get(tp);
			Long end = endMap.get(tp);
			Long lag = end-oam.offset();
			totalLag += lag;
			System.out.printf("%s: consumer offset=%d, end offset=%d, lag=%d%n", tp.toString(), oam.offset(), end, lag);
		}
		System.out.println("total lag="+totalLag);
	}
	
	private class LagData {
		long consumerOffset;
		long endOffset;
		String partition;
		long timeLagSec;
	}
	
	private class LagDataRollup {
		long offsetLag;
		long timeLagMaxSec;
	}
	
	private class TopicPartitionSorter implements Comparator<TopicPartition> {
		@Override
		public int compare(TopicPartition o1, TopicPartition o2) {
			return o1.toString().compareTo(o2.toString());
		}	
	}
	
	private Map<TopicPartition, Duration> getTimeOffsets(Map<TopicPartition, Long> currentOffsets) {
		long now = System.currentTimeMillis();
		Map<TopicPartition, Duration> timeMap = new HashMap<>();

		Consumer<String, ?> activeConsumer = consumer;
		activeConsumer.unsubscribe();
		List<TopicPartition> activeList = new ArrayList<>();
		Map<TopicPartition, Long> endOffsets = activeConsumer.endOffsets(currentOffsets.keySet());
		Map<TopicPartition, Long> startOffsets = activeConsumer.beginningOffsets(currentOffsets.keySet());
		for (TopicPartition key: currentOffsets.keySet()) {
			long diff = endOffsets.get(key) - startOffsets.get(key);
			if (diff > 0) activeList.add(key);
		}
		activeConsumer.assign(activeList);
		
		for (TopicPartition tp: activeList) {
			activeConsumer.seek(tp, currentOffsets.get(tp));
			boolean done = false;
			int emptyPolls = 0;
			while (!done) {
				ConsumerRecords<String, ?> records = null;
				try {
					records = activeConsumer.poll(Duration.ofMillis(appConfig.getConsumerPollTimeoutMs()));
					if (records.isEmpty()) {
						emptyPolls++;
					} else {
						emptyPolls = 0;
					}
					if (emptyPolls > appConfig.getMaxEmptyPolls()) {
						System.out.println("Start Time: Too many empty loops, timing out....");
						done = true;
						break;
					}
					for (ConsumerRecord<String, ?> record : records) {
						long time = Math.max(0, now - record.timestamp());
						timeMap.put(tp, Duration.ofMillis(time));
						done = true;
						break;
					}
				} catch (SerializationException serex) {
					done = true;
				}	
			}
		}
		
		activeConsumer.unsubscribe();	
		return timeMap;
	}
	
	private Map<TopicPartition, Duration> getTimeStampForOffet(Map<TopicPartition, Long> currentOffsets) {
		Map<TopicPartition, Duration> timeMap = new HashMap<>();
		Map<TopicPartition, Long> startTime = new HashMap<>();
		Map<TopicPartition, Long> endTime = new HashMap<>();
		Consumer<String, ?> activeConsumer = consumer;
		activeConsumer.unsubscribe();
		List<TopicPartition> activeList = new ArrayList<>();
		Map<TopicPartition, Long> endOffsets = activeConsumer.endOffsets(currentOffsets.keySet());
		Map<TopicPartition, Long> startOffsets = activeConsumer.beginningOffsets(currentOffsets.keySet());
		for (TopicPartition key: currentOffsets.keySet()) {
			long diff = endOffsets.get(key) - startOffsets.get(key);
			if (diff > 0) activeList.add(key);
		}
		activeConsumer.assign(activeList);

		// get start times
		for (TopicPartition tp: activeList) {
			activeConsumer.seek(tp, currentOffsets.get(tp));
		}
		Set<TopicPartition> doneList = new HashSet<>(timeMap.size());
		boolean done = false;
		int emptyPolls = 0;
		while (!done) {
			ConsumerRecords<String, ?> records = null;
			try {
				records = activeConsumer.poll(Duration.ofMillis(appConfig.getConsumerPollTimeoutMs()));
				if (records.isEmpty()) {
					emptyPolls++;
				} else {
					emptyPolls = 0;
				}
				if (emptyPolls > appConfig.getMaxEmptyPolls()) {
					System.out.println("Start Time: Too many empty loops, timing out....");
					done = true;
					break;
				}
				for (ConsumerRecord<String, ?> record : records) {
					TopicPartition tp = new TopicPartition(record.topic(), record.partition());
					if(doneList.contains(tp)) continue;
					startTime.put(tp, record.timestamp());
					doneList.add(tp);
					if (doneList.size() == activeList.size()) {
						System.out.println("Found current timestamps for all active partitions....");
						done = true;
						break;
					} 
				}
			} catch (SerializationException serex) {
				done = true;
			}	
		}
		// get end times
		for (TopicPartition tp: activeList) {
			long offset = endOffsets.get(tp) - 1;
			activeConsumer.seek(tp, offset);
		}
		doneList = new HashSet<>(timeMap.size());
		done = false;
		emptyPolls = 0;
		while (!done) {
			ConsumerRecords<String, ?> records = null;
			try {
				records = activeConsumer.poll(Duration.ofMillis(appConfig.getConsumerPollTimeoutMs()));
				if (records.isEmpty()) {
					emptyPolls++;
				} else {
					emptyPolls = 0;
				}
				if (emptyPolls > appConfig.getMaxEmptyPolls()) {
					System.out.println("End Time: Too many empty loops, timing out....");
					done = true;
					break;
				}
				for (ConsumerRecord<String, ?> record : records) {
					TopicPartition tp = new TopicPartition(record.topic(), record.partition());
					if(doneList.contains(tp)) continue;
					endTime.put(tp, record.timestamp());
					doneList.add(tp);
					if (doneList.size() == activeList.size()) {
						System.out.println("Found end timestamps for all active partitions....");
						done = true;
						break;
					} 
				}
			} catch (SerializationException serex) {
				done = true;
			}	
		}
		activeConsumer.unsubscribe();	
		for (TopicPartition tp: activeList) {
			if (endTime.containsKey(tp) && startTime.containsKey(tp)) {
				timeMap.put(tp, Duration.ofMillis(endTime.get(tp) - startTime.get(tp)));
			} else {
				if (!endTime.containsKey(tp)) System.out.println("Don't have endTime for " + tp);
				if (!startTime.containsKey(tp)) System.out.println("Don't have startTime for " + tp);
			}
		}
		return timeMap;
	}

}
