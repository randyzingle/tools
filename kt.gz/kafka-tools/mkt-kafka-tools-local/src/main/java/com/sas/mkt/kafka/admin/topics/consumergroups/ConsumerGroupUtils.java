package com.sas.mkt.kafka.admin.topics.consumergroups;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.Node;
import org.apache.kafka.common.TopicPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;

import kafka.admin.AdminClient;
import kafka.coordinator.group.GroupOverview;
import scala.collection.JavaConversions;

public class ConsumerGroupUtils {
	
	private static final Logger logger = LoggerFactory.getLogger(ConsumerGroupUtils.class);
	// refresh list of topic-consumer groups if it's older than an hour - it takes a little over a minute to generate
	private static final long updateInfoFrequencyMs = 1000 * 60 * 60; 
	private AdminClient adminClient;
	private Map<String, List<ConsumerGroupDTO>> topicConsumerGroupMap;
	private long lastUpdate = 0L;
	
	public static void main(String[] args) {
		ConsumerGroupUtils cgu = new ConsumerGroupUtils();
		cgu.init(new ApplicationConfiguration());
		List<ConsumerGroupDTO> cglist = cgu.getConsumerGroupListForTopic("baldur-test-events");
		System.out.println(cglist);
		cgu.destroy();

	}
	
	public void init(ApplicationConfiguration appConfig) {
		// Setup the AdminClient
		try {
			logger.debug("attempting to create the AdminClient...");
    		KafkaConnectionUtils kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
    		Properties props = kcu.getKafkaConsumerProperties();
    		String brokerUrlList = (String)props.get(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG);
    		adminClient = AdminClient.createSimplePlaintext(brokerUrlList);	
    	} catch (Exception ex) {
    		logger.error("failed to create the AdminClient..." + ex.getMessage());
    	}
		
	}
	
	public void destroy() {
		logger.debug("closing the AdminClient...");
		adminClient.close();
	}
	
    public Collection<Node> findAllBrokers() {
    	Collection<Node> nodeList = JavaConversions.asJavaCollection(adminClient.findAllBrokers());
    	for (Node node: nodeList) {
    		System.out.println(node);
    	}
    	return nodeList;
    }
    
    public List<ConsumerGroupDTO> getConsumerGroupListForTopic(String topic) {
    	long timeSinceLastUpdate = System.currentTimeMillis() - lastUpdate;
    	if (topicConsumerGroupMap == null || timeSinceLastUpdate  > updateInfoFrequencyMs) {
    		System.out.println("updating map...");
    		topicConsumerGroupMap = getConsumerGroupsPerTopic();
    	}
    	return topicConsumerGroupMap.get(topic);
    }
    
    public Map<String, List<ConsumerGroupDTO>> getConsumerGroupsPerTopic() {
    	topicConsumerGroupMap = new HashMap<>();
    	Collection<GroupOverview> groupList = listAllConsumerGroups();
    	for (GroupOverview group: groupList) {
    		AdminClient.ConsumerGroupSummary summary = adminClient.describeConsumerGroup(group.groupId(), 0);
    		Collection<AdminClient.ConsumerSummary> consumers = JavaConversions.asJavaCollection(summary.consumers().get());
    		List<ConsumerDTO> consumerList = new ArrayList<>(consumers.size());
    		ConsumerGroupDTO cgi = new ConsumerGroupDTO();
    		for (AdminClient.ConsumerSummary cs: consumers) {
    			ConsumerDTO consumer = new ConsumerDTO();
    			consumer.assignment = JavaConversions.asJavaCollection(cs.assignment());
    			consumer.clientId = cs.clientId();
    			consumer.consumerId = cs.consumerId();
    			consumer.host = cs.host().replaceAll("/", "");
    			consumerList.add(consumer);
    			// loop through topic partitions to determine topic subscription
    			for (TopicPartition tp: consumer.assignment) {
    				String topic = tp.topic();
    				if (topicConsumerGroupMap.containsKey(topic)) {
    					List<ConsumerGroupDTO> cglist = topicConsumerGroupMap.get(topic);
    					if (!cglist.contains(cgi)) {
    						cglist.add(cgi);
    					}
    				} else {
    					List<ConsumerGroupDTO> cglist = new ArrayList<>();
    					cglist.add(cgi);
    					topicConsumerGroupMap.put(topic, cglist);
    				}
    			}
    		}   		
    		cgi.groupId = group.groupId();
    		cgi.protocolType = group.protocolType();
    		cgi.assignmentStrategy = summary.assignmentStrategy();
    		cgi.coordinator = summary.coordinator().toString();
    		cgi.state = summary.state();
    		cgi.consumers = consumerList;
    	}
    	lastUpdate = System.currentTimeMillis();
    	return topicConsumerGroupMap;
    }
	
    /**
     * top level consumer group data: GroupOverview. Contains the groupId (name) and protocolType (typically = consumer)
     * @return Collection<GroupOverview>
     */
    public Collection<GroupOverview> listAllConsumerGroups() {
    	Collection<GroupOverview> consumerGroupList = JavaConversions.asJavaCollection(adminClient.listAllConsumerGroupsFlattened());
    	return consumerGroupList;
    }
    
    /**
     * Consumer group details. Get using groupId of GroupOverview. Contains list of Consumers that belong to the group
     * @param groupId
     * @param timeoutMs
     * @return AdminClient.ConsumerGroupSummary
     */
    public AdminClient.ConsumerGroupSummary getConsumerGroupSummary(String groupId, Long timeoutMs) {
    	AdminClient.ConsumerGroupSummary cgSummary = null;
    	cgSummary = adminClient.describeConsumerGroup(groupId, timeoutMs);
    	return cgSummary;
    }
    
    /**
     * Given a ConsumerSummary return the list of Consumers
     * @param consumerGroup
     * @return Collection<AdminClient.ConsumerSummary>
     */
    public Collection<AdminClient.ConsumerSummary> getConsumersForGroup(AdminClient.ConsumerGroupSummary consumerGroup) {
    	Collection<AdminClient.ConsumerSummary> consumers = JavaConversions.asJavaCollection(consumerGroup.consumers().get());
    	return consumers;
    }
	
	public class ConsumerGroupDTO {
		// from GroupOverview
		private String groupId;
		private String protocolType;
		// from ConsumerGroupSummary
		private String assignmentStrategy;
		private List<ConsumerDTO> consumers;
		private String coordinator; // Node = host, port, id
		private String state;
		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("ConsumerGroupInfo [groupId=").append(groupId).append(", protocolType=").append(protocolType)
					.append(", assignmentStrategy=").append(assignmentStrategy).append(", consumers=").append(consumers)
					.append(", coordinator=").append(coordinator).append(", state=").append(state).append("]");
			return builder.toString();
		}
	}
	
	public class ConsumerDTO {
		// from ConsumerSummary
		private Collection<TopicPartition> assignment;
		private String clientId;
		private String consumerId;
		private String host;
		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("ConsumerInfo [assignment=").append(assignment).append(", clientId=").append(clientId)
					.append(", consumerId=").append(consumerId).append(", host=").append(host).append("]");
			return builder.toString();
		}
	}

}
