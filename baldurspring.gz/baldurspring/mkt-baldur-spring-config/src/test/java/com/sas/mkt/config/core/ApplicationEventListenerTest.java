package com.sas.mkt.config.core;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.mockito.Mock;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.ContextRefreshedEvent;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.appspecific.GlobalConfiguration;

public class ApplicationEventListenerTest {
	

	ApplicationConfiguration appConfig = new ApplicationConfiguration();
	GlobalConfiguration globalConfig = new GlobalConfiguration();
	
	ApplicationEventListener applicationEventListener = new ApplicationEventListener(appConfig, globalConfig);
	
	@Mock
	ContextRefreshedEvent cre;
	
	@Mock
	ApplicationReadyEvent are;

	@Test
	public void testHandleContextRefresh() {
		applicationEventListener.handleContextRefresh(cre);
//		assertTrue(true);
	}
	
	@Test
	public void handleApplicationReady() {
		applicationEventListener.handleApplicationReady(are);
//		assertTrue(true);
	}

}
