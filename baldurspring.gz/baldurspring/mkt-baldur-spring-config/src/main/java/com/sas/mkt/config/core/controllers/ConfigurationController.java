package com.sas.mkt.config.core.controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.core.BaseUtils;
import com.sas.mkt.config.core.ConfigUtils;
import com.sas.mkt.config.core.PropertyDetails;
import com.sas.mkt.config.core.PropertyMap;
import com.sas.mkt.config.core.configserver.ConfigProperty;
import com.sas.mkt.config.core.configserver.ConfigServerClient;
import com.sas.mkt.config.core.controllers.ConfigurationController.LoggerLevelInfo;
import com.sas.mkt.config.core.events.ApplicationConfigurationEvent;
import com.sas.mkt.config.core.startup.ConfigServiceHelper;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.LoggerContext;

/**
 * @author razing
 *
 */
@RestController
@RequestMapping("/config")
public class ConfigurationController {

	private final static Logger logger = LoggerFactory.getLogger(ConfigurationController.class);
	private final static String LOG_LEVEL_OVERRIDE = "logLevelOverride";
	
	private List<String> configList = Arrays.asList(
			LOG_LEVEL_OVERRIDE
		);

	ApplicationConfiguration appConfig;
	ConfigServerClient client;
	ConfigUtils configUtils;
	ConfigServiceHelper configServiceHelper;
	PropertyMap propertyMap;
	@Autowired
	public ConfigurationController(ApplicationConfiguration appConfig, ConfigServerClient client, ConfigUtils configUtils,
			ConfigServiceHelper configServiceHelper, PropertyMap propertyMap) {
		this.appConfig = appConfig;
		this.client = client;
		this.configUtils = configUtils;
		this.configServiceHelper = configServiceHelper;
		this.propertyMap = propertyMap;
	}

	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/appconf", method = RequestMethod.GET)
	public String appconf() {
		return appConfig.toString();
	}

	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/props", method = RequestMethod.GET)
	public String props() {
		configServiceHelper.refreshProperties();
		return getPropertySources();
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/logs", method = RequestMethod.GET)
	public String getLogLevels() {
		return getLoggerInfo();
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/logs", method = RequestMethod.POST)
	public ResponseEntity<LoggerLevelInfo> modifyLogLevels(@RequestBody LoggerLevelInfo data) {
		ResponseEntity<LoggerLevelInfo> responseEntity = null;
		logger.info("modifying log level: {}", data.toString());
		boolean levelSet = setLoggerLevel(data);
		if (levelSet) {
			responseEntity = new ResponseEntity<>(data, null, HttpStatus.ACCEPTED);
		} else {
			responseEntity = new ResponseEntity<>(data, null, HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public ResponseEntity<PropTuple> edit(@RequestBody PropTuple data) {
		logger.info("editing configuration server parameter: {}", data.toString());
		ResponseEntity<PropTuple> responseEntity = null;
		try {
			ConfigProperty cp = new ConfigProperty(data.tier, data.component, data.name, data.value);
			if(data.id == null || data.id.trim().equals("")) {
				// this is new to the config server, will get an ID
				cp = client.createProperty(cp);		
				data.id = cp.id;
				logger.info("configuration server parameter saved: {}", cp.toString());
			} else {
				// we are updating an existing value in the config server
				cp.id = data.id;
				client.updateProperty(cp);
			} 
			responseEntity = new ResponseEntity<>(data, null, HttpStatus.ACCEPTED);
		} catch (RestClientException rce) {
			// need to let the caller know we failed
			HttpHeaders headers = new HttpHeaders();
			headers.add("Failure", rce.getMessage());
			responseEntity = new ResponseEntity<>(null, headers, HttpStatus.BAD_REQUEST);
			logger.warn(rce.getMessage());
		}
		// update this based on response above
		return responseEntity;
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public ResponseEntity<PropTuple> delete(@RequestBody PropTuple data) {
		logger.info("deleting configuration server parameter: {}", data.toString());
		PropTuple pt = new PropTuple();
		ResponseEntity<PropTuple> responseEntity = null;
		try {
			ConfigProperty cp = new ConfigProperty(data.tier, data.component, data.name, data.value);
			cp.id = data.id;
			client.deleteProperty(cp);
			String nname = ConfigUtils.normalizeName(cp.name);
			PropertyDetails pd = appConfig.originalProperties.get(nname);
			if (pd != null) {
				pt.component = pd.getComponentNm();
				pt.id = pd.getId();
				pt.name = pd.getName();
				pt.source = pd.getPropertySourceName();
				pt.tier = pd.getTierNm();
				pt.value = pd.getValue();
			}
		} catch (RestClientException rce) {
			// need to let the caller know we failed
			HttpHeaders headers = new HttpHeaders();
			headers.add("Failure", rce.getMessage());
			responseEntity = new ResponseEntity<>(pt, headers, HttpStatus.BAD_REQUEST);
			logger.warn(rce.getMessage());
			return responseEntity;
		}
		// update this based on response above
		return new ResponseEntity<>(pt, null, HttpStatus.ACCEPTED);
	}
	
	protected void spewLogLevel(Logger logger) {
		// we want this block displayed no matter what the log level is
		String message = "";
		message = "error is enabled: " + logger.isErrorEnabled();
		System.out.println(message);
		message = "warn is enabled: " + logger.isWarnEnabled();
		System.out.println(message);
		message = "info is enabled: " + logger.isInfoEnabled();
		System.out.println(message);
		message = "debug is enabled: " + logger.isDebugEnabled();
		System.out.println(message);
		message = "trace is enabled: " + logger.isTraceEnabled();
		System.out.println(message);
		// check the log level functionality
		logger.trace("This is a trace message");
        logger.debug("This is a debug message");
        logger.info("This is an info message");
        logger.warn("This is a warn message");
        logger.error("This is an error message");
	}
	
	private boolean setLoggerLevel(LoggerLevelInfo info) {
		String update = String.format("%s=%s", info.name, info.level);
		ConfigProperty cp = new ConfigProperty(appConfig.tierName, appConfig.componentName, LOG_LEVEL_OVERRIDE, update);
		try {
			ConfigProperty checkExists = client.getProperty(cp);
			client.updateProperty(cp);
		} catch (RestClientException ex) {
			client.createProperty(cp);
		}
		return true;
	}
	
    @EventListener
    public void handleApplicationConfigurationChanged(ApplicationConfigurationEvent ace) {
    	System.out.println("Config change notice in LogManager");
        logger.debug("application configuration changed: {}", ace.getOverrideList().toString());
        for (PropertyDetails pd: ace.getOverrideList()) {
        	if (configList.contains(pd.getName())) {
        		System.out.println("Config change in LogManager ... changing log levels");
        		String update = pd.getValue();
        		if (update != null && update.contains("=")) {
        			String[] level = update.split("=");
        			if (level.length == 2) {
	        			LoggerLevelInfo info = new LoggerLevelInfo(level[0], level[1]);
	            		setLocalLoggerLevel(info);
        			}
        		}	
        	}
        }
    }
	
	private void setLocalLoggerLevel(LoggerLevelInfo info) {
		LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory();
		ch.qos.logback.classic.Logger logger = lc.exists(info.name);
		if (logger != null) {
			String level = info.level;
			if (level != null) {
				level = level.trim();
				if (level.equals("ERROR")) {
					logger.setLevel(Level.ERROR);
				} else if (level.equals("WARN")) {
					logger.setLevel(Level.WARN);
				} else if (level.equals("INFO")) {
					logger.setLevel(Level.INFO);
				} else if (level.equals("DEBUG")) {
					logger.setLevel(Level.DEBUG);
				} else if (level.equals("TRACE")) {
					logger.setLevel(Level.TRACE);
				}
			}
			spewLogLevel(logger);
		}
	}
	
	protected String getLoggerInfo() {
		String s = "";
		LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory();
	    List<ch.qos.logback.classic.Logger> llist = lc.getLoggerList();
	    ArrayList<LoggerLevelInfo> baseList = new ArrayList<>();
	    for (ch.qos.logback.classic.Logger logger: llist) {
		    	if (logger.getLevel() != null) {
		    		logger.debug(logger.getName() + ": " + logger.getEffectiveLevel() + " - " + logger.getLevel());
		    		baseList.add(new LoggerLevelInfo(logger.getName(), logger.getLevel().toString()));
		    	}
		}
	    ObjectMapper mapper = new ObjectMapper();
		try {
			s = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(baseList);
		} catch (JsonProcessingException e) {
			logger.error(e.getMessage());
		}
		logger.debug(s);
		return s;
	}
	
	protected String getPropertySources() {
		String s = "";
		TreeMap<String, PropertyDetails> applicationMap = propertyMap.propertyMap.get(PropertyMap.APPLICATION);
		SubDisplayConfig app = getSubDisplayConfig("Application-Specific Configuration", applicationMap);
		TreeMap<String, PropertyDetails> globalMap = propertyMap.propertyMap.get(PropertyMap.GLOBAL);
		SubDisplayConfig global = getSubDisplayConfig("Tier-Global Configuration", globalMap);
		FullDisplayConfig fdc = new FullDisplayConfig();
		fdc.application = app;
		fdc.global = global;
		fdc.component = appConfig.componentName;

		ObjectMapper mapper = new ObjectMapper();
		try {
			s = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(fdc);
		} catch (JsonProcessingException e) {
			logger.error(e.getMessage());
		}
		logger.debug(s);
		return s;
	}

	protected SubDisplayConfig getSubDisplayConfig(String title, TreeMap<String, PropertyDetails> map) {
		SubDisplayConfig sdc = new SubDisplayConfig();
		sdc.title = title;
		List<PropTuple> plist = new ArrayList<>();
		for (Map.Entry<String, PropertyDetails> entry : map.entrySet()) {
			PropertyDetails pd = entry.getValue();
			// For multi-subproject builds, only include things that are in this subproject's application.properties file in the display
			if (pd.getPropertySourceName() == null || pd.getPropertySourceName().trim().equals("")) continue;
			String type = getTypeString(pd);
			PropTuple pt = new PropTuple(pd.getName(), pd.getValue(), pd.getId(), pd.getPropertySourceName(), pd.getComponentNm(), pd.getTierNm(), type);
			plist.add(pt);
		}
		sdc.items = plist;
		return sdc;
	}
	
	protected String getTypeString(PropertyDetails pd) {
		String type = pd.getType().getName();
		if (type.equals(String.class.getName())) {
			type = "string";
		} else if (type.equals(Boolean.class.getName()) || type.equals("boolean")) {
			type = "boolean";
		} else if (type.equals(Byte.class.getName()) || type.equals("byte")) {
			type = "string";
		} else if (type.equals(Double.class.getName()) || type.equals("double")) {
			type = "float";
		} else if (type.equals(Float.class.getName()) || type.equals("float")) {
			type = "float";
		} else if (type.equals(Integer.class.getName()) || type.equals("int")) {
			type = "int";
		} else if (type.equals(Long.class.getName()) || type.equals("long")) {
			type = "int";
		} else if (type.equals(Short.class.getName()) || type.equals("short")) {
			type = "int";
		}
		return type;
	}
	
	static protected class LoggerLevelInfo {
		public String name;
		public String level;
		
		public LoggerLevelInfo() {}
		
		LoggerLevelInfo(String name, String level) {
			this.name = name;
			this.level = level;
		}

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("LoggerLevelInfo [name=").append(name).append(", level=").append(level).append("]");
			return builder.toString();
		}

	}

	static protected class PropTuple {
		public String name;
		public String value;
		public String id;
		public String source;
		public String component;
		public String tier;
		public String type;
		
		public PropTuple() {}

		PropTuple(String name, String value, String id, String source, String component, String tier, String type) {
			this.name = name;
			this.value = value;
			this.id = id;
			this.source = source;
			this.component = component;
			this.tier = tier;
			this.type = type;
		}

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("PropTuple [name=").append(name).append(", value=").append(value).append(", id=").append(id)
					.append(", source=").append(source).append(", component=").append(component).append(", tier=")
					.append(tier).append(", type=").append(type).append("]");
			return builder.toString();
		}
	
	}
	
	static private class SubDisplayConfig {
		private String title;
		private List<PropTuple> items = new ArrayList<>();

		public String getTitle() {
			return this.title;
		}

		public List<PropTuple> getItems() {
			return this.items;
		}

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("SubDisplayConfig [title=").append(title).append(", items=").append(items).append("]");
			return builder.toString();
		}
		
	}

	static private class FullDisplayConfig {
		private String component;
		private SubDisplayConfig application;
		private SubDisplayConfig global;

		public String getComponent() {
			return this.component;
		}

		public SubDisplayConfig getApplication() {
			return this.application;
		}

		public SubDisplayConfig getGlobal() {
			return global;
		}

		@Override
		public String toString() {
			StringBuilder builder = new StringBuilder();
			builder.append("FullDisplayConfig [component=").append(component).append(", application=")
					.append(application).append(", global=").append(global).append("]");
			return builder.toString();
		}
	}
}