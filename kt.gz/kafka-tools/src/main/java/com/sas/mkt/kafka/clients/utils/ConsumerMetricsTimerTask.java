package com.sas.mkt.kafka.clients.utils;

import java.util.*;

import com.amazonaws.services.cloudwatch.model.Dimension;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.common.Metric;
import org.apache.kafka.common.MetricName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SuppressWarnings("rawtypes")
public class ConsumerMetricsTimerTask extends TimerTask {
	private static Logger logger = LoggerFactory.getLogger(ConsumerMetricsTimerTask.class);
	public static final String RECORDS_LAG_MAX = "records-lag-max";
	public static final String RECORDS_CONSUMED_RATE = "records-consumed-rate";
	
    private static final String METRIC_MAX_LAGS = "max_lags";
    private static final String METRIC_LAG_DELTA = "lag_delta";
    private static final String METRIC_CONSUMED_RATE = "consumed_rate";
	
	private Consumer consumer = null;
	private String dimensionName = null;
	private String dimensionValue = null;

	private double previousMaxLag;
	private boolean initialized = false;
	
	/**
	 * @deprecated Sprint 2104 - use KafkaGauges registryConsumerMetricsAsGauges(Consumer<String, SpecificRecordBase> consumer)
	 */
	public ConsumerMetricsTimerTask(Consumer consumer, String dimensionName, String dimensionValue) {
		this.consumer = consumer;
		this.dimensionName = dimensionName;
		this.dimensionValue = dimensionValue;
		this.previousMaxLag = 0;
	}
	
	@Override
	public void run() {
		try
		{
			readConsumerMetrics();
		}
		catch(Exception ex)
		{
			logger.error("Exception reading consumer metrics: " + ex.getMessage());
		}
		catch(Error er)
		{
			logger.error("Error reading consumer metrics: " + er.getMessage());
		}
	}

	/**
	 * Reading records-lag-max metric for the consumer group within the time window
	 *  
	 * records-lag-max: The maximum lag in terms of number of records for any partition in this window. 
	 * An increasing value over time is your best indication that the consumer group is not keeping up 
	 * with the producers.
     *
	 */
	@SuppressWarnings("unchecked")
	private void readConsumerMetrics() {
		if (logger.isDebugEnabled()) {
			logger.debug("Reading metrics from consumer...");
		}
		
		Map<String, Double> awsMetrics = new HashMap<String, Double>();
		Map<String, Collection<Dimension>> dimensionMap = new HashMap<>();
		Dimension groupDimension = new Dimension();
		groupDimension.setName( this.dimensionName );
		groupDimension.setValue( this.dimensionValue );
		String clientId="";

		synchronized (consumer) {
			Map<MetricName, ? extends Metric> metrics = consumer.metrics();
			if (metrics != null && metrics.size() > 0) {
				for (MetricName mName:metrics.keySet()) {
					Metric metric = metrics.get(mName);
					String name = mName.name();
					
					Object test = metric.metricValue();
					if (!(test instanceof Double)) {
						continue;
					}
					Double dvalue = (Double)test;
					if (dvalue.isNaN()) continue;
					double value = dvalue.doubleValue();
                    Collection<Dimension> dimensions = new ArrayList<>();
                    dimensions.add( groupDimension );
					
					if (name != null && name.equals(RECORDS_LAG_MAX)) {
						if (mName.tags().get("partition")!=null) {
							continue;  // we only want the consumer-wide max lag, not the lag for each partition.
						}
						clientId=mName.tags().get("client-id");
						if (logger.isDebugEnabled()) { 
							logger.debug(mName.tags().get("client-id") + " " + RECORDS_LAG_MAX +": " + value);
						}
						// filter out -Infinity which means no records returned from any partitions in latest poll
						boolean noRecords = false;
						if (value < 0)
						{
							value = 0;
							noRecords = true;
						}
						awsMetrics.put(METRIC_MAX_LAGS, value);
                        dimensionMap.put(METRIC_MAX_LAGS, dimensions);

                        // Avoid setting an incorrectly large delta due to previousMaxLag set to 0 when this timer was
						// first initialized, or when no records were returned from any partitions in the latest poll
                        if ( this.initialized )
						{
							awsMetrics.put( METRIC_LAG_DELTA, value - this.previousMaxLag );
							dimensionMap.put( METRIC_LAG_DELTA, dimensions );
						}

						// Only set the previousMaxLag if the latest poll returned some records
						if ( !noRecords )
						{
							this.previousMaxLag = value;
							this.initialized = true;
						}
					}
					
					if (name != null && name.equals(RECORDS_CONSUMED_RATE)) {
						if (mName.tags().get("topic")!=null) {
							continue;  // we only want the consumer-wide rate, not the rate for each topic.
						}
						if (logger.isDebugEnabled()) { 
							logger.debug(mName.tags().get("client-id") + " " + RECORDS_CONSUMED_RATE +": " + value);
						}
						// filter out -Infinity which means no records returned from any partitions in latest poll
						if (value < 0)
							value = 0;
						awsMetrics.put(METRIC_CONSUMED_RATE, value);
						dimensionMap.put( METRIC_CONSUMED_RATE, dimensions );
					}
				}
			}
		}
		
		// upload the metrics to AWS Cloudwatch
		CloudWatchMetricPublisher.publishKafkaMetrics( dimensionMap, awsMetrics);
	}
}
