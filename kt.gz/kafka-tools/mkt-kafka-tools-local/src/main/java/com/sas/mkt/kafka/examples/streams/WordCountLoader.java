package com.sas.mkt.kafka.examples.streams;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;

public class WordCountLoader {
	private static final Logger logger = LoggerFactory.getLogger(WordCountLoader.class);
	
	private String file = "Source/resources/books/huckfinn.txt";
	private String huck = "huckfinn";
	private String topic = "test-wordcount-in";

	public static void main(String[] args) {
		WordCountLoader wl = new WordCountLoader();
		try {
			wl.run();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	private void run() throws Exception {
		KafkaConnectionUtils kcu;
		try {
			String configServiceURL = "http://configservice-dev.cidev.sas.us:8080/";
			kcu = KafkaConnectionUtils.getInstance(configServiceURL);
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			return;
		}
		Properties props = kcu.getKafkaProducerProperties(huck);
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
				org.apache.kafka.common.serialization.StringSerializer.class);
		Producer<String, String> producer = new KafkaProducer<String, String>(props);

		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		String line = null;
		
		while ( (line = br.readLine()) != null) {
			ProducerRecord<String, String> record = new ProducerRecord<String, String>(topic, huck, line);
			producer.send(record);
			System.out.println(line);
		}
		
		try {Thread.sleep(3000);} catch (Exception ex) {ex.printStackTrace();}
		producer.close();
		fr.close();
	}

}
