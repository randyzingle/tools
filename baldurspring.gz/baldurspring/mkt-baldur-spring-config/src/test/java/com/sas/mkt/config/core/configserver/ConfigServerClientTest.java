package com.sas.mkt.config.core.configserver;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.web.client.RestClientException;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;


public class ConfigServerClientTest {
	
	@Test(expected = RestClientException.class)
	public void testDeleteProperty() {
		ConfigProperty cp = new ConfigProperty();
		ApplicationConfiguration appConfig = new ApplicationConfiguration();
		ConfigServerClient client = new ConfigServerClient(appConfig);
		client.deleteProperty(cp);
	}
	
	@Test(expected = RestClientException.class)
	public void testUpdateProperty() {
		ConfigProperty cp = new ConfigProperty();
		ApplicationConfiguration appConfig = new ApplicationConfiguration();
		ConfigServerClient client = new ConfigServerClient(appConfig);
		client.updateProperty(cp);
	}
	
	@Test(expected = RestClientException.class)
	public void testGetProperty() {
		ConfigProperty cp = new ConfigProperty();
		ApplicationConfiguration appConfig = new ApplicationConfiguration();
		ConfigServerClient client = new ConfigServerClient(appConfig);
		List<ConfigProperty> cplist = new ArrayList<>();
		cplist.add(cp);
		client.printPropertyIds(cplist);
		client.getProperty(cp);
	}
	

}
