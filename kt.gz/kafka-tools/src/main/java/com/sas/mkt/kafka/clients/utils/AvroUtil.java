package com.sas.mkt.kafka.clients.utils;

import com.sas.mkt.kafka.domain.common.*;
import com.sas.mkt.kafka.domain.events.EnhancedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class AvroUtil
{
	private static final Logger logger = LoggerFactory.getLogger(AvroUtil.class);

	public static final String EVENT_IDENTITY = "IdentityEvent";
	public static final String EVENT_MODE_ACTIVE = "active";

	public static final String CUSTOM_EVENT_NAME            = "customEventName";
	public static final String CUSTOM_EVENT_GROUP_NAME      = "customEventGroupName";
	public static final String CUSTOM_EVENT_REVENUE_VALUE   = "customEventRevenueValue";

	public static final String CUSTOM_EVENT_NAME_LOWERCASE          = "customeventname";
	public static final String CUSTOM_EVENT_GROUP_NAME_LOWERCASE      = "customeventgroupname";
	public static final String CUSTOM_EVENT_REVENUE_VALUE_LOWERCASE   = "customeventrevenuevalue";

	//raw property or does it have a schema location?
	public final static String SYSTEM_TYPE = "system_type";

	public final static String EVENT_CHANNEL = "event_channel";
	public final static String EVENT_CHANNEL_ID = "channel_user_id";
	public final static String SESSION = "session";

	public final static String EVENT_NAME = "eventname";
	public final static String EVENT_UUID = "event_uid";
	public final static String EVENT = "event";
	public final static String EVENT_CATEGORY = "event_category";
	public final static String PARENT_EVENT_UID = "parent_event_uid";

	public final static String EVENT_DESIGNED_NAME = "event_designed_name";

	public final static String ACCOUNT = "account";
	public final static String EVENT_GUID = "guid";

	public final static String USER_AGENT = "user_agent";

	public final static String BROWSER_NAME = "browser_name";

	public static final String REFERER_PAGE_URI="referrer";  /*I18NOK:LINE*/
	public final static String REFERER_PATH = "referrer_path";
	public final static String REFERER_HOST = "referrer_host";
	public final static String REFERER_SCHEME = "referrer_scheme";
	public final static String REFERER_PROPERTY_PREFIX = "referrer.";

	public final static String REFERER_DOT_SOCIAL = "referrer.social";
	public final static String REFERER_SOCIAL = "referrer_social";
	public final static String REFERER_DOT_SEARCH = "referrer.search";
	public final static String REFERER_SEARCH = "referrer_search";



	public final static String PAGE_ID = "page_id";


	//ipinfo
	public final static String GEO_IP = "geo_ip";
	public final static String GEO_IP_PROPERTY = "geo_ip_property";

	public final static String GEO_SIC_CODE = "geo_sic_code";
	public final static String GEO_CITY = "geo_city";
	public final static String GEO_COUNTRY = "geo_country";
	public final static String GEO_REGION =	"geo_region";
	public final static String GEO_LOCID = "geo_locid";
	public final static String GEO_LATITUDE = "geo_latitude";
	public final static String GEO_LONGITUDE = "geo_longitude";


	public final static String TIMESTAMP = "timestamp";

	public final static String INTERNAL_TENANT_ID = "internal_tenant_id";

	public final static String PAGE_LOAD_ID = "load_id";
	public final static String PAGE_URI = "uri";
	public final static String PAGE_PATH = "page_path";
	public final static String PAGE_HOST = "page_host";
	public final static String PAGE_SCHEME = "page_scheme";
	public final static String PAGE_QUERY = "page_query";
	public final static String PAGE_TITLE = "page_title";
	public final static String PAGE_PROPERTY_PREFIX = "uri.";
	public static final String DOMAIN = "domain";  /*I18NOK:LINE*/
	public final static String PAGE_VIEW_SEQUENCE_NUM = "page_view_sequence_num";

	//public final static String BROWSER_NAME = "browser_name";
	public final static String BROWSER_COOKIES_ENABLED = "browser_cookies_enabled";
	public final static String BROWSER_LANGUAGE = "browser_language_name";
	public final static String BROWSER_CONNECTION_TYPE = "browser_connection_type";
	public final static String BROWSER_FLASH_VERSION = "browser_flash_version";
	public final static String BROWSER_FLASH_ENABLED = "browser_flash_enabled";
	public final static String BROWSER_JAVA_VERSION = "browser_java_version";
	public final static String BROWSER_JAVA_ENABLED = "browser_java_enabled";
	public final static String BROWSER_JAVASCRIPT_ENABLED = "browser_javascript_enabled";

	//deviceInfo
	public static final String MOBILE_DEVICE_LANGUAGE = "mobile_device_language";
	public static final String MOBILE_DEVICE_MANUFACTURER = "mobile_device_mfg";
	public static final String MOBILE_DEVICE_MODEL = "mobile_device_model";
	public static final String MOBILE_DEVICE_TYPE = "mobile_device_type";
	public static final String MOBILE_PLATFORM = "mobile_platform";
	public static final String MOBILE_PLATFORM_VERSION = "mobile_platform_version";
	public static final String MOBILE_SCREEN_HEIGHT = "mobile_screen_height";
	public static final String MOBILE_SCREEN_WIDTH = "mobile_screen_width";
	//service provider
	public static final String MOBILE_CARRIER_NAME = "mobile_carrier_name";
	public static final String MOBILE_COUNTRY_CODE = "mobile_country_code";
	public static final String MOBILE_NETWORK_CODE = "mobile_network_code";


	public final static String VISITOR_STATE = "visitor_state";
	public final static String VISITOR_REFFERAL_URI = "visitor_referral_uri";
	public final static String VISIT_ID = "visit_id";


	//public final static String VID = "vid";
	public final static String IDENTITY_ID = /*"identity_id"*/"vid";
	public final static String IDENTITY_VISIT_ID = "identity_visit_id";
	//public final static String IDENTITY_SESSION_ID = "identity_session_id";


	public final static String BROWSER_PLATFORM = "browser_platform";
	public final static String BROWSER_DEVICE_TYPE = "browser_device_type";
	//public final static String DEVICE_INFO_SCREEN_HEIGHT = "device_info_screen_height";
	public final static String SCREEN_INFO = "screen_info";



	public final static String OBFUSCATE_IP_ADDRESS = "obfuscate_ip_address";


	public final static String LOGON_TYPE = "logon_type";
	public final static String EVENT_MODE_TAG = "event_mode";
	public final static String EVENT_MODE_LOGIN = "login";
	public final static String LOGON_VALUE = "logon_value";



	public static final String PROPERTY_VALUE_VISITOR_NEW       = "new";



	public static final String LINE       = "line";
	public static final String COLUMN     = "column";
	public static final String MESSAGE    = "message";




	public static final String MEDIA_URL       = "media_url";
	public static final String MEDIA_PLAYER     = "media_player";
	public static final String MEDIA_PLAYER_VERSION    = "media_player_version";
	public static final String MEDIA_DURATION    = "media_duration";
	public static final String MEDIA_POSITION    = "media_position";
	public static final String MEDIA_ACTION    = "media_action";
	public static final String MEDIA_FIRST_INTERACTION_FLAG    = "media_first_interaction_flag";


	//activity
	public static final String ACTIVITY_ID = "activity_id";
	public static final String ABTEST_PATH_ID = "abtest_path_id";
	public static final String ACTIVITY_IA_TAG_VALUE = "activity_ia_tag_value";
	public static final String ACTIVITY_NAME = "activity_nm";
	public static final String ACTIVITY_NODE_ID = "activity_node_id";
	public static final String ACTIVITY_TASK_TYPE = "activity_task_type";
	public static final String ACTIVITY_TIME_BOX = "activity_timebox";
	public static final String ACTIVITY_CANCEL_GOALS = "activity_cancel_goals";

	//trigger
	public static final String ACTIVITY_TRIGGER_EVENT_ID = "activity_trigger_event_id";
	public static final String TRIGGER_EVENT_EXEC_CTX = "trigger_event_exec_ctxt";
	public static final String TRIGGER_EVENT_EXP_W_FREQ = "trigger_event_exp_with_freq";
	public static final String TRIGGER_EVENT_EXP_ID = "trigger_event_expr_id";
	public static final String TRIGGER_EVENT_EXP_FILTER_TOTAL = "triggerevent_expression_filter_total";


	//ecommerce
	public static final String CART_TYPE = "cart_type";
	public static final String CART_ITEM_COUNT = "cartitem_count";
	public static final String CART_ID = "cartId";
	public static final String PAYMENT_TYPE = "paymentType";
	public static final String DELIVERY_TYPE = "deliveryType";
	public static final String TAX = "tax_num";
	public static final String TOTAL_COST = "totalCost_num";
	public static final String SHIPPING_COST = "shippingCost_num";
	public static final String ORDER_ID = "orderId";

	public static final String CART_ID_LOWERCASE = "cartid";
	public static final String PAYMENT_TYPE_LOWERCASE = "paymenttype";  //needed for the loop that does lowercase string switch statement
	public static final String DELIVERY_TYPE_LOWERCASE = "deliverytype";
	public static final String TOTAL_COST_LOWERCASE = "totalcost_num";
	public static final String SHIPPING_COST_LOWERCASE = "shippingcost_num";
	public static final String ORDER_ID_LOWERCASE = "orderid";

	//billing location properties
	public static final String BILLING_CITY = "billingCity";
	public static final String BILLING_COUNTRY = "billingCountry";
	public static final String BILLING_POSTCODE = "billingPostcode";
	public static final String BILLING_REGION = "billingRegion";

	public static final String BILLING_CITY_LOWERCASE = "billingcity";
	public static final String BILLING_COUNTRY_LOWERCASE = "billingcountry";
	public static final String BILLING_POSTCODE_LOWERCASE = "billingpostcode";
	public static final String BILLING_REGION_LOWERCASE = "billingregion";


	//shipping location properties
	public static final String SHIPPING_CITY = "shippingCity";
	public static final String SHIPPING_COUNTRY = "shippingCountry";
	public static final String SHIPPING_POSTCODE = "shippingPostcode";
	public static final String SHIPPING_REGION = "shippingRegion";

	public static final String SHIPPING_CITY_LOWERCASE = "shippingcity";
	public static final String SHIPPING_COUNTRY_LOWERCASE = "shippingcountry";
	public static final String SHIPPING_POSTCODE_LOWERCASE = "shippingpostcode";
	public static final String SHIPPING_REGION_LOWERCASE = "shippingregion";

	//contact response
	public static final String CONTACT_RESPONSE = "contact_response";
	public static final String CONTACT_RESPONSE_TAG = "contact_response_tag";
	public static final String RESPONSE_TRACKING_CODE = "response_tracking_code";
	public static final String RESPONSE_TYPE = "response_type";
	public static final String RESPONSE_VALUE = "response_value";

	//impression
	public static final String CONTROL_GROUP = "control_group";
	public static final String CREATIVE_ID = "creative_id";
	public static final String CREATIVE_VERSION_ID = "creative_version_id"; 
	public static final String CREATIVE_CONTENT = "creative_content";
	public static final String GOAL_EVENT = "goalEvent";
	public static final String GOAL_EVENT_LOWERCASE = "goalevent"; //needed for the loop that does lowercase string switch statement
	public static final String GOAL_ID = "goal_guid";
	public static final String SPOT_ID = "spot_id";
	public static final String TASK_ID = "task_id";
	public static final String TASK_VERSION_ID = "task_version_id";
	public static final String VARIANT_ID = "variant_id";
	public static final String IMPRINT_ID = "imprint_id";
	public static final String OCCURRENCE_ID = "occurrence_id";
	public static final String IS_CONTROL_GROUP = "is_control_group";
	public static final String MERGETAG_ATTRIBUTE_NAME = "mergetag_attribute_name";
	public static final String MERGETAG_IA_SAFE_ID = "mergetag_ia_safe_id";
	public static final String MESSAGE_ID = "message_id";
	public static final String MESSAGE_VERSION_ID = "message_version_id"; 
	public static final String SEGMENT_ID = "segment_id";
	public static final String SEGMENT_VERSION_ID = "segment_version_id"; 

	//beacon
	public static final String BEACON_ID = "beacon_id";
	public static final String BEACON_MAJOR = "beacon_major";
	public static final String BEACON_MINOR = "beacon_minor";
	public static final String BEACON_NAME = "beacon_name";
	public static final String BEACON_UUID = "beacon_uuid";
	public static final String BEACON_KEYWORDS = "keywords";

	//geofence
	public static final String GEOFENCE_NAME = "geofence_name";
	public static final String GEOFENCE_ID = "geofence_id";
	public static final String GEOFENCE_REGION = "region";
	public static final String GEOFENCE_CITY = "city";
	public static final String GEOFENCE_STATE = "state";
	public static final String GEOFENCE_KEYWORDS = "keywords";

	//app
	public static final String APP_LANGUAGE = "mobile_app_language";
	public static final String APP_VERSION = "mobile_app_version";
	public static final String APP_ID = "mobile_appid";
	public static final String APP_SDK_VERSION = "mobile_sdk_version";

	//promotion
	public static final String PROMOTION_NAME            = "promotionName";
	public static final String PROMOTION_TYPE            = "promotionType";
	public static final String PROMOTION_PLACEMENT       = "promotionPlacement";
	public static final String PROMOTION_CREATIVE        = "promotionCreative";
	public static final String PROMOTION_TRACKING_CODE   = "promotionTrackingCode";
	public static final String PROMOTION_RECORD_TYPE     = "promotionRecordType";

	public static final String PROMOTION_NAME_LOWERCASE            = "promotionname";
	public static final String PROMOTION_TYPE_LOWERCASE            = "promotiontype";
	public static final String PROMOTION_PLACEMENT_LOWERCASE       = "promotionplacement";
	public static final String PROMOTION_CREATIVE_LOWERCASE        = "promotioncreative";
	public static final String PROMOTION_TRACKING_CODE_LOWERCASE   = "promotiontrackingcode";
	public static final String PROMOTION_RECORD_TYPE_LOWERCASE     = "promotionrecordtype";

	public static final String TRAFFIC_SOURCE_NAME="traffic_source_name"; /*I18NOK:LINE*/
	public static final String TRAFFIC_SOURCE_TYPE="traffic_source_type"; /*I18NOK:LINE*/
	public static final String TRAFFIC_SOURCE_PLACEMENT="traffic_source_placement"; /*I18NOK:LINE*/
	public static final String TRAFFIC_SOURCE_CREATIVE="traffic_source_creative"; /*I18NOK:LINE*/
	public static final String TRAFFIC_SOURCE_TRACKING_CODE="traffic_source_tracking_code"; /*I18NOK:LINE*/

	public static final String DOCUMENT_URL = "document_url";


	//journey or business process
	public static final String BUSINESS_PROCESS_ATTRIBUTE_1 = "businessProcessAttribute1"; /*I18NOK:LINE*/ //Attribute_1: properties.attrib1
	public static final String BUSINESS_PROCESS_ATTRIBUTE_2 = "businessProcessAttribute2"; /*I18NOK:LINE*/ //Attribute_2: properties.attrib2
	public static final String BUSINESS_PROCESS_STEP_NAME = "businessProcessStepName"; /*I18NOK:LINE*/  //Step_Name: journey.stepName
	public static final String BUSINESS_PROCESS_STEP_ATTEMPTS = "businessProcessStepAttempts"; /*I18NOK:LINE*/  //Step_Attempts: journey. stepAttemptIndexInt

	public static final String BUSINESS_PROCESS_ATTRIBUTE_1_LOWERCASE = "businessprocessattribute1"; /*I18NOK:LINE*/ //Attribute_1: properties.attrib1
	public static final String BUSINESS_PROCESS_ATTRIBUTE_2_LOWERCASE = "businessprocessattribute2"; /*I18NOK:LINE*/ //Attribute_2: properties.attrib2
	public static final String BUSINESS_PROCESS_STEP_NAME_LOWERCASE = "businessprocessstepname"; /*I18NOK:LINE*/  //Step_Name: journey.stepName
	public static final String BUSINESS_PROCESS_STEP_ATTEMPTS_LOWERCASE = "businessprocessstepattempts"; /*I18NOK:LINE*/  //Step_Attempts: journey. stepAttemptIndexInt

	//product properties
	public static final String PRODUCT_AVAILABILITY_MESSAGE = "product_availability_message"; /*I18NOK:LINE*/
	public static final String PRODUCT_GROUP = "product_group"; /*I18NOK:LINE*/
	public static final String PRODUCT_ID = "product_id"; /*I18NOK:LINE*/
	public static final String PRODUCT_NAME = "product_name"; /*I18NOK:LINE*/
	public static final String PRODUCT_QUANTITY = "product_quantity_num"; /*I18NOK:LINE*/
	public static final String PRODUCT_SKU = "product_sku"; /*I18NOK:LINE*/
	public static final String PRODUCT_UNIT_PRICE = "product_unit_price_num"; /*I18NOK:LINE*/
	public static final String PRODUCT_SAVINGS_MESSAGE = "product_savings_message"; /*I18NOK:LINE*/
	public static final String PRODUCT_SHIPPING_MESSAGE = "product_shipping_message"; /*I18NOK:LINE*/
	public static final String PRODUCT_ACTION = "action";

	//internal search
	public static final String INTERNAL_SEARCH_RESULT_COUNT = "searchResultCount";
	public static final String INTERNAL_SEARCH_TERM = "searchTerm";
	public static final String INTERNAL_SEARCH_NAME = "searchName";
	public static final String INTERNAL_SEARCH_NAME_LOWERCASE = "searchname";
	public static final String INTERNAL_SEARCH_FIELD_DISPLAY_FLAG = "resultsDisplayFlag";
	public static final String INTERNAL_SEARCH_FIELD_DISPLAY_FLAG_LOWERCASE = "resultsdisplayflag";
	public static final String INTERNAL_SEARCH_FIELD_ID = "fieldId";
	public static final String INTERNAL_SEARCH_FIELD_ID_LOWERCASE = "fieldid";
	public static final String INTERNAL_SEARCH_FIELD_NAME = "fieldName";
	public static final String INTERNAL_SEARCH_FIELD_NAME_LOWERCASE = "fieldname";

	public static final String INTERNAL_SEARCH_RESULT_COUNT_LOWERCASE = "searchresultcount";
	public static final String INTERNAL_SEARCH_TERM_LOWERCASE = "searchterm";

	public static final String LINK_TRACKING_ID = "linkTrackingId";
	public static final String LINK_TRACKING_LABEL = "linkTrackingLabel";
	public static final String LINK_TRACKING_GROUP = "linkTrackingGroup";

	public static final String LINK_TRACKING_ID_LOWERCASE = "linktrackingid";
	public static final String LINK_TRACKING_LABEL_LOWERCASE = "linktrackinglabel";
	public static final String LINK_TRACKING_GROUP_LOWERCASE = "linktrackinggroup";

	public static final String EMAIL_RECIPIENT_DOMAIN = "recipientDomain";
	public static final String EMAIL_RECIPIENT_EMAIL_ADDRESS = "recipientEmailAddress";
	public static final String EMAIL_PROGRAM_ID = "emailProgramId";
	public static final String EMAIL_REPLY_CORRELATED = "emailReplyCorrelated";
	public static final String EMAIL_SEND_AGENT_ID = "emailSendAgentId";
	public static final String EMAIL_SUBJECT = "emailSubject";
	public static final String EMAIL_IMPRINT_URL = "emailImprintURL";
	public static final String EMAIL_REASON = "emailReason";

	public static final String EMAIL_RECIPIENT_DOMAIN_LOWERCASE = "recipientdomain";
	public static final String EMAIL_RECIPIENT_EMAIL_ADDRESS_LOWERCASE = "recipientemailaddress";
	public static final String EMAIL_PROGRAM_ID_LOWERCASE = "emailprogramid";
	public static final String EMAIL_REPLY_CORRELATED_LOWERCASE = "emailreplycorrelated";
	public static final String EMAIL_SEND_AGENT_ID_LOWERCASE = "emailsendagentid";
	public static final String EMAIL_SUBJECT_LOWERCASE = "emailsubject";
	public static final String EMAIL_IMPRINT_LOWERCASE = "emailimprinturl";
	public static final String EMAIL_REASON_LOWERCASE = "emailreason";

	private static AvroUtil instance = null;
	public static AvroUtil getInstance()
	{

		if(null == instance)
		{
			synchronized(AvroUtil.class)
			{
				if(null == instance)
					instance = new AvroUtil();
			}
		}

		return instance;
	}

	/*
	 * Used for testing / mock override
	 * */
	public static void setInstance(AvroUtil instance)
	{
		AvroUtil.instance = instance;
	}

	public Map<String,String> eventFromAvro(EnhancedEvent event)
	{
		if(null == event)
			return null;


		Map<String, String> propertiesExisting = event.getProperties();

		Map<String, String> properties;

		if(null != propertiesExisting)
			properties = new HashMap<String,String>(propertiesExisting);
		else
			properties = new HashMap<String,String>();

		setProperty(event.getParentEventUid(), PARENT_EVENT_UID, properties);

		//are we using this or the Identity class?
		setProperty(event.getIdentityId(), IDENTITY_ID, properties);
		setProperty(event.getEventName(), EVENT_NAME, properties);
		setProperty(event.getEventDesignedName(), EVENT_DESIGNED_NAME, properties);
		setProperty(event.getEventDesignedId(), EVENT_UUID, properties);
		setProperty(event.getGuid(), EVENT_GUID, properties);
		setProperty(event.getChannelType(), EVENT_CHANNEL, properties);
		setProperty(event.getChannelId(), EVENT_CHANNEL_ID, properties);
		setProperty(event.getSessionId(), SESSION, properties);
		setProperty(event.getExternalTenantId(), ACCOUNT, properties);
		setProperty(event.getIpAddress(), GEO_IP, properties);
		setProperty(event.getEventType(), EVENT, properties);
		//setProperty(event.getDomain(), DOMAIN, properties);
		setProperty(event.getCustomName(), CUSTOM_EVENT_NAME, properties);
		setProperty(event.getCustomGroupName(), CUSTOM_EVENT_GROUP_NAME, properties);
		setProperty(event.getCustomRevenueDbl(), CUSTOM_EVENT_REVENUE_VALUE, properties);



		String val;

		EventCategory eventCategory = event.getEventCategory();
		if(null != eventCategory)
		{
			val = eventCategory.toString();
			setProperty(val, EVENT_CATEGORY, properties);
		}

		Integer id = event.getInternalTenantId();
		if(null != id  /*&& id != 0 ??*/)
		{
			val = id.toString();
			setProperty(val, INTERNAL_TENANT_ID, properties);
		}

		ObfuscateIpAddress obIp = event.getObfuscateIpAddress();
		if(null != obIp)
		{
			val = obIp.toString();
			setProperty(val, OBFUSCATE_IP_ADDRESS, properties);
		}

		//fill in any additional properties
		propertiesFromBrowser(event.getBrowser(), properties);
		propertiesFromPage(event.getPage(), properties);
		propertiesFromDeviceInfo(event.getDeviceInfo(), properties);
		propertiesFromServiceProvider(event.getServiceProvider(), properties);
		propertiesFromDate(event.getDate(), properties);
		propertiesFromVisit(event.getVisit(), properties);
		propertiesFromIdentity(event.getIdentity(), properties);
		propertiesFromGeoLocation(event.getIpInfo(), properties);
		propertiesFromMedia(event.getMedia(), properties);
		propertiesFromActivity(event.getActivity(), properties);
		propertiesFromECommerce(event.getECommerce(), properties);
		propertiesFromContactResponse(event.getContactResponse(), properties);
		propertiesFromImpression(event.getImpression(), properties);
		propertiesFromPromotion(event.getPromotion(), properties);
		propertiesFromTrigger(event.getTrigger(), properties);
		propertiesFromBeacon(event.getBeacon(), properties);
		propertiesFromApp(event.getApp(), properties);
		propertiesFromGeoFence(event.getGeofence(), properties);
		propertiesFromPromotion(event.getPromotion(), properties);
		propertiesFromDownload(event.getDownload(), properties);
		propertiesFromSession(event.getSession(), properties);
		propertiesFromJourney(event.getJourney(), properties);
		propertiesFromProduct(event.getProduct(), properties);
		propertiesFromInternalSearch(event.getInternalSearch(), properties);
		propertiesFromLinkTracking(event.getLinkTracking(), properties);
		propertiesFromEmail(event.getEmail(), properties);

		processExistingProperties(event, propertiesExisting, properties);

		return properties;
	}

	private void propertiesFromSession(Session session, Map<String,String> properties)
	{
		if(null == session)
			return;

		Map<String,String> userSourceMap = session.getUserSourceMap();

		//Extract page categories into flattened map
		if(null != userSourceMap){
			Set<String> keys = userSourceMap.keySet();

			for(String key:keys)
			{
				setProperty( userSourceMap.get(key), key, properties);
			}
		}

	}


	private void processExistingProperties(EnhancedEvent event, Map<String,String> propertiesExisting, Map<String,String> properties)
	{
		//String val = null;

		if(null == propertiesExisting)
			return;

		//would be quicker if we didn't have to enumerate but
		//we need to for the 'geo.*' case
		//and the existing code had the equalsIgnoreCase usage
		//not sure there is a chance of mixed case coming back or not.
		for (String property : propertiesExisting.keySet())
		{
			if(property.equalsIgnoreCase(REFERER_DOT_SOCIAL))
			{
				setProperty(propertiesExisting.get(property), REFERER_SOCIAL, properties);
			}
			else if(property.equalsIgnoreCase(REFERER_DOT_SEARCH))
			{
				setProperty(propertiesExisting.get(property), REFERER_SEARCH, properties);
			}
//			else if(property.equalsIgnoreCase(LOGIN_EVENT))
//			{
//				properties.put(EVENT_MODE_TAG, EVENT_MODE_LOGIN);
//			}
			else if (property.startsWith("geo."))
			{
				properties.put(property.replaceAll("\\.", "_"), propertiesExisting.get(property));
			}


		}


		//newProperties.put("event_channel", "web");
		//newProperties.put("channel_user_id", properties.get("visitor"));


		//Benson: RawEventConverter should set the loginType and loginValue consistently to not need the original commented out code below
		//We can simplify by just looking at the eventName, logintype, and loginvalue to determine whether we have enough info to actually log in
		Identity identity = event.getIdentity();
		if(EVENT_IDENTITY.equals(event.getEventName()) && identity.getLoginType() != null && identity.getLoginValue() != null) {
			if(!(properties.containsKey(EVENT_MODE_TAG) && null != properties.get(EVENT_MODE_TAG) && properties.get(EVENT_MODE_TAG).compareTo(EVENT_MODE_ACTIVE) == 0))
				properties.put(EVENT_MODE_TAG, EVENT_MODE_LOGIN);
		}

//        String evtName = properties.get(EVENT_NAME);
//        if (evtName != null && evtName.equals("IdentityEvent") && properties.get(LOGON_VALUE) != null && properties.get(LOGON_TYPE) != null){
//            properties.put(EVENT_MODE_TAG, EVENT_MODE_LOGIN);
//        }else{
//            // Mobile Identity events are already correct for Mobile so don't corrupt the identity stuff in that case
//            if (properties.get(LOGON_VALUE) == null) {
//                String string = properties.get(LOGIN_EVENT);
//                if (string == null || string.equals(""))
//                {
//                    string = properties.get("User_ID_Attribute");
//                    if (string != null && !string.equals(""))
//                    {
//                        if (evtName != null && evtName.equals("IdentityEvent"))
//                        {
//                            properties.put(EVENT_MODE_TAG, EVENT_MODE_LOGIN);
//                        }
//                    }
//                }
//
//                properties.put(LOGON_VALUE, string);
//            }
//
//            if (properties.get(LOGON_TYPE) == null) {
//                String string = properties.get(LOGIN_EVENT_TYPE);
//                if (string != null && string.equals("email"))
//                {
//                    string = EMAILID;
//                }
//                properties.put(LOGON_TYPE, string);
//            }
//        }


		// Is this a session start?
		//Benson discussed with Forrest that this no longer makes sense to do downstream in the ESPServer.
		//Not sure why it was done in the EspEventPublisher web handler for Tag.
//        String visitorState = properties.get(VISITOR_STATE);
//		String eventName = properties.get(EVENT_NAME);
//        if (PROPERTY_VALUE_VISITOR_NEW.equals(visitorState) && !"PageLoad".equals(eventName))
//        {
//        	//LOG.debug("NewSession event");
//        	properties.put(EVENT, "NewSession");
//        }
	}

	private void setProperty(Enum<?> val, String key, Map<String, String> properties)
	{
		if(null == properties)
			return;

		if(null == val)
			return;

		properties.put(key, val.name().toLowerCase());

	}

	private void setProperty(Boolean val, String key, Map<String, String> properties)
	{
		if(null == properties)
			return;

		if(null == val)
			return;

		properties.put(key, val.toString());
	}

	private void setProperty(Integer val, String key, Map<String, String> properties)
	{
		if(null == properties)
			return;

		if(null == val)
			return;

		properties.put(key, val.toString());
	}

	private void setProperty(Long val, String key, Map<String, String> properties)
	{
		if(null == properties)
			return;

		if(null == val)
			return;

		properties.put(key, val.toString());
	}

	private void setProperty(Double val, String key, Map<String, String> properties)
	{
		if(null == properties)
			return;

		if(null == val)
			return;

		properties.put(key, val.toString());
	}

	private void setProperty(String val, String key, Map<String, String> properties)
	{
		if(null == properties)
			return;

		if(null == val)
			return;

		if(val.length() > 0)
			properties.put(key, val);

	}

	private void propertiesFromApp(App a, Map<String, String> properties)
	{
		if(null == a)
			return;

		setProperty(a.getAppId(), APP_ID, properties);
		setProperty(a.getAppLanguage(), APP_LANGUAGE, properties);
		setProperty(a.getAppVersion(), APP_VERSION, properties);
		setProperty(a.getSdkVersion(), APP_SDK_VERSION, properties);
	}

	private void propertiesFromBeacon(Beacon b, Map<String, String> properties)
	{
		if(null == b)
			return;

		setProperty(b.getBeaconId(), BEACON_ID, properties);
		setProperty(b.getBeaconMajor(), BEACON_MAJOR, properties);
		setProperty(b.getBeaconMinor(), BEACON_MINOR, properties);
		setProperty(b.getBeaconName(), BEACON_NAME, properties);
		setProperty(b.getBeaconUuid(), BEACON_UUID, properties);
		Map<String, String> props = b.getProperties();
		if (props != null) {
			String keywords = props.get(BEACON_KEYWORDS);
			if (keywords != null)
				setProperty(keywords, BEACON_KEYWORDS, properties);
		}
	}

	private void propertiesFromContactResponse(ContactResponse cr, Map<String, String> properties){
		if(null == cr)
			return;
		setProperty(cr.getResponseTrackingCode(), RESPONSE_TRACKING_CODE, properties);
		setProperty(cr.getResponseType(), RESPONSE_TYPE, properties);
		setProperty(cr.getResponseValue(), RESPONSE_VALUE, properties);
		setProperty(cr.getContactResponseCode(), CONTACT_RESPONSE, properties);
		setProperty(cr.getContactResponseTag(), CONTACT_RESPONSE_TAG, properties);
	}

	private void propertiesFromImpression(Impression i, Map<String, String> properties)
	{
		if(null == i)
			return;

		setProperty(i.getControlGroup(), CONTROL_GROUP, properties);
		setProperty(i.getCreativeId(), CREATIVE_ID, properties);
		setProperty(i.getCreativeVersionId(), CREATIVE_VERSION_ID, properties);
		setProperty(i.getCreativeContent(), CREATIVE_CONTENT, properties);
		setProperty(i.getGoalEvent(), GOAL_EVENT, properties);
		setProperty(i.getGoalId(), GOAL_ID, properties);
		setProperty(i.getTaskId(), TASK_ID, properties);
		setProperty(i.getTaskVersionId(), TASK_VERSION_ID, properties);
		setProperty(i.getSpotId(), SPOT_ID, properties);
		setProperty(i.getVariantId(), VARIANT_ID, properties);
		setProperty(i.getImprintId(), IMPRINT_ID, properties);
		setProperty(i.getOccurrenceId(), OCCURRENCE_ID, properties);

		if(null != i.getIsControlGroup() && i.getIsControlGroup())
			setProperty("true", IS_CONTROL_GROUP, properties); //true or 'y'?

		setProperty(i.getMergeTagAttributeName(), MERGETAG_ATTRIBUTE_NAME, properties);
		setProperty(i.getMergeTagIaSafeId(), MERGETAG_IA_SAFE_ID, properties);
		setProperty(i.getMessageId(), MESSAGE_ID, properties);
		setProperty(i.getMessageVersionId(), MESSAGE_VERSION_ID, properties);
		setProperty(i.getSegmentId(), SEGMENT_ID, properties);
		setProperty(i.getSegmentVersionId(), SEGMENT_VERSION_ID, properties);

	}

	private String getCartType(ECommerceAction eCommerceAction) {
		String ret = null;

		if(eCommerceAction != null) {
			switch (eCommerceAction) {
				case cartView:
					ret = "cartview";
					break;
				case checkout:
					ret = "checkout";
					break;
				case order:
					ret = "purchase";
					break;
			}
		}

		return ret;
	}

	private ECommerceAction getECommerceAction(String cart_type) {
		ECommerceAction ret = null;

		if(cart_type != null) {
			if ("cartview".equals(cart_type))
			{
				ret = ECommerceAction.cartView;
			}
			else if ("purchase".equals(cart_type))
			{
				ret = ECommerceAction.order;
			}
			else if ("checkout".equals(cart_type))
			{
				ret = ECommerceAction.checkout;
			}
		}

		return ret;
	}

	private void propertiesFromECommerce(ECommerce e, Map<String, String> properties)
	{
		if(null == e)
			return;

		if(null != e.getItemCount())
			setProperty(e.getItemCount().toString(), CART_ITEM_COUNT, properties);

		setProperty(getCartType(e.getECommerceAction()), CART_TYPE, properties);
		setProperty(e.getCartId(), CART_ID, properties);
		setProperty(e.getPaymentType(), PAYMENT_TYPE, properties);
		setProperty(e.getDeliveryType(), DELIVERY_TYPE, properties);
		setProperty(e.getTotalShippingDbl(), SHIPPING_COST, properties);
		setProperty(e.getTotalValueDbl(), TOTAL_COST, properties);
		setProperty(e.getTotalTaxDbl(), TAX, properties);
		setProperty(e.getOrderId(), ORDER_ID, properties);

		propertiesFromBillingLocation(e.getBillingAddress(), properties);
		propertiesFromShippingLocation(e.getShippingAddress(), properties);
	}

	private void propertiesFromBillingLocation(Location lProps, Map<String,String> properties)
	{
		if(null == lProps)
			return;

		if(null == properties)
			return;

		setProperty(lProps.getCity(), BILLING_CITY, properties);
		setProperty(lProps.getCountry(), BILLING_COUNTRY, properties);
		setProperty(lProps.getPostalCode(), BILLING_POSTCODE, properties);
		setProperty(lProps.getRegion(), BILLING_REGION, properties);

	}

	private void propertiesFromShippingLocation(Location lProps, Map<String,String> properties)
	{
		if(null == lProps)
			return;

		if(null == properties)
			return;

		setProperty(lProps.getCity(), SHIPPING_CITY, properties);
		setProperty(lProps.getCountry(), SHIPPING_COUNTRY, properties);
		setProperty(lProps.getPostalCode(), SHIPPING_POSTCODE, properties);
		setProperty(lProps.getRegion(), SHIPPING_REGION, properties);

	}

	private void propertiesFromActivity(Activity activity, Map<String,String> properties)
	{
		if(null == activity)
			return;


		setProperty(activity.getActivityId(), ACTIVITY_ID, properties);
		setProperty(activity.getAbPathAssignmentId(), ABTEST_PATH_ID, properties);
		setProperty(activity.getIaTagValue(), ACTIVITY_IA_TAG_VALUE, properties);
		setProperty(activity.getActivityName(), ACTIVITY_NAME, properties);
		setProperty(activity.getActivityNodeId(), ACTIVITY_NODE_ID, properties);
		setProperty(activity.getActivityTaskType(), ACTIVITY_TASK_TYPE, properties);
		setProperty(activity.getActivityTimebox(), ACTIVITY_TIME_BOX, properties);
		setProperty(activity.getActivityCancelGoals(), ACTIVITY_CANCEL_GOALS, properties);


	}

	private void propertiesFromTrigger(Trigger t, Map<String, String> properties)
	{
		if(null == t)
			return;

		setProperty(t.getTriggerEventId(), ACTIVITY_TRIGGER_EVENT_ID, properties);

		setProperty(t.getExecutionContext(), TRIGGER_EVENT_EXEC_CTX, properties);
		setProperty(t.getExpressionFrequency(), TRIGGER_EVENT_EXP_W_FREQ, properties);
		setProperty(t.getExpressionId(), TRIGGER_EVENT_EXP_ID, properties);
		setProperty(t.getExpressionFilterTotal(), TRIGGER_EVENT_EXP_FILTER_TOTAL, properties);
	}

	private void propertiesFromMedia(Media mProps, Map<String, String> properties)
	{
		if(null == mProps)
			return;


		setProperty(mProps.getMediaUrl(), MEDIA_URL, properties);
		setProperty(mProps.getMediaPlayer(), MEDIA_PLAYER, properties);
		setProperty(mProps.getMediaPlayerVersion(), MEDIA_PLAYER_VERSION, properties);
		setProperty(mProps.getMediaPosition(), MEDIA_POSITION, properties);
		setProperty(mProps.getMediaAction(), MEDIA_ACTION, properties);
		setProperty(mProps.getMediaFirstInteractionFlag(), MEDIA_FIRST_INTERACTION_FLAG, properties);


		Float fVal = mProps.getMediaLength();
		if(null != fVal)
		{
			try
			{
				String val = fVal.toString();
				setProperty(val, MEDIA_DURATION, properties);
			}
			catch(Exception ex)
			{
				logger.error("Error parsing media duration: " + ex.getMessage());
			}
		}

	}

	private void propertiesFromIdentity(Identity iProps, Map<String, String> properties)
	{
		if(null == iProps)
			return;

		setProperty(iProps.getIdentityId(), IDENTITY_ID, properties);
		setProperty(iProps.getSessionId(), SESSION, properties);
		setProperty(iProps.getVisitId(), IDENTITY_VISIT_ID, properties);

		setProperty(iProps.getLoginType(), LOGON_TYPE, properties);
		setProperty(iProps.getLoginValue(), LOGON_VALUE, properties);

	}

	private void propertiesFromVisit(Visit vProps, Map<String,String> properties)
	{
		if(null == vProps)
			return;


		setProperty(vProps.getVisitorState(), VISITOR_STATE, properties);
		setProperty(vProps.getVisitId(), VISIT_ID, properties);


		URI uri = vProps.getReferrer();

		if(null != uri)
		{
			setProperty(uri.getUri(), VISITOR_REFFERAL_URI, properties);
		}

		setProperty(vProps.getTrafficSourceCreative(), TRAFFIC_SOURCE_CREATIVE, properties);
		setProperty(vProps.getTrafficSourceName(), TRAFFIC_SOURCE_NAME, properties);
		setProperty(vProps.getTrafficSourcePlacement(), TRAFFIC_SOURCE_PLACEMENT, properties);
		setProperty(vProps.getTrafficSourceTrackingCode(), TRAFFIC_SOURCE_TRACKING_CODE, properties);
		setProperty(vProps.getTrafficSourceType(), TRAFFIC_SOURCE_TYPE, properties);
	}

	private void propertiesFromDate(DateTime dProps, Map<String,String> properties)
	{
		if(null == dProps)
			return;

		if(null == properties)
			return;

		Long lVal = null;
		String val = null;

		//presume that generated time stamp matches up with the current tag TIMESTAMP field.
		lVal = dProps.getGeneratedTimestamp();

		if(null != lVal)
		{
			val = lVal.toString();
			setProperty(val, TIMESTAMP, properties);
		}
	}

	private void propertiesFromPage(Page pProps, Map<String,String> properties)
	{
		if(null == pProps)
			return;


		URI uri = pProps.getReferrerUri();

		//right thing?
		if(null != uri)
		{
			setProperty(uri.getUri(), REFERER_PAGE_URI, properties);
			setProperty(uri.getPath(), REFERER_PATH, properties);
			setProperty(uri.getHost(), REFERER_HOST, properties);
			setProperty(uri.getScheme(), REFERER_SCHEME, properties);

			Map<String,String> props = uri.getProperties();

			if(null != props)
			{
				Set<String> keys = props.keySet();

				for(String key:keys)
				{
					setProperty( props.get(key), key, properties);
				}
			}

		}

		setProperty(pProps.getPageId(), PAGE_ID, properties);
		setProperty(pProps.getViewSequenceNum(), PAGE_VIEW_SEQUENCE_NUM, properties);
		setProperty(pProps.getLoadId(), PAGE_LOAD_ID, properties);
		setProperty(pProps.getPageTitle(), PAGE_TITLE, properties);
		setProperty(pProps.getErrorDescription(), MESSAGE, properties);

		String val = pProps.getErrorLocation();
		if(null != val && val.length() > 0)
		{
			//"line: x, column: y"
			//need to split on the column
			//the remove everything before the ':"
			//and trim.
			//could validate which on is column and which one is line
			String [] vals = val.split(",");

			//always expect two
			if(vals.length == 2)
			{
				if(null != vals[0] && null != vals[1])
				{
					int lineIndex = -1;
					int columnIndex = -1;

					if(vals[0].contains("line") && vals[1].contains("column"))
					{
						lineIndex = 0;
						columnIndex = 1;
					}
					else if(vals[1].contains("line") && vals[0].contains("column"))
					{
						lineIndex = 1;
						columnIndex = 0;
					}

					//if one is good they should both be good
					if(lineIndex > -1)
					{
						try
						{
							String line = vals[lineIndex].substring(vals[lineIndex].indexOf(':')+1);
							String column = vals[columnIndex].substring(vals[columnIndex].indexOf(':')+1);

							if(null != line && null != column)
							{
								setProperty(line.trim(), LINE, properties);
								setProperty(column.trim(), COLUMN, properties);
							}
						}
						catch(Exception ex)
						{
							logger.error(ex.getMessage());
						}
					}
				}
			}
		}


		uri = pProps.getUri();

		if(null != uri)
		{
			setProperty(uri.getUri(), PAGE_URI, properties);
			setProperty(uri.getPath(), PAGE_PATH, properties);
			//setProperty(uri.getHost(), PAGE_HOST, properties);
			setProperty(uri.getHost(), DOMAIN, properties);
			setProperty(uri.getScheme(), PAGE_SCHEME, properties);
			setProperty(uri.getQuery(), PAGE_QUERY, properties);


			Map<String,String> props = uri.getProperties();

			if(null != props)
			{
				Set<String> keys = props.keySet();

				for(String key:keys)
				{
					setProperty( props.get(key), key, properties);
				}
			}
		}

		//Extract page categories into flattened map
		Map<String,String> categoryMap = pProps.getPageCategoryMap();
		if(null != categoryMap){
			Set<String> keys = categoryMap.keySet();

			for(String key:keys)
			{
				setProperty( categoryMap.get(key), key, properties);
			}
		}

	}

	private void propertiesFromBrowser(Browser bProps, Map<String,String> properties)
	{
		if(null == bProps)
			return;


		setProperty(bProps.getUserAgent(), USER_AGENT, properties);
		setProperty(bProps.getName(), BROWSER_NAME, properties);
		setProperty(bProps.getBrowserPlatform(), BROWSER_PLATFORM, properties);

		setProperty(bProps.getFlashVersion(), BROWSER_FLASH_VERSION, properties);
		setProperty(bProps.getBrowserLanguage(), BROWSER_LANGUAGE, properties);
		setProperty(bProps.getConnectionType(), BROWSER_CONNECTION_TYPE, properties);
		setProperty(bProps.getJavaVersion(), BROWSER_JAVA_VERSION, properties);
		setProperty(bProps.getUserAgent(), USER_AGENT, properties);

		if(null != bProps.getFlashEnabled() && bProps.getFlashEnabled())
			setProperty("true", BROWSER_FLASH_ENABLED, properties);

		if(null != bProps.getCookiesEnabled() && bProps.getCookiesEnabled())
			setProperty("true", BROWSER_COOKIES_ENABLED, properties);

		if(null != bProps.getJavaEnabled() && bProps.getJavaEnabled())
			setProperty("true", BROWSER_JAVA_ENABLED, properties);

		if(null != bProps.getJavascriptEnabled() && bProps.getJavascriptEnabled())
			setProperty("true", BROWSER_JAVASCRIPT_ENABLED, properties);

	}

	private void propertiesFromDeviceInfo(DeviceInfo dProps, Map<String,String> properties)
	{
		if(null == dProps)
			return;

		setProperty(dProps.getDeviceType(), BROWSER_DEVICE_TYPE, properties);
		//setProperty(dProps.getScreenHeight(), DEVICE_INFO_SCREEN_HEIGHT, properties);

		String height = dProps.getScreenHeight();
		String width = dProps.getScreenWidth();
		String depth = dProps.getScreenDepth();

		String screen_info = (height == null ? "" : height) + "x" + (width == null ? "" : width) + "@" + (depth == null ? "" : depth);
		setProperty(screen_info, SCREEN_INFO, properties);

		//Add mobile specific properties if channel is mobile
		String channel = properties.get(EVENT_CHANNEL);
		if("mobile".equalsIgnoreCase(channel)){
			setProperty(dProps.getDeviceLanguage(), MOBILE_DEVICE_LANGUAGE, properties);
			setProperty(dProps.getDeviceType(), MOBILE_DEVICE_TYPE, properties);
			setProperty(dProps.getManufacturer(), MOBILE_DEVICE_MANUFACTURER, properties);
			setProperty(dProps.getModel(), MOBILE_DEVICE_MODEL, properties);
			setProperty(dProps.getPlatform(), MOBILE_PLATFORM, properties);
			setProperty(dProps.getPlatformVersion(), MOBILE_PLATFORM_VERSION, properties);
			setProperty(dProps.getScreenHeight(), MOBILE_SCREEN_HEIGHT, properties);
			setProperty(dProps.getScreenWidth(), MOBILE_SCREEN_WIDTH, properties);
		}
	}

	private void propertiesFromServiceProvider(ServiceProvider sProps, Map<String,String> properties)
	{
		if(null == sProps)
			return;

		//Add mobile specific properties if channel is mobile
		String channel = properties.get(EVENT_CHANNEL);
		if("mobile".equalsIgnoreCase(channel)){
			setProperty(sProps.getName(), MOBILE_CARRIER_NAME, properties);
			setProperty(sProps.getMobileCountryCode(), MOBILE_COUNTRY_CODE, properties);
			setProperty(sProps.getNetworkCode(), MOBILE_NETWORK_CODE, properties);
		}
	}

	private void propertiesFromGeoLocation(Location lProps, Map<String,String> properties)
	{
		if(null == lProps)
			return;

		if(null == properties)
			return;

		setProperty(lProps.getCity(), GEO_CITY, properties);
		setProperty(lProps.getCountry(), GEO_COUNTRY, properties);
		setProperty(lProps.getRegion(), GEO_REGION, properties);
		setProperty(lProps.getSicCode(), GEO_SIC_CODE, properties);
		setProperty(lProps.getIpProperty(), GEO_IP_PROPERTY, properties);
		setProperty(lProps.getLat(), GEO_LATITUDE, properties);
		setProperty(lProps.getLon(), GEO_LONGITUDE, properties);

	}

	private void propertiesFromGeoFence(Geofence gProps, Map<String,String> properties)
	{
		if(null == gProps)
			return;

		if(null == properties)
			return;

		setProperty(gProps.getGeofenceCity(), GEOFENCE_CITY, properties);
		setProperty(gProps.getGeofenceId(), GEOFENCE_ID, properties);
		setProperty(gProps.getGeofenceName(), GEOFENCE_NAME, properties);
		setProperty(gProps.getGeofenceRegion(), GEOFENCE_REGION, properties);
		setProperty(gProps.getGeofenceState(), GEOFENCE_STATE, properties);
		Map<String, String> props = gProps.getProperties();
		if (props != null) {
			String keywords = props.get(GEOFENCE_KEYWORDS);
			if (keywords != null)
				setProperty(keywords, GEOFENCE_KEYWORDS, properties);
		}

//		setProperty(gProps.getGeofenceId(), GEO_LOCID, properties);
//		propertiesFromLocation(gProps.getLocation(), properties);
	}

	private void propertiesFromPromotion(Promotion lProps, Map<String,String> properties)
	{
		if(null == lProps)
			return;

		if(null == properties)
			return;

		setProperty(lProps.getPromotionName(), PROMOTION_NAME, properties);
		setProperty(lProps.getPromotionType(), PROMOTION_TYPE, properties);
		setProperty(lProps.getPlacementId(), PROMOTION_PLACEMENT, properties);
		setProperty(lProps.getCreativeName(), PROMOTION_CREATIVE, properties);
		setProperty(lProps.getTrackingCode(), PROMOTION_TRACKING_CODE, properties);
		setProperty(lProps.getRecordType(), PROMOTION_RECORD_TYPE, properties);

	}

	private void propertiesFromDownload(Download dProps, Map<String,String> properties)
	{
		if(null == dProps)
			return;

		if(null == properties)
			return;

		setProperty(dProps.getUrlLink(), DOCUMENT_URL, properties);

	}


	private void propertiesFromJourney(Journey jProps, Map<String,String> properties)
	{
		if(null == jProps)
			return;

		if(null == properties)
			return;

		setProperty(jProps.getStepName(), BUSINESS_PROCESS_STEP_NAME, properties);
		setProperty(jProps.getStepAttemptIndexInt(), BUSINESS_PROCESS_STEP_ATTEMPTS, properties);
		setProperty(properties.get("attrib1"), BUSINESS_PROCESS_ATTRIBUTE_1, properties);
		setProperty(properties.get("attrib2"), BUSINESS_PROCESS_ATTRIBUTE_2, properties);
	}

	private void propertiesFromProduct(Product pProps, Map<String,String> properties)
	{
		if(null == pProps)
			return;

		if(null == properties)
			return;

		setProperty(pProps.getAvailabilityMsg(), PRODUCT_AVAILABILITY_MESSAGE, properties);
		setProperty(pProps.getProductGroup(), PRODUCT_GROUP, properties);
		setProperty(pProps.getProductId(), PRODUCT_ID, properties);
		setProperty(pProps.getProductName(), PRODUCT_NAME, properties);
		setProperty(pProps.getProductSku(), PRODUCT_SKU, properties);
		setProperty(pProps.getQuantity(), PRODUCT_QUANTITY, properties);
		setProperty(pProps.getSavingsMsg(), PRODUCT_SAVINGS_MESSAGE, properties);
		setProperty(pProps.getShippingMsg(), PRODUCT_SHIPPING_MESSAGE, properties);
		setProperty(pProps.getUnitPriceDbl(), PRODUCT_UNIT_PRICE, properties);

	}

	private void propertiesFromInternalSearch(InternalSearch iProps, Map<String,String> properties)
	{
		if(null == iProps)
			return;

		if(null == properties)
			return;

		setProperty(iProps.getResultsDisplayed(), INTERNAL_SEARCH_RESULT_COUNT, properties);
		setProperty(iProps.getSearchTerm(), INTERNAL_SEARCH_TERM, properties);
		setProperty(iProps.getSearchName(), INTERNAL_SEARCH_NAME, properties);
		setProperty(iProps.getResultsDisplayFlagBoolean(), INTERNAL_SEARCH_FIELD_DISPLAY_FLAG, properties);
		setProperty(iProps.getSearchFieldId(), INTERNAL_SEARCH_FIELD_ID, properties);
		setProperty(iProps.getSearchFieldName(), INTERNAL_SEARCH_FIELD_NAME, properties);
	}

	private void propertiesFromLinkTracking(LinkTracking lProps, Map<String,String> properties)
	{
		if(null == lProps)
			return;

		if(null == properties)
			return;

		setProperty(lProps.getLinkTrackingId(), LINK_TRACKING_ID, properties);
		setProperty(lProps.getLinkTrackingLabel(), LINK_TRACKING_LABEL, properties);
		setProperty(lProps.getLinkTrackingGroup(), LINK_TRACKING_GROUP, properties);
	}

	private void propertiesFromEmail(Email eProps, Map<String,String> properties)
	{
		if(null == eProps)
			return;

		if(null == properties)
			return;

		setProperty(eProps.getRecipientDomain(), EMAIL_RECIPIENT_DOMAIN, properties);
		setProperty(eProps.getRecipientEmailAddress(), EMAIL_RECIPIENT_EMAIL_ADDRESS, properties);
		setProperty(eProps.getEmailProgramId(), EMAIL_PROGRAM_ID, properties);
		setProperty(eProps.getEmailReplyCorrelated(), EMAIL_REPLY_CORRELATED, properties);
		setProperty(eProps.getEmailSendAgentId(), EMAIL_SEND_AGENT_ID, properties);
		setProperty(eProps.getEmailSubject(), EMAIL_SUBJECT, properties);
		setProperty(eProps.getImprintURL(), EMAIL_IMPRINT_URL, properties);
		setProperty(eProps.getReason(), EMAIL_REASON, properties);
	}

	private Trigger getTrigger(EnhancedEvent event)
	{
		Trigger t = event.getTrigger();

		if(null == t)
		{
			t = Trigger.newBuilder().build();
			event.setTrigger(t);
		}

		return t;
	}

	private ContactResponse getContactResponse(EnhancedEvent event)
	{
		ContactResponse cr = event.getContactResponse();

		if(null == cr)
		{
			cr = ContactResponse.newBuilder().build();
			event.setContactResponse(cr);
		}

		return cr;
	}

	private Impression getImpression(EnhancedEvent event)
	{
		Impression i = event.getImpression();

		if(null == i)
		{
			i = Impression.newBuilder().build();
			event.setImpression(i);
		}

		return i;
	}

	private ECommerce getECommerce(EnhancedEvent event)
	{
		ECommerce e = event.getECommerce();

		if(null == e)
		{
			e = ECommerce.newBuilder().build();
			event.setECommerce(e);
		}

		return e;
	}

	private Location getBillingLocation(EnhancedEvent event)
	{
		ECommerce e = getECommerce(event);
		Location l = e.getBillingAddress();

		if(null == l)
		{
			l = Location.newBuilder().build();
			e.setBillingAddress(l);
		}

		return l;
	}

	private Location getShippingLocation(EnhancedEvent event)
	{
		ECommerce e = getECommerce(event);
		Location l = e.getShippingAddress();

		if(null == l)
		{
			l = Location.newBuilder().build();
			e.setShippingAddress(l);
		}

		return l;
	}

	private Activity getActivity(EnhancedEvent event)
	{
		Activity a = event.getActivity();

		if(null == a)
		{
			a = Activity.newBuilder().build();
			event.setActivity(a);
		}

		return a;
	}

	private Media getMedia(EnhancedEvent event)
	{
		Media m = event.getMedia();

		if(null == m)
		{
			m = Media.newBuilder().build();
			event.setMedia(m);
		}

		return m;
	}

	private Browser getBrowser(EnhancedEvent event)
	{
		Browser b = event.getBrowser();

		if(null == b)
		{
			b = Browser.newBuilder().build();
			event.setBrowser(b);
		}

		return b;
	}

	private DateTime getDateTime(EnhancedEvent event)
	{
		DateTime dt = event.getDate();

		if(null == dt)
		{
			dt = DateTime.newBuilder().build();
			event.setDate(dt);
		}

		return dt;
	}



	private Page getPage(EnhancedEvent event)
	{
		Page p = event.getPage();

		if(null == p)
		{
			p = Page.newBuilder().build();
			event.setPage(p);
		}

		//validate the URI too
		URI uri = getURI(p.getReferrerUri());

		//set it, it will be the same reference if it already existed or a new one if it didn't
		p.setReferrerUri(uri);

		uri = getURI(p.getUri());

		//set it, it will be the same reference if it already existed or a new one if it didn't
		p.setUri(uri);



		return p;
	}

	public URI getURI(URI uri)
	{
		if(null == uri)
			uri = URI.newBuilder().build();

		Map<String,String> properties = uri.getProperties();

		if(null == properties)
		{
			properties = new TreeMap<String,String>();
			uri.setProperties(properties);
		}

		return uri;
	}

	private DeviceInfo getDeviceInfo(EnhancedEvent event)
	{
		DeviceInfo d = event.getDeviceInfo();

		if(null == d)
		{
			d = DeviceInfo.newBuilder().build();
			event.setDeviceInfo(d);
		}

		return d;
	}

	private ServiceProvider getServiceProvider(EnhancedEvent event)
	{
		ServiceProvider s = event.getServiceProvider();

		if(null == s)
		{
			s = ServiceProvider.newBuilder().build();
			event.setServiceProvider(s);
		}

		return s;
	}

	private Visit getVisit(EnhancedEvent event)
	{
		Visit v = event.getVisit();

		if(null == v)
		{
			v = Visit.newBuilder().build();
			event.setVisit(v);
		}

		//force initialization
		URI uri = getURI(v.getReferrer());

		//set the returned value if already initialized it will be the same otherwise the newly initialized value
		v.setReferrer(uri);

		return v;
	}

	private Identity getIdentity(EnhancedEvent event)
	{
		Identity identity = event.getIdentity();

		if(null == identity)
		{
			identity = Identity.newBuilder().build();
			event.setIdentity(identity);
		}

		return identity;
	}

	private Location getGeoLocation(EnhancedEvent event)
	{
		Location loc = event.getIpInfo();

		if(null == loc)
		{
			loc = new Location();
			event.setIpInfo(loc);
		}

		return loc;
	}

	private Beacon getBeacon(EnhancedEvent event)
	{
		Beacon b = event.getBeacon();

		if(null == b)
		{
			b = Beacon.newBuilder().build();
			event.setBeacon(b);
		}

		return b;
	}

	private Geofence getGeofence(EnhancedEvent event)
	{
		Geofence b = event.getGeofence();

		if(null == b)
		{
			b = Geofence.newBuilder().build();
			event.setGeofence(b);
		}

		return b;
	}


	private App getApp(EnhancedEvent event)
	{
		App a = event.getApp();

		if(null == a)
		{
			a = App.newBuilder().build();
			event.setApp(a);
		}

		return a;
	}

	private Promotion getPromotion(EnhancedEvent event)
	{
		Promotion p = event.getPromotion();

		if(null == p)
		{
			p = Promotion.newBuilder().build();
			event.setPromotion(p);
		}

		return p;
	}

	private Download getDownload(EnhancedEvent event)
	{
		Download d = event.getDownload();

		if(null == d)
		{
			d = Download.newBuilder().build();
			event.setDownload(d);
		}

		return d;
	}

	private Journey getJourney(EnhancedEvent event)
	{
		Journey j = event.getJourney();

		if(null == j)
		{
			j = Journey.newBuilder().build();
			event.setJourney(j);
		}

		return j;
	}

	private Product getProduct(EnhancedEvent event)
	{
		Product p = event.getProduct();

		if(null == p)
		{
			p = Product.newBuilder().build();
			event.setProduct(p);
		}

		return p;
	}

	private InternalSearch getInternalSearch(EnhancedEvent event)
	{
		InternalSearch i = event.getInternalSearch();

		if(null == i)
		{
			i = InternalSearch.newBuilder().build();
			event.setInternalSearch(i);
		}

		return i;
	}

	private LinkTracking getLinkTracking(EnhancedEvent event)
	{
		LinkTracking lt = event.getLinkTracking();

		if(null == lt)
		{
			lt = LinkTracking.newBuilder().build();
			event.setLinkTracking(lt);
		}

		return lt;
	}

	private Email getEmail(EnhancedEvent event)
	{
		Email e = event.getEmail();

		if(null == e)
		{
			e = Email.newBuilder().build();
			event.setEmail(e);
		}

		return e;
	}

	private Integer intFromNumericStr(String value) {
		try {
			return (int) Double.parseDouble(value);
		} catch (Exception e) {
			return null;
		}
	}

	private Double doubleFromNumericStr(String value) {
		try {
			return Double.parseDouble(value);
		} catch (Exception e) {
			return null;
		}
	}

	public EnhancedEvent eventFromMap(Map<String, String> event)
	{
		if(null == event)
			return null;

		EnhancedEvent avEvent = new EnhancedEvent();
		//avEvent.setForms(new Forms());
		//avEvent.setProduct(new Product());
		avEvent.setIpInfo(new Location());
		avEvent.setApp(new App());
		//avEvent.setIot(new Iot());
		//avEvent.setPromotions(new Promotions());
		avEvent.setDeviceInfo(new DeviceInfo());


		//if we are mapping it presume engage
		//avEvent.set);//.setEventClass(eventClass.engage);

		Map<String,String> properties = new HashMap<String, String>();



		Set<String> keys = event.keySet();
		String lineAttr = null;
		String columnAttr = null;

		for(String key:keys)
		{
			String value = event.get(key);

			if(null == value /*|| value.length() <= 0*/)
				continue;

			switch(key.toLowerCase())
			{
				case "ruleversion":
					avEvent.setRuleVersion(value);
					break;
				case IDENTITY_VISIT_ID :
					getIdentity(avEvent).setVisitId(value);
					break;

				//TODO: this should be vid
				//but vid can come through in the properties as well
				//when we test converting to map and then back there can be
				//a collision but ultimately ESP needs the 'vid' key to match identity
				//if vid is mapped to enhanced location is shouldn't be in the properties
				case IDENTITY_ID :
					avEvent.setIdentityId(value);
					getIdentity(avEvent).setIdentityId(value);
					break;
				case CUSTOM_EVENT_GROUP_NAME_LOWERCASE :
					avEvent.setCustomGroupName(value);
					break;
				case CUSTOM_EVENT_NAME_LOWERCASE:
					avEvent.setCustomName(value);
					break;
				case CUSTOM_EVENT_REVENUE_VALUE_LOWERCASE:
					try{
						avEvent.setCustomRevenueDbl(new Double(value));
					}catch(NumberFormatException nfe){
						logger.error("Unable to parse custom revenue as a Double for this value: "+value);
					}
					break;
				case EVENT_NAME :
					avEvent.setEventName(value);

					//if we have a designedId then use the name as the designedName as well
					if(avEvent.getEventDesignedId() != null && avEvent.getEventDesignedId().length() > 0) {
						//only assign it if we don't already have a value assigned
						if(null == avEvent.getEventDesignedName())
							avEvent.setEventDesignedName(value);
					}

					break;

				case EVENT_DESIGNED_NAME :
					//avEvent.setEventName(value);

					//if we have a designedId then use the name as the designedName as well
					//if(avEvent.getEventDesignedId() != null && avEvent.getEventDesignedId().length() > 0)
					avEvent.setEventDesignedName(value);

					break;
				case EVENT_UUID :
					avEvent.setEventDesignedId(value);

					//if we have a designedId then use the name as the designedName as well
					if(avEvent.getEventName() != null && avEvent.getEventName().length() > 0) {
						//only set it if we don't already have a value assigned
						if(null == avEvent.getEventDesignedName())
							avEvent.setEventDesignedName(avEvent.getEventName());
					}

					break;
//enable when supported by enhanced service
				case EVENT_GUID :
					avEvent.setGuid(value);
					break;

				case EVENT_CHANNEL :
					avEvent.setChannelType(value);
					break;

				case EVENT_CHANNEL_ID :
					avEvent.setChannelId(value);
					break;

				//set as eventType string
				case EVENT :
//					properties.put(EVENT, value);
					avEvent.setEventType(value);
					break;

				case EVENT_CATEGORY :
//					properties.put(EVENT, value);
					try
					{
						if(value.length() > 0)
							avEvent.setEventCategory(EventCategory.valueOf(value));
					}
					catch(Exception ex)
					{
						logger.error("Error converting event category: " + value);
					}
					break;



				//added for ESP since it can't consume '.' notation
				//so just strip it out, since the original should continue to exist
				case REFERER_SEARCH :
					break;

				//added for ESP since it can't consume '.' notation
				//so just strip it out, since the original should continue to exist
				case REFERER_SOCIAL :
					break;

				case SESSION :
					avEvent.setSessionId(value);
					getIdentity(avEvent).setSessionId(value);
					break;

				case ACCOUNT :
					avEvent.setExternalTenantId(value);
					break;

				case USER_AGENT :
					getBrowser(avEvent).setUserAgent(value);
					break;

				case BROWSER_DEVICE_TYPE :
					//getBrowser(avEvent).setBrowserType(value);
					getDeviceInfo(avEvent).setDeviceType(value);
					break;

				case BROWSER_NAME :
					getBrowser(avEvent).setName(value);
					break;

				case BROWSER_PLATFORM :
					getBrowser(avEvent).setBrowserPlatform(value);
					break;

				case GEO_IP :
					//getBrowser(avEvent).setIpAddress(value);
					avEvent.setIpAddress(value);
					break;

				case GEO_CITY :
					getGeoLocation(avEvent).setCity(value);
					break;

				case GEO_COUNTRY :
					getGeoLocation(avEvent).setCountry(value);
					break;

				case GEO_REGION :
					getGeoLocation(avEvent).setRegion(value);
					break;


				case REFERER_PAGE_URI :
					getPage(avEvent).getReferrerUri().setUri(value);
					break;

				case REFERER_PATH :
					getPage(avEvent).getReferrerUri().setPath(value);
					break;

				case REFERER_HOST :
					getPage(avEvent).getReferrerUri().setHost(value);
					break;

				case REFERER_SCHEME :
					getPage(avEvent).getReferrerUri().setScheme(value);
					break;

				case PAGE_ID :
					getPage(avEvent).setPageId(value);
					break;

				case PAGE_VIEW_SEQUENCE_NUM :
					getPage(avEvent).setViewSequenceNum(intFromNumericStr(value));
					break;

				case MESSAGE:
					getPage(avEvent).setErrorDescription(value);
					break;


				//line and column get broken apart / joined together...
				case LINE:
					lineAttr = value;

					if(null != columnAttr && null != lineAttr)
					{
						//"line: x, column: y"
						getPage(avEvent).setErrorLocation(LINE + ":" + lineAttr + "," + COLUMN + ":" + columnAttr);
					}

					break;

				case COLUMN:
					columnAttr = value;

					if(null != columnAttr && null != lineAttr)
					{
						//"line: x, column: y"
						getPage(avEvent).setErrorLocation(LINE + ":" + lineAttr + "," + COLUMN + ":" + columnAttr);
					}

					break;


//				case TagConstants.CHANNEL_USER_ID :
//					avEvent.set(value);
//					break;


//				TenantId is the internalId, account is external
//				case "account" :
//					avEvent.setTenantId(value);
//					break;

				case TIMESTAMP :
					try
					{
						if(value.length() > 0)
						{
							Long ts = Long.decode(value);
							getDateTime(avEvent).setGeneratedTimestamp(ts);
						}
					}
					catch(Exception ex)
					{
						logger.error("Timestamp parse error: " + ex.getMessage());
					}

					break;

				case INTERNAL_TENANT_ID :
					Integer id = Integer.decode(value);
					avEvent.setInternalTenantId(id);
					break;

				case PAGE_LOAD_ID :
					getPage(avEvent).setLoadId(value);
					break;

				case PAGE_TITLE :
					getPage(avEvent).setPageTitle(value);
					break;

				case PAGE_URI :
					getPage(avEvent).getUri().setUri(value);
					break;

				case PAGE_PATH :
					getPage(avEvent).getUri().setPath(value);
					break;

				case PAGE_HOST :
					getPage(avEvent).getUri().setHost(value);
					break;

				case PAGE_SCHEME :
					getPage(avEvent).getUri().setScheme(value);
					break;

				case PAGE_QUERY :
					getPage(avEvent).getUri().setQuery(value);
					break;

				case BROWSER_FLASH_ENABLED :
					getBrowser(avEvent).setFlashEnabled(Boolean.parseBoolean(value));
					break;

				case BROWSER_FLASH_VERSION :
					getBrowser(avEvent).setFlashVersion(value);
					break;

				case BROWSER_LANGUAGE :
					getBrowser(avEvent).setBrowserLanguage(value);
					break;

				case BROWSER_CONNECTION_TYPE :
					getBrowser(avEvent).setConnectionType(value);
					break;

				case BROWSER_COOKIES_ENABLED :
					getBrowser(avEvent).setCookiesEnabled(Boolean.parseBoolean(value));
					break;

				case BROWSER_JAVA_ENABLED :
					getBrowser(avEvent).setJavaEnabled(Boolean.parseBoolean(value));
					break;

				case BROWSER_JAVA_VERSION :
					getBrowser(avEvent).setJavaVersion(value);
					break;

				case BROWSER_JAVASCRIPT_ENABLED :
					getBrowser(avEvent).setJavascriptEnabled(Boolean.parseBoolean(value));
					break;

				case VISITOR_STATE :
					getVisit(avEvent).setVisitorState(value);
					break;

				case VISIT_ID :
					getVisit(avEvent).setVisitId(value);
					break;

				case VISITOR_REFFERAL_URI :
					getVisit(avEvent).getReferrer().setUri(value);
					break;

				case TRAFFIC_SOURCE_CREATIVE:
					getVisit(avEvent).setTrafficSourceCreative(value);
					break;

				case TRAFFIC_SOURCE_NAME:
					getVisit(avEvent).setTrafficSourceName(value);
					break;

				case TRAFFIC_SOURCE_PLACEMENT:
					getVisit(avEvent).setTrafficSourcePlacement(value);
					break;

				case TRAFFIC_SOURCE_TRACKING_CODE:
					getVisit(avEvent).setTrafficSourceTrackingCode(value);
					break;

				case TRAFFIC_SOURCE_TYPE:
					getVisit(avEvent).setTrafficSourceType(value);
					break;

				case SCREEN_INFO:
				{
					try
					{
						String screenInfo = value;
						if(screenInfo != null)
						{
							int start = screenInfo.indexOf("x");
							int end = screenInfo.indexOf("@");
							if(start!= -1)
							{
								String height = screenInfo.substring(0, start);
								getDeviceInfo(avEvent).setScreenHeight(height);
								if(end!= -1)
								{
									String width = screenInfo.substring(start+1, end);
									getDeviceInfo(avEvent).setScreenWidth(width);

									String depth = screenInfo.substring(end+1);
									getDeviceInfo(avEvent).setScreenDepth(depth);
								}
								//what if the @ isn't included, is that possible?
								else
								{
									String width = screenInfo.substring(start+1);
									getDeviceInfo(avEvent).setScreenWidth(width);
								}
							}
						}

					}
					catch(Exception ex)
					{
						logger.error("Error parsing screen info: " + ex.getMessage());
					}
				}
				break;

				case OBFUSCATE_IP_ADDRESS :
					try {
						avEvent.setObfuscateIpAddress(ObfuscateIpAddress.valueOf(value));
					} catch (Exception e) {
						logger.error("Error parsing ObfuscateIpAddress", e);
					}
					break;

				case DOMAIN:
					//avEvent.setDomain(value);
					getPage(avEvent).getUri().setHost(value);
					break;
				case MEDIA_URL:
					getMedia(avEvent).setMediaUrl(value);
					break;

				case MEDIA_PLAYER:
					getMedia(avEvent).setMediaPlayer(value);
					break;

				case MEDIA_PLAYER_VERSION:
					getMedia(avEvent).setMediaPlayerVersion(value);
					break;

				case MEDIA_DURATION:

					if(value.length() > 0)
					{
						try
						{
							getMedia(avEvent).setMediaLength(Float.valueOf(value));
						}
						catch(Exception ex)
						{
							logger.error("Media duration parse error: " + ex.getMessage());
						}
					}
					break;
				case MEDIA_POSITION:

					if(value.length() > 0)
					{
						try
						{
							getMedia(avEvent).setMediaPosition(Long.valueOf(value));
						}
						catch(Exception ex)
						{
							logger.error("Media position parse error: " + ex.getMessage());
						}
					}
					break;
				case MEDIA_ACTION:
					try {
						getMedia(avEvent).setMediaAction(MediaAction.valueOf(value));
					} catch (Exception e) {
						logger.error("Error parsing MediaAction", e);
					}
					break;
				case MEDIA_FIRST_INTERACTION_FLAG:
					getMedia(avEvent).setMediaFirstInteractionFlag(Boolean.parseBoolean(value));
					break;
				case MOBILE_CARRIER_NAME:
					getServiceProvider(avEvent).setName(value);
					break;
				case MOBILE_COUNTRY_CODE:
					getServiceProvider(avEvent).setMobileCountryCode(value);
					break;
				case MOBILE_DEVICE_LANGUAGE:
					getDeviceInfo(avEvent).setDeviceLanguage(value);
					break;
				case MOBILE_DEVICE_MANUFACTURER:
					getDeviceInfo(avEvent).setManufacturer(value);
					break;
				case MOBILE_DEVICE_MODEL:
					getDeviceInfo(avEvent).setModel(value);
					break;
				case MOBILE_DEVICE_TYPE:
					getDeviceInfo(avEvent).setDeviceType(value);
					break;
				case MOBILE_NETWORK_CODE:
					getServiceProvider(avEvent).setNetworkCode(value);
					break;
				case MOBILE_PLATFORM:
					getDeviceInfo(avEvent).setPlatform(value);
					break;
				case MOBILE_PLATFORM_VERSION:
					getDeviceInfo(avEvent).setPlatformVersion(value);
					break;
				case MOBILE_SCREEN_HEIGHT:
					getDeviceInfo(avEvent).setScreenHeight(value);
					break;
				case MOBILE_SCREEN_WIDTH:
					getDeviceInfo(avEvent).setScreenWidth(value);
					break;

				case CART_ITEM_COUNT:
					try
					{
						if(value.length() > 0)
							getECommerce(avEvent).setItemCount(intFromNumericStr(value));
					}
					catch(Exception ex)
					{
						logger.error("Cart item count parse error: " + ex.getMessage());
					}

					break;

				case CART_TYPE:
					getECommerce(avEvent).setECommerceAction(getECommerceAction(value));
					break;

				case CART_ID_LOWERCASE:
					getECommerce(avEvent).setCartId(value);
					break;

				case PAYMENT_TYPE_LOWERCASE:
					getECommerce(avEvent).setPaymentType(value);
					break;

				case DELIVERY_TYPE_LOWERCASE:
					getECommerce(avEvent).setDeliveryType(value);
					break;

				case TAX:
					getECommerce(avEvent).setTotalTaxDbl(doubleFromNumericStr(value));
					break;

				case ORDER_ID_LOWERCASE:
					getECommerce(avEvent).setOrderId(value);
					break;

				case TOTAL_COST_LOWERCASE:
					getECommerce(avEvent).setTotalValueDbl(doubleFromNumericStr(value));
					break;

				case SHIPPING_COST_LOWERCASE:
					getECommerce(avEvent).setTotalShippingDbl(doubleFromNumericStr(value));
					break;

				case BILLING_CITY_LOWERCASE:
					getBillingLocation(avEvent).setCity(value);
					break;

				case BILLING_COUNTRY_LOWERCASE:
					getBillingLocation(avEvent).setCountry(value);
					break;

				case BILLING_POSTCODE_LOWERCASE:
					getBillingLocation(avEvent).setPostalCode(value);
					break;

				case BILLING_REGION_LOWERCASE:
					getBillingLocation(avEvent).setRegion(value);
					break;

				case SHIPPING_CITY_LOWERCASE:
					getShippingLocation(avEvent).setCity(value);
					break;

				case SHIPPING_COUNTRY_LOWERCASE:
					getShippingLocation(avEvent).setCountry(value);
					break;

				case SHIPPING_POSTCODE_LOWERCASE:
					getShippingLocation(avEvent).setPostalCode(value);
					break;

				case SHIPPING_REGION_LOWERCASE:
					getShippingLocation(avEvent).setRegion(value);
					break;

				case RESPONSE_TRACKING_CODE:
					getContactResponse(avEvent).setResponseTrackingCode(value);
					break;

				case RESPONSE_TYPE:
					getContactResponse(avEvent).setResponseType(value);
					break;

				case RESPONSE_VALUE:
					getContactResponse(avEvent).setResponseValue(value);
					break;

				case CONTACT_RESPONSE:
					getContactResponse(avEvent).setContactResponseCode(value);
					break;

				case CONTACT_RESPONSE_TAG:
					getContactResponse(avEvent).setContactResponseTag(value);
					break;

				case CONTROL_GROUP:
					getImpression(avEvent).setControlGroup(value);
					break;

				case CREATIVE_ID:
					getImpression(avEvent).setCreativeId(value);
					break;

				case CREATIVE_VERSION_ID:
					getImpression(avEvent).setCreativeVersionId(value);
					break;

				case CREATIVE_CONTENT:
					getImpression(avEvent).setCreativeContent(value);
					break;

				case GOAL_EVENT_LOWERCASE:
					getImpression(avEvent).setGoalEvent(value);
					break;

				case GOAL_ID:
					getImpression(avEvent).setGoalId(value);
					break;

				case SPOT_ID:
					getImpression(avEvent).setSpotId(value);
					break;

				case TASK_ID:
					getImpression(avEvent).setTaskId(value);
					break;

				case TASK_VERSION_ID:
					getImpression(avEvent).setTaskVersionId(value);
					break;

				case VARIANT_ID:
					getImpression(avEvent).setVariantId(value);
					break;

				case IMPRINT_ID:
					getImpression(avEvent).setImprintId(value);
					break;
					
				case OCCURRENCE_ID:
					getImpression(avEvent).setOccurrenceId(value);
					break;

				case IS_CONTROL_GROUP:
					try
					{
						getImpression(avEvent).setIsControlGroup(Boolean.valueOf(value));
					}
					catch(Exception ex)
					{
						logger.error("Error parsing is control group property: " + ex.getMessage());

					}

					break;

				case MERGETAG_ATTRIBUTE_NAME:
					getImpression(avEvent).setMergeTagAttributeName(value);
					break;

				case MERGETAG_IA_SAFE_ID:
					getImpression(avEvent).setMergeTagIaSafeId(value);
					break;

				case MESSAGE_ID:
					getImpression(avEvent).setMessageId(value);
					break;

				case MESSAGE_VERSION_ID:
					getImpression(avEvent).setMessageVersionId(value);
					break;  

				case SEGMENT_ID:
					getImpression(avEvent).setSegmentId(value);
					break;

				case SEGMENT_VERSION_ID:
					getImpression(avEvent).setSegmentVersionId(value);
					break;  

				case LOGON_TYPE:
					getIdentity(avEvent).setLoginType(value);
					break;

				case LOGON_VALUE:
					getIdentity(avEvent).setLoginValue(value);
					break;

				case PARENT_EVENT_UID:
					avEvent.setParentEventUid(value);
					break;

				case ACTIVITY_ID:
					getActivity(avEvent).setActivityId(value);
					break;

				case ABTEST_PATH_ID:
					getActivity(avEvent).setAbPathAssignmentId(value);
					break;

				case ACTIVITY_IA_TAG_VALUE:
					getActivity(avEvent).setIaTagValue(value);
					break;

				case ACTIVITY_NAME:
					getActivity(avEvent).setActivityName(value);
					break;

				case ACTIVITY_NODE_ID:
					getActivity(avEvent).setActivityNodeId(value);
					break;

				case ACTIVITY_TASK_TYPE:
					getActivity(avEvent).setActivityTaskType(value);
					break;

				case ACTIVITY_TIME_BOX:
					getActivity(avEvent).setActivityTimebox(value);
					break;

				case ACTIVITY_CANCEL_GOALS:
					getActivity(avEvent).setActivityCancelGoals(value);
					break;

				case ACTIVITY_TRIGGER_EVENT_ID:
					getTrigger(avEvent).setTriggerEventId(value);
					break;

				case TRIGGER_EVENT_EXEC_CTX:
					getTrigger(avEvent).setExecutionContext(value);
					break;

				case TRIGGER_EVENT_EXP_W_FREQ:
					getTrigger(avEvent).setExpressionFrequency(value);
					break;

				case TRIGGER_EVENT_EXP_ID:
					getTrigger(avEvent).setExpressionId(value);
					break;

				case TRIGGER_EVENT_EXP_FILTER_TOTAL:
					getTrigger(avEvent).setExpressionFilterTotal(value);
					break;

				case BEACON_ID:
					getBeacon(avEvent).setBeaconId(value);
					break;

				case BEACON_MAJOR:
					getBeacon(avEvent).setBeaconMajor(value);
					break;

				case BEACON_MINOR:
					getBeacon(avEvent).setBeaconMinor(value);
					break;

				case BEACON_NAME:
					getBeacon(avEvent).setBeaconName(value);
					break;

				case BEACON_UUID:
					getBeacon(avEvent).setBeaconUuid(value);
					break;
				case BEACON_KEYWORDS:
					Map<String, String> keywordsProperties = getBeacon(avEvent).getProperties();
					if (keywordsProperties == null)
					{
						keywordsProperties = new HashMap<String, String>();
						getBeacon(avEvent).setProperties(keywordsProperties);
					}
					keywordsProperties.put(BEACON_KEYWORDS, value);

					//shared with geofence
					keywordsProperties = getGeofence(avEvent).getProperties();
					if (keywordsProperties == null)
					{
						keywordsProperties = new HashMap<String, String>();
						getGeofence(avEvent).setProperties(keywordsProperties);
					}
					keywordsProperties.put(GEOFENCE_KEYWORDS, value);
					break;

				case GEOFENCE_NAME:
					getGeofence(avEvent).setGeofenceName(value);
					break;
				case GEOFENCE_CITY:
					getGeofence(avEvent).setGeofenceCity(value);
					break;
				case GEOFENCE_STATE:
					getGeofence(avEvent).setGeofenceState(value);
					break;
				case GEOFENCE_REGION:
					getGeofence(avEvent).setGeofenceRegion(value);
					break;
				case GEOFENCE_ID:
					getGeofence(avEvent).setGeofenceId(value);
					break;

				case APP_LANGUAGE:
					getApp(avEvent).setAppLanguage(value);
					break;

				case APP_VERSION:
					getApp(avEvent).setAppVersion(value);
					break;

				case APP_ID:
					getApp(avEvent).setAppId(value);
					break;

				case APP_SDK_VERSION:
					getApp(avEvent).setSdkVersion(value);
					break;

				case PROMOTION_CREATIVE_LOWERCASE:
					getPromotion(avEvent).setCreativeName(value);
					break;

				case PROMOTION_NAME_LOWERCASE:
					getPromotion(avEvent).setPromotionName(value);
					break;

				case PROMOTION_PLACEMENT_LOWERCASE:
					getPromotion(avEvent).setPlacementId(value);
					break;

				case PROMOTION_RECORD_TYPE_LOWERCASE:
					try {
						getPromotion(avEvent).setRecordType(PromotionRecordType.valueOf(value));
					} catch (IllegalArgumentException e) {
						logger.error("Error parsing PromotionRecordType");
					}
					break;

				case PROMOTION_TRACKING_CODE_LOWERCASE:
					getPromotion(avEvent).setTrackingCode(value);
					break;

				case PROMOTION_TYPE_LOWERCASE:
					getPromotion(avEvent).setPromotionType(value);
					break;

				case DOCUMENT_URL:
					getDownload(avEvent).setUrlLink(value);
					break;

				case BUSINESS_PROCESS_STEP_NAME_LOWERCASE:
					getJourney(avEvent).setStepName(value);
					break;

				case BUSINESS_PROCESS_STEP_ATTEMPTS_LOWERCASE:
					getJourney(avEvent).setStepAttemptIndexInt(intFromNumericStr(value));
					break;

				case BUSINESS_PROCESS_ATTRIBUTE_1_LOWERCASE:
					setProperty(value, "attrib1", properties);
					break;

				case BUSINESS_PROCESS_ATTRIBUTE_2_LOWERCASE:
					setProperty(value, "attrib2", properties);
					break;

				case PRODUCT_AVAILABILITY_MESSAGE:
					getProduct(avEvent).setAvailabilityMsg(value);
					break;

				case PRODUCT_GROUP:
					getProduct(avEvent).setProductGroup(value);
					break;

				case PRODUCT_ID:
					getProduct(avEvent).setProductId(value);
					break;

				case PRODUCT_NAME:
					getProduct(avEvent).setProductName(value);
					break;

				case PRODUCT_QUANTITY:
					getProduct(avEvent).setQuantity(intFromNumericStr(value));
					break;

				case PRODUCT_SKU:
					getProduct(avEvent).setProductSku(value);
					break;

				case PRODUCT_UNIT_PRICE:
					getProduct(avEvent).setUnitPriceDbl(doubleFromNumericStr(value));
					break;

				case PRODUCT_SAVINGS_MESSAGE:
					getProduct(avEvent).setSavingsMsg(value);
					break;

				case PRODUCT_SHIPPING_MESSAGE:
					getProduct(avEvent).setShippingMsg(value);
					break;

				case INTERNAL_SEARCH_RESULT_COUNT_LOWERCASE:
					getInternalSearch(avEvent).setResultsDisplayed(intFromNumericStr(value));
					break;

				case INTERNAL_SEARCH_TERM_LOWERCASE:
					getInternalSearch(avEvent).setSearchTerm(value);
					break;

				case INTERNAL_SEARCH_NAME_LOWERCASE:
					getInternalSearch(avEvent).setSearchName(value);
					break;

				case INTERNAL_SEARCH_FIELD_DISPLAY_FLAG_LOWERCASE:
					getInternalSearch(avEvent).setResultsDisplayFlagBoolean(Boolean.parseBoolean(value));
					break;

				case INTERNAL_SEARCH_FIELD_ID_LOWERCASE:
					getInternalSearch(avEvent).setSearchFieldId(value);
					break;

				case INTERNAL_SEARCH_FIELD_NAME_LOWERCASE:
					getInternalSearch(avEvent).setSearchFieldName(value);
					break;

				case LINK_TRACKING_ID_LOWERCASE:
					getLinkTracking(avEvent).setLinkTrackingId(value);
					break;

				case LINK_TRACKING_LABEL_LOWERCASE:
					getLinkTracking(avEvent).setLinkTrackingLabel(value);
					break;

				case LINK_TRACKING_GROUP_LOWERCASE:
					getLinkTracking(avEvent).setLinkTrackingGroup(value);
					break;

				case EMAIL_RECIPIENT_DOMAIN_LOWERCASE:
					getEmail(avEvent).setRecipientDomain(value);
					break;

				case EMAIL_RECIPIENT_EMAIL_ADDRESS_LOWERCASE:
					getEmail(avEvent).setRecipientEmailAddress(value);
					break;

				case EMAIL_PROGRAM_ID_LOWERCASE:
					getEmail(avEvent).setEmailProgramId(value);
					break;

				case EMAIL_REPLY_CORRELATED_LOWERCASE:
					getEmail(avEvent).setEmailReplyCorrelated(value);
					break;

				case EMAIL_SEND_AGENT_ID_LOWERCASE:
					getEmail(avEvent).setEmailSendAgentId(value);
					break;
					
				case EMAIL_SUBJECT_LOWERCASE:
					getEmail(avEvent).setEmailSubject(value);
					break;

				case EMAIL_IMPRINT_LOWERCASE:
					getEmail(avEvent).setImprintURL(value);
					break;

				case EMAIL_REASON_LOWERCASE:
					getEmail(avEvent).setReason(value);
					break;

				default:

					if(key.startsWith(PAGE_PROPERTY_PREFIX))
					{
						if(value.length() > 0)
							getPage(avEvent).getUri().getProperties().put(key, value);
					}
					else if(key.startsWith(REFERER_PROPERTY_PREFIX))
					{
						if(value.length() > 0)
							getPage(avEvent).getReferrerUri().getProperties().put(key, value);
					}
					else
					{
						setProperty(value, key, properties);
					}
			}
		}

		avEvent.setProperties(properties);


		return avEvent;
	}


}
