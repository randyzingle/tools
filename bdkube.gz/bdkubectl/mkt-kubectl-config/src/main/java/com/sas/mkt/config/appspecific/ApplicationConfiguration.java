package com.sas.mkt.config.appspecific;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.sas.mkt.config.core.Configuration;

@Component
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false, ignoreInvalidFields = false)
public class ApplicationConfiguration extends Configuration {

	/**
	 * Do not change the following fields - used by the framework
	 */
	private String componentName;

	// passed in as environment variables in EC2 & Docker
	private String tierName;
	private String configServiceUrl;
	private String configStackName;

	// Console metrics
	private boolean consoleMetricsReporterActivated;
	private String consoleMetricsFilters;
	private int consoleMetricsReporterRateSec;

	// Dynamically change log levels
	private String logLevelOverride;
	// END Do not change the following

	/**
	 * These are application specific and can be changed
	 */
	// AppSpecific Properties

	// End AppSpecific Properties ... add getters and setters for the props you
	// added

	public String getComponentName() {
		return componentName;
	}

	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

	public String getTierName() {
		return tierName;
	}

	public void setTierName(String tierName) {
		this.tierName = tierName;
	}

	public String getConfigServiceUrl() {
		return configServiceUrl;
	}

	public void setConfigServiceUrl(String configServiceUrl) {
		this.configServiceUrl = configServiceUrl;
	}

	public String getConfigStackName() {
		return configStackName;
	}

	public void setConfigStackName(String configStackName) {
		this.configStackName = configStackName;
	}

	public boolean isConsoleMetricsReporterActivated() {
		return consoleMetricsReporterActivated;
	}

	public void setConsoleMetricsReporterActivated(boolean consoleMetricsReporterActivated) {
		this.consoleMetricsReporterActivated = consoleMetricsReporterActivated;
	}

	public String getConsoleMetricsFilters() {
		return consoleMetricsFilters;
	}

	public void setConsoleMetricsFilters(String consoleMetricsFilters) {
		this.consoleMetricsFilters = consoleMetricsFilters;
	}

	public int getConsoleMetricsReporterRateSec() {
		return consoleMetricsReporterRateSec;
	}

	public void setConsoleMetricsReporterRateSec(int consoleMetricsReporterRateSec) {
		this.consoleMetricsReporterRateSec = consoleMetricsReporterRateSec;
	}


	public String getLogLevelOverride() {
		return logLevelOverride;
	}

	public void setLogLevelOverride(String logLevelOverride) {
		this.logLevelOverride = logLevelOverride;
	}

	@Override
	public String toString() {
		return "ApplicationConfiguration [componentName=" + componentName + ", tierName=" + tierName
				+ ", configServiceUrl=" + configServiceUrl + ", configStackName=" + configStackName
				+ ", consoleMetricsReporterActivated=" + consoleMetricsReporterActivated + ", consoleMetricsFilters="
				+ consoleMetricsFilters + ", consoleMetricsReporterRateSec=" + consoleMetricsReporterRateSec
				+ ", logLevelOverride=" + logLevelOverride + "]";
	}



}
