package com.sas.mkt.kafka.clients.consumers.simple;

import java.util.Arrays;
import java.util.Date;
import java.util.Properties;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;

import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;

/**
 * @author razing
 *
 */
public class SimpleStringConsumer {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private boolean done = false;
	
	private long first = 0L;
	private long last = 0L;
	Consumer<String, String> consumer;
	private ApplicationConfiguration appConfig = new ApplicationConfiguration();

	public static void main(String[] args) {
		SimpleStringConsumer bc = new SimpleStringConsumer();
		bc.simpleConsumeMessages();
	}

	private void simpleConsumeMessages() {
		// Set up the consumer
		KafkaConnectionUtils kcu;
		try {
			kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			return;
		}
		// If we want to re-read from the beginning each time then we need to make this unique
		String groupID = appConfig.getTierName() + "-" + appConfig.getComponentName() + System.currentTimeMillis();
		
		Properties props = kcu.getKafkaConsumerProperties();
		// also need this to read from the beginning each time
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
				org.apache.kafka.common.serialization.StringDeserializer.class);
		props.remove(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG);
		props.remove(KafkaAvroDeserializerConfig.SCHEMA_REGISTRY_URL_CONFIG);
		
		
		consumer = new KafkaConsumer<>(props);
		String topic = "connect-status";
        consumer.subscribe(Arrays.asList(topic));

		// Consume Messages
		int cnt = 0;	
		Thread t = new Thread(new KillSwitch());
		t.start();
		System.out.println("CONSUMING MESSAGES.....");

		while (!done) {	
			ConsumerRecords<String, String> records = consumer.poll(1000);
			for (ConsumerRecord<String, String> record: records) {
				cnt++;
				String value = record.value();
				String s = String.format("%s, %d, %d, %s, %s", record.key(), cnt, record.timestamp(), new Date(record.timestamp()).toString(), value);
				System.out.println(s);
				long timestamp = record.timestamp();
				if (first == 0) {
					first = timestamp;
				}
				last = timestamp;
				if (cnt % 1000 == 0) {
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}	
		}
		System.out.printf("Read %d messages%n", cnt);
		System.out.println("first message: " + new Date(first).toString());
		System.out.println("last message: " + new Date(last).toString());
		consumer.close();
	}
	
	public class KillSwitch implements Runnable {

		@Override
		public void run() {
			try {
				Thread.sleep(300000);
				done = true;
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			
		}
		
	}
}
