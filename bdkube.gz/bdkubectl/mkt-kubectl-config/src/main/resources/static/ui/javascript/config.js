// load the config data

var configApp = angular.module("configApp", []);

configApp.controller("LogCtrl", function ($scope, $http, $location) {
  var baseUrl = $location.$$absUrl;
  var contextPath = '/' + $location.$$absUrl.split('/')[3];
  //var contextPath = 'http://localhost:8080/kafkaAdmin'; // local development
  console.log(baseUrl);
  $scope.getLogLevels = function () {
    $http({
      method: 'GET',
      url: contextPath + '/config/logs'
    }).then(function successCallback(response) {
      $scope.loggers = response.data;
      console.log('response');
      console.log($scope.loggers);
      console.log('end response');
    }, function errorCallback(response) {
      console.log('failed to get logger levels from server');
    });
  }
  $scope.getLogLevels();
  $scope.editing = false;

  $scope.cancelEdit = function() {
    $scope.editStatus = '';
    $scope.resetFields();
    $scope.editing = false;
  }

  $scope.resetFields = function() {
    if ($scope.loggers === null || $scope.rollback === null) {
      // we are in some weird state here - just close the editor
    } else {
      $scope.logger.level = $scope.rollback.level;
    }
  }

  $scope.edit = function() {
    // Don't need validation here?
    $scope.updateLogLevels($scope.logger);

  }

  $scope.updateLogLevels = function (logger) {
    console.log('POSTING: ');
    console.log(logger);
    url = contextPath + '/config/logs';
    config = 'application/json';
    $http.post(url, logger, config).then(function successCallback(response) {
      // update grid with data & success message
      console.log(response);
      $scope.editing = false;
    }, function errorCallback(response) {
      // update UI with error message
      console.log(response);
      $scope.editStatus = 'Failed to update logger';
    });
  }

  $scope.levelList = ['ERROR', 'WARN', 'INFO', 'DEBUG', 'TRACE'];

  $scope.showEditForm = function(logger) {
    // List of things we won't allow a user to edit or delete

    $scope.editing = true;
    $scope.logger = logger;
    rollback = {};
    rollback.level = logger.level;
    $scope.rollback = rollback;

    console.log("Setup Editor")
    console.log($scope.logger);
    console.log($scope.rollback);
  }
});

configApp.controller("ConfigCtrl", function ($scope, $http, $location) {
  var lockedPropertiesList = ['componentName [locked]', 'tierName [locked]', 'configServiceUrl [locked]', 'configStackName [locked]', 'serviceDiscoveryUrl [locked]'];
  var component_global = "component_global"
  var baseUrl = $location.$$absUrl;
  var contextPath = '/' + $location.$$absUrl.split('/')[3];
  //var contextPath = 'http://localhost:8080/kafkaAdmin'; // local development
  //console.log(baseUrl);
  console.log(contextPath + '/config/props');
  $scope.getProps = function () {
    $http({
      method: 'GET',
      url: contextPath + '/config/props'
    }).then(function successCallback(response) {
      $scope.props = response.data;
      console.log($scope.props);
      for (var i=0; i<$scope.props.application.items.length; i++) {
        //console.log($scope.props.application.items[i].name, $scope.props.application.items[i].value);
        if ($scope.props.application.items[i].name == 'componentName') {
          $scope.componentName = $scope.props.application.items[i].value;
          $scope.props.application.items[i].name += ' [locked]';
        }
        else if ($scope.props.application.items[i].name == 'configServiceUrl') {
          $scope.configServiceUrl = $scope.props.application.items[i].value;
          $scope.props.application.items[i].name += ' [locked]';
        }
        else if ($scope.props.application.items[i].name == 'tierName') {
          $scope.tierName = $scope.props.application.items[i].value;
          $scope.props.application.items[i].name += ' [locked]';
        }
        else if ($scope.props.application.items[i].name == 'configStackName') {
          $scope.tierName = $scope.props.application.items[i].value;
          $scope.props.application.items[i].name += ' [locked]';
        }
        else if ($scope.props.application.items[i].name == 'serviceDiscoveryUrl') {
            $scope.tierName = $scope.props.application.items[i].value;
            $scope.props.application.items[i].name += ' [locked]';
          }
        else if ($scope.props.application.items[i].name == 'logLevelOverride') {
            $scope.props.application.items.splice(i,1);
        }
      }

      $scope.componentList = [$scope.componentName, component_global];
      console.log("ComponentList: ", $scope.componentList);

    }, function errorCallback(response) {
      console.log('failed to get properties from server');
    });
  }
  $scope.getProps();
  $scope.editing = false;

  $scope.showEditForm = function(item) {
    // List of things we won't allow a user to edit or delete
    if(lockedPropertiesList.includes(item.name)) return;

    $scope.editing = true;
    $scope.config = item;
    rollback = {};
    rollback.value = item.value;
    rollback.component = item.component;
    rollback.tier = item.tier;
    rollback.source = item.source;
    $scope.rollback = rollback;
    // I need to grab the index of this item so that I can update the main grid
    if (item.id) {
      $scope.editText = "Edit";
      $scope.deletable = true;
    } else {
      $scope.editText = "Add";
      $scope.deletable = false;
    }
    console.log("Setup Editor")
    console.log($scope.config);
    console.log($scope.rollback);
  }

  $scope.resetFields = function() {
    if ($scope.config === null || $scope.rollback === null) {
      // we are in some wierd state here - just close the editor
    } else {
      $scope.config.component = $scope.rollback.component;
      $scope.config.source = $scope.rollback.source;
      $scope.config.tier = $scope.rollback.tier;
      $scope.config.value = $scope.rollback.value;
    }
  }

  $scope.cancelEdit = function() {
    $scope.editStatus = '';
    $scope.resetFields();
    $scope.editing = false;
  }

  $scope.edit = function() {
    // send update to sever
    console.log("UPDATING: ", $scope.config);
    $scope.config.value = $scope.config.value.trim();
    val = $scope.config.value;
    type = $scope.config.type
    valid = true;
    message = '';

    // validate the component
    component = $scope.config.component;
    console.log("Component: " + component);
    console.log(component, component_global, $scope.rollback.component, $scope.componentName);
    console.log(component == component_global);
    console.log($scope.rollback.component == $scope.componentName);
    if (component === null || !$scope.componentList.includes(component)) {
      // let the user know the component isn't valid and bail
      message = 'You need to choose a component';
      $scope.editStatus = message;
      console.log("No Component...");
      return;
    }
    if (component == component_global && $scope.rollback.component == $scope.componentName) {
      // make the user delete the specific component value first then set componentGlobal
      message = 'Delete the value for component ' + $scope.componentName + ' first, then add value for ' + component_global;
      $scope.editStatus = message;
      $scope.resetFields();
      console.log("Specific Component must be deleted first");
      return;
    }

    // validate the data type
    if (type == "boolean") {
      console.log("Type is boolean - try to convert");
      if (val == "true" || val == "false") {
        console.log("we have a valid boolean: ", val);
      } else {
        console.log("BOOM");
        valid = false;
        message = 'Failed to set field, ' + $scope.config.name + ' must be a boolean value';
      }
    } else if (type == "int") {
      console.log("Type is int - try to convert");
      re = new RegExp('^[+\-]?\d+$');
      if (isNaN(val) || re.test(val)) {
        console.log("BOOM");
        valid = false;
        message = 'Failed to set field, ' + $scope.config.name + ' must be an integer';
      } else {
        console.log("we have a valid int: ", val);
      }
    } else if (type == "float") {
      console.log("Type is float - try to convert");
      if (isNaN(val)) {
        console.log("BOOM");
        valid = false;
        message = 'Failed to set field, ' + $scope.config.name + ' must be a real number';
      } else {
        console.log("we have a valid float: ", val);
      }
    } else if (type == "string") {
      console.log("Type is string - nothing to see here");
      console.log("strings are things: ", val);
    }

    if (valid) {
      // we've passed validation, send to config server
      $scope.editStatus = '';
      $scope.config.tier = $scope.tierName;
      $scope.config.source = 'CONFIG_SERVER_APPLICATION';
      // need to add in some error handling here
      $scope.updateConfigServer($scope.config);
      $scope.editing = false;
      $scope.deletable = false;
    } else {
      // let the user know a field isn't valid
      $scope.editStatus = message;
      console.log($scope.editStatus);
    }
  }

  $scope.delete = function() {
    // send delete to server
    console.log("DELETING: ", $scope.config);
    // need to handle errors here
    $scope.deleteConfigServer($scope.config);
    $scope.editing = false;
    $scope.deletable = false;
    $scope.editStatus = '';
  }

  $scope.updateConfigServer = function (item) {
    url = contextPath + '/config/edit';
    config = 'application/json';
    console.log(item);
    $http.post(url, item, config).then(function successCallback(response) {
      // update grid with data & success message
      console.log(response);
      item.id = response.data.id;
    }, function errorCallback(response) {
      // update UI with error message
      console.log(response);
    });
  }

  $scope.deleteConfigServer = function (item) {
    url = contextPath + '/config/delete';
    config = 'application/json';
    $http.post(url, item, config).then(function successCallback(response) {
      // update grid with data & success message
      console.log('deleted property...');
      console.log(response);
      item.value = response.data.value;
      item.id = response.data.id;
      item.component = response.data.component;
      item.tier = response.data.tier;
      item.source = response.data.source;
    }, function errorCallback(response) {
      // update UI with error message
      console.log('ERROR deleting property...');
      console.log(response);
    });
  }
});
