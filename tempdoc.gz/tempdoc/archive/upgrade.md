# Spring Boot 2.2.4, AWS 1.11.702, Kafka 2.4.0 upgrade notes

## First Pass (checked into staging & master)
### Kafka and AWS SDK Libraries
### common/config/dependencies.gradle
versions.aws_java_sdk = '1.11.714'
versions.confluent = '5.4.0'
versions.kafka = '2.4.0'

## Second Pass - branch springboot2
### Spring Boot Libraries and plugins
### common/config/dependencies.gradle
versions.springBoot = '2.2.4.RELEASE'

versions.groovy = '2.5.9'
versions.gson = '2.8.6'
versions.jackson = '2.10.2'
versions.jacksonBom = '2.10.2'
versions.jacksonDatabind = '2.10.2'
versions.logback = '1.2.3'
versions.postgresql = '9.4.1212.jre7'
versions.slf4j = '1.7.30'
versions.spring = '5.2.3.RELEASE'
versions.springCloud = '1.3.6.RELEASE'
versions.springSecurity = '5.2.1.RELEASE'
versions.springRetry = '1.2.5.RELEASE'
versions.springWS = '3.0.8.RELEASE'
versions.xml_apis='1.4.01'
// new fields
versions.liquibase = '3.8.5'
versions.dropWizard = '4.1.2'

// change the following
libraries.liquibase = 'org.liquibase:liquibase-core:3.5.5'
libraries.metrics_annotation = 'io.dropwizard.metrics:metrics-annotation:3.1.5@jar'
libraries.metrics_core = 'io.dropwizard.metrics:metrics-core:3.1.5@jar'
libraries.metrics_jvm = 'io.dropwizard.metrics:metrics-jvm:3.1.5@jar'
libraries.metrics_json = 'io.dropwizard.metrics:metrics-json:3.1.5@jar'
libraries.metrics_servlet = 'io.dropwizard.metrics:metrics-servlet:3.1.5@jar'
libraries.metrics_servlets = 'io.dropwizard.metrics:metrics-servlets:3.1.5@jar'
libraries.metrics_healthchecks = 'io.dropwizard.metrics:metrics-healthchecks:3.1.5@jar'
// to this
libraries.liquibase = "org.liquibase:liquibase-core:${versions.liquibase}"
libraries.metrics_annotation = "io.dropwizard.metrics:metrics-annotation:${versions.dropWizard}@jar"
libraries.metrics_core = "io.dropwizard.metrics:metrics-core:${versions.dropWizard}@jar"
libraries.metrics_jvm = "io.dropwizard.metrics:metrics-jvm:${versions.dropWizard}@jar"
libraries.metrics_json = "io.dropwizard.metrics:metrics-json:${versions.dropWizard}@jar"
libraries.metrics_servlet = "io.dropwizard.metrics:metrics-servlet:${versions.dropWizard}@jar"
libraries.metrics_servlets = "io.dropwizard.metrics:metrics-servlets:${versions.dropWizard}@jar"
libraries.metrics_healthchecks = "io.dropwizard.metrics:metrics-healthchecks:${versions.dropWizard}@jar"


// AWS dependency:
// AWS SDK 1.11.714 requires httpclient version => 4.5.9
// change
libraries.httpclient = 'org.apache.httpcomponents:httpclient:4.5.6'
// to
libraries.httpclient = 'org.apache.httpcomponents:httpclient:4.5.9'

### build.gradle
// update the classpath versions of the two spring boot plugins to the values below
classpath 'org.springframework.boot:spring-boot-gradle-plugin:2.2.4.RELEASE'
classpath 'io.spring.gradle:dependency-management-plugin:1.0.9.RELEASE'

### mkt-template-docker-service/build.gradle
```
# 1. replace
bootRepackage
# with (global replacement)
bootJar

# 2. comment out additional properties in springBoot.buildInfo
springBoot {
    buildInfo {
		//TODO razing Jan2020 - find replacement for additionalProperties
        // add to the defaults of build.time, build.artifact, build.group, build.name, build.version
        //additionalProperties = [
        //    'release':   buildRelease,
        //    'type':      buildType,
        //    'timestamp': buildLevel,
        //    'user':      user
        //]
    }
}

# 3. Update, if present, the mkt-shared-rest-context and mkt-shared-infra-client dependencies to ${buildSprint}sb2, and change the group
    compile ("com.sas.mkt.shared.infra.client:mkt-shared-infra-client:1.${buildSprint}sb2.+")
    compile ("com.sas.mkt.shared.rest.context:mkt-shared-rest-context:1.${buildSprint}sb2.+")

If you are not using it comment out the SAS CDP i18n plugin (if you are using it you'll have to wait for it to be upgraded)
// SAS CDP plugins
//apply plugin: 'i18n'

```

### SAS Commons Libraries
The SpringBoot 2 compatible versions of SAS Commons are: (in common/config/dependencies.gradle)
```
// SAS Commons dependencies
libraries.sas_commons_context = 'com.sas.commons:commons-context:3.0.17'
libraries.sas_commons_expr = 'com.sas.commons:commons-expr:4.0.5'
libraries.sas_commons_logging = 'com.sas.commons:commons-logging:3.0.19'
libraries.sas_commons_rest = 'com.sas.commons:commons-rest:4.0.29'
libraries.sas_commons_rest_l10n = 'com.sas.commons:commons-rest-l10n:3.0.18'
libraries.sas_commons_rest_representations = 'com.sas.commons:commons-rest-representations:2.4.7'
```
* **'mkt-shared-commons-rest' library has been replaced with upstream com.sas.commons version 'com.sas.commons:commons-rest'**
* **'mkt-shared-rest-client' has been dropped and should not be required**

### CI360 Shared Libraries
```
mkt-shared-infra-client
mkt-shared-rest-context
mkt-shared
mkt-plan-shared
```
The CI360 Shared Libraries will have a SpringBoot 1.5 and SpringBoot 2 version for each of the 2004 & 2005 sprints.
In 2006 the only version (v2006) will be the SpringBoot 2 version.

| Version | SpringBoot Version |
| ------- | ------------------ |
| v2004 | SpringBoot 1.5 |
| v2004sb2 | SpringBoot 2 |
| v2005 | SpringBoot 1.5 |
| v2005sb2 | SpringBoot 2 |
| v2006 | SpringBoot 2 |

Pull these in using **"1.${buildSprint}.+"** and **"1.${buildSprint}sb2.+"** in the gradle dependencies section.

### {your-app}-service/src/main/resources/application.properties
// change
server.contextPath=/<your-context-path>
// to
server.servlet.context-path=/<your-context-path>

// If your are using the liquibase manager lambda to run liquibase/ddl (you should be!) then
// change
liquibase.enabled=false
// to
spring.liquibase.enabled=false

### changes to Spring Boot configuration properties
Spring Boot has changed the way relaxed binding works:
https://spring.io/blog/2018/03/28/property-binding-in-spring-boot-2-0

#### Sample Config Property Change
For example, the character _ is no longer allowed. This needs to be changed to a -

There's an example in mkt-template-docker-config in the class GlobalConfiguration.java.
```
# replace
@ConfigurationProperties(prefix = "tier_global", ignoreUnknownFields=false, ignoreInvalidFields=false)
# with
@ConfigurationProperties(prefix = "tier-global", ignoreUnknownFields=false, ignoreInvalidFields=false)
# and update any reference from tier_global to tier-global
```

#### Test Framework Changes
// change
import org.springframework.boot.context.embedded.LocalServerPort;
// to
import org.springframework.boot.web.server.LocalServerPort;

#### Your Apps Specific Problems
You will most likely have other incompatability issues with your application. There's a 1.5.x to 2.x upgrade guide here: https://github.com/spring-projects/spring-boot/wiki/Spring-Boot-2.0-Migration-Guide

Go through it, fix things up until you get a successful build and run.

### Custom Web Server configuration
https://www.baeldung.com/embeddedservletcontainercustomizer-configurableembeddedservletcontainer-spring-boot

### Repository replacements
https://jira.spring.io/browse/DATACMNS-944
https://stackoverflow.com/questions/44101061/missing-crudrepositoryfindone-method

```
findOne(...) -> findById(...).orElse(null);
delete(...) -> deleteById(...)
```

### Bean definition overriding
https://stackoverflow.com/questions/53723303/springboot-beandefinitionoverrideexception-invalid-bean-definition

		System.setProperty("spring.main.allow-bean-definition-overriding", "true");

### Errors:
```
#1. java.lang.NoSuchMethodError: org.apache.tomcat.util.modeler.Registry.disableRegistry()V
```

Remove your explicit tomcat overrides.  Let spring boot supply it.

```
#2 jdbcUrl is required with driverClassName
```

Rename property: spring.datasource.jdbcurl -> spring.datasource.jdbcUrl

```
#3: com.fasterxml.jackson.databind.Module: Provider com.fasterxml.jackson.module.jaxb.JaxbAnnotationModule not found


dependencies.gradle change:
libraries.jackson = [
    "com.fasterxml.jackson.core:jackson-core:${versions.jackson}@jar",
    "com.fasterxml.jackson.core:jackson-annotations:${versions.jackson}@jar",
    "com.fasterxml.jackson.core:jackson-databind:${versions.jacksonDatabind}@jar",
    "com.fasterxml.jackson.module:jackson-module-jaxb-annotations:${versions.jackson}@jar"
]
```

as per: https://stackoverflow.com/questions/59933277/provider-com-fasterxml-jackson-module-jaxb-jaxbannotationmodule-not-found-afte

```
#4: ERROR in ch.qos.logback.core.joran.spi.Interpreter@13:74 - no applicable action for [springProperty]
```
Remove this from logback-spring.mxl:
```
  <springProperty scope="context" name="LOG_DIR" source="logging.path" />
```
