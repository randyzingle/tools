package com.sas.mkt.kafka.examples.connect;

public class ConnectDBDataGenerator {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

	}
	


}
