package com.sas.mkt.baldur.spring.kafka;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.clients.utils.KafkaGauges;

/**
 * @author razing
 *
 */
@Component
public class SampleConsumer implements Runnable {
	
	private AtomicBoolean stop = new AtomicBoolean(false);
	
	@Autowired
	ApplicationConfiguration appConfig;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	Consumer<String, SpecificRecordBase> consumer;
	
	@Override
	public void run() {
		stop.set(false);
		consumer = getConsumer();	
		consumeMessages();
	}
	
	public void restart() {
		stop.set(true);
		consumer = getConsumer();
		consumeMessages();
	}
	
	public void stop() {
		stop.set(true);
	}
	
	public void registerMetrics(Consumer<String, SpecificRecordBase> consumer) {
		KafkaGauges.getKafkaGauges().registryConsumerMetricsAsGauges(consumer);
	}
	
	private Consumer<String, SpecificRecordBase> getConsumer() {
		KafkaConnectionUtils kcu;
		try {
			kcu = KafkaConnectionUtils.getInstance(appConfig.configServiceUrl);
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			return null;
		}
		Properties consumerProps = kcu.getKafkaConsumerProperties(appConfig.tierName, appConfig.componentName);		
		// For testing we'll use a unique group id and read from the start of the topic each time
		// THIS IS NOT SOMETHING YOU SHOULD DO IN PRODUCTION CODE!
		consumerProps.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		String groupID = appConfig.getTierName() + "-" + appConfig.getComponentName() + System.currentTimeMillis();
		consumerProps.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		
		System.out.println("CONSUMER-KEYSET++++");
		Set<Object> keys = consumerProps.keySet();
		List<String> list = new ArrayList<>();
		for (Object o: keys) {
			list.add(o.toString());
		}
		Collections.sort(list);
		for (String s: list) {
			System.out.println(s + ": " + consumerProps.get(s));
		}
		System.out.println("END-KEYSET+++++++++");
		Consumer<String, SpecificRecordBase> c = new KafkaConsumer<>(consumerProps);
		return c;
	}


	private void consumeMessages() {		
		Consumer<String, SpecificRecordBase> consumer = getConsumer();
		consumer.subscribe(Arrays.asList(KafkaConfig.BALDUR_TOPIC));
		registerMetrics(consumer);

		// Consume Messages
		int cnt = 0;
		SpecificRecordBase te = null;
		System.out.println("CONSUMING MESSAGES.....");
		while (!stop.get()) {
			ConsumerRecords<String, SpecificRecordBase> records = consumer.poll(Duration.ofSeconds(1000l));
			for (ConsumerRecord<String, SpecificRecordBase> record : records) {
				cnt++;
				te = record.value();
				if (cnt % 50000 == 0) {
					System.out.println(cnt + "-consumer: " + te);
				}
			}
		}
		System.out.println("Closing the consumer");
		consumer.close();

	}

}
