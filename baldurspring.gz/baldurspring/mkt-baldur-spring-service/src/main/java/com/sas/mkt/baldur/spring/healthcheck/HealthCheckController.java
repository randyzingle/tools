package com.sas.mkt.baldur.spring.healthcheck;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.Status;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.health.HealthCheck.Result;
import com.codahale.metrics.health.HealthCheckRegistry;

/**
 * This should not need modification. It supports the following end points in a
 * standard way.
 *
 * <ul>
 * <li>/commons/metrics
 * <li>/commons/ping
 * <li>/commons/healthcheck
 * <li>/commons/diagnostics
 * </ul>
 *
 * I've removed the ScheduledTasks class that called updateDiagnostics on a
 * timer because you can't load session scoped beans like TopicUtils from
 * outside of a web context. Instead I'm tracking the last run of diagnostics
 * and returning the cached data if the time interval is < MIN_UPDATE_INTERVAL
 *
 * @author sasjtb
 * @author razing
 */
@Controller
public class HealthCheckController {
	private static final String NO_SPECIFIC_HEALTHCHECKS = "No specific healthchecks are defined.";
	private static final Logger log = LoggerFactory.getLogger(HealthCheckController.class);
	private static final long MIN_UPDATE_INTERVAL = 900000; // 15 minutes in milliseconds
	private static long lastUpdateTimestamp = 0L;

	@Autowired
	MetricRegistry metricRegistry;

	@Autowired
	HealthCheckRegistry healthRegistry;

	private SortedMap<String, Result> lastResults = new TreeMap<String, Result>();

	// TODO REMOVE - NOT FOR PRODUCTION!!!
	@RequestMapping(value = "/commons/getenv", method = RequestMethod.GET)
	public @ResponseBody String g2() {
		StringBuilder builder = new StringBuilder();
		builder.append("<html><body><table>");
		Map<String, String> envmap = System.getenv();
		List<String> ss = new ArrayList<>(envmap.keySet());
		Collections.sort(ss);
		for (String key: ss) {
			builder.append("<tr><td>"+key+"</td><td>"+envmap.get(key)+"</td></tr>");
		}
		builder.append("</table></body></html>");
		return builder.toString();
	}

	@RequestMapping(value = "/commons/metrics", method = RequestMethod.GET)
	public @ResponseBody MetricRegistry getMetrics(final HttpServletResponse response) {
		response.setHeader("Cache-Control", "must-revalidate,no-cache,no-store");
		return metricRegistry;
	}

	@RequestMapping(value = "/commons/ping", method = RequestMethod.GET)
	public @ResponseBody String ping(final HttpServletResponse response) {
		response.setHeader("Cache-Control", "must-revalidate,no-cache,no-store");
		return "OK";
	}

	@RequestMapping(value = "/commons/healthcheck", method = RequestMethod.GET)
	public @ResponseBody Health getHealth(final HttpServletResponse response, final HttpServletRequest request) {
		long timeSinceLastUpdate = System.currentTimeMillis() - lastUpdateTimestamp;
		Health result = null;
		response.setHeader("Cache-Control", "must-revalidate,no-cache,no-store");
		synchronized (this) {
			if (this.lastResults.isEmpty() || timeSinceLastUpdate > MIN_UPDATE_INTERVAL) {
				result = summarizeResults(getDiagnostics(response, request));
			} else {
				result = summarizeResults(this.lastResults);
			}
			if (result.getStatus().equals(Status.DOWN)) {
				response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			} else {
				response.setStatus(HttpServletResponse.SC_OK);
			}
			return result;
		}
	}

	private Health summarizeResults(Map<String, Result> results) {
		boolean healthy = true;
		for (String name : results.keySet()) {
			Result result = results.get(name);
			if (!result.isHealthy()) {
				healthy = false;
			}
		}
		return healthy ? Health.up().build() : Health.down().build();
	}

	@RequestMapping(value = "/commons/diagnostics", method = RequestMethod.GET)
	public @ResponseBody SortedMap<String, Result> getDiagnostics(final HttpServletResponse response,
			final HttpServletRequest request) {
		updateDiagnostics();
		response.setHeader("Cache-Control", "must-revalidate,no-cache,no-store");
		SortedMap<String, Result> results;
		synchronized (this) {
			results = this.lastResults;
		}
		if (results.isEmpty()) {
			results.put("NONE", Result.healthy(NO_SPECIFIC_HEALTHCHECKS));
			response.setStatus(HttpServletResponse.SC_OK);
		} else {
			response.setStatus(HttpServletResponse.SC_OK);
		}

		return results;
	}

	public void updateDiagnostics() {
		synchronized (this) {
			this.lastResults = healthRegistry.runHealthChecks();
			lastUpdateTimestamp = System.currentTimeMillis();
		}
	}
}
