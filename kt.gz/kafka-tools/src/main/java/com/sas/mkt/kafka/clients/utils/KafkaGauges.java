package com.sas.mkt.kafka.clients.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.ToDoubleFunction;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.common.Metric;
import org.apache.kafka.common.MetricName;

import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.Metrics;

public class KafkaGauges {
	
	ToDoubleFunction<Metric> value = meter -> ((Double)meter.metricValue()).doubleValue();
	List<String> producerScalingList = Arrays.asList("record-error-rate", "request-latency-avg");
	List<String> consumerScalingList = Arrays.asList("fetch-latency-max", "records-lag-max");
	
	List<Meter> consumerMeters = new ArrayList<>();
	List<Meter> producerMeters = new ArrayList<>();
	
	private static final KafkaGauges kafkaGauges = new KafkaGauges();
	public static KafkaGauges getKafkaGauges() {
		return kafkaGauges;
	}
	
	private KafkaGauges() {
		// use this as a singleton
	}
	
	/**
	 * Creates micrometer gauges for the following KafkaProducer meters:
	 * "record-error-rate",
	 * "request-latency-avg", 
	 * "outgoing-byte-rate",
	 * "record-send-rate", 
	 * "request-rate", 
	 * "record-queue-time-avg", 
	 * "records-per-request-avg", 
	 * "request-size-avg",
	 * "record-size-average", 
	 * "batch-size-average"
	 * 
	 * @param producer
	 */
	public void registerProducerMetricsAsGauges(Producer<String, SpecificRecordBase> producer) {		
		
		// If we've restarted the producer we need to drop the meters and re-add
		for (Meter meter: producerMeters) {
			Metrics.globalRegistry.remove(meter);
		}
		
		List<String> producerMetrics = Arrays.asList("record-error-rate", "request-latency-avg", "outgoing-byte-rate",
				"record-send-rate", "request-rate", "record-queue-time-avg", "records-per-request-avg", "request-size-avg",
				"record-size-average", "batch-size-average");
		
		Map<MetricName, ? extends Metric> map = producer.metrics();
		Set<MetricName> mset = map.keySet();
		for (MetricName mn : mset) {
			Metric metric = map.get(mn);
			if (metric.metricName().group().equals("producer-metrics") && producerMetrics.contains(metric.metricName().name())) {
				System.out.printf("group: %s, name: %s, value: %s%n", metric.metricName().group(),
						metric.metricName().name(), metric.metricValue());
				String fullName = "kafka.producer."+metric.metricName().name();
				if (producerScalingList.contains(metric.metricName().name())) {
					Gauge gauge = Gauge.builder(fullName, metric, value)
					.tags("scaling", "true",
						"info", "true",
						"kafka", "producer",
						"group", "producer-metrics")
					.register(Metrics.globalRegistry);
					producerMeters.add(gauge);
				} else {
					Gauge gauge = Gauge.builder(fullName, metric, value)
						.tags("info", "true",
							"kafka", "producer",
							"group", "producer-metrics")
						.register(Metrics.globalRegistry);
					producerMeters.add(gauge); 
				}
			}
		}
	}
	
	/**
	 * Creates micrometer gauges for the following KafkaConsumer meters:
	 * "fetch-latency-max", 
	 * "records-lag-max", 
	 * "records-consumed-rate",
	 * "bytes-consumed-rate", 
	 * "fetch-rate", 
	 * "fetch-size-avg", 
	 * "records-per-request-avg"
	 * "commit-latency-avg",
	 * "sync-time-avg"
	 * 
	 * @param producer
	 */
	public void registryConsumerMetricsAsGauges(Consumer<String, SpecificRecordBase> consumer) {
		
		// If we've restarted the consumer we need to drop the meters and re-add
		for (Meter meter: consumerMeters) {
			Metrics.globalRegistry.remove(meter);
		}
		
		List<String> consumerFetchManagerMetrics = Arrays.asList("fetch-latency-max", "records-lag-max", "records-consumed-rate",
				"bytes-consumed-rate", "fetch-rate", "fetch-size-avg", "records-per-request-avg");
		
		List<String> consumerCoordinatorMetrics = Arrays.asList("commit-latency-avg","sync-time-avg");
		
		Map<MetricName, ? extends Metric> map = consumer.metrics();
		Set<MetricName> mset = map.keySet();
		for (MetricName mn : mset) {
			Metric metric = map.get(mn);
			// need to fix scaling vs non-scaling metrics here and with producer
			if (metric.metricName().group().equals("consumer-fetch-manager-metrics") && consumerFetchManagerMetrics.contains(metric.metricName().name())) {
				System.out.printf("group: %s, name: %s, value: %s%n", metric.metricName().group(),
						metric.metricName().name(), metric.metricValue());
				String fullName = "kafka.consumer."+metric.metricName().name();
				if (consumerScalingList.contains(metric.metricName().name())) {
					Gauge gauge = Gauge.builder(fullName, metric, value)
					.tags("scaling", "true",
							"info", "true",
							"kafka", "consumer",
							"group", "consumer-fetch-manager-metrics")
					.register(Metrics.globalRegistry);
					consumerMeters.add(gauge);
				} else {
					Gauge gauge = Gauge.builder(fullName, metric, value)
					.tags("info", "true",
							"kafka", "consumer",
							"group", "consumer-fetch-manager-metrics")
					.register(Metrics.globalRegistry);
					consumerMeters.add(gauge);
				}
				
				// create our custom consumerlagdelta gauge
				if (metric.metricName().name().equals("records-lag-max")) {
					String name = "kafka.consumer.lag_delta";
//					createConsumerLagDeltaGauge(name, metric); // These numbers look off - need to look into this more
				}
			}
			if (metric.metricName().group().equals("consumer-coordinator-metrics") && consumerCoordinatorMetrics.contains(metric.metricName().name())) {
				System.out.printf("group: %s, name: %s, value: %s%n", metric.metricName().group(),
						metric.metricName().name(), metric.metricValue());
				String fullName = "kafka.consumer."+metric.metricName().name();
				if (consumerScalingList.contains(metric.metricName().name())) {
					Gauge gauge = Gauge.builder(fullName, metric, value)
					.tags("scaling", "true",
							"info", "true",
							"kafka", "consumer",
							"group", "consumer-coordinator-metrics")
					.register(Metrics.globalRegistry);
					consumerMeters.add(gauge);
				} else {
					Gauge gauge = Gauge.builder(fullName, metric, value)
					.tags("info", "true",
							"kafka", "consumer",
							"group", "consumer-coordinator-metrics")
					.register(Metrics.globalRegistry);
					consumerMeters.add(gauge);
				}
				
			}
		}
		
	}
	
	private void createConsumerLagDeltaGauge(String name, Metric metric) {
		ConsumerLagDeltaGauge cldg = new ConsumerLagDeltaGauge(name, metric);
		Gauge g0 = Gauge.builder(name, cldg, value)
		.tags("scaling", "true",
				"info", "true",
				"kafka", "consumer",
				"group", "consumer-coordinator-metrics")
		.register(Metrics.globalRegistry);
		cldg.setGauge(g0);
		new Thread(cldg).start();
	}
	
	private class ConsumerLagDeltaGauge implements Metric, Runnable {
		
		private Metric metric;
		private MetricName metricName;
		Gauge gauge;
		
		double plag = -1.0;
		double clag = -1.0;
		double delta = 0;
		double temp = 0;
		
		public void setGauge(Gauge guage) {
			this.gauge = guage;
		}
		
		public ConsumerLagDeltaGauge(String name, Metric metric) {
			this.metric = metric;
			this.metricName = new MetricName(name, "consumer-fetch-manager-metrics", "lag delta", new HashMap());
		}
		
		@Override
		public void run() {
			while(true) {
				Object x = gauge.value();
				System.out.println(x);
				try {
					Thread.sleep(60 * 1000l);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		@Override
		public MetricName metricName() {
			return metricName;
		}

		@Override
		public double value() {
			return delta;
		}

		@Override
		public Object metricValue() {
			try {
				temp = clag;
				clag = Double.valueOf(metric.metricValue().toString());
				plag = temp;
				
			} catch (NumberFormatException nfe) {
				nfe.printStackTrace();
			}
			
			if (Double.isNaN(clag) || Double.isNaN(plag) || plag < 0.0 || clag < 0.0) {
				delta = 0;
			} else {
				delta = clag - plag;
			}
			return Double.valueOf(delta);
		}
		
	}

}

