package com.sas.mkt.baldur.spring.healthcheck;

import org.springframework.context.annotation.Configuration;

import com.codahale.metrics.health.HealthCheck;

/**
 * This obviously need to change to check real stuff ...
 *
 * @author razing
 */
@Configuration
public class SuperGoodHealthCheck extends HealthCheck {

	@Override
	protected Result check() throws Exception {
		boolean isHealthy = true; // no you shouldn't do this in your application
		if (isHealthy) {
			return Result.healthy("My Super Good App is Healthy.");
		}
		return Result.healthy("My Super Good App is NOT Healthy.");
	}

}
