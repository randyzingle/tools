package com.sas.mkt.kafka.examples.config;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

public class ReadKafkaConfigServiceProps {

	public static ApplicationConfiguration appConfig = new ApplicationConfiguration();
	private final static Logger logger = LoggerFactory.getLogger(ReadKafkaConfigServiceProps.class);

	public static void main(String[] args) {
		ReadKafkaConfigServiceProps rp = new ReadKafkaConfigServiceProps();
//		appConfig.setConfigServiceUrl("http://configservice-dev.cidev.sas.us:8080/");
//		appConfig.setConfigServiceUrl("http://configservice-dev.cidev.sas.us:8080/");
//		appConfig.setConfigServiceUrl("http://configservice-latest09.cidev.sas.us:8080/");
//		appConfig.setConfigServiceUrl("http://configservice-tst.cidev.sas.us:8080/");
//		appConfig.setConfigServiceUrl("http://configservice-eurc.cidev.sas.us:8080/");
		appConfig.setConfigServiceUrl("http://configservice-infrastage.cidev.sas.us:8080/");
		String tierNm = "tier_global";
		String value = "";
		
		String componentNm = "mkt-kafka";
		String name = "";
//		value = "{\"acks\":\"0\"}";
		
//		String componentNm = "component_global";
//		String name = "kafkaProducerProperties";
//		value = "{\"acks\":\"all\",\"retries\":1,\"batch.size\":65536,\"max.in.flight.requests.per.connection\":1,\"linger.ms\":50}";

		ConfigUtils.bigPrint("original list");
		List<ConfigProperty> cpl = rp.getProperties(tierNm, componentNm, name, null);
		for (ConfigProperty cp : cpl) {
			System.out.println(cp.componentNm + ": " + cp.name + ", " + cp.value);

//			System.out.println(cp.name + ", " + cp.value);
		}
		System.out.printf("Found %d properties%n", cpl.size());


		ConfigProperty configProp = new ConfigProperty(tierNm, componentNm, name, value);
//		rp.deleteProperty(configProp);
//		rp.updateConfig(tierNm, componentNm, name, value, cpl);
		
		// cluster upgrade
//		rp.setupCluster(tierNm, componentNm);

	}
	
	private void setupCluster(String tierNm, String componentNm) {
		List<ConfigProperty> cpl = null;
		String name = "sas.mkt.kafka.cluster";
		String value = "kafka-broker-0.cidev.sas.us:32000,kafka-broker-1.cidev.sas.us:32001,kafka-broker-2.cidev.sas.us:32002";
		ConfigProperty configProp = new ConfigProperty(tierNm, componentNm, name, value);
		ConfigUtils.bigPrint("updating property");
		updateProperty(configProp);
		cpl = getProperties(tierNm, componentNm, null, null);
		for (ConfigProperty cp : cpl) {
			System.out.println(cp);
		}

		name = "sas.mkt.kafka.connect.distributed";
		value = "connect-dev.cidev.sas.us:31225";
		configProp = new ConfigProperty(tierNm, componentNm, name, value);
		ConfigUtils.bigPrint("updating property");
		updateProperty(configProp);
		cpl = getProperties(tierNm, componentNm, null, null);
		for (ConfigProperty cp : cpl) {
			System.out.println(cp);
		}

		name = "sas.mkt.kafka.schema.registry";
		value = "http://schemaregistry-dev.cidev.sas.us:31856";
		configProp = new ConfigProperty(tierNm, componentNm, name, value);
		ConfigUtils.bigPrint("updating property");
		updateProperty(configProp);
		cpl = getProperties(tierNm, componentNm, null, null);
		for (ConfigProperty cp : cpl) {
			System.out.println(cp);
		}

		name = "sas.mkt.kafka.zookeeper";
		value = "zookeeper-dev.cidev.sas.us:30334";
		configProp = new ConfigProperty(tierNm, componentNm, name, value);
		ConfigUtils.bigPrint("updating property");
		updateProperty(configProp);
		cpl = getProperties(tierNm, componentNm, null, null);
		for (ConfigProperty cp : cpl) {
			System.out.println(cp);
		}
	}

	private void updateConfig(String tierNm, String componentNm, String name, String value, List<ConfigProperty> cpl) {
//		String s = String.format("Adding name=%s, value=%s to config server", name, value);
//		ConfigUtils.bigPrint(s);
//		createProperty(tierNm, componentNm, name, value);
//		cpl = getProperties(tierNm, componentNm, null, null);
//		for (ConfigProperty cp : cpl) {
//			System.out.println(cp);
//		}


	}

	private void componentList(String baseUrl) {
		RestTemplate rt = new RestTemplate();

		HttpHeaders headers = new HttpHeaders();
		headers.set(ConfigProperty.AUDIT_COMPONENT_HEADER, "baldursoft");
		headers.set("Accept", "application/json");
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

		ResponseEntity<ResourceCollection> responseEntity = null;
		ResourceCollection collection = null;
		boolean moreData = true;
		int limit = 100;

		List<ConfigProperty> props = new ArrayList<>();
		int nloops = 0;
		int cnt = 0;
		while (moreData) {
			nloops += 1;
			String url = String.format("%s?start=%d&limit=%d", baseUrl, cnt, limit);
			responseEntity = rt.exchange(url, HttpMethod.GET, entity,
					new ParameterizedTypeReference<ResourceCollection>() {
					});
			collection = responseEntity.getBody();
			int nfound = collection.items.size();
			cnt += nfound;
			if (nfound == 0)
				moreData = false;
			props.addAll(collection.items);
		}
		System.out.println("Called the config-server " + nloops + " times");

		TreeMap<String, Integer> cmap = new TreeMap<>();
		for (ConfigProperty prop : props) {
			String key = prop.componentNm;
			if (cmap.containsKey(key)) {
				cmap.put(key, cmap.get(key) + 1);
			} else {
				cmap.put(key, 1);
			}
		}
		Set<String> keySet = cmap.keySet();
		int totalFields = 0;
		for (String key : keySet) {
			totalFields += cmap.get(key);
			System.out.println(key + ": " + cmap.get(key));
		}
		System.out.println("Found " + cmap.size() + " distinct components.");
		System.out.println("Found " + totalFields + " total values.");

	}

	public void deleteProperty(ConfigProperty cp) throws RestClientException {
		if (cp.id == null) {
			List<ConfigProperty> cpl = this.getProperties(cp.tierNm, cp.componentNm, cp.name, null);
			if (cpl == null || cpl.size() != 1 || cpl.get(0).id == null) {
				logger.error("Failed to delete config property, could not get property ID from config server for "
						+ cp.toString());
				return;
			} else {
				cp.id = cpl.get(0).id;
				logger.debug("deleting property for " + cp.toString());
				System.out.println("deleting property for " + cp.toString());
			}
		}
		String auditComponent = appConfig.getComponentName();
		RestTemplate restTemplate = new RestTemplate();
		String url = appConfig.getConfigServiceUrl() + ConfigProperty.COLLECTION_NAME + "/" + cp.id;
		HttpHeaders headers = new HttpHeaders();
		headers.set(ConfigProperty.AUDIT_COMPONENT_HEADER, auditComponent);
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.DELETE, entity, String.class);
		logger.debug(responseEntity.getBody());

	}

	public void updateProperty(ConfigProperty cp) throws RestClientException {
		if (cp.id == null) {
			List<ConfigProperty> cpl = this.getProperties(cp.tierNm, cp.componentNm, cp.name, null);
			if (cpl == null || cpl.size() != 1 || cpl.get(0).id == null) {
				logger.error("Failed to update config property, could not get property ID from config server for "
						+ cp.toString());
				return;
			} else {
				cp.id = cpl.get(0).id;
				logger.debug("updating property for " + cp.toString());
			}
		}

		String auditComponent = appConfig.getComponentName();
		RestTemplate restTemplate = new RestTemplate();
		String url = appConfig.getConfigServiceUrl() + ConfigProperty.COLLECTION_NAME + "/" + cp.id;
		HttpHeaders headers = new HttpHeaders();
		headers.set(ConfigProperty.AUDIT_COMPONENT_HEADER, auditComponent);
		headers.set("Content-Type", ConfigProperty.MEDIA_TYPE_JSON_VALUE);
		headers.set("CI360BypassStaticProtection", "true");

		// ObjectMapper objectMapper = new ObjectMapper();
		// try {
		// String json = objectMapper.writeValueAsString(cps);
		// } catch (JsonProcessingException e) {
		// logger.error(e.getMessage());
		// }

		HttpEntity<ConfigProperty> request = new HttpEntity<ConfigProperty>(cp, headers);
		restTemplate.put(url, request, ConfigProperty.class);
	}

	/*
	 * Create a new property in the config server Will throw a 400 bad request if
	 * the property already exists
	 */
	public void createProperty(String tierName, String componentName, String name, String value)
			throws RestClientException {
		ConfigProperty cps = new ConfigProperty(tierName, componentName, name, value);
		createProperty(cps);
	}

	public void createProperty(ConfigProperty configProperty) {
		List<ConfigProperty> props = new ArrayList<>();
		props.add(configProperty);
		createProperties(props);
	}

	public void createProperties(List<ConfigProperty> properties) throws RestClientException {
		String auditComponent = appConfig.getComponentName();
		RestTemplate restTemplate = new RestTemplate();
		String url = appConfig.getConfigServiceUrl() + ConfigProperty.COLLECTION_NAME;
		HttpHeaders headers = new HttpHeaders();
		headers.set("AuditComponent", auditComponent);
		headers.set("Content-Type", ResourceCollection.MEDIA_TYPE_JSON_VALUE);

		ResourceCollection collection = new ResourceCollection();
		collection.name = ResourceCollection.COLLECTION_NAME;
		collection.accept = ResourceCollection.MEDIA_TYPE_BASE_VALUE;
		collection.items = properties;

		HttpEntity<ResourceCollection> request = new HttpEntity<ResourceCollection>(collection, headers);
		ResourceCollection response = restTemplate.postForObject(url, request, ResourceCollection.class);

		List<ConfigProperty> props = response.items;
		System.out.println(props);

	}

	public List<ConfigProperty> getProperties(String tierName, String componentName, String name, String value)
			throws RestClientException {
		ConfigProperty cps = new ConfigProperty(tierName, componentName, name, null);
		List<ConfigProperty> props = getProperties(cps);
		return props;
	}

	public List<ConfigProperty> getProperties(ConfigProperty config) throws RestClientException {
		String auditComponent = appConfig.getComponentName();
		// note all the RestTemplate stuff throws the RuntimeException:
		// org.springframework.web.client.RestClientException

		RestTemplate restTemplate = new RestTemplate();
		String name = config.name == null ? "" : config.name;
		String value = config.value == null ? "" : config.value;
		String url = appConfig.getConfigServiceUrl() + ConfigProperty.COLLECTION_NAME + "?tierNm=" + config.tierNm
				+ "&componentNm=" + config.componentNm + "&name=" + name + "&value=" + value;

		HttpHeaders headers = new HttpHeaders();
		headers.set("AuditComponent", auditComponent);
		headers.set("Accept", "application/json");

		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

		ResponseEntity<ResourceCollection> responseEntity = null;

		int pageSize = 500;
		int pageStart = 0;
		boolean nextPage = true;
		List<ConfigProperty> allProps = null;

		while (nextPage) {
			String pagedURL = url + "&start=" + pageStart + "&limit=" + pageSize;

			try {
				responseEntity = restTemplate.exchange(pagedURL, HttpMethod.GET, entity,
						new ParameterizedTypeReference<ResourceCollection>() {
						});
				ResourceCollection collection = responseEntity.getBody();
				List<ConfigProperty> props = collection.items;

				if (null == allProps) {
					allProps = props;
				} else
					allProps.addAll(props);

				if (null == props || (props.size() < pageSize))
					nextPage = false;
				else {
					pageStart += props.size();
				}

			} catch (Exception rce) {
				String message = String.format("Failed to connect to the config server at %s%n%s", url,
						rce.getMessage());
				logger.error(message);

				// validInitialization = false;
				nextPage = false;
			}
		}

		return allProps;
	}

	public void printPropertyIds(List<ConfigProperty> props) {
		for (ConfigProperty cp : props) {
			logger.debug("{} {} {}", cp.id, cp.name, cp.value);
		}
	}

}
