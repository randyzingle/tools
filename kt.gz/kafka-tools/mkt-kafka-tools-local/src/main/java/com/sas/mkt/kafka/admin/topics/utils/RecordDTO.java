package com.sas.mkt.kafka.admin.topics.utils;

import java.io.Serializable;
import java.util.Map;

public class RecordDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	public String key;
	public long offset;
	public int partition;
	public long timestamp;
	public Map<String, String> value;

}
