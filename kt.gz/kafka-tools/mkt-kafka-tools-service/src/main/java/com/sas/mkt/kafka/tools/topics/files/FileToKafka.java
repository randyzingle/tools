package com.sas.mkt.kafka.tools.topics.files;

import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.producer.BufferExhaustedException;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.errors.InterruptException;
import org.apache.kafka.common.errors.SerializationException;
import org.springframework.beans.factory.annotation.Autowired;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.domain.events.RawEvent;

public class FileToKafka {
	
	private Producer<String, SpecificRecordBase> producer;
	private boolean destroy = false;
	private String configServiceUrl = "http://configservice-dev.cidev.sas.us:8080/";
	
	@Autowired
	ApplicationConfiguration appConfig;
	
	public void fireAndForget(List<RawEvent> eventList) {
		KafkaConnectionUtils kcu;
		try {
//			kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
			kcu = KafkaConnectionUtils.getInstance(configServiceUrl);
		} catch (Exception ex) {
			System.out.println(ex.toString());
			return;
		}

//		String topic = appConfig.getKafkaTopicPrefix() + "-" + appConfig.getTestEventsTopic();
		String topic = "baldur-raw-events";
		Properties props = kcu.getKafkaConsumerProperties(appConfig.getTierName(), appConfig.getComponentName());
		props.put("max.block.ms", 4000); // maximum amount of time you will block in send() because buffer is full
		props.put("request.timeout.ms", 10000); // maximum amount of time you will block in send() waiting for broker response after which you will resend / or fail if retries are exhausted (default 30sec)
		props.put("metrics.sample.window.ms", 30000); // The window of time a metrics sample is computed over - default 30sec
		producer = new KafkaProducer<>(props);
		int cnt = 0;
		while (true) {
			if (destroy) break;
			for (RawEvent rawEvent: eventList) {
				if (destroy) break;
				ProducerRecord<String, SpecificRecordBase> record = new ProducerRecord<>(topic, rawEvent.getSessionId(), rawEvent);
				// note, send() actually places the message in a buffer which is read and sent by a separate thread
				try {
					producer.send(record); // if the cluster is gone this will NOT throw an exception -> all the metrics will have gone to zero
					System.out.println("sent: " + record.toString());
					cnt++;
				} catch (SerializationException|BufferExhaustedException|InterruptException ex) {
					ex.printStackTrace();
				} 
			}
			destroy = true;
		}
		System.out.printf("Sent %d messages%n", cnt);
		// make sure the buffers empty out
		producer.flush();
		long sleep = 2000L;
		producer.close(sleep, TimeUnit.MILLISECONDS);
	}

}
