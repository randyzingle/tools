package com.sas.mkt.kafka.clients.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

//tag
/**
 * Gathers the properties required to communicate with Kafka brokers and the
 * Kafka Schema Registry.
 * <p>
 * You should NOT need to call this class directly. It's used by
 * {@link KafkaConnectionUtils KafkaConnectionUtils} to set up Kafka
 * connections.
 * <p>
 * The configuration parameters are pulled from the <b>mkt-kafka</b> component
 * in the global tier of the configuration server. You can override the
 * parameters either with environment variables or with system properties passed
 * to the java executable. Properties will take precedence in this order (from
 * highest precedence to lowest):
 * <ul>
 * <li>system properties</li>
 * <li>environment variables</li>
 * <li>config server properties</li>
 * </ul>
 *
 * @author razing
 * @since 1707
 */
public class KafkaProperties {
	private static Logger logger = LoggerFactory.getLogger(KafkaProperties.class);

	protected static final String CONFIG_SERVER_KAFKA_COMPONENTNM = "mkt-kafka";
	protected static final String CONFIG_SERVER_TIER_GLOBAL = "tier_global";
	protected static final String BASE_KAFKA_ENV_PROP_NAME = "SAS_MKT_KAFKA";
	protected static final String BASE_KAFKA_SYSTEM_PROP_NAME = "sas.mkt.kafka";
	
	protected static final String KAFKA_PRODUCER_PROPERTIES = "kafkaProducerProperties";
	protected static final String KAFKA_CONSUMER_PROPERTIES = "kafkaConsumerProperties";

	protected HashMap<String, String> kp;
	private Boolean instanceInitialized = false;

	private ObjectMapper mapper;

//	public static void main(String[] args) {
//		String configServiceURL = "http://configservice-dev.cidev.sas.us:8080/";
//		KafkaProperties singleton = KafkaProperties.getInstance(configServiceURL);
//		System.out.println(singleton.getKafkaProperties().toString());
//	}

	// private static KafkaProperties instance;
	private static Map<String, KafkaProperties> instanceMap = new HashMap<String, KafkaProperties>();

	protected KafkaProperties() {
		mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	}

	/**
	 * Resets any data currently associated with the singleton. Provided for testing
	 * purposes and not intended for production usage.
	 *
	 **/
	public static void resetInstance() {
		synchronized (instanceMap) {
			logger.info("Resetting the current instance.");
			instanceMap.clear();
		}
	}

	/**
	 * Provide a specific instance for testing purposes. Call resetInstance when
	 * done with the test.
	 *
	 */
	public static void setTestInstance(String configServiceURL, String tierName, KafkaProperties instance) {
		String key = buildKey(configServiceURL, tierName);
		logger.info("Setting test instance for: " + key);
		instanceMap.put(key, instance);
	}

	protected boolean isInstanceInitialized() {
		return instanceInitialized;
	}

	private static String buildKey(String configServiceURL, String tierName) {
		String key = configServiceURL + "_" + tierName;
		return key;
	}

	public static KafkaProperties getInstance(String configServiceURL) {
		return getInstance(configServiceURL, CONFIG_SERVER_TIER_GLOBAL);
	}

	public static KafkaProperties getInstance(String configServiceURL, String tierName) {
		if (configServiceURL != null && !configServiceURL.endsWith("/"))
			configServiceURL = configServiceURL + "/";
		// with support for tier name we can't have just one instance
		// we need an instance map since tier name can change
		synchronized (instanceMap) {
			if (null == tierName)
				tierName = CONFIG_SERVER_TIER_GLOBAL;

			String key = buildKey(configServiceURL, tierName);
			KafkaProperties instance = instanceMap.get(key);

			if (null == instance) {
				instance = new KafkaProperties();
				instanceMap.put(key, instance);
			}

			// if the instance isn't marked as initialized try to configure it again
			if (!instance.isInstanceInitialized())
				instance.configureKafka(configServiceURL, tierName);

			return instance;
		}

	}

	public HashMap<String, String> getKafkaProperties() {
		return kp;
	}

	private void configureKafka(String configServiceURL, String tierName) {
		kp = new HashMap<>();
		// get kafka properties from the config server

		getConfigServiceProperties(configServiceURL, tierName);
		// over-write config server properties with environment variables
		getEnvironmentProperties();
		// over-write config server props and environment variables with system (-D)
		// properties
		getSystemProperties();
	}

	// TODO clean up - new stuff Jan 2021 - tier and component based Kafka consumer
	// and producer properties
	// generic config server call for given tierName, componentName, and
	// propertyName

	public Properties parseConfigServerKafkaProperties(String configServiceURL, String tierName, String componentName,
			String propertyName) {
		Properties props = new Properties();
		Map<String, Object> map;
		
		// component_global
		String globalUrl = configServiceURL + ConfigProperty.COLLECTION_NAME + "?tierNm=" + tierName + "&componentNm="
				+ "component_global" + "&name=" + propertyName;
//		System.out.println("**************************");
//		System.out.println(globalUrl);
//		System.out.println("**************************");
		List<ConfigProperty> global = getPropsByUrl(globalUrl);
		if (global != null && global.size() == 1) {
			String value = global.get(0).value;
			try {
				map = mapper.readValue(value, new TypeReference<Map<String, Object>>() {});
				for (String key : map.keySet()) {
					System.out.println("key: " + key + ", value: " + map.get(key));
					props.put(key, map.get(key));
				}
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		// component specific - over write anything that's common with component_global
		String componentUrl = configServiceURL + ConfigProperty.COLLECTION_NAME + "?tierNm=" + tierName + "&componentNm="
				+ componentName + "&name=" + propertyName;
//		System.out.println("**************************");
//		System.out.println(componentUrl);
//		System.out.println("**************************");
		List<ConfigProperty> component = getPropsByUrl(componentUrl);
		if (component != null && component.size() == 1) {
			String value = component.get(0).value;
			try {
				map = mapper.readValue(value, new TypeReference<Map<String, Object>>() {});
				for (String key : map.keySet()) {
					System.out.println("key: " + key + ", value: " + map.get(key));
					props.put(key, map.get(key));
				}
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return props;
	}

	private void getConfigServiceProperties(String configServiceURL, String tierName) {

		// don't want to restrict to just CONFIG_SERVER_TIER_GLOBAL, need to pull for
		// the specified tier too.
		String url = configServiceURL + ConfigProperty.COLLECTION_NAME + "?componentNm="
				+ CONFIG_SERVER_KAFKA_COMPONENTNM + "&tierNm=" + tierName;

		boolean validInitialization = true;

		List<ConfigProperty> allProps = getPropsByUrl(url);

		if (null != allProps) {
			initializeKafkaProperties(allProps, tierName);
		}

		String message = String.format("Kafka Configuration from config service [%s]:%n%s", configServiceURL,
				kp.toString());
		logger.info(message);

		instanceInitialized = validInitialization;
	}

	private List<ConfigProperty> getPropsByUrl(String surl) {
		int pageSize = 200;
		int pageStart = 0;
		boolean nextPage = true;
		List<ConfigProperty> allProps = null;

		while (nextPage) {
			String pagedURL = surl + "&start=" + pageStart + "&limit=" + pageSize;

			try {
				URL url = new URL(pagedURL);
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				con.setRequestMethod("GET");
				// set headers
				con.setRequestProperty("Accept", "application/json");
				con.setRequestProperty(ConfigProperty.AUDIT_COMPONENT_HEADER, "baldursoft");

				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				String inputLine;
				StringBuffer content = new StringBuffer();
				while ((inputLine = in.readLine()) != null) {
					content.append(inputLine);
				}
				in.close();
				con.disconnect();
				// initialize mapper in constructor - expensive object to build.
				ResourceCollection rc = mapper.readValue(content.toString(), ResourceCollection.class);
				List<ConfigProperty> props = rc.items;

				if (null == allProps) {
					allProps = props;
				} else
					allProps.addAll(props);

				if (null == props || (props.size() < pageSize))
					nextPage = false;
				else {
					pageStart += props.size();
				}

			} catch (Exception rce) {
				nextPage = false;
			}
		}
		return allProps;
	}

	protected void initializeKafkaProperties(List<ConfigProperty> props, String tierName) {
		if (null == props)
			return;

		// default to global if not provided
		if (null == tierName || tierName.length() <= 0)
			tierName = CONFIG_SERVER_TIER_GLOBAL;

		Map<String, ConfigProperty> propMatches = new HashMap<String, ConfigProperty>();

		for (ConfigProperty prop : props) {

			// if a tier global property override existing otherwise add only if empty
			if (!propMatches.containsKey(prop.name))
				propMatches.put(prop.name, prop);
			else {
				ConfigProperty current = propMatches.get(prop.name);

				if (null == current) {
					// we match either the specific tier or global tier
					if ((prop.tierNm.compareTo(CONFIG_SERVER_TIER_GLOBAL) == 0)
							|| (prop.tierNm.compareTo(tierName) == 0))
						propMatches.put(prop.name, prop);
				} else {
					// if we don't currently have the specific one we are looking for
					// check to see if this one is the specific one we want
					// if(null != tierName)
					{
						if (tierName.compareTo(current.tierNm) != 0) {
							if ((prop.tierNm.compareTo(tierName) == 0)) {
								propMatches.put(prop.name, prop);
							}
						}
					}
//        			else
//        			{
//        				//if for some reason we don't have any tierName to match to then we default
//        				//to tierGlobal
//        				if((prop.tierNm.compareTo(CONFIG_SERVER_TIER_GLOBAL) == 0))
//	        			{
//	        				propMatches.put(prop.name, prop);
//	        			}
//        			}
				}
			}

		}

		Set<Entry<String, ConfigProperty>> propEntries = propMatches.entrySet();
		for (Entry<String, ConfigProperty> keepProp : propEntries) {
			kp.put(keepProp.getValue().name, keepProp.getValue().value);
		}
	}

	private void getEnvironmentProperties() {
		Map<String, String> envMap = System.getenv();
		Set<String> keyset = envMap.keySet();
		for (String key : keyset) {
			if (key.startsWith(BASE_KAFKA_ENV_PROP_NAME)) {
				kp.put(convertEnvNameToProp(key), envMap.get(key));
			}
		}
		String message = String.format("Kafka Configuration after parsing environment variables: %n%s", kp.toString());
		logger.info(message);
	}

	private void getSystemProperties() {
		Properties props = System.getProperties();
		Set<String> keys = props.stringPropertyNames();
		for (String key : keys) {
			if (key.startsWith(BASE_KAFKA_SYSTEM_PROP_NAME)) {
				kp.put(key, props.getProperty(key));
			}
		}
		String message = String.format("Kafka Configuration after parsing system properties: %n%s", kp.toString());
		logger.info(message);
	}

	private String convertEnvNameToProp(String prop) {
		if (prop != null) {
			prop = prop.replace('_', '.').toLowerCase();
		}
		return prop;
	}

}