# Java 13 Memory Flags

Now that we're all on Java 13, we're running on a version of Java that's natively container aware. Our JVM will use Memory resources passed into the container as the max possible values. We can specify our requested Java Heap size as a percentage of this value.

## Set Heap Usage
By default, when the JVM starts up it allocates 25% of available memory as heap. So if we give our container 1GB of RAM our heap size will be 250MB and the rest will be reserved for class-loading, garbage collectors, and our threads / stack. This is most likely not what we want. If our application needs memory in the 500MB+ range we're most likely caching a lot of stuff on the heap.

We can request that a larger part of our available memory be allocated as heap space with the JVM flag -XX:MaxRAMPercentage. We'll request 80% of memory as heap with:
* -XX:MaxRAMPercentage=80

Doing this we go from using ~1/4 of the available RAM as heap:
```
$ docker run --rm --name baldur --memory='500m' -p8080:8080 mkt-devops/mkt-baldur-spring
VM settings:
    Max. Heap Size (Estimated): 121.81M
    Using VM: OpenJDK 64-Bit Server VM
...
```
To ~80% of the available RAM:
```
$ docker run --rm --name baldur --memory='500m' -e JDK_JAVA_OPTIONS='-XX:MaxRAMPercentage=80' -p8080:8080 mkt-devops/mkt-baldur-spring
NOTE: Picked up JDK_JAVA_OPTIONS: -XX:MaxRAMPercentage=80
NOTE: Picked up JDK_JAVA_OPTIONS: -XX:MaxRAMPercentage=80
VM settings:
    Max. Heap Size (Estimated): 386.69M
    Using VM: OpenJDK 64-Bit Server VM
```

### Giving Memory Back

We're Running our applications on shared environments both in ECS and (eventually) Kubernetes. If our application has memory usage spikes, then it needs to return that memory to the shared pool when we're done.

By default the JVM will reserve 40% of the requested heap on start up and won't ask the GC to return memory to the shared pool unless 70% of the heap is empty. We can change these values with the flags: -XX:MinHeapFreeRatio and -XX:MaxHeapFreeRatio. If we want to be frugal we can get stingy with unused memory and set:
* -XX:MinHeapFreeRatio=5
* -XX:MaxHeapFreeRatio=10
Which will start the JVM with 5% of the maximum heap size and will restore memory to the common pool once the unused portion of the heap goes over 10%. These are the recommended values in the [Oracle Java Tools Document](https://docs.oracle.com/en/java/javase/15/docs/specs/man/java.html).
The Oracle docs also suggest setting the following flag if you use the above memory flags:
* -XX:-ShrinkHeapInSteps

### Putting it all together

```
$ docker run --rm --name baldur --memory='500m' -e JDK_JAVA_OPTIONS='-XX:MaxRAMPercentage=80 -XX:MinHeapFreeRatio=5 -XX:MaxHeapFreeRatio=10 -XX:-ShrinkHeapInSteps' -p8080:8080 mkt-devops/mkt-baldur-spring
NOTE: Picked up JDK_JAVA_OPTIONS: -XX:MaxRAMPercentage=80 -XX:MinHeapFreeRatio=5 -XX:MaxHeapFreeRatio=10 -XX:-ShrinkHeapInSteps
NOTE: Picked up JDK_JAVA_OPTIONS: -XX:MaxRAMPercentage=80 -XX:MinHeapFreeRatio=5 -XX:MaxHeapFreeRatio=10 -XX:-ShrinkHeapInSteps
VM settings:
    Max. Heap Size (Estimated): 386.69M
    Using VM: OpenJDK 64-Bit Server VM
...
```
Where we are passing all our memory configuration requests into the JVM using the single environment variable **JDK_JAVA_OPTIONS**.

Note, we could also just bake these into the Dockerfile startup command but it's much more flexible and easy to change and experiment with, if we use an environment variable.

#### ECS
In ECS everything is setup in cloudformation.json / environments.yaml.

We have two cloudformation parameters that deal with memory:
* MaxMemory - can't exceed this or the OOM manager will terminate the container
* MinMemory - used to schedule the container in ECS (the underlying server needs to have at least this much free RAM)

The parameter MaxMemory sets the TaskDefinition->ContainerDefinitions->Memory variable which is used as the base point for all the JVM memory percentage calculations.

If we add the following to our ContainerDefinitions->Environment array (see cloudformation.json in mkt-template-docker):
```json
{
  "Name": "JDK_JAVA_OPTIONS",
  "Value": "-XX:MaxRAMPercentage=80 -XX:MinHeapFreeRatio=5 -XX:MaxHeapFreeRatio=10 -XX:-ShrinkHeapInSteps"
},
```
And set the parameter MaxMemory=4096 then our container comes up with:
```
Max. Heap Size (Estimated): 3.20G
```
and will aggressively return un-used heap to the server's pool.

#### Kubernetes
In Kubernetes we add the environment variable to the env section of the container definition:
```yaml
env:
- name: JDK_JAVA_OPTIONS
  value: "-XX:MaxRAMPercentage=80 -XX:MinHeapFreeRatio=5 -XX:MaxHeapFreeRatio=10 -XX:-ShrinkHeapInSteps"
```
If we set a resource request and limit for memory:
```yaml
resources:
  requests:
    memory: "1000Mi"
  limits:
    memory: "4000Mi"
```
The the JVM will use the **limit** as the base value for our percentage calculations:
```
$ k logs baldur-spring-5f8c79b86c-8cbz2
NOTE: Picked up JDK_JAVA_OPTIONS: -XX:MaxRAMPercentage=80 -XX:MinHeapFreeRatio=5 -XX:MaxHeapFreeRatio=10 -XX:-ShrinkHeapInSteps
NOTE: Picked up JDK_JAVA_OPTIONS: -XX:MaxRAMPercentage=80 -XX:MinHeapFreeRatio=5 -XX:MaxHeapFreeRatio=10 -XX:-ShrinkHeapInSteps
VM settings:
    Max. Heap Size (Estimated): 3.02G
    Using VM: OpenJDK 64-Bit Server VM
```

But if we just set a request then the **server's max RAM** will be used (here we're on a t2.large with 8GB of RAM):
```yaml
resources:
  requests:
    memory: "1000Mi"
```
from the logs:
```
$ k logs baldur-spring-5fd445cf7f-f2fzg
NOTE: Picked up JDK_JAVA_OPTIONS: -XX:MaxRAMPercentage=80 -XX:MinHeapFreeRatio=5 -XX:MaxHeapFreeRatio=10 -XX:-ShrinkHeapInSteps
NOTE: Picked up JDK_JAVA_OPTIONS: -XX:MaxRAMPercentage=80 -XX:MinHeapFreeRatio=5 -XX:MaxHeapFreeRatio=10 -XX:-ShrinkHeapInSteps
VM settings:
    Max. Heap Size (Estimated): 5.54G
    Using VM: OpenJDK 64-Bit Server VM
```
Which is not necessarily a bad thing - if there are free resources and our pod needs them then there's no reason to limit it artificially - as long as it gives the memory back! But if your application has possible memory leaks then it's best to set an upper limit as well as a request.

Like ECS the lower value, the **request** will be used to place the pod on a server.

### Caveats
I've tested this thoroughly in kubernetes by driving heap usage and watching the pod eventually give memory back to the server, but have just spot checked it in ECS.
