package com.sas.mkt.kubectl.operators;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.sas.mkt.kubectl.data.TemplateData;

public abstract class KubernetesOperator {
	
	private final String STATUS_FAILED = "FAILED";
	private final String STATUS_SUCCESS = "SUCCESS";
	
	private String runFile;
	
	public TemplateData run(TemplateData td) {
		td.results.status = STATUS_SUCCESS;
		try {
			configureLifecycle(td);
			customizeTemplate(td);
			if (!td.abort) {
				populateTemplate(td);
				kubectl(td);
			}
		} catch (Exception ex) {
			td.response.append(ex.getMessage());
			td.results.status = STATUS_FAILED;
		}
		td.results.message = td.response.toString();
		return td;
	}
	
	protected abstract void customizeTemplate(TemplateData td);
	
	private void configureLifecycle(TemplateData td) throws Exception {
		String lc = td.lifecycle; 
		if (lc == null) {
			throw new Exception("Invalid CloudFormation Lifecycle, expecting {create, update, delete}, got: " + lc);
		}
		if (lc.equalsIgnoreCase("create") || lc.equalsIgnoreCase("update")) {
			td.apply = true;
		} else if (lc.equalsIgnoreCase("delete")) {
			td.apply = false;
		} else {
			throw new Exception("Invalid CloudFormation Lifecycle, expecting {create, update, delete}, got: " + lc);
		}
	}
	
	private void populateTemplate(TemplateData td) throws JsonParseException, JsonMappingException, IOException {
		
		UUID uuid = UUID.randomUUID();
        String randomUUIDString = uuid.toString();
		runFile = "/tmp/" + randomUUIDString + td.template+"-"+td.version+".yaml";
		
		String templateFile = "templates/" + td.template+"-"+td.version+".yaml"; 
		
		ClassLoader loader = this.getClass().getClassLoader();
		InputStream inputStream = loader.getResourceAsStream(templateFile);		
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));	
		Map<String, String> map = td.parameters;
		StringBuilder stringBuilder = new StringBuilder();
		String line = null;
		String ls = System.getProperty("line.separator");
		while ((line = reader.readLine()) != null) {
			for (String key: map.keySet()) {
				line = Pattern.compile("<<" + key + ">>", Pattern.CASE_INSENSITIVE).matcher(line).replaceAll(map.get(key));
			}
			stringBuilder.append(line);
			stringBuilder.append(ls);
		}
		reader.close();

		String content = stringBuilder.toString();
		//td.response.append(content); do this in debug only
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(runFile));
	    writer.write(content);
	    writer.flush();
	    writer.close();
	}
	
	private void kubectl(TemplateData td) {
		boolean apply = td.apply;
		
		ProcessBuilder processBuilder = new ProcessBuilder();
		Map<String, String> env = processBuilder.environment();
		env.put("PATH", env.get("PATH") + ":/usr/local/bin/");

		// Run a shell command
		String runCommand = "";
		if (apply) {
			runCommand = "kubectl apply -f " + runFile;
		} else {
			runCommand = "kubectl delete -f " + runFile;
		}
		processBuilder.command("bash", "-c", runCommand);

		try {
			Process process = processBuilder.start();
			StringBuilder output = new StringBuilder();
			BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			BufferedReader error = new BufferedReader(new InputStreamReader(process.getErrorStream()));
			String line;
			while ((line = reader.readLine()) != null) {
				output.append(line + "\n");
			}

			while ((line = error.readLine()) != null) {
				output.append(line + "\n");
			}

			int exitVal = process.waitFor();
			if (exitVal == 0) {
				System.out.println("Success!");
//				System.out.println(output);
				td.response.append(output);
				td.results.status = STATUS_SUCCESS;
			} else {
				System.out.println("this blew up...");
				td.response.append(output);
//				System.out.println(output);
				td.results.status = STATUS_FAILED;
				throw new Exception("kubectl command failed");
			}
			if (process.isAlive()) {
				process.destroy();
			}

		} catch (Exception e) {
			td.response.append(e.getMessage());
			td.results.status = STATUS_FAILED;
		}  
	}

}
