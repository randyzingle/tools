package com.sas.mkt.kafka.clients.utils;

import java.util.HashMap;
import java.util.List;

/**
 * Test class meant solely for unit test cases
 * tag
 * */
public class KafkaPropertiesTestImpl extends KafkaProperties
{

	public KafkaPropertiesTestImpl()
	{
		super();

		reset();
	}

	public void reset()
	{
		kp = new HashMap<>();
	}

	public HashMap<String, String> getProperties(List<ConfigProperty> props, String tierName)
	{
		initializeKafkaProperties(props, tierName);

		return kp;
	}
}
