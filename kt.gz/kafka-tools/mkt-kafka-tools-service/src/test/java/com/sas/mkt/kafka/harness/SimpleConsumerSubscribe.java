package com.sas.mkt.kafka.harness;

import java.util.Arrays;
import java.util.Properties;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;

@Component
public class SimpleConsumerSubscribe implements WakeableConsumer {

	private ApplicationConfiguration appConfig;
	private boolean done = false;

	public Consumer<String, SpecificRecordBase> consumer;

	@Autowired
	public SimpleConsumerSubscribe(ApplicationConfiguration appConfig) {
		this.appConfig = appConfig;
	}

	public void init() {
		KafkaConnectionUtils kcu = null;
		try {
			kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return;
		}
		Properties consumerProperties = kcu.getKafkaConsumerProperties(appConfig.getTierName(), appConfig.getComponentName());
		String groupID = appConfig.getTierName() + "-" + appConfig.getComponentName() + System.currentTimeMillis();
		consumerProperties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		consumerProperties.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		consumer = new KafkaConsumer<>(consumerProperties);


	}

	public void consumeWithSubscribe() {
		System.out.println("Consuming messages with subscribe...");
		String topic = "baldur-test-events";
		consumer.subscribe(Arrays.asList(topic));

		// Consume Messages
		try {
			while (!done) {
				ConsumerRecords<String, SpecificRecordBase> records = consumer.poll(10000);
				for (ConsumerRecord<String, SpecificRecordBase> record : records) {
					System.out.println(record.value());
				}
			}
		} catch (WakeupException wex) {
			System.out.println("boom");
			wex.getMessage();
		} finally {
			consumer.close();
		}

	}

	@Override
	public void wakeUp() {
		done = true;
	}

}
