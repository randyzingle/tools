package com.sas.mkt.config.core;

import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.TreeMap;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.Environment;
import org.springframework.mock.env.MockEnvironment;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.appspecific.GlobalConfiguration;

@RunWith(MockitoJUnitRunner.class)
public class PropertyMapTest {
	
	private static PropertyMap propertyMap;
	
	@BeforeClass
	public static void setUp() {
		ApplicationConfiguration appConfig = new ApplicationConfiguration();
		GlobalConfiguration globalConfig = new GlobalConfiguration();
		Environment env = new MockEnvironment();
		propertyMap = new PropertyMap(appConfig, globalConfig, env);
	}

	@Test
	public void testInitialize() {	
		HashMap<String, TreeMap<String, PropertyDetails>> pm = propertyMap.propertyMap;
		assertNotNull(pm);
		propertyMap.initialize();
		assertNotNull(pm);
	}

}
