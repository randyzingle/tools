package com.sas.mkt.baldur.spring.controllers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.sas.mkt.baldur.spring.db.AwsKeys;
import com.sas.mkt.baldur.spring.db.AwsKeysDTO;
import com.sas.mkt.baldur.spring.db.PostgresFunctionCaller;

@RestController
@RequestMapping("/")
public class DatabaseDriver {
	
	@Autowired
	PostgresFunctionCaller pgcaller;
	
//	http://baldurspring-mymir.cidev.sas.us:8080/database/loads3data?bucket=garbagedump&file=data.csv&tablename=table1
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "database/loads3data", method = RequestMethod.GET)
	public String loads3data(@RequestParam String bucket, String file, String tablename) {
		String message = pgcaller.loadS3Data(bucket, file, tablename);
		return message;
	}

	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "database/getcreds", method = RequestMethod.GET)
	public String getcreds() {
		AwsKeysDTO keys = new AwsKeys().getAwsKey();
		return keys.toString();
	}

	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "database/getenv", method = RequestMethod.GET)
	public String getenv() {
		StringBuffer buff = new StringBuffer();
		Map<String, String> env = System.getenv();
		Set<String> keys = env.keySet();
		List<String> list = new ArrayList<String>(keys);
		Collections.sort(list);
		for (String key : list) {
			buff.append("<p>" + key + ": " + env.get(key) + "</p>");
		}
		return buff.toString();
	}
	
//	AWS credentials provider chain that looks for credentials in this order:
//		Environment Variables - AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY (RECOMMENDED since they are recognized by all the AWS SDKs and CLI except for .NET), or AWS_ACCESS_KEY and AWS_SECRET_KEY (only recognized by Java SDK)
//		Java System Properties - aws.accessKeyId and aws.secretKey
//		Web Identity Token credentials from the environment or container
//		Credential profiles file at the default location (~/.aws/credentials) shared by all AWS SDKs and the AWS CLI
//		Credentials delivered through the Amazon EC2 container service if AWS_CONTAINER_CREDENTIALS_RELATIVE_URI" environment variable is set and security manager has permission to access the variable,
//		Instance profile credentials delivered through the Amazon EC2 metadata service
	@CrossOrigin(origins = "http://localhost:8000") 
	@RequestMapping(value = "database/getbest", method = RequestMethod.GET)
	public String getbest() {
		String best = "";
		DefaultAWSCredentialsProviderChain chain = DefaultAWSCredentialsProviderChain.getInstance();
		AWSCredentials credentials = chain.getCredentials();
		best = credentials.toString();
		String s1 = credentials.getAWSAccessKeyId();
		String s2 = credentials.getAWSSecretKey();
		System.out.println(s1);
		System.out.println(s2);
		return best;
	}

}
