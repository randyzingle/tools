package com.sas.mkt.kafka.tools.startup;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import com.sas.mkt.config.core.ApplicationConstants;
import com.sas.mkt.config.core.BaseUtils;
import com.sas.mkt.kafka.tools.s3connect.S3ConnectManager;

@Component
public class ApplicationStartupRunner implements ApplicationRunner, Ordered {

	private final static Logger logger = LoggerFactory.getLogger(ApplicationStartupRunner.class);

	@Autowired
	S3ConnectManager s3ConnectManager;

	@Override
	public int getOrder() {
		return ApplicationConstants.CONFIG_SERVICE_RUNNER_ORDER + 10;
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		BaseUtils.bigPrint("Kafka Tools is Running!");
//
//		// Set up the Kafka S3 Connect Manager
//		s3ConnectManager.init();

	}

}
