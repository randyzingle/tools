package com.sas.mkt.kafka.admin.topics;

import java.io.File;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.avro.LogicalType;
import org.apache.avro.Schema;
import org.apache.avro.Schema.Field;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sas.mkt.kafka.admin.topics.utils.RecordSetDTO;
import com.sas.mkt.kafka.admin.topics.utils.TopicInfo;
import com.sas.mkt.kafka.admin.topics.utils.TopicUtils;

/**
 * @author razing
 *
 */
public class OffsetConsumerDriver {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	private static String fileBase = "src/main/resources/data/";
	private TopicUtils topicUtils;

	public static void main(String[] args) {
		OffsetConsumerDriver bc = new OffsetConsumerDriver();
		bc.topicUtils = new TopicUtils();
//		bc.getMessages();
		bc.getInfo();

	}
	
	private void getInfo() {
		topicUtils.init();
		String topic = "dev-enhanced-events";
		TopicInfo topicInfo = topicUtils.getTopicInfo(topic);
		System.out.println(topicInfo);
		topicUtils.destroy();
	}
	
	private void getMessages() {
		long ocstart = System.currentTimeMillis();
		topicUtils.init();
		System.out.printf("Took %d ms to open the consumer%n", (System.currentTimeMillis() - ocstart));

		long startOff = (6 * 24 * 60 * 60 * 1000);
		long endOff = (1 * 60 * 1000);
		long now = System.currentTimeMillis();
		long startTime = now - startOff;
		long endTime = now - endOff;
		String topic = "mymir-test-events";
		String keyFilter = "baldursoft0";
		Map<String, String> valueFilter = new HashMap<>();
		valueFilter.put("ip", "192.168.2.2");
		RecordSetDTO srs = topicUtils.readMessagesInTimeRange(topic, startTime, endTime, keyFilter, valueFilter);
		System.out.println("Runtime (ms): " + (System.currentTimeMillis() - now));

		if (srs != null) {
			ObjectMapper mapper = new ObjectMapper();
			try {
				String rstring = mapper.writeValueAsString(srs);

				File f = new File(fileBase + topic + ".json");
				try (FileWriter fw = new FileWriter(f)) {
					fw.write(rstring + System.lineSeparator());
					fw.flush();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("No records found");
		}
		
		long t2 = System.currentTimeMillis();
		srs = topicUtils.readMessagesInTimeRange(topic, startTime, endTime, null, null);
		System.out.println("Runtime (ms): " + (System.currentTimeMillis() - t2));
		
		topicUtils.destroy();
	}

}
