'''
ECHO Echo echo e...

Source code located in GitLab:
    // TODO - put in layers project https://gitlab.sas.com/CustomerIntelligence/DevOps/mkt-infra

Configuration:
"Handler": "EchoServer.handler"
"Runtime": "python3.6"
"Timeout": "300"

Aug 6, 2019
@author: razing
'''
import json
from urllib.request import urlopen, Request, HTTPError, URLError
from urllib.parse import urlencode
import boto3
import re
import time
import uuid

# ===============================================================================
#  Sample CloudFormation events
# ===============================================================================
'''
Create event:
{
  "RequestType": "Create",
  "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-UDZOW2HK3IWD",
  "ResponseURL": "https://cloudformation-custom-resource-response-useast1.s3.amazonaws.com",
  "StackId": "arn:aws:cloudformation:us-east-1:952478859445:stack/razing-custom/40d839f0-8cd3-11e7-a3f6-50faeaabf0d1",
  "RequestId": "5f078456-de85-4775-9441-9347eaac6407",
  "LogicalResourceId": "WAFInfo",
  "ResourceType": "AWS::CloudFormation::CustomResource",
  "ResourceProperties": {
    "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-UDZOW2HK3IWD",
    "RateLimit": "2000",
    "Description": "Lambda will return ID of: WebACL, RateBasedRule",
    "Region": "us-east-1",
    "ALBArn": "arn:aws:elasticloadbalancing:us-east-1:952478859445:loadbalancer/app/razing-ELB-17401GTSWCHZC/f2fe45278d0d859e",
    "StackName": "razing-custom"
  }
}

Update event:
{
  "RequestType": "Update",
  "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-XRSHVD5NRA7I",
  "ResponseURL": "https://cloudformation-custom-resource-response-useast1.s3.amazonaws.com",
  "StackId": "arn:aws:cloudformation:us-east-1:952478859445:stack/razing-custom/afb9dbe0-8cd7-11e7-bd36-500c219ab02a",
  "RequestId": "7310f283-36ce-43b8-a88e-2f022103ba7c",
  "LogicalResourceId": "WAFInfo",
  "PhysicalResourceId": "None",
  "ResourceType": "AWS::CloudFormation::CustomResource",
  "ResourceProperties": {
    "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-XRSHVD5NRA7I",
    "RateLimit": "2000",
    "Description": "Lambda will return ID of: WebACL, RateBasedRule",
    "Region": "us-east-1",
    "ALBArn": "arn:aws:elasticloadbalancing:us-east-1:952478859445:loadbalancer/app/razing-ELB-17401GTSWCHZC/f2fe45278d0d859e",
    "StackName": "razing-custom"
  },
  "OldResourceProperties": {
    "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-XRSHVD5NRA7I",
    "RateLimit": "2500",
    "Description": "Lambda will return ID of: WebACL, RateBasedRule",
    "Region": "us-east-1",
    "ALBArn": "arn:aws:elasticloadbalancing:us-east-1:952478859445:loadbalancer/app/razing-ELB-17401GTSWCHZC/f2fe45278d0d859e",
    "StackName": "razing-custom"
  }
}

Delete event:
{
  "RequestType": "Delete",
  "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-13C1UUQ66AQ0P",
  "ResponseURL": "https://cloudformation-custom-resource-response-useast1.s3.amazonaws.com",
  "StackId": "arn:aws:cloudformation:us-east-1:952478859445:stack/razing-custom/09cdd3e0-8cdb-11e7-b660-503acac41e35",
  "RequestId": "4f6ae1d6-0a71-4bf5-bd7e-3c2f4b8c62ec",
  "LogicalResourceId": "WAFInfo",
  "PhysicalResourceId": "None",
  "ResourceType": "AWS::CloudFormation::CustomResource",
  "ResourceProperties": {
    "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-13C1UUQ66AQ0P",
    "RateLimit": "2000",
    "Description": "Lambda will return ID of: WebACL, RateBasedRule",
    "Region": "us-east-1",
    "ALBArn": "arn:aws:elasticloadbalancing:us-east-1:952478859445:loadbalancer/app/razing-ELB-17401GTSWCHZC/f2fe45278d0d859e",
    "StackName": "razing-custom"
  }
}
'''

# ===============================================================================
#  Constants
# ===============================================================================
STATUS_FAILED = 'FAILED'
STATUS_SUCCESS = 'SUCCESS'

# ===============================================================================
#  Entry Point for Lambda
# ===============================================================================
def handler(event, context):
    #print(event)
    rtype = event['RequestType']
    status = event['ResourceProperties']['Status']
    gitsha = event['ResourceProperties']['GitTagShaVersion']
    #print(event['ResourceProperties'])

    if rtype == 'Create':
        print('creating stuff')
        #create_resources(event, context)
    elif rtype == 'Update':
        print('updating stuff')
        #update_resources(event, context)
    elif rtype == 'Delete':
        print('deleting stuff')
        #delete_resources(event, context)
    else:
        print(rtype, ' :Not a proper request-type, should be one of [Create|Update|Delete]')

    send_response(event, STATUS_SUCCESS)
    #send_waithandle(event, status)

# ===============================================================================
#  Test code that signals WaitCondition
# ===============================================================================
def send_waithandle(event, responseStatus):
    print('sending signal to CF WaitCondition')
    data = 'alls well that ends well'
    responseUrl = event['ResourceProperties']['WaitHandleUrl']
    responseBody = {
        'Status': responseStatus,
        'Reason': 'Everything is peachy',
        'UniqueId': str(uuid.uuid4()),
        'Data': data
    }

    #print(responseBody)
    edata = json.dumps(responseBody)
    edata = edata.encode('utf-8')
    #headers = {'Content-Length': len(edata), 'Content-Type': ''}
    headers = {'Content-Length': len(edata), 'Content-Type': ''}
    #print(headers)
    req = Request(
        responseUrl,
        headers=headers,
        data=edata,
        method='PUT')
    req.get_method = lambda: 'PUT'
    try:
        urlopen(req)
    except Exception as e:
        print(e)



# ===============================================================================
#  Cloudformation HTTP PUT response indicating SUCCESS or FAILURE of lambda
# ===============================================================================
def send_response(event, responseStatus):
    print('sending response to CloudFormation')
    data = {}
    data['RequestType'] =  event['RequestType']
    responseBody = {
        'Status': responseStatus,
        'Reason': 'Why not? Why do I need to have a reason?',
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'Data': data
    }

    # PhysicalResourceId only sent with Update and Delete requests
    responseBody['PhysicalResourceId'] = event.get('PhysicalResourceId', 'None')

    #print(responseBody)
    edata = json.dumps(responseBody)
    edata = edata.encode('utf-8')
    headers = {'Content-Length': len(edata), 'Content-Type': ''}
    #Sprint(headers)
    req = Request(
        event['ResponseURL'],
        headers=headers,
        data=edata,
        method='PUT')
    req.get_method = lambda: 'PUT'
    try:
        urlopen(req)
    except Exception as e:
        print(e)


# ===============================================================================
#  Test Code for runs from the command line
# ===============================================================================
if __name__ == "__main__":
    print('in __main__ function')

    #"Status": "SUCCESS" | "FAILED"

    event = '''
    {
      "RequestType": "Create",
      "ServiceToken": "arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-XRSHVD5NRA7I",
      "ResponseURL": "http://localhost:8080/service",
      "StackId": "arn:aws:cloudformation:us-east-1:952478859445:stack/razing-custom/afb9dbe0-8cd7-11e7-bd36-500c219ab02a",
      "RequestId": "7310f283-36ce-43b8-a88e-2f022103ba7c",
      "LogicalResourceId": "Echo",
      "PhysicalResourceId": "None",
      "ResourceType": "AWS::CloudFormation::CustomResource",
      "ResourceProperties": {
        "StackPrefix": "baldur",
        "ProjectName": "mkt-docker",
        "Description": "Lambda will manage Postgresql DB lifecycle",
        "RDSStackName": "baldur-rds",
        "Status": "SUCCESS",
        "GitTagShaVersion", "asdf"
      },
      "OldResourceProperties": {
        "StackPrefix": "baldur",
        "ProjectName": "mkt-docker",
        "Description": "Lambda will manage Postgresql DB lifecycle",
        "RDSStackName": "baldur-rds",
        "Status": "SUCCESS"
      }
    }
    '''
    context = {}
    handler(json.loads(event), context)
