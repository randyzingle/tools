package com.sas.mkt.config.core.configserver;

import org.springframework.web.client.RestTemplate;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;

public class ConfigServerClientTestImpl extends ConfigServerClient 
{
	protected RestTemplate mockedTemplate;
	
	public ConfigServerClientTestImpl(RestTemplate mockedTemplate, ApplicationConfiguration mockConfig)
	{
		super(mockConfig);
		this.mockedTemplate = mockedTemplate;
		this.appConfig = mockConfig;
	}
	
	@Override
	protected RestTemplate getRestTemplate()
	{
		return mockedTemplate;
	}

}
