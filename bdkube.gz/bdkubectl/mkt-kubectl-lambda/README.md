# Kubernetes Deployment Tool

The Kubernetes Deployment Tool creates kubernetes resources, like kubectl and helm, but plugs into our existing AWS resource creation infrastructure.

## Motivation
We want to be able to build/update/delete our applications and all of their supporting AWS infrastructure with a single command. The cloud engineering team looked at several ways to do this.

### Kubernetes Native (best?)
Create everything from within Kubernetes, using standard kubectl/helm for kubernetes resources and custom operators in kubernetes to build the AWS resources. This is probably our long term target but custom operators are very complicated pieces of software that require intimate kubernetes knowledge. AWS / open source community are [working on this](https://github.com/aws/aws-service-operator-k8s) but full AWS support looks like it might take quite some time.

### Scripting (worst)
Shell scripts that drive kubectl/helm for kubernetes resources and cloudformation for AWS resources. Doable but hacky, difficult, and likely to run into environment dependency issues (windows|mac|linux). Would have to reproduce all the error handling, rollback, update, logging etc. logic that's built into cloudformation and kubectl.

### Drive Everything From Cloudformation via Custom Resources (ok?)
We've already written cloudformation scripts for all of our current resources. If we move parts of our application stack to kubernetes the rest of the deployment scripts can stay as is.

## Sample Application - Motivation Part II
Our full stack for SAS CI TNG (gitgrid/monolith) includes several nested stacks including one that builds out a full RDS server for use by the Platform stack. Platform creates top level databases that aren't named with tier-prefixes like we do with our microservices, so we can't deploy all of our Platform databases to the same Postgres RDS server (again like we do with our microservices) but have to build a server per stack.

We currently have 33 full stacks which create 33 db.t2.large RDS instances. This costs around **$80K per year**. These databases show some spikes in resource usage but most are sitting at ~10% CPU usage and ~15% RAM usage. Our 33 instances in total, at resource usage that most of them are sitting at for the vast majority of the time use at total of **30GB RAM** and under **7 vCPUs**. If we spun up 2 reserved instances of m5a.xlarge kubernetes worker nodes they would supply us with **32GB RAM** and **8 vCPUs** of processing power which is enough to handle of our development tier Platform database needs. This would cost **$1.2K per year**.

### Our Plan
Our plan is to replace the RDS portion of the full tier script with one that still creates an RDS instance in all production environments (doesn't change anything at all about the way this is created) but creates a kubernetes-hosted instance in the development environment:
* CF Parameter IsDevInstall = 0 -> create all the resources and stack outputs currently being created
* CF Parameter IsDevInstall = 1 -> create kubernetes postgres and all stack output currently being created

### Implementation
We've fronted all the current resource creation with the Condition: Production and have added a custom resource fronted with the Condition: Development. The custom resource builds out the kubernetes resource as shown in the following diagram:

![image info](docs/KubectlManager.png)
