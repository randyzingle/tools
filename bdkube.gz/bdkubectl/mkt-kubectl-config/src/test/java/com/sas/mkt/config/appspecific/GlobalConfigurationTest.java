package com.sas.mkt.config.appspecific;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class GlobalConfigurationTest {
	
	private static GlobalConfiguration g;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		g = new GlobalConfiguration();
	}

	@Test
	public void testGetMktTenantServiceUrl() {
		g.getMktTenantServiceUrl();
	}

	@Test
	public void testSetMktTenantServiceUrl() {
		g.setMktTenantServiceUrl("baldur");
	}

	@Test
	public void testGetRedisClusterPrimaryEndpoint() {
		g.getRedisClusterPrimaryEndpoint();
	}

	@Test
	public void testSetRedisClusterPrimaryEndpoint() {
		g.setRedisClusterPrimaryEndpoint("baldur");
	}

	@Test
	public void testGetRedisClusterPrimaryEndpointPort() {
		g.getRedisClusterPrimaryEndpointPort();
	}

	@Test
	public void testSetRedisClusterPrimaryEndpointPort() {
		g.setRedisClusterPrimaryEndpointPort(1);
	}

	@Test
	public void testGetRedisClusterReadEndpointPorts() {
		g.getRedisClusterReadEndpointPorts();
	}

	@Test
	public void testSetRedisClusterReadEndpointPorts() {
		g.setRedisClusterReadEndpointPorts("baldur");
	}

	@Test
	public void testGetRedisClusterReadEndpoints() {
		g.getRedisClusterReadEndpoints();
	}

	@Test
	public void testSetRedisClusterReadEndpoints() {
		g.setRedisClusterReadEndpoints("baldur");
	}

	@Test
	public void testGetDataBucketTopic() {
		g.getDataBucketTopic();
	}

	@Test
	public void testSetDataBucketTopic() {
		g.setDataBucketTopic("baldur");
	}

	@Test
	public void testGetConfigBucket() {
		g.getConfigBucket();
	}

	@Test
	public void testSetConfigBucket() {
		g.setConfigBucket("baldur");
	}

	@Test
	public void testGetDataBucket() {
		g.getDataBucket();
	}

	@Test
	public void testSetDataBucket() {
		g.setDataBucket("baldur");
	}

	@Test
	public void testGetDeploymentBucket() {
		g.getDeploymentBucket();
	}

	@Test
	public void testSetDeploymentBucket() {
		g.setDeploymentBucket("baldur");
	}

	@Test
	public void testGetOpsBucket() {
		g.getOpsBucket();
	}

	@Test
	public void testSetOpsBucket() {
		g.setOpsBucket("baldur");
	}

	@Test
	public void testGetTestBucket() {
		g.getTestBucket();
	}

	@Test
	public void testSetTestBucket() {
		g.setTestBucket("baldur");
	}

	@Test
	public void testToString() {
		g.toString();
	}

}
