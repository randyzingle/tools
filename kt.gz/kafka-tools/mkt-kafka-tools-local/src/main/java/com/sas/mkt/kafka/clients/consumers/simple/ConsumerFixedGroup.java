package com.sas.mkt.kafka.clients.consumers.simple;

import java.util.Arrays;
import java.util.Properties;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.clients.utils.KafkaTopicUtils;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;

public class ConsumerFixedGroup {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	Consumer<String, SpecificRecordBase> consumer;
	private ApplicationConfiguration appConfig = new ApplicationConfiguration();

	public static void main(String[] args) {
		ConsumerFixedGroup bc = new ConsumerFixedGroup();
		bc.appConfig.setConfigServiceUrl("http://configservice-dev.cidev.sas.us:8080/");
		bc.simpleConsumeMessages();
//		Timer metricsTimer = KafkaConnectionUtils.scheduleMetricsTimer( consumer, "ConsumerGroup", consumerGroup, 45, 60 );
//        Timer metricsTimerProducer = KafkaConnectionUtils.scheduleMetricsTimer( producer, TestEventsTopic, 45, 60 );
	}

	private void simpleConsumeMessages() {
		// Set up the consumer
		KafkaConnectionUtils kcu;
		try {
			kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
			System.out.println("VALID CONNECTION..........");
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			return;
		}
		// If we want to re-read from the beginning each time then we need to make this unique
		String groupID = "baldur-"+System.currentTimeMillis();
		
		Properties props = kcu.getKafkaConsumerProperties();
		// also need this to read from the beginning each time
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		consumer = new KafkaConsumer<>(props);
//		Timer metricsTimer = KafkaConnectionUtils.scheduleMetricsTimer( consumer, "ConsumerGroup", groupID, 45, 60 );
		KafkaTopicUtils ktu = new KafkaTopicUtils(appConfig.getConfigServiceUrl());
		String topic = "baldur-test-events";
        consumer.subscribe(Arrays.asList(topic));

		// Consume Messages
		int cnt = 0;
		boolean done = false;
		SpecificRecordBase te = null;
		while (!done) {	
			ConsumerRecords<String, SpecificRecordBase> records = consumer.poll(1000);
			for (ConsumerRecord<String, SpecificRecordBase> record: records) {
				cnt++;
				te = record.value();
				if (cnt % 200 == 0) System.out.println(te);

				if (cnt >= 1000*1000) {
					done = true;
					System.out.println(te);
					break;
				}
//				recordProcessor.processRecord(record);
			}	
		}
		System.out.printf("Read %d messages%n", cnt);
		consumer.close();
//		recordProcessor.shutDown();
	}
}
