package com.sas.mkt.kafka.clients.streams;

import java.util.HashMap;
import java.util.Properties;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.KStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.domain.TestEvent;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;

public class FilterPipe {
	private static final Logger logger = LoggerFactory.getLogger(FilterPipe.class);
	ApplicationConfiguration appConfig = new ApplicationConfiguration();

	public static void main(String[] args) {
		FilterPipe fp = new FilterPipe();
		fp.filterIt();
	}
	
	public void filterIt() {
		KafkaConnectionUtils kcu;
		try {
			kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			System.out.println(ex.toString());
			return;
		}
		
		HashMap<String, String> map = kcu.getKafkaProperties();
		String brokers = map.get(KafkaConnectionUtils.SAS_MKT_KAFKA_CLUSTER);
		String zookeeper = map.get(KafkaConnectionUtils.SAS_MKT_KAFKA_ZOOKEEPER);
		String schemareg = map.get(KafkaConnectionUtils.SAS_MKT_KAFKA_SCHEMA_REGISTRY);
		System.out.printf("brokers: %s%nzookeeper: %s%nschema registry: %s%n", brokers, zookeeper, schemareg);
		
		Properties props = new Properties();
		props.put(StreamsConfig.APPLICATION_ID_CONFIG, "baldur-filter");
		props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, brokers);
		props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
		props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.serdeFrom(TestEvent.class));
		
		final StreamsBuilder builder = new StreamsBuilder();
		String topic = "baldur-test-events";
		KStream<String, TestEvent> source = builder.stream(topic);
		source.to("baldurcopy-test-events");
		
		final Topology topology = builder.build();
		System.out.println(topology.describe());
		
		final KafkaStreams streams = new KafkaStreams(topology, props);

	}

}
