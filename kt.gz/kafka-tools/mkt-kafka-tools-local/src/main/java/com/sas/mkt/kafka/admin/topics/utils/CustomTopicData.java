package com.sas.mkt.kafka.admin.topics.utils;

public class CustomTopicData implements Comparable<CustomTopicData>{
	
	private String topicName;
	private Long numberMessages;
	private long oldestMessage;
	private long youngestMessage;
	
	public CustomTopicData(String topicName, Long numberMessages) {
		super();
		this.topicName = topicName;
		this.numberMessages = numberMessages;
	}
	
	public String getTopicName() {
		return topicName;
	}
	public Long getNumberMessages() {
		return numberMessages;
	}
	
	
	public long getOldestMessage() {
		return oldestMessage;
	}

	public long getYoungestMessage() {
		return youngestMessage;
	}

	@Override
	public int compareTo(CustomTopicData other) {
		int result = Long.compare(this.numberMessages, other.getNumberMessages());
		if (result == 0) result = this.topicName.compareTo(other.getTopicName());
		return result;	
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CustomTopicData [topicName=").append(topicName).append(", numberMessages=")
				.append(numberMessages).append(", oldestMessage=").append(oldestMessage).append(", youngestMessage=")
				.append(youngestMessage).append("]");
		return builder.toString();
	}
	
}
