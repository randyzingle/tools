package com.sas.mkt.config.appspecific;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.sas.mkt.config.core.Configuration;

@Component
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false, ignoreInvalidFields = false)
public class ApplicationConfiguration extends Configuration {

	/**
	 * Do not change the following fields - used by the framework
	 */
	private String componentName;

	// passed in as environment variables in EC2 & Docker
	private String tierName;
	private String configServiceUrl;
	private String configStackName;

	// Console metrics
	private boolean consoleMetricsReporterActivated;
	private String consoleMetricsFilters;
	private int consoleMetricsReporterRateSec;

	// CloudWatch metrics
	private boolean cloudWatchMetricsReporterActivated;
	private String cloudWatchMetricFilters;
	private int cloudWatchMetricsReporterRateSec;

	// Logger metrics
//	private boolean loggerMetricsReporterActivated;
//	private String loggerMetricsFilter;
//	private int loggerMetricsReporterRateSec;

	// Dynamically change log levels
	private String logLevelOverride;
	// END Do not change the following

	/**
	 * These are application specific and can be changed
	 */
	// AppSpecific Properties

	// End AppSpecific Properties ... add getters and setters for the props you
	// added

	public String getComponentName() {
		return componentName;
	}

	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

	public String getTierName() {
		return tierName;
	}

	public void setTierName(String tierName) {
		this.tierName = tierName;
	}

	public String getConfigServiceUrl() {
		return configServiceUrl;
	}

	public void setConfigServiceUrl(String configServiceUrl) {
		this.configServiceUrl = configServiceUrl;
	}

	public String getConfigStackName() {
		return configStackName;
	}

	public void setConfigStackName(String configStackName) {
		this.configStackName = configStackName;
	}

	public boolean isConsoleMetricsReporterActivated() {
		return consoleMetricsReporterActivated;
	}

	public void setConsoleMetricsReporterActivated(boolean consoleMetricsReporterActivated) {
		this.consoleMetricsReporterActivated = consoleMetricsReporterActivated;
	}

	public String getConsoleMetricsFilters() {
		return consoleMetricsFilters;
	}

	public void setConsoleMetricsFilters(String consoleMetricsFilters) {
		this.consoleMetricsFilters = consoleMetricsFilters;
	}

	public int getConsoleMetricsReporterRateSec() {
		return consoleMetricsReporterRateSec;
	}

	public void setConsoleMetricsReporterRateSec(int consoleMetricsReporterRateSec) {
		this.consoleMetricsReporterRateSec = consoleMetricsReporterRateSec;
	}

	public boolean isCloudWatchMetricsReporterActivated() {
		return cloudWatchMetricsReporterActivated;
	}

	public void setCloudWatchMetricsReporterActivated(boolean cloudWatchMetricsReporterActivated) {
		this.cloudWatchMetricsReporterActivated = cloudWatchMetricsReporterActivated;
	}

	public String getCloudWatchMetricFilters() {
		return cloudWatchMetricFilters;
	}

	public void setCloudWatchMetricFilters(String cloudWatchMetricFilters) {
		this.cloudWatchMetricFilters = cloudWatchMetricFilters;
	}

	public int getCloudWatchMetricsReporterRateSec() {
		return cloudWatchMetricsReporterRateSec;
	}

	public void setCloudWatchMetricsReporterRateSec(int cloudWatchMetricsReporterRateSec) {
		this.cloudWatchMetricsReporterRateSec = cloudWatchMetricsReporterRateSec;
	}

	public String getLogLevelOverride() {
		return logLevelOverride;
	}

	public void setLogLevelOverride(String logLevelOverride) {
		this.logLevelOverride = logLevelOverride;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ApplicationConfiguration [componentName=").append(componentName).append(", tierName=")
				.append(tierName).append(", configServiceUrl=").append(configServiceUrl).append(", configStackName=")
				.append(configStackName).append(", consoleMetricsReporterActivated=")
				.append(consoleMetricsReporterActivated).append(", consoleMetricsFilters=")
				.append(consoleMetricsFilters).append(", consoleMetricsReporterRateSec=")
				.append(consoleMetricsReporterRateSec).append(", cloudWatchMetricsReporterActivated=")
				.append(cloudWatchMetricsReporterActivated).append(", cloudWatchMetricFilters=")
				.append(cloudWatchMetricFilters).append(", cloudWatchMetricsReporterRateSec=")
				.append(cloudWatchMetricsReporterRateSec).append(", logLevelOverride=").append(logLevelOverride)
				.append("]");
		return builder.toString();
	}

}
