package com.sas.mkt.baldur.spring.metrics;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.Metrics;
import io.micrometer.core.instrument.Timer;

/**
 * Ask yourself - should I include this class in my project for production
 * deployments? Hint, think about the name of the class.
 * 
 * You can use this to fire up some known Counters, Timers, and Gauges to test your Registry configurations.
 * 
 * Use the metrics/generatemetrics?runtimesec=60 to fire up the meters. It will run for whatever time you enter (in sec).
 * If you leave the time blank it will run for 10 minutes.
 * 
 * @author razing
 * @since Sprint 2105 (March 2021)
 *
 */
@RestController
@RequestMapping("/")
public class TEMPJUNKMETRICSGENERATOR {
	
	public static HashMap<String, FixedGauge> gaugeMap = new HashMap<>();

	@RequestMapping(value = "metrics/generatemetrics", method = RequestMethod.GET)
	public String createMetrics(@RequestParam(defaultValue = "600") int runtimesec) {
		MetricMaker mm = new MetricMaker();
		mm.runtimesec = runtimesec;
		new Thread(mm).start();
		return "metrics generating for: ?runtimesec=" + runtimesec + " secs";
	}

	private class MetricMaker implements Runnable {

		public int runtimesec;

		@Override
		public void run() {
			System.out.println("FIRING UP METRICS");
			BlabberMetrics metrics = new BlabberMetrics();
			metrics.start();
			try {
				Thread.sleep(runtimesec * 1000l);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("KILLING METRICS");
			metrics.stop();
		}

	}

	private class BlabberMetrics {

		private boolean runit = true;

		public void start() {
			runit = true;
			System.out.println("Starting BlabberMetrics...");
			simpleTimer();
			buttersGauge();
			finnrGauge();
			aldirCounter();
			samCounter();
			baldurCounter();
			mymirCounter();
		}

		public void stop() {
			System.out.println("Stopping BlabberMetrics...");
			runit = false;
		}

		private void simpleTimer() {
			Timer timer = Metrics.timer("bstimer", "info", "true");
			TimerBlabber tb = new TimerBlabber();
			tb.configure(2000l);
			tb.setMeter(timer);
			Thread t1 = new Thread(tb);
			t1.start();
		}

		private void buttersGauge() {
			List<String> list = new ArrayList<>(4);
			Gauge gauge = Gauge.builder("butters", list, List::size).tags("info", "true")
					.register(Metrics.globalRegistry);
			GaugeBlabber cb = new GaugeBlabber(list);
			cb.configure(10000l, "butters");
			cb.setMeter(gauge);
			Thread t1 = new Thread(cb);
			t1.start();
		}

		private void finnrGauge() {
			List<String> list = new ArrayList<>(4);
			Gauge gauge = Gauge.builder("finnr", list, List::size).tags("scaling", "false", "info", "true")
					.register(Metrics.globalRegistry);

			GaugeBlabber cb = new GaugeBlabber(list);
			cb.configure(5000l, "finnr");
			cb.setMeter(gauge);
			Thread t1 = new Thread(cb);
			t1.start();
		}

		private void aldirCounter() {
			Counter c1 = Metrics.counter("aldir", "info", "true");
			CounterBlabber cb = new CounterBlabber();
			cb.configure(3000l, "aldir");
			cb.setMeter(c1);
			Thread t1 = new Thread(cb);
			t1.start();
		}

		private void samCounter() {
			Counter c1 = Metrics.counter("sam", "scaling", "true", "info", "true");
			CounterBlabber cb = new CounterBlabber();
			cb.configure(1000l, "sam");
			cb.setMeter(c1);
			Thread t1 = new Thread(cb);
			t1.start();
		}

		private void baldurCounter() {
			Counter c1 = Metrics.counter("baldur", "scaling", "true", "info", "true");
			CounterBlabber cb = new CounterBlabber();
			cb.configure(6000l, "baldur");
			cb.setMeter(c1);
			Thread t1 = new Thread(cb);
			t1.start();
		}

		private void mymirCounter() {
			Counter c1 = Metrics.counter("mymir");
			CounterBlabber cb = new CounterBlabber();
			cb.configure(3000l, "mymir");
			cb.setMeter(c1);
			Thread t1 = new Thread(cb);
			t1.start();
		}

		private class TimerBlabber implements Runnable {

			private Long sleepTime = 1000l;
			private Timer meter;

			private void setMeter(Timer meter) {
				this.meter = meter;
			}

			public void configure(long sleepTime) {
				this.sleepTime = sleepTime;
			}

			@Override
			public void run() {
				while (runit) {
					meter.record(() -> {
						try {
							long dt = (long) (Math.random() * 100);
							Thread.sleep(950l + dt); // 1000 ms +/- 50 ms
						} catch (Exception ex) {
							ex.printStackTrace();
						}
					});
					try {
						Thread.sleep(sleepTime);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}

		}

		private class CounterBlabber implements Runnable {

			public void configure(long sleepTime, String name) {
				this.sleepTime = sleepTime;
				this.name = name;
			}

			private String name;
			private Long sleepTime = 1000l;
			private Counter meter;

			private void setMeter(Counter meter) {
				this.meter = meter;
			}

			@Override
			public void run() {
				while (runit) {
					meter.increment();
//					System.out.println("*** incrementing counter for : " + name + " -> " + meter.count());
					try {
						Thread.sleep(sleepTime);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}

		}
		

		private class GaugeBlabber implements Runnable {

			List<String> list;

			public GaugeBlabber(List<String> list) {
				this.list = list;
			}

			public void configure(long sleepTime, String name) {
				this.sleepTime = sleepTime;
				this.name = name;
			}

			private String name;
			private Long sleepTime = 1000l;
			private Gauge meter;

			private void setMeter(Gauge meter) {
				this.meter = meter;
			}

			@Override
			public void run() {
				int i = 0;
				while (runit) {
					i++;
					list.add("hello");
//					System.out.println("*** gauge value for : " + name + " -> " + val);
					try {
						Thread.sleep(sleepTime);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					if (i % 1000 == 0) {
						System.out.println("CLEARING THE LIST for GAUGES");
						list.clear();
					}
				}

			}

		}
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "metrics/buildgauge", method = RequestMethod.GET)
	public String buildGauge(
			@RequestParam(defaultValue = "6000") long runTimeSec,
			@RequestParam(defaultValue = "baldurdog") String name,
			@RequestParam(defaultValue = "1000") int size
			) {
		String gname = buildGauge(name, runTimeSec, size);
		return "built gauge: " + gname;
	}

	
	private String buildGauge(String name, long runTimeSec, int size) {
		if (gaugeMap.containsKey(name)) {
			FixedGauge fg = gaugeMap.get(name);
			fg.killSwitch();
			List<String> list = fg.getList();
			Gauge gauge = fg.getGauge();
			FixedGauge fixedGauge = new FixedGauge(gauge, runTimeSec, size, list);
			Thread t = new Thread(fixedGauge);
			t.start();
		} else {
			List<String> list = new ArrayList<>(4);
			Gauge gauge = Gauge.builder(name, list, List::size).tags("scaling", "true")
					.register(Metrics.globalRegistry);  
			FixedGauge fixedGauge = new FixedGauge(gauge, runTimeSec, size, list);
			Thread t = new Thread(fixedGauge);
			t.start();
			gaugeMap.put(name, fixedGauge);
		}
		return name;
	}
	
	private class FixedGauge implements Runnable {
		
		private Gauge gauge;
		private long runTimeSec;
		private int size;
		private List<String> list;
		
		private boolean doit = true;
		
		public Gauge getGauge() {
			return gauge;
		}
		
		public List<String> getList() {
			return list;
		}
		
		public FixedGauge(Gauge gauge, long runTimeSec, int size, List<String> list) {
			this.gauge = gauge;
			this.runTimeSec = runTimeSec;
			this.size = size;
			this.list = list;
			list.clear();
			for (int i=0; i< size; i++) {
				list.add("hello");
			}
		}
		
		public void killSwitch() {
			doit = false;
		}

		@Override
		public void run() {
			System.out.println("--> starting Gauge: " + gauge.getId());
			long startTime = System.currentTimeMillis() / 1000;
			while (doit) {
				long endTime = System.currentTimeMillis() / 1000;
				if ((endTime - startTime) > runTimeSec) doit = false;
				int buffer = (int)(Math.random() * size/10.0);
				double sign = Math.random();
				if (sign < 0.5) {
					for (int j=(list.size()-buffer); j < list.size(); j++) {
						list.remove(j);
					}
				} else {
					for (int j=0; j < buffer; j++) {
						list.add("hello");
					}
				}	
				try {
					Thread.sleep(1000l);
					System.out.println("--> size: " + list.size());
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			System.out.println("--> killing Gauge: " + gauge.getId());
		}
		
	}

}
 