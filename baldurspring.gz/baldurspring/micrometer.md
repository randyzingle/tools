# Micrometer (and DataDog)

Micrometer allows you to instrument your code with dimensional metrics with a vendor-neutral interface and decide on the monitoring system as a last step - potentially shipping metrics to multiple back ends.

Micrometer comes with built in support for the following (among others):
* Azure Monitor
* CloudWatch
* Datadog
* Elastic
* Prometheus
* StatsD

Micrometer comes with out of the box instrumentation of
* caches
* classloader
* garbage collection
* processor utilization
* thread pools
* ... more

Meter - interface for collecting a set of measurements. Meters are created from and held in a MeterRegistry. Each supported monitoring system has an implementation of a MeterRegistry. How a registry is created varies for each implementation.

SimpleMeterRegistry - holds the data in memory and doesn't export the data anywhere. A SimpleMeterRegistry is autowired into your Spring based apps.

CompositeMeterRegistry - hold multiple registries, allowing you to publish metrics to more than one monitoring system simultaneously. We can use the CompositeMeterRegistry to **create all of our meters** then add target registries to the CompositeMeterRegistry for delivery. There is a static global registry (Metrics.globalRegistry) which is a composite registry that has static builders for generating meters. This is **what we should be using to create all of our meters**.

Meters are uniquely identified by name and dimension.
Naming convention - use all lower case and separate words with a '.', as in:
```sh
registry.timer("http.server.requests")
```
Micrometer will translate this name to one that conforms with the naming conventions of your target system.

Use the same naming convention for tags:
```sh
registry.counter("database.calls", "db", "users")
registry.counter("http.requests", "uri", "/api/users")
```

Common tags can be configured at the registry level:
```java
registry.config().commonTags("stack", "prod", "region", "us-east-1");
registry.config().commonTags(Arrays.asList(Tag.of("stack", "prod"), Tag.of("region", "us-east-1"))); // equivalently
```
In the Spring environment this is more commonly done by adding a MeterRegistryCustomizer bean to be sure that common tags are applied before autoconfigured meter binders.

Meter Filters - you can configure **each registry** with meter filters, controlling at the registry level, what meters are registered and what kinds of statistics they emit. You can:
* Deny or Accept meters
* Transform meter IDs (changing names, tags, base units)
* Configure distribution statistics for some meter types
Implementations of MeterFilter are added programmatically to the registry:
```java
registry.config()
    .meterFilter(MeterFilter.ignoreTags("too.much.information"))
    .meterFilter(MeterFilter.denyNameStartsWith("jvm"));
```

## Spring Boot 2
Spring Boot 2 configures a composite MeterRegistry to which any number of registry implementations can be added, allowing you to ship your metrics to more than one monitoring system. Through, MeterRegistryCustomizer, you can customize the whole set of registries at once or individual implementations in particular. For example, a commonly requested setup is to (1) export metrics to both Prometheus and CloudWatch, (2) add a set of common tags to metrics flowing to both (for example, host and application identifying tags) and (3) whitelist only a small subset of metrics to CloudWatch.

### Create simple Meters

```java
String name = "baldurcount";
Counter c1 = Metrics.counter(name);
for (int i=0; i<100; i++) {
  c1.increment();
}
```
At http://localhost:8080/baldur/actuator/metrics/baldurcount
```json
{
  "name": "baldurcount",
  "description": null,
  "baseUnit": null,
  "measurements": [
    {
      "statistic": "COUNT",
      "value": 57
    }
  ],
  "availableTags": []
}
```

Customization

Enable/Disable Registries:
management.metrics.export.datadog.enabled=false
...

Configuration:
management.metrics.export.datadog.api-key=YOUR_KEY
management.metrics.export.datadog.step=30s

management.metrics.export.elastic.host=https://elastic.example.com:8086


<dependency>
	<groupId>io.prometheus</groupId>
	<artifactId>simpleclient_pushgateway</artifactId>
</dependency>
When the Prometheus Pushgateway dependency is present on the classpath, Spring Boot auto-configures a PrometheusPushGatewayManager bean. This manages the pushing of metrics to a Prometheus Pushgateway. The PrometheusPushGatewayManager can be tuned using properties under management.metrics.export.prometheus.pushgateway. For advanced configuration, you can also provide your own PrometheusPushGatewayManager bean.
