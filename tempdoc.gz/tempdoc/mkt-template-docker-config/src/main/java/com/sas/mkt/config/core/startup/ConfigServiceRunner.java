package com.sas.mkt.config.core.startup;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import com.sas.mkt.config.core.ApplicationConstants;
import com.sas.mkt.config.core.BaseUtils;
import com.sas.mkt.config.core.ConfigUtils;
import com.sas.mkt.config.core.redis.RedisConfigListener;

/**
 * This class loads application specific and tier_global properties from the
 * Configuration Service. The method, public void run(ApplicationArguments
 * args), is called once the Spring application context is fully loaded so all
 * of the configuration properties will have been loaded from property files and
 * the environment, by the time this runs.
 *
 * The Configuration Server is queried with: 
 * 		tierNm=appConfig.getTierName()
 * 		componentNm=appConfig.getComponentName() 
 * and with:
 * 		tierNm=appConfig.getTierName()
 * 		componentNm="component_global" 
 * to get back a list of all properties for that tier/component.
 * 
 * Defaults for all application specific properties are given in
 * application.properties. These will be overridden by environment variables,
 * system properties, and configuration server values (for the given tierNm and
 * componentNm). We are assuming that values for application-specific properties
 * are only set in the config server as overrides or features flags which is why
 * that has top precedence.
 *
 * The order of precedence for Application properties is (top one wins):
 * <ol>
 * <li>Configuration Server value</li>
 * <li>System Property (-Dname=value pair given on java command line)</li>
 * <li>OS Environment variable</li>
 * <li>application.properties</li>
 * </ol>
 *
 * The order of precedence for Global properties is (top one wins):
 * <ol>
 * <li>System Property (-Dname=value pair given on java command line)</li>
 * <li>OS Environment variable</li>
 * <li>application.properties</li>
 * <li>Configuration Server value</li>
 * </ol>
 * 
 * The following sample values show you the naming conventions you need to use:
 * in ApplicationConfiguration.java: private double bigNumber;
 * Spring Framework:
 * in application.properties: application.bigNumber=3.7E45
 * as System Property: -Dapplication.bigNumber=3.7E45
 * as Environment var: APPLICATION_BIG_NUMBER=3.47E45
 * Config Server:
 * name=bigNumber, value=3.47E45
 *
 * When running in EC2 the URL for the configuration server and the tierName
 * must be passed in as environment variables. When running locally you can use
 * environment variables or set the values in application.properties.
 *
 * This is the first ApplicationRunner that runs (getOrder() = 0)
 *
 * @author razing
 *
 */
@Component
public class ConfigServiceRunner implements ApplicationRunner, Ordered {

	private final static Logger logger = LoggerFactory.getLogger(ConfigServiceRunner.class);

	@Autowired
	ConfigUtils configUtils;
	
	@Autowired
	RedisConfigListener redisConfigListener;

	@Override
	public int getOrder() {
		return ApplicationConstants.CONFIG_SERVICE_RUNNER_ORDER;
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		// Get original configuration information from the Config Server
		BaseUtils.bigPrint("Getting Config Data");
		configUtils.init();
		logger.debug("ConfigUtils init()");
		// Hook up to Redis to get notifications
		redisConfigListener.init();
		logger.debug("RedisConfigListener init()");
	}
	
}
