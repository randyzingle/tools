package com.sas.mkt.config.core.configserver;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;

/**
 * @author razing
 *
 */
@Component
public class ConfigServerClient {

	private final static Logger logger = LoggerFactory.getLogger(ConfigServerClient.class);

	ApplicationConfiguration appConfig;
	@Autowired
	public ConfigServerClient(ApplicationConfiguration appConfig) {
		this.appConfig = appConfig;
	}
	
	public boolean isHealthy() {
		try {
			List<ConfigProperty> props = getProperties("tier_global", "mkt-kafka", "", "");
			if (props != null && props.size() > 1) return true;
		} catch (Exception ex) {
			return false;
		}
		return false;
	}

	protected RestTemplate getRestTemplate() {
		return new RestTemplate();
	}

	public void deleteProperty(ConfigProperty cp) throws RestClientException {
		if (cp.id == null) {
			List<ConfigProperty> cpl = this.getProperties(cp.tierNm, cp.componentNm, cp.name, null);
			if (cpl == null || cpl.size() != 1 || cpl.get(0).id == null) {
				String s = "Failed to delete config property, could not get property ID from config server for "
						+ cp.toString();
				logger.error(s);
				throw (new RestClientException(s));
			} else {
				cp.id = cpl.get(0).id;
			}
		}
		logger.debug("deleting property for {}", cp.toString());
		String auditComponent = appConfig.getComponentName();
		RestTemplate restTemplate = getRestTemplate();
		String url = appConfig.getConfigServiceUrl() + ConfigProperty.COLLECTION_NAME + "/" + cp.id;
		HttpHeaders headers = new HttpHeaders();
		headers.set(ConfigProperty.AUDIT_COMPONENT_HEADER, auditComponent);
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.DELETE, entity, String.class);
		logger.debug(responseEntity.getBody());

	}

	public void updateProperty(ConfigProperty cp) throws RestClientException {
		if (cp.id == null) {
			List<ConfigProperty> cpl = this.getProperties(cp.tierNm, cp.componentNm, cp.name, null);
			if (cpl == null || cpl.size() != 1 || cpl.get(0).id == null) {
				String s = "Failed to update config property, could not get property ID from config server for "
						+ cp.toString();
				logger.error(s);
				throw (new RestClientException(s));
			} else {
				cp.id = cpl.get(0).id;
				logger.debug("updating property for {}", cp.toString());
			}
		}

		String auditComponent = appConfig.getComponentName();
		RestTemplate restTemplate = getRestTemplate();
		String url = appConfig.getConfigServiceUrl() + ConfigProperty.COLLECTION_NAME + "/" + cp.id;
		HttpHeaders headers = new HttpHeaders();
		headers.set(ConfigProperty.AUDIT_COMPONENT_HEADER, auditComponent);
		headers.set("Content-Type", ConfigProperty.MEDIA_TYPE_JSON_VALUE);

		HttpEntity<ConfigProperty> request = new HttpEntity<ConfigProperty>(cp, headers);
		restTemplate.put(url, request, ConfigProperty.class);
	}

	/*
	 * Create a new property in the config server Will throw a 400 bad request if
	 * the property already exists
	 */
	public ConfigProperty createProperty(String tierName, String componentName, String name, String value)
			throws RestClientException {
		ConfigProperty cps = new ConfigProperty(tierName, componentName, name, value);
		return createProperty(cps);
	}

	public ConfigProperty createProperty(ConfigProperty configProperty) {
		String auditComponent = appConfig.getComponentName();
		RestTemplate restTemplate = getRestTemplate();
		String url = appConfig.getConfigServiceUrl() + ConfigProperty.COLLECTION_NAME;
		HttpHeaders headers = new HttpHeaders();
		headers.set("AuditComponent", auditComponent);
		headers.set("Content-Type", ConfigProperty.MEDIA_TYPE_JSON_VALUE);
		HttpEntity<ConfigProperty> request = new HttpEntity<ConfigProperty>(configProperty, headers);
		ConfigProperty createdProp = restTemplate.postForObject(url, request, ConfigProperty.class);
		return createdProp;
	}

	public ConfigProperty getProperty(ConfigProperty config) throws RestClientException {
		ConfigProperty cp = null;
		List<ConfigProperty> list = getProperties(config);
		if (list != null && list.size() == 1) {
			cp = list.get(0);
		} else {
			throw new RestClientException("Could not find property: " + config);
		}
		return cp;
	}

	public List<ConfigProperty> getProperties(String tierName, String componentName, String name, String value)
			throws RestClientException {
		ConfigProperty cps = new ConfigProperty(tierName, componentName, name, null);
		List<ConfigProperty> props = getProperties(cps);
		return props;
	}

	public List<ConfigProperty> getProperties(ConfigProperty config) throws RestClientException {
		String auditComponent = appConfig.getComponentName();
		// note all the RestTemplate stuff throws the RuntimeException:
		// org.springframework.web.client.RestClientException

		RestTemplate restTemplate = getRestTemplate();
		String name = config.name == null ? "" : config.name;
		String value = config.value == null ? "" : config.value;
		String componentNm = config.componentNm == null ? "" : config.componentNm;
		String url = appConfig.getConfigServiceUrl() + ConfigProperty.COLLECTION_NAME + "?tierNm=" + config.tierNm
				+ "&componentNm=" + componentNm + "&name=" + name + "&value=" + value;

		HttpHeaders headers = new HttpHeaders();
		headers.set("AuditComponent", auditComponent);
		headers.set("Accept", "application/json");

		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);

		ResponseEntity<ResourceCollection<ConfigProperty>> responseEntity = null;

		int pageSize = 500;
		int pageStart = 0;
		boolean nextPage = true;
		List<ConfigProperty> allProps = new ArrayList<>();

		while (nextPage) {
			String pagedURL = url + "&start=" + pageStart + "&limit=" + pageSize;

			try {
				responseEntity = restTemplate.exchange(pagedURL, HttpMethod.GET, entity,
						new ParameterizedTypeReference<ResourceCollection<ConfigProperty>>() {
						});
				ResourceCollection<ConfigProperty> collection = responseEntity.getBody();
				List<ConfigProperty> props = collection.items;

				if (null == allProps) {
					allProps = props;
				} else
					allProps.addAll(props);

				if (null == props || (props.size() < pageSize))
					nextPage = false;
				else {
					pageStart += props.size();
				}

			} catch (Exception rce) {
				String message = String.format("Failed to connect to the config server at %s%n%s", url,
						rce.getMessage());
				logger.error(message);

				// validInitialization = false;
				nextPage = false;
			}
		}

		return allProps;
	}

	public void printPropertyIds(List<ConfigProperty> props) {
		for (ConfigProperty cp : props) {
			logger.debug("{} {} {}", cp.id, cp.name, cp.value);
		}
	}

}
