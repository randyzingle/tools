package com.sas.mkt.kafka.clients.utils;

import java.util.*;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.errors.InterruptException;
import org.apache.kafka.common.errors.SerializationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.domain.common.StagedOffer;
import com.sas.mkt.kafka.domain.common.Treatment;
import com.sas.mkt.kafka.domain.events.EnhancedEvent;

public class TestProduceEnhancedEvent {

    private static Logger logger = LoggerFactory.getLogger(TestProduceEnhancedEvent.class);

    private static String clientID = "mkt-kafka-shared-test";
    private static String configServiceURL = "http://configservice-dev.cidev.sas.us:8080/";

    public void produceEventToTopic(String topic, String key, EnhancedEvent e ){
        Producer<String, SpecificRecordBase> producer = getProducer();
        ProducerRecord<String, SpecificRecordBase> record = new ProducerRecord<>(topic, key, e);
        // note, send() actually places the message in a buffer which is read and sent by a separate thread
        try {
            producer.send(record);
            logger.info("Sent event: "+e);
        } catch (SerializationException|BufferExhaustedException|InterruptException ex) {
            ex.printStackTrace();
        }finally{
            producer.close();
        }
    }
    
    public Producer<String, SpecificRecordBase> getProducer() {
        // get the Fire-And-Forget Producer from our utility class
        KafkaConnectionUtils kcu;
        try {
            kcu = KafkaConnectionUtils.getInstance(configServiceURL);
        } catch (Exception ex) {
            logger.error("Failed to connect to Kafka");
            logger.error(ex.getMessage());
            return null;
        }
        Properties properties = kcu.getKafkaProducerProperties("test", "mkt-kafka-shared");
        properties.put(ProducerConfig.CLIENT_ID_CONFIG, clientID);

        Producer<String, SpecificRecordBase> p = new KafkaProducer<>(properties);//kcu.getKafkaProducer(clientID);
        return p;
    }

    //Uncomment @Test to run
    //@Test
    public void testStagedOfferUnidev2(){
        String topic = "unidev-business-events";
        String tenantMoniker = "unidev2";
        int tenantId = 1806102;
        String tenantExternalId = "2ac9ae1e1100013d78aefbb9";        
        
        Map<String,String> properties = new HashMap<String,String>();
        properties.put("NumericWithConstraints-6", "NumericWithConstraints-6-Value");
        properties.put("FormatedNumeric-6", "FormatedNumeric-6-Value");
        properties.put("MultiLineText-6", "MultiLineText-6-Value");
        properties.put("Numeric2-6", "Numeric2-6-Value");
        properties.put("Numeric1-6", "Numeric1-6-Value");
        
        EnhancedEvent enhancedEvent = EnhancedEvent.newBuilder()
            .setGuid(UUID.randomUUID().toString())
            .setEventName("stagedOffer")
            .setChannelType("external")
            .setChannelId("bensonChannelId")
            .setIdentityId("bensonIdentityId")
            .setInternalTenantId(tenantId)
            .setExternalTenantId(tenantExternalId)
            .setStagedOffer(
                StagedOffer.newBuilder()
                .setTreatments(Arrays.asList(Treatment.newBuilder()
                        .setEndTimestamp(Long.MAX_VALUE)
                        .setId("TngWeb3313-6TRT1148")
                        .setProperties(properties)
                        .build()))
                .build())
            .build();
                
        produceEventToTopic(topic, enhancedEvent.getIdentityId(), enhancedEvent);        
    }
    
    
}
