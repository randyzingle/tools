package com.sas.mkt.config.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.sas.mkt.config.core.PropertyDetails;

public class PropertyDetailsTest {

	private PropertyDetails config;
	
	@Before
	public void setUp() throws NoSuchMethodException, SecurityException {
		config = new PropertyDetails("hello", "world", String.class, String.class.getMethod("toString"), String.class.getMethod("toString"));
	}
	
	@Test
	public void testGetters() throws NoSuchMethodException, SecurityException {
		assertEquals("hello", config.getName());
		assertEquals("world", config.getValue());
		assertEquals(String.class, config.getType());
		assertEquals(String.class.getMethod("toString"), config.getSetMethod());
		assertEquals(String.class.getMethod("toString"), config.getGetMethod());
	}
	
	@Test
	public void testToString() {		
		String configString = config.toString();
		String matchString = "PropertyDetails [name=hello, value=world, id=null, componentNm=null, tierNm=null, propertySourceName=null]";
		assertEquals(matchString, configString);
	}
	
	@Test
	public void testHashCode() throws NoSuchMethodException, SecurityException {
		assertEquals(-1107615551, config.hashCode());	
		PropertyDetails tempConfig1 = new PropertyDetails(null, null, String.class, String.class.getMethod("toString"), String.class.getMethod("toString"));
		assertEquals(961, tempConfig1.hashCode());
	}
	
	@Test
	public void testEquals() throws NoSuchMethodException, SecurityException {
		assertTrue(config.equals(config));
		
		assertFalse(config.equals(null));
		
		assertFalse(config.equals(new Object()));
		
		PropertyDetails tempConfig1 = new PropertyDetails(null, null, String.class, String.class.getMethod("toString"), String.class.getMethod("toString"));
		PropertyDetails tempConfig2 = new PropertyDetails(null, null, String.class, String.class.getMethod("toString"), String.class.getMethod("toString"));
		PropertyDetails tempConfig3 = new PropertyDetails("hello", null, String.class, String.class.getMethod("toString"), String.class.getMethod("toString"));
		PropertyDetails tempConfig4 = new PropertyDetails("hello", "world", String.class, String.class.getMethod("toString"), String.class.getMethod("toString"));
		
		assertFalse(config.equals(tempConfig1));
		assertFalse(tempConfig1.equals(config));
		assertTrue(tempConfig1.equals(tempConfig2));
		assertFalse(config.equals(tempConfig3));
		assertTrue(config.equals(tempConfig4));
		assertFalse(tempConfig3.equals(config));
		assertTrue(tempConfig4.equals(config));
	}
}
