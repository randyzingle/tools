package com.sas.mkt.kafka.clients.consumers.standard;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.ConsumerRecord;

public interface CIKafkaRecordProcessor extends Runnable {

	public void run();
	public void shutDown();
	public void processRecord(ConsumerRecord<String, SpecificRecordBase> record);
	
}
