package com.sas.mkt.baldur.spring.db;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.fasterxml.jackson.databind.ObjectMapper;

public class AwsKeys {

	public AwsKeysDTO getAwsKey() {
		AwsKeysDTO keys = null;
		StringBuffer buff = new StringBuffer();

		// are we running in ECS?
		String credurl = System.getenv("AWS_CONTAINER_CREDENTIALS_RELATIVE_URI");
		if (credurl != null) {
			try {
				URL url = new URL("http://169.254.170.2" + credurl);
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				con.setRequestMethod("GET");
				BufferedReader rd = new BufferedReader(new InputStreamReader(con.getInputStream()));
				String line;
				while ((line = rd.readLine()) != null) {
					buff.append(line);
				}
				rd.close();
				ObjectMapper mapper = new ObjectMapper();
				keys = mapper.readValue(buff.toString(), AwsKeysDTO.class);
			} catch (Exception ex) {
				// log this - do something intelligent
				System.out.println(ex.getMessage());
			}
			return keys;
		}
		// TODO need to do EKS check as well
		
		// TODO pull from environment variables if running locally
		return keys;
	}

}
