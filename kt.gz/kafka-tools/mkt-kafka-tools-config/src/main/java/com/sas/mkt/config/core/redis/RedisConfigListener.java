package com.sas.mkt.config.core.redis;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Timer;
import java.util.TimerTask;

import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.appspecific.GlobalConfiguration;
import com.sas.mkt.config.core.ApplicationConstants;
import com.sas.mkt.config.core.BaseUtils;
import com.sas.mkt.config.core.configserver.ConfigServerClient;
import com.sas.mkt.config.core.startup.ConfigServiceHelper;
import com.sas.mkt.config.health.ExternalDependency;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPubSub;

@Component
public class RedisConfigListener implements Runnable, ExternalDependency {
	
	private final static Logger logger = LoggerFactory.getLogger(ConfigServerClient.class);
	
	public static final String CONFIG_REDIS_THREADNAME = "sas-config-redis-thread";
	
	private static final String CONFIG_SERVER_UPDATE_CHANNEL = "-events";
//	private static final String CONFIG_SERVER_UPDATE_KEY = "-timestamp";
	
	// We going to stage changes as they come in and then will only refresh config properties once
	// we haven't seen a change for more than delay ms.
	private static long DELAY_CONFIG_UPDATE_MS = 5000L; // 5 secs
	private static boolean stagedChange = false;
	private Timer timer;
	
	private Jedis jedis;
	private JedisPubSub jedisPubSub;
	
	protected String redisHost;
	protected int redisPort;
	
	ApplicationConfiguration appConfig;
	GlobalConfiguration globalConfig;
	ConfigServiceHelper configServiceHelper;
	@Autowired
	public RedisConfigListener(ApplicationConfiguration appConfig, GlobalConfiguration globalConfig,
			ConfigServiceHelper configServiceHelper) {
		this.appConfig = appConfig;
		this.globalConfig = globalConfig;
		this.configServiceHelper = configServiceHelper;
	}
	
	public Jedis getJedisConnection() {
		if(this.isHealthy()) {
			return jedis;
		} else {
			this.restart();
		}
		return jedis;
	}
	
	/**
	 * This is how the Redis endpoints are stored in the config server:
	 * 
	 * These are used for publishing to Redis:
	 * aws-redis: redis_cluster_primary_endpoint_port, 6379
	 * aws-redis: redis_cluster_primary_endpoint, cache-dev-redis.cidev.sas.us
	 * 
	 * These are used for read-only access to Redis:
	 * aws-redis: redis_cluster_read_endpoint_ports, [6379] // stored as an array of ints
	 * aws-redis: redis_cluster_read_endpoints, cache-dev-redis.cidev.sas.us // stored as a comma separated list
	 * 
	 * The following method picks a port and endpoint/host from the read list and falls back
	 * to the primary ports if it can't find any.
	 */
	protected void setupRedisEndpoints() {
		String host = null;
		String ports = null;
		int port = -1;

		host = globalConfig.getRedisClusterReadEndpoints();
		if (host != null) {
			if (host.contains(",")) {
				String[] hlist = host.split(",");
				host = hlist[0];
			}
			try { 
			    InetAddress inetHost = InetAddress.getByName(host);
			    logger.debug("Found RedisClusterReadEndpoint host: {}", inetHost.getHostName());
			} catch(UnknownHostException uhe) {	 
				host = null;
			    logger.warn("Found a RedisClusterReadEndpoint host but it's an invalid hostname: {}", uhe.getMessage());
			}
			redisHost = host;
		}

		ports = globalConfig.getRedisClusterReadEndpointPorts();
		if (ports != null) {
			ports = ports.replaceAll("\\[", "").replaceAll("\\]","");
			if (ports.contains(",")) {
				String[] plist = ports.split(",");
				ports = plist[0];
			}
			try {
				port = Integer.parseInt(ports);
			} catch (NumberFormatException nfe) {
				logger.warn("Found a RedisClusterReadEndpointPort in ConfigServer but can't parse it {}", nfe.getMessage());
			}
			redisPort = port;
		}
		
		if (ports == null || host == null || port == -1) {
			// we'll try to use the primary endpoints
			redisHost = globalConfig.getRedisClusterPrimaryEndpoint();
			redisPort = globalConfig.getRedisClusterPrimaryEndpointPort();
		}

	}

	@Override
	public void run() {
		jedis = openJedisConnection();
		BaseUtils.bigInfo("Connecting to Redis at: " + globalConfig.getRedisClusterPrimaryEndpoint() + ":"
				+ globalConfig.getRedisClusterPrimaryEndpointPort(), logger);
//		// time stamp of last updated property in the config server: we aren't using this (yet)
//		String key = appConfig.getConfigStackName() + CONFIG_SERVER_UPDATE_KEY;
//		String ts = jedis.get(key);
//		Date date = new Date(Long.parseLong(ts));

		String channel = appConfig.getConfigStackName() + CONFIG_SERVER_UPDATE_CHANNEL;
		jedisPubSub = new RedisChannelSubscriber();
		// blocking method
		jedis.subscribe(jedisPubSub, channel);	
	}
	
	private class RedisChannelSubscriber extends JedisPubSub {
		@Override 
		public void onMessage(String channel, String message) {
			logger.trace("Redis channel: {}", channel);
			logger.debug("Redis message: {}", message);
			ObjectMapper mapper = new ObjectMapper();
			try {
				RedisMessage re = mapper.readValue(message, RedisMessage.class);
				if (re.getTierNm().equals(appConfig.getTierName())) {
					if (re.getComponentNm().equals(appConfig.getComponentName()) || re.getComponentNm().equals(ApplicationConstants.GLOBAL_COMPONENT_NAME)) {
						BaseUtils.bigInfo("Found configuration server match in redis poll: " + re.toString(), logger);
	
						if (stagedChange) {
							timer.cancel();
							timer = new Timer();
							timer.schedule(new ConfigRefresher(), DELAY_CONFIG_UPDATE_MS);
						} else {
							stagedChange = true;
							timer = new Timer();
							timer.schedule(new ConfigRefresher(), DELAY_CONFIG_UPDATE_MS);
						}
						
					}
				}
			} catch (IOException ioex) {
				logger.warn("Failed to read Redis Config Message: " + ioex.getMessage()); 
			}
		}
	}
	
	private class ConfigRefresher extends TimerTask {

		@Override
		public void run() {	
			configServiceHelper.refreshProperties();
			stagedChange = false;
		}
		
	}
	
	protected Jedis openJedisConnection() {
		setupRedisEndpoints();
		Jedis jedis = new Jedis(redisHost, redisPort);
		return jedis;
	}
	
	@PreDestroy
	public void close() {
		logger.debug("Closing Redis Connection");
		logger.debug("Unsubscribe from channels...");
		if(jedisPubSub != null && jedisPubSub.isSubscribed()) {
			jedisPubSub.unsubscribe();
			// unsubscribe isn't instant. Give it a second
			try {Thread.sleep(500);}catch(Exception ex) {logger.info(ex.getMessage());}
		}
		logger.debug("Close Redis Connection...");
		// trap any socket exceptions from channels that haven't dropped their subscriptions yet
		try {
			jedis.close();
		} catch (Exception ex) {
			logger.warn("Problem closing Redis Connection: " + ex.getMessage());
		}
	}
	
	@Override
	public void init() {
		Thread redisThread = new Thread(this, RedisConfigListener.CONFIG_REDIS_THREADNAME);
		redisThread.start();
	}
	
	@Override
	public boolean isHealthy() {
		if (jedis == null || !jedis.isConnected()) return false;
		return true;
	}
	@Override
	public void restart() {
		close();
		init();
	}
	
}
