package com.sas.mkt.config.appspecific;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.sas.mkt.config.core.Configuration;

@Component
@PropertySource("classpath:tier_global_overrides.properties")
@ConfigurationProperties(prefix = "tier-global", ignoreUnknownFields=false, ignoreInvalidFields=false)
public class GlobalConfiguration extends Configuration {
    
	/*
	 * tier_global_ovverides.properities should only be populated in development environments to 
	 * do things like point to a locally running redis server vs the AWS redis cluster.  
	 */
	// Service Discovery
	private String mktTenantServiceUrl;
	
	// Redis
	private String redisClusterPrimaryEndpoint;
	private int redisClusterPrimaryEndpointPort;
	//redis_cluster_read_endpoint_ports
	private String redisClusterReadEndpointPorts;
	private String redisClusterReadEndpoints;
	
	// S3 Buckets
	private String dataBucketTopic;
	private String configBucket;
	private String dataBucket;
	private String deploymentBucket;
	private String opsBucket;
	private String testBucket;
	
	// Kafka 
	private String sasMktKafkaSchemaRegistry;
	private String sasMktKafkaConnectS3Bucket;
	private String sasMktKafkaConnectDistributed;
	private String sasMktKafkaCluster;
	private String sasMktKafkaZookeeper;

	// Replay
	private String replayMktDatahubLoaderServiceUrl;

	public String getMktTenantServiceUrl() {
		return mktTenantServiceUrl;
	}
	public void setMktTenantServiceUrl(String mktTenantServiceUrl) {
		this.mktTenantServiceUrl = mktTenantServiceUrl;
	}
	public String getRedisClusterPrimaryEndpoint() {
		return redisClusterPrimaryEndpoint;
	}
	public void setRedisClusterPrimaryEndpoint(String redisClusterPrimaryEndpoint) {
		this.redisClusterPrimaryEndpoint = redisClusterPrimaryEndpoint;
	}
	public int getRedisClusterPrimaryEndpointPort() {
		return redisClusterPrimaryEndpointPort;
	}
	public void setRedisClusterPrimaryEndpointPort(int redisClusterPrimaryEndpointPort) {
		this.redisClusterPrimaryEndpointPort = redisClusterPrimaryEndpointPort;
	}
	public String getRedisClusterReadEndpointPorts() {
		return redisClusterReadEndpointPorts;
	}
	public void setRedisClusterReadEndpointPorts(String redisClusterReadEndpointPorts) {
		this.redisClusterReadEndpointPorts = redisClusterReadEndpointPorts;
	}
	public String getRedisClusterReadEndpoints() {
		return redisClusterReadEndpoints;
	}
	public void setRedisClusterReadEndpoints(String redisClusterReadEndpoints) {
		this.redisClusterReadEndpoints = redisClusterReadEndpoints;
	}
	public String getDataBucketTopic() {
		return dataBucketTopic;
	}
	public void setDataBucketTopic(String dataBucketTopic) {
		this.dataBucketTopic = dataBucketTopic;
	}
	public String getConfigBucket() {
		return configBucket;
	}
	public void setConfigBucket(String configBucket) {
		this.configBucket = configBucket;
	}
	public String getDataBucket() {
		return dataBucket;
	}
	public void setDataBucket(String dataBucket) {
		this.dataBucket = dataBucket;
	}
	public String getDeploymentBucket() {
		return deploymentBucket;
	}
	public void setDeploymentBucket(String deploymentBucket) {
		this.deploymentBucket = deploymentBucket;
	}
	public String getOpsBucket() {
		return opsBucket;
	}
	public void setOpsBucket(String opsBucket) {
		this.opsBucket = opsBucket;
	}
	public String getTestBucket() {
		return testBucket;
	}
	public void setTestBucket(String testBucket) {
		this.testBucket = testBucket;
	}
	public String getSasMktKafkaSchemaRegistry() {
		return sasMktKafkaSchemaRegistry;
	}
	public void setSasMktKafkaSchemaRegistry(String sasMktKafkaSchemaRegistry) {
		this.sasMktKafkaSchemaRegistry = sasMktKafkaSchemaRegistry;
	}
	public String getSasMktKafkaConnectS3Bucket() {
		return sasMktKafkaConnectS3Bucket;
	}
	public void setSasMktKafkaConnectS3Bucket(String sasMktKafkaConnectS3Bucket) {
		this.sasMktKafkaConnectS3Bucket = sasMktKafkaConnectS3Bucket;
	}
	public String getSasMktKafkaConnectDistributed() {
		return sasMktKafkaConnectDistributed;
	}
	public void setSasMktKafkaConnectDistributed(String sasMktKafkaConnectDistributed) {
		this.sasMktKafkaConnectDistributed = sasMktKafkaConnectDistributed;
	}
	public String getSasMktKafkaCluster() {
		return sasMktKafkaCluster;
	}
	public void setSasMktKafkaCluster(String sasMktKafkaCluster) {
		this.sasMktKafkaCluster = sasMktKafkaCluster;
	}
	public String getSasMktKafkaZookeeper() {
		return sasMktKafkaZookeeper;
	}
	public void setSasMktKafkaZookeeper(String sasMktKafkaZookeeper) {
		this.sasMktKafkaZookeeper = sasMktKafkaZookeeper;
	}

	public String getReplayMktDatahubLoaderServiceUrl() {
		return replayMktDatahubLoaderServiceUrl;
	}

	public void setReplayMktDatahubLoaderServiceUrl(String replayMktDatahubLoaderServiceUrl) {
		this.replayMktDatahubLoaderServiceUrl = replayMktDatahubLoaderServiceUrl;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("GlobalConfiguration [mktTenantServiceUrl=").append(mktTenantServiceUrl)
				.append(", redisClusterPrimaryEndpoint=").append(redisClusterPrimaryEndpoint)
				.append(", redisClusterPrimaryEndpointPort=").append(redisClusterPrimaryEndpointPort)
				.append(", redisClusterReadEndpointPorts=").append(redisClusterReadEndpointPorts)
				.append(", redisClusterReadEndpoints=").append(redisClusterReadEndpoints).append(", dataBucketTopic=")
				.append(dataBucketTopic).append(", configBucket=").append(configBucket).append(", dataBucket=")
				.append(dataBucket).append(", deploymentBucket=").append(deploymentBucket).append(", opsBucket=")
				.append(opsBucket).append(", testBucket=").append(testBucket).append(", sasMktKafkaSchemaRegistry=")
				.append(sasMktKafkaSchemaRegistry).append(", sasMktKafkaConnectS3Bucket=")
				.append(sasMktKafkaConnectS3Bucket).append(", sasMktKafkaConnectDistributed=")
				.append(sasMktKafkaConnectDistributed).append(", sasMktKafkaCluster=").append(sasMktKafkaCluster)
				.append(", sasMktKafkaZookeeper=").append(sasMktKafkaZookeeper).append("]");
		return builder.toString();
	}

	
}