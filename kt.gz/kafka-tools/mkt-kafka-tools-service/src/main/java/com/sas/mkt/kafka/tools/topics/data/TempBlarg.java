package com.sas.mkt.kafka.tools.topics.data;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TempBlarg {

	public static void main(String[] args) {
		long now = System.currentTimeMillis();
		RecordSetDTO rsd = new RecordSetDTO();
		rsd.requestedEndTime = now;
		rsd.requestedStartTime = now - (1000 * 60 * 60 * 24 * 10);
		rsd.topic = "baldur-test-events";
		ObjectMapper mapper = new ObjectMapper();
		try {
			String json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(rsd);
			System.out.println(json);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
