package com.sas.mkt.config.health;

public interface ExternalDependency extends HealthCheckTarget {
	
	public void init();
	public void restart();
	
}
