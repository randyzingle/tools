# Docker based build


export GRADLE_USER_HOME=/Users/razing/work/github/base/mkt-kafka-tools/.gradle
gradlew build

# docker file
```
FROM ubuntu

LABEL "maintainer"="randall.zingle@sas.com"

RUN apt-get update

RUN apt-get install -y openjdk-8-jdk  && apt-get install -y python3.7

COPY common/ /project/common
COPY .gradle/ /root/.gradle

WORKDIR /project
CMD ["./gradlew", "build"]
```
build directory

```
$ pwd
/Users/razing/work/github/base/mkt-kafka-tools
(base) razing@mlb727 mkt-kafka-tools $ ls
Dockerfile			common				mkt-kafka-tools-smoketest
```
 # build it

 ```
 docker build -t cloudeng/buildimagejdk8:1 .
