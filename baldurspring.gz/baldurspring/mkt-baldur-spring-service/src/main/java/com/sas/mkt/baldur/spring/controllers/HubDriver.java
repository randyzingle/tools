package com.sas.mkt.baldur.spring.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hub")
public class HubDriver {
	
	private Map<String, Candidate> candMap = new HashMap<>();
	{
		Candidate c1 = new Candidate("Baldur", "Zingle", 13, "Chief Barker");
		candMap.put("BaldurZingle", c1);
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/get", method = RequestMethod.GET)
	public ResponseEntity<Candidate> getCandidate(@PathVariable("name") String name) {
		ResponseEntity<Candidate> responseEntity = null;
		Candidate data = null;
		if (name == null || name.isBlank()) {
			data = new Candidate("bad", "bad", 0, "not found");
			responseEntity = new ResponseEntity<>(data, null, HttpStatus.BAD_REQUEST);
		}
		else {
			boolean found = candMap.containsKey(name);
			if (found) data = candMap.get(name);
			responseEntity = new ResponseEntity<>(data, null, HttpStatus.ACCEPTED);
		} 
		return responseEntity;
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/getall", method = RequestMethod.GET)
	public ResponseEntity<List<Candidate>> getCandidates() {
		ResponseEntity<List<Candidate>> responseEntity = null;
		List<Candidate> clist = new ArrayList<>();
		for (String key: candMap.keySet()) {
			clist.add(candMap.get(key));
		}
		responseEntity = new ResponseEntity<>(clist, null, HttpStatus.ACCEPTED);
		return responseEntity;
	}
	
	@CrossOrigin(origins = "http://localhost:8000")
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ResponseEntity<Candidate> edit(@RequestBody Candidate data) {
		ResponseEntity<Candidate> responseEntity = null;
		try {
			if (data == null 
					|| data.firstName == null || data.firstName.isBlank() 
					|| data.lastName == null || data.lastName.isBlank()
					|| data.position == null || data.position.isBlank()) 
			{
				throw new Exception ("bad candidate!");
			} else {
				candMap.put(data.firstName+data.lastName, data);
			}
			responseEntity = new ResponseEntity<>(data, null, HttpStatus.ACCEPTED);
		} catch (Exception rce) {
			// need to let the caller know we failed
			HttpHeaders headers = new HttpHeaders();
			headers.add(rce.getMessage(), rce.getMessage());
			responseEntity = new ResponseEntity<>(null, headers, HttpStatus.BAD_REQUEST);
		}
		// update this based on response above
		return responseEntity;
	}
	
	private class Candidate {
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + getEnclosingInstance().hashCode();
			result = prime * result + age;
			result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
			result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
			result = prime * result + ((position == null) ? 0 : position.hashCode());
			result = prime * result + salary;
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Candidate other = (Candidate) obj;
			if (!getEnclosingInstance().equals(other.getEnclosingInstance()))
				return false;
			if (age != other.age)
				return false;
			if (firstName == null) {
				if (other.firstName != null)
					return false;
			} else if (!firstName.equals(other.firstName))
				return false;
			if (lastName == null) {
				if (other.lastName != null)
					return false;
			} else if (!lastName.equals(other.lastName))
				return false;
			if (position == null) {
				if (other.position != null)
					return false;
			} else if (!position.equals(other.position))
				return false;
			if (salary != other.salary)
				return false;
			return true;
		}
		
		public Candidate(String firstName, String lastName, int age, String position) {
			this.firstName = firstName;
			this.lastName = lastName;
			this.age = age;
			this.position = position;
		}
		public String firstName;
		public String lastName;
		public int age;
		public String position;
		public int salary;
		private HubDriver getEnclosingInstance() {
			return HubDriver.this;
		}
	}

}
