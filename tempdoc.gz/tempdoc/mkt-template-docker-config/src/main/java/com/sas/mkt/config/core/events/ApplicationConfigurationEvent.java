package com.sas.mkt.config.core.events;

import java.util.List;

import org.springframework.context.ApplicationEvent;

import com.sas.mkt.config.core.PropertyDetails;

/**
 * ApplicationConfigurationEvent contains a list of configuration properties that have changed. 
 * Components that need to respond to configuration changes need to implement an @EventListener that
 * listens for this event.
 * 
 * @author razing
 *
 */
public class ApplicationConfigurationEvent extends ApplicationEvent {

    private static final long serialVersionUID = 1L;
    private final List<PropertyDetails> overrideList;

    public ApplicationConfigurationEvent(Object source, List<PropertyDetails> overrideList) {
        super(source);
        this.overrideList = overrideList;
    }

    public List<PropertyDetails> getOverrideList() {
        return overrideList;
    }
    
}
