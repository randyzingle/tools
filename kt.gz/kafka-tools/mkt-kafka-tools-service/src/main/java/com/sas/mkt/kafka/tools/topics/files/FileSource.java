package com.sas.mkt.kafka.tools.topics.files;


import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.avro.Schema;
import org.apache.avro.file.DataFileReader;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.DatumReader;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sas.mkt.kafka.domain.events.RawEvent;

/**
 * @author razing
 *
 */
public class FileSource {

    private String fileName;
    private static List<RawEvent> eventList = new ArrayList<>(100);

    public static void main(String[] args) {
    	FileSource kfs = new FileSource();
        try {
        	String topic = "dev-raw-events";
        	kfs.fileName = "src/main/resources/data/"+topic+".avro";
        	eventList = kfs.generic();
        	FileToKafka ftk = new FileToKafka();
        	ftk.fireAndForget(eventList);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private List<RawEvent> generic() throws Exception {
        File avroFile = new File(fileName);
        DatumReader<GenericRecord> reader = new GenericDatumReader<GenericRecord>();
        DataFileReader<GenericRecord> fileReader = new DataFileReader<GenericRecord>(avroFile, reader);
        GenericRecord record = new GenericData.Record(fileReader.getSchema());
        ObjectMapper mapper = new ObjectMapper();
        int cnt = 0;
        Schema schema = fileReader.getSchema();
        System.out.println(schema.getFullName());
        Class<?> clazz = Class.forName(schema.getFullName());
        System.out.println(clazz.getName());
        while (fileReader.hasNext()) {
        	cnt++;
            fileReader.next(record);   
            String newRec = record.toString();
            Object event = mapper.readValue(newRec, clazz); 
            eventList.add((RawEvent)event);
        }
        fileReader.close();
        System.out.println("Found " + cnt  + " records");
        return eventList;
    }


}