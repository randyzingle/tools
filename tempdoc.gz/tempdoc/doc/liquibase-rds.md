# RDS Usage and Liquibase Integration

## Introduction

If your application uses a Relational Database System (RDS) you have to add various things to your cloudformation script and to your build and property files.

We use Liquibase to create our database structure. Liquibase is a database refactoring system written in Java.  More information can be found at the
[Liquibase web site](http://www.liquibase.org/).

## Build Dependencies: <yourproject>-service/build.gradle
Pull in all of your required RDS libraries. Typically you'll need liquibase for database versioning / ddl, the postgres JDBC driver, hsql libraries for spinning up your container for ping tests, and the spring boot JPA libraries. You will need to add something like this to your service's **build.gradle** file:

#### Runtime libraries
These get deployed with the application.
```
// Database Support - add the following libraries to use RDS (or substitute your JDBC driver if not using postgres)
compile libraries.postgresql
compile libraries.spring_orm
compile libraries.hsql
compile libraries.spring_boot_starter_data_jpa
compile libraries.liquibase
```

#### Integration Test Support
These do not get deployed with the application and are used to spin up and manage a docker-based postgres instance (and whatever other docker-based services you want to run against).
```
// modules for integrationTest
// docker-compose-rule libs -> supports starting docker containers for external dependencies
// docker-compose-rule
testCompile libraries.docker_compose_rule_junit4
testCompile libraries.docker_compose_rule_core
testCompile libraries.jayway_awaitility
testCompile libraries.zafarkhaja
```


## Cloudformation Changes (cloudformation.json)
Add the following to the Parameters section:
```
"ChangeLogFile": {
  "Description": "Liquibase ChangeLog FileName",
  "Type": "String",
  "Default": "db.changelog-master.yaml"
},
"RDSStackName": {
  "Description": "The RDS stack for the region",
  "Default": "dev-rds",
  "Type": "String"
}
```
The first parameter is the name of your changelog file. It **should be db.changelog-master.yaml** but if you've been using something different put your name in instead.

Add the following two resources to the Resources section:
```
"RDSStackInfo": {
  "Type": "Custom::BucketStackInfo",
  "Properties": {
    "ServiceToken": {
      "Fn::Join": [
        ":",
        [
          "arn:aws:lambda",
          {
            "Ref": "AWS::Region"
          },
          {
            "Ref": "AWS::AccountId"
          },
          "function:lookupStackVariables"
        ]
      ]
    },
    "StackName": {
      "Ref": "RDSStackName"
    },
    "GitTagShaVersion": {
      "Ref": "GitTagShaVersion"
    }
  }
},
"RdsDatabaseManager": {
  "Type": "AWS::CloudFormation::CustomResource",
  "Version": "1.0",
  "Properties": {
    "ServiceToken": {
      "Fn::Join": [
        ":",
        [
          "arn:aws:lambda",
          {
            "Ref": "AWS::Region"
          },
          {
            "Ref": "AWS::AccountId"
          },
          "function:RdsDatabaseManager"
        ]
      ]
    },
    "ProjectName": {
      "Fn::FindInMap": [
        "Constants",
        "InstanceValues",
        "ProjectName"
      ]
    },
    "StackPrefix": {
      "Ref": "StackPrefix"
    },
    "RDSStackName": {
      "Ref": "RDSStackName"
    },
    "DeploymentBucket": {
      "Fn::GetAtt": [
        "BaseStackInfo",
        "DeploymentBucket"
      ]
    },
    "CodeDeployLocation": {
      "Ref": "CodeDeployLocation"
    },
    "ECSCluster": {
      "Fn::GetAtt": [
        "ECSStackInfo",
        "ECSCluster"
      ]
    },
    "IsProduction": {
      "Ref": "IsProduction"
    },
    "GitTagShaVersion": {
      "Ref": "GitTagShaVersion"
    },
    "ChangeLogFile": {
      "Ref": "ChangeLogFile"
    },
    "ConfigStackName": {
      "Ref": "ConfigStackName"
    }
  }
},
```

Add the following three environment variables to Resources->TaskDefinition->Properties->ContainerDefinitions->Environment:
```
{
  "Name": "RDSEncodedPassword",
  "Value": {
    "Fn::GetAtt": [
      "RDSStackInfo",
      "RDSEncodedPassword"
    ]
  }
},
{
  "Name": "JdbcURL",
  "Value": {
    "Fn::GetAtt": [
      "RDSStackInfo",
      "JdbcURL"
    ]
  }
},
{
  "Name": "SecureParams",
  "Value": {
    "Fn::GetAtt": [
      "RDSStackInfo",
      "SecureParams"
    ]
  }
}
```

## Java Changes - startup class
When our application starts it needs to run a class called **PreContextLoadedConfiguration** that runs after all the x.properties, environment variables, and system parameters have been read in but before any Spring Beans are loaded. This class handles the decryption of the password we get from the RDS stack output and sets up our proper JDBC URL:
```
public class TemplateDockerApplication {
	public static void main(String[] args) throws Throwable {
		SpringApplication application = new SpringApplication(TemplateDockerApplication.class);
		application.addListeners(new PreContextLoadedConfiguration());
		application.run(args);
	}
}
```
The PreContextLoadedConfiguration.java class is included in the template project.

## environments.yaml file changes
Add you two RDS based parameters for each stack's section with the proper RDSStackName for each reqion/stack:
```
ChangeLogFile: "db.changelog-master.yaml"
RDSStackName: "dev-rds"
```

## Run Environments

### In AWS
Liquibase is run only during cloudformation stack update as this is the only time your database structure should be changing. We don't want each container that scales out to try and rebuild the table structure. So we need to disable liquibase on application startup.

### application.properties files
Make sure you set the Spring configuration setting to disable Liquibase (in **application.properties**), and set up some of the common Postgres parameters:

```
# Unless you are running against a local RDS, liquibase will be handled by a lambda
spring.liquibase.enabled=false
# Postgres specific setup
spring.jpa.database=POSTGRESQL
spring.datasource.platform=postgres
spring.jpa.hibernate.naming-strategy=org.hibernate.cfg.DefaultNamingStrategy
```

### Running Locally
First **don't use HSQL** for your development and test runs. If you're running against Postgresql in production run against Postgresql locally. This will allow you to test postgres specific features and test how your code will run against newer versions of postgres. This is easier than ever with docker (see below).

This example uses PostgreSQL for the database. The properties in src/main/resources/**application-postgres.properties** will connect us to our locally postgres database:

```
spring.liquibase.enabled=true
spring.jpa.database=POSTGRESQL
spring.datasource.platform=postgres
spring.jpa.hibernate.naming-strategy=org.hibernate.cfg.DefaultNamingStrategy
spring.database.driverClassName=org.postgresql.Driver
spring.datasource.url=jdbc:postgresql://localhost:5432/postgres
spring.datasource.username=postgres
spring.datasource.password=baldur
```
Substitute the password you used to setup postgres in the spring.datasource.password line.

Start your application with the following system property to use the above configuration:
```
-Dspring.profiles.active=postgres
```

### Running Locally vs Docker Postgres
If you don't want to install Postgres on your machine you can simply run it as a docker image. Use the following command to spin up Postgres as a docker container:

```
docker run --name localpostgres --rm -p5432:5432 -e POSTGRES_PASSWORD=baldur -d postgres:9.6
```

If you want to run both and installed Postgres and a spin up a docker version just change the port you forward to so that the two don't clash (and update application-postgres.properties with this port):
```sh
# forward to port 5555
docker run --name localpostgres --rm -p5555:5432 -e POSTGRES_PASSWORD=baldur -d postgres:9.6

# now you have a local postgres in docker listening at port 5555
docker ps
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS                    NAMES
49a48bb7c644        postgres:9.6        "docker-entrypoint.s…"   4 days ago          Up 4 days           0.0.0.0:5555->5432/tcp   localpostgres

# shut it down when you're done:
docker kill 49a48bb7c644
```

### Test a new version
One of the great advantages of running against docker is that we can easily check to see if our application runs against newer versions of our database. For example, we can just run:
```
docker run --name localpostgres --rm -p5432:5432 -e POSTGRES_PASSWORD=baldur -d postgres:10
```
Then run our application to see if it works properly against **Postgresql 10**.

## Unit/Integration Test
In our service subproject we have integration test code in src/test-integration/java and properties in src/test-integration/resources.

The properties file looks like this is a combination of our runtime application.properties and a subset of application-postgres.properties.

#### src/test-integration/resource/integration-test.properties
The property file we feed to Spring Boot for our test run looks like this:
```
# Web services port
server.port=8080

# @@@TEMPLATE@@@ - Change the contextPath below to your apiName
# Must be lowerCamelCase and describe the service's primary functional area or resource.
# Must NOT be based on SAS product or organization names or abbreviations.
server.servlet.context-path=/templateService

# componentName should never change, this needs to be set to hit the configuration server properly
application.componentName=mkt-template-docker

#### FIELDS WHICH MUST BE OVERRIDEN DURING CLOUDFORMATION FOR AWS-Deployed INSTANCES ####
application.tierName=finnr
application.configServiceUrl=http://configservice-dev.cidev.sas.us:8080/
application.configStackName=dev-mkt-config
#### END - FIELDS WHICH MUST BE OVERRIDEN

#### Generic Settings ####
# Console Metrics (dev/demo only)
application.consoleMetricsReporterActivated=false
application.consoleMetricsReporterRateSec=1200
application.consoleMetricsFilters=
# CloudWatch Metrics
application.cloudWatchMetricsReporterActivated=false
application.cloudWatchMetricsReporterRateSec=1200
application.cloudWatchMetricFilters=

# Add service specific properties here (these will be used when running locally).

#DB for template bringup
spring.liquibase.enabled=true
spring.jpa.database=POSTGRESQL
spring.datasource.platform=postgres
spring.jpa.hibernate.naming-strategy=org.hibernate.cfg.DefaultNamingStrategy
spring.database.driverClassName=org.postgresql.Driver
```

#### src/test-integration/resource/postgres.yaml
Our test code spins up a postgres database using the following docker-compose file:
```
version: '3'
services:
  postgres:
    image: postgres:9.6
    hostname: postgres
    ports:
      - "5432"
    networks:
      - baldurnet
    environment:
      POSTGRES_PASSWORD: baldur

networks:
  baldurnet:
```

#### PostgresTest.java
Our integration test code looks like the following. It spins up a postgres database, configures Spring Boot with the proper database properties, loads sample data, exercises our code, then spins the database back down:
```
package com.sas.mkt.template.docker.TEMPLATESAMPLE.data;

import java.util.List;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.palantir.docker.compose.DockerComposeRule;
import com.palantir.docker.compose.configuration.ProjectName;
import com.palantir.docker.compose.connection.DockerMachine;
import com.palantir.docker.compose.connection.DockerPort;
import com.palantir.docker.compose.connection.waiting.HealthChecks;
import com.sas.mkt.template.docker.TemplateDockerApplication;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = TemplateDockerApplication.class)
@TestPropertySource(locations = "classpath:integration-test.properties")
public class PostgresTests {

	private static final int POSTGRES_PORT = 5432;
	private static final String POSTGRES = "postgres";

	@Autowired
	private CustomerRepository repository;

	@LocalServerPort
	int randomServerPort;

	private static final DockerMachine dockerMachine = DockerMachine.localMachine().build();
	private static final String BALDUR_PASSWORD = "baldur";

	@ClassRule
	public static DockerComposeRule docker = DockerComposeRule.builder().machine(dockerMachine)
			.file("src/test-integration/resources/postgres.yaml").projectName(ProjectName.random())
			.waitingForService(POSTGRES, HealthChecks.toHaveAllPortsOpen())
			.saveLogsTo("build/dockerLogs/dockerComposeRuleTest").build();

	@BeforeClass
	public static void initialize() {
		setupPorts();
	}

	public static void setupPorts() {
		DockerPort postgres = docker.containers().container(POSTGRES).port(POSTGRES_PORT);
		String postgresurl = String.format("jdbc:postgresql://%s:%s/postgres", postgres.getIp(),
				postgres.getExternalPort());
		System.setProperty("spring.datasource.url", postgresurl);
		System.setProperty("spring.datasource.username", "postgres");
		System.setProperty("spring.datasource.password", BALDUR_PASSWORD);
	}

	@Test
	public void getCustomers() {
		repository.save(new Customer("Harry", "Potter"));
		repository.save(new Customer("Hermione", "Granger"));
		repository.flush();
		long numberCustomers = repository.count();
		Assert.assertTrue(numberCustomers == 2);
		List<Customer> customers = repository.findByLastName("Granger");
		Assert.assertTrue(customers.size() == 1);
		Assert.assertTrue(customers.get(0).getFirstName().equals("Hermione"));
	}

}
```

## Liquibase DB changelog
Liquibase creates/updates the DB schema using the DB changelog.  Create this file under your <projectname>-service subproject at **src/main/resources/db.changelog/db.changelog-master.yaml**.  The Liquibase site has complete instructions on how this file works.  The file contains instructions for upgrading the DB schema through the various release cycle changes.  

### Working with an existing database
If you already have a database in place and you want to generate a starter changelog file with the current database structure run the following command:

```
liquibase.bat --driver=org.postgresql.Driver --classpath=c:\workspaces\test\postgresql-9.4.1212.jre7.jar --changeLogFile=db.changelog-master.yaml --url="jdbc:postgresql://localhost:5432/postgres" --username=postgres --password=Go4thsas generateChangeLog
```

You need to find your project's postgresql-x.jar file and possibly copy it somewhere more convenient
for this operation.  The command above allows Liquibase to attach to the running DB and pull the current
schema to initialize the DB changelog.

**Note:** You will need to hand-edit the DB changelog file after this step and add conditional logic so
Liquibase doesn't try to re-create the DB every time you re-start your application.  Read the Liquibase
documentation.

# Sample Application
If you want to see a runnable sample of the above checkout the git branch **staging-rds**. It includes some classes under a x.data package that use a Postgres database.
