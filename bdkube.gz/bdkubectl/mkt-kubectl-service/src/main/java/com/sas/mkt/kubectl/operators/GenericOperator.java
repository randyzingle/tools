package com.sas.mkt.kubectl.operators;

import com.sas.mkt.kubectl.data.TemplateData;

public class GenericOperator extends KubernetesOperator {

	@Override
	protected void customizeTemplate(TemplateData td) {
		// no customization in the GenericOperator
	}

}
