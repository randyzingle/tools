package com.sas.mkt.kafka.clients.streams;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class BookKafkaLoader {

	public static void main(String[] args) {
		BookKafkaLoader loader = new BookKafkaLoader();
		String book = "src/main/resources/data/huckfinn.txt";
		try {
			loader.load(book);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	private void load(String bookName) throws Exception {
		File f = new File(bookName);
		BufferedReader reader = new BufferedReader(new FileReader(f));
		String s = null;
		while ((s = reader.readLine()) != null) {
			String[] words = s.split("\\s");
			for (String word: words) {
				word = word.replace("?", "").replace("_", "").replace(",", "").replace("!", "").replace(".", "").replace("\"", "").replace(":", "").trim();
				System.out.println(word);
			}
		}
		
		reader.close();
		
	}

}
