package com.sas.mkt.kafka.examples.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * Request and Response representation of the configuration properties used by
 * the REST controller.
 * 
 * @author Scott.Lynch@sas.com
 *
 */
@JsonInclude(Include.NON_NULL)
public class ConfigProperty
{
    public static final String MEDIA_TYPE_BASE_VALUE = "application/vnd.sas.configuration.configproperty";
    public static final String MEDIA_TYPE_JSON_VALUE = "application/vnd.sas.configuration.configproperty+json";
    public static final String COLLECTION_NAME = "configproperties";
	public static final String AUDIT_COMPONENT_HEADER = "AuditComponent";
	
	public ConfigProperty(String tierNm, String componentNm, String name, String value) {
		this.tierNm = tierNm;
		this.componentNm = componentNm;
		this.name = name;
		this.value = value;
	}
	
	public ConfigProperty() {}
 
    public int version = 1;
    public String id;
    public String name;
    public String value;
    public String description;
    public String date;
    public String tierId;
    public String tierNm;
    public String tierDesc;
    public String componentId;
    public String componentNm;
    public String componentDesc;

	@Override
	public String toString() {
		return "ConfigProperty [name=" + name + ", value=" + value + ", tierNm=" + tierNm + ", componentNm="
				+ componentNm + "]";
	}

}
