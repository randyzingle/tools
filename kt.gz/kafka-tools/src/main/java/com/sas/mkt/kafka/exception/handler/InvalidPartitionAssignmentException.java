package com.sas.mkt.kafka.exception.handler;

public class InvalidPartitionAssignmentException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public InvalidPartitionAssignmentException(String string)
	{
		super(string);
	}

}
