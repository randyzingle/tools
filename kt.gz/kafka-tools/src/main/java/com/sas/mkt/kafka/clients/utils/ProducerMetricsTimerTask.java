package com.sas.mkt.kafka.clients.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimerTask;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.common.Metric;
import org.apache.kafka.common.MetricName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SuppressWarnings("rawtypes")
public class ProducerMetricsTimerTask extends TimerTask {
	private static Logger logger = LoggerFactory.getLogger(ProducerMetricsTimerTask.class);

	// should be more than 0 if we are producing events
	private static final String[] METRICS_OF_INTEREST = { "record-send-rate", "records-per-request-avg", "request-rate",
			"request-size-avg", "record-error-rate", "record-size-avg" };
	private Producer producer = null;
	private String dimensionName = null;
	private String dimensionValue = null;
	private List<String> metricsOfInterest = null;

	/**
	 * 
	 * @param producer
	 * @param dimensionName
	 * @param dimensionValue
	 * @deprecated Sprint 2104 - use KafkaGauges registerProducerMetricsAsGauges(Producer<String, SpecificRecordBase> producer)
	 */
	public ProducerMetricsTimerTask(Producer producer, String dimensionName, String dimensionValue) {
		this.producer = producer;
		this.dimensionName = dimensionName;
		this.dimensionValue = dimensionValue;

		metricsOfInterest = new ArrayList<String>();// Arrays.<String>asList(METRICS_OF_INTEREST);
		for (String s : METRICS_OF_INTEREST)
			metricsOfInterest.add(s);
	}

	@Override
	public void run() {

		try {
			readProducerMetrics();
		} catch (Exception ex) {
			logger.error("Exception reading producer metrics: " + ex.getMessage());
		} catch (Error er) {
			logger.error("Error reading producer metrics: " + er.getMessage());
		}
	}

	/**
	 * Reading records-lag-max metric for the consumer group within the time window
	 * 
	 * records-lag-max: The maximum lag in terms of number of records for any
	 * partition in this window. An increasing value over time is your best
	 * indication that the consumer group is not keeping up with the producers.
	 *
	 */
	@SuppressWarnings("unchecked")
	private void readProducerMetrics() {
		if (logger.isDebugEnabled()) {
			logger.debug("Reading metrics from producer...");
		}

		Map<String, Double> awsMetrics = new HashMap<String, Double>();

		synchronized (producer) {
			Map<MetricName, ? extends Metric> metrics = producer.metrics();
			if (metrics != null && metrics.size() > 0) {
				for (MetricName mName : metrics.keySet()) {
					Metric metric = metrics.get(mName);
					String name = mName.name();
					Object test = metric.metricValue();
					if (test instanceof Double) {
						Double dvalue = (Double) test;
						if (dvalue.isNaN())
							continue;
						double value = dvalue.doubleValue();

						if (name != null && metricsOfInterest.contains(name)) {
							if (logger.isDebugEnabled()) {
								logger.debug(name + "/" + value);
							}
							// filter out -Infinity which means no records returned from any partitions in
							// latest poll
							if (value < 0)
								value = 0;
							awsMetrics.put(name, value);
						}
					} else {
						continue;
					}

				}
			}
		}

		// upload the metrics to AWS Cloudwatch
		CloudWatchMetricPublisher.publishKafkaMetrics(dimensionName, dimensionValue, awsMetrics);
	}
}
