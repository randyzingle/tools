About this example.

## General Use

You will have to rename the packages from com.sas.mkt.example to com.sas.mkt._yourService_

Make sure you specify a 'method=' on each @RequestMapping, otherwise SpringFox generates documentation endpoints for **all** possible HTTP methods.

## /commons endpoints

There are support for 4 endpoints you need to supply in your service in this template. The controller for them is AdminMetricsController. You may not need any changes to the controller, but to see how the endpoints work see the [saspedia](http://sww.sas.com/saspedia/MicroService_CI360#Service_Ops_Checks "read this!") article.


Two things you will need to do are:

1. Replace the classes GeneralHealthCHeck and BeachBoysHealthCheck. Add at least one class that extends com.codahale.metrics.health.HealthCheck to contribute to the health check registry.
2. Consider how often diagnostics run in a background thread. This is set in ScheduledTasks.

## API name

Your API name needs to be specified in the web application context (server.contextpath) as some aspects of SAS commons.rest rely on it being there (true for 9.4 not sure for Viya). See [REST API standard for API names](http://sww.sas.com/saspedia/REST_API_standards#API_names) for specifics on correct API names.

In this example you can find it set to /templateService in the following places:
1. mkt-template-microservice-service/src/main/resources/application.properties: sets the web application context path for spring to pick up - **server.contextPath=/templateService**
2. mkt-template-microservice-cloudformation/src/main/cloudformation/cloudformation.json#L202: Target for ELB healthcheck needs to be set to correct url, otherwise deployed instance will fail - e.g. **"Target": "HTTP:8080/templateService/commons/ping"**

This results in all the endpoints correctly including the API name without it being hardcoded into the controller e.g. "http://localhost:8080/templateService/hello".

# Builds:
To run the service locally w/o requiring AWS resources and using the embedded HSQL DB, run:
> `gradle bootRun`

To run the service locally w/o requiring AWS resources, but using a local Postgres DB on localhost:5432, run:
> `gradle bootRun -Dspring.profiles.active=nonec2,files,postgres`


## Debugging `bootRun`
Add the following to `build.gradle` to support `bootRun` launch of the micro-service with debugging enabled.

    bootRun{
        jvmArgs=["-Xdebug", "-Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=8000"]
    }

A remote debugger setup in Eclipse should use the following:

* Type: Remote Java Application
* host: localhost
* port: 8000
* connection type: Standard(Socket Attach)

## RootController
A controller has been added to handle the root endpoint for the Template Service which is required by COE standards. This required the following changes:

1. Adding dependencies on the SAS Viya commons-rest and commons-rest-representations libraries. See [commons-rest](http://sww.sas.com/saspedia/Commons-rest) and [commons-rest-representations](http://sww.sas.com/saspedia/Commons-rest). The recommended Gradle specifications from those pages have been used and because the SAS REST API world is predicated on 'no breaking changes' it is not expected that there will be any issues consuming those libraries directly from the SAS Viya CDP (eventually).
2. Because the libraries above use logback instead of log4j2 as the implementation for slf4j, it is necessary to switch over to using logback. See [Change logging implementation from log4j to logback](https://rndjira.sas.com/browse/NGMTS-2762) and [Logging in microservices](http://sww.sas.com/saspedia/Logging_in_microservices).

## OpenAPI documentation
When the template microservice is running you can access the generated OpenAPI documentation using a URL similar to the examples shown below:

* Running locally

	http://localhost:8080/templateService/v2/api-docs - JSON representation
	http://localhost:8080/templateService/swagger-ui.html#/ - OpenAPI UI

* Running in AWS

	http://{IP of EC2 instance}:8080/templateService/v2/api-docs - JSON representation
	http://{IP of EC2 instance}:8080/templateService/swagger-ui.html#/ - OpenAPI UI
