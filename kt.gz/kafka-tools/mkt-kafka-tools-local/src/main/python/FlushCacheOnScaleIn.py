'''
ASG Termination Hook will call this lambda in Termination:Wait and this lambda
will call the cache/flush endpoint on the instance

Source code located in GitLab:
    https://gitlab.sas.com/CustomerIntelligence/Shared/mkt-kafka-tools

Configuration:
"Handler": "FlushCacheOnScaleIn.handler"
"Runtime": "python3.6"
"Timeout": "300"

Feb 5, 2019
@author: razing
'''
import json
from urllib.request import urlopen, Request, HTTPError, URLError
from urllib.parse import urlencode
import boto3


# ===============================================================================
#  Entry Point for Lambda
# ===============================================================================
def lambda_handler(event, context):
    print('event')
    print(event)

    flush_cache(event)
    
def get_endpoint(event):
    print('------------------------')
    contextRoot = event['detail']['NotificationMetadata']
    ec2 = boto3.client('ec2')
    instanceId = event['detail']['EC2InstanceId']
    response = ec2.describe_instances(InstanceIds=[instanceId])
    instanceDetails = response['Reservations'][0]['Instances'][0]
    ipAddress = instanceDetails['PrivateIpAddress']
    
    endpoint = 'http://'+ipAddress+':8080/'+contextRoot+'/cache/scalein'
    print(endpoint)
    return endpoint
    

def flush_cache(event):
    print('------------------------')
    endpoint = get_endpoint(event)
    responseBody = event 
    edata = json.dumps(responseBody)
    edata = edata.encode('utf-8')
    headers = {'Content-Length': len(edata), 'Content-Type': 'application/json'}
    req = Request(
        endpoint,
        headers=headers,
        data=edata,
        method='POST')
    req.get_method = lambda: 'POST'
    try:
        urlopen(req)
    except Exception as e:
        print(e)

        
        
# ===============================================================================
#  Test Code for runs from the command line
# ===============================================================================
if __name__ == "__main__":
    print('in __main__ function')

    event = '''
        {
          "version": "0",
          "id": "63c4beb5-6e57-60bd-0850-2ff7f59e774c",
          "detail-type": "EC2 Instance-terminate Lifecycle Action",
          "source": "aws.autoscaling",
          "account": "952478859445",
          "time": "2019-02-06T14:26:55Z",
          "region": "us-east-1",
          "resources": [
            "arn:aws:autoscaling:us-east-1:952478859445:autoScalingGroup:ae488a3b-cd42-41cc-b340-a29ae88ba71c:autoScalingGroupName/finnr-mkt-kafka-tools-ASG-1NDK1D62W0EBE"
          ],
          "detail": {
            "LifecycleActionToken": "09d8a1e8-232a-4b68-952f-f17dcd324c09",
            "AutoScalingGroupName": "finnr-mkt-kafka-tools-ASG-1NDK1D62W0EBE",
            "LifecycleHookName": "finnr-mkt-kafka-tools-ASGLifecycleHook-MONWHJXVK9DK",
            "EC2InstanceId": "i-0fe5c543ce28b7ff0",
            "LifecycleTransition": "autoscaling:EC2_INSTANCE_TERMINATING",
            "NotificationMetadata": "marketingKafkaTools"
          }
        }
    '''
    context = {}
    lambda_handler(json.loads(event), context)
