package com.sas.mkt.kafka.admin.topics.utils;

import java.util.List;

public class TopicInfo {

	public enum ValueType {StringType, AvroType, Unknown}
	
	private String topic;
	private ValueType valueType;
	private long numberMessages;
	private String schemaName;
	private List<FieldDTO> fieldList;
	
	public TopicInfo(String topic, ValueType valueType, long numberMessages, String schemaName, List<FieldDTO> fieldList) {
		super();
		this.topic = topic;
		this.valueType = valueType;
		this.numberMessages = numberMessages;
		this.schemaName = schemaName;
		this.fieldList = fieldList;
	}

	public String getTopic() {
		return topic;
	}

	public ValueType getValueType() {
		return valueType;
	}

	public long getNumberMessages() {
		return numberMessages;
	}

	public String getSchemaName() {
		return schemaName;
	}

	public List<FieldDTO> getFieldList() {
		return fieldList;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TopicInfo [topic=").append(topic).append(", valueType=").append(valueType)
				.append(", numberMessages=").append(numberMessages).append(", schemaName=").append(schemaName)
				.append(", fieldList=").append(fieldList).append("]");
		return builder.toString();
	}

}
