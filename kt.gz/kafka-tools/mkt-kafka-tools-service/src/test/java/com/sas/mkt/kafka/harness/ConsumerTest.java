package com.sas.mkt.kafka.harness;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.MockConsumer;
import org.apache.kafka.clients.consumer.OffsetResetStrategy;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.record.TimestampType;
import org.junit.Test;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.kafka.domain.DogNames;
import com.sas.mkt.kafka.domain.TestEvent;

public class ConsumerTest {

	private ApplicationConfiguration appConfig;
	private MockConsumer<String, SpecificRecordBase> consumer = new MockConsumer<>(OffsetResetStrategy.EARLIEST);

//	@Test
	public void integrationTest() {
		appConfig = new ApplicationConfiguration();
		appConfig.setConfigServiceUrl("http://configservice-dev.cidev.sas.us:8080/");
		SimpleConsumerSubscribe simpleConsumerSubscribe = new SimpleConsumerSubscribe(appConfig);
		simpleConsumerSubscribe.init();
		KillSwitch ks = new KillSwitch();
		ks.init(simpleConsumerSubscribe);
		Thread t = new Thread(ks);
		t.start();
		simpleConsumerSubscribe.consumeWithSubscribe();
	}

	@Test
	public void consumeTestEventsWithSubscribe() {
		SimpleConsumerSubscribe simpleConsumerSubscribe = new SimpleConsumerSubscribe(appConfig);
		String topic = "baldur-test-events";
		TopicPartition topicPartition = new TopicPartition(topic, 0);
		Collection<TopicPartition> partitions = Arrays.asList(topicPartition);
		HashMap<TopicPartition, Long> beginningOffsets = new HashMap<>();
		beginningOffsets.put(topicPartition, 0L);
		consumer.subscribe(Arrays.asList(topic));
		consumer.rebalance(partitions);
		consumer.updateBeginningOffsets(beginningOffsets);
		ConsumerRecord<String, SpecificRecordBase> record = getConsumerRecord(0L);
		consumer.addRecord(record);
		simpleConsumerSubscribe.consumer = consumer;
		KillSwitch ks = new KillSwitch();
		ks.init(simpleConsumerSubscribe);
		Thread t = new Thread(ks);
		t.start();
		simpleConsumerSubscribe.consumeWithSubscribe();
	}

	@Test
	public void consumeTestEventsWithAssign() {
		SimpleConsumerAssign simpleConsumerAssign = new SimpleConsumerAssign(appConfig);
		long numberMessages = 10L;
		String topic = "baldur-test-events";
		TopicPartition topicPartition = new TopicPartition(topic, 0);

		HashMap<TopicPartition, Long> beginningOffsets = new HashMap<>();
		beginningOffsets.put(topicPartition, 0L);
		HashMap<TopicPartition, Long> endOffsets = new HashMap<>();
		endOffsets.put(topicPartition, 0L + numberMessages);

		consumer.assign(Arrays.asList(topicPartition));
		consumer.updateBeginningOffsets(beginningOffsets);
		consumer.updateEndOffsets(endOffsets);

		for (long i = 0L; i <= numberMessages; i++) {
			ConsumerRecord<String, SpecificRecordBase> record = getConsumerRecord(i);
			consumer.addRecord(record);
		}

		simpleConsumerAssign.consumer = consumer;
		KillSwitch ks = new KillSwitch();
		ks.init(simpleConsumerAssign);
		Thread t = new Thread(ks);
		t.start();
		simpleConsumerAssign.consumeWithAssign();
	}

	private ConsumerRecord<String, SpecificRecordBase> getConsumerRecord(long offset) {
		// set up TestEvent
		TestEvent.Builder bdr = TestEvent.newBuilder();
		bdr.setIp("10.1.1.1").setSite("baldursoft").setDogs(DogNames.Baldur).setTimeStamp(System.currentTimeMillis());
		TestEvent testEvent = bdr.build();
		// create record
		int partition = 0;
		long timestamp = System.currentTimeMillis();
		long checksum = 1L;
		int serializedKeySize = 10;
		int serializedValueSize = 10;
		ConsumerRecord<String, SpecificRecordBase> record = new ConsumerRecord<String, SpecificRecordBase>(
				"baldur-test-events", partition, offset, timestamp, TimestampType.CREATE_TIME, checksum,
				serializedKeySize, serializedValueSize, "baldurkey", testEvent);
		return record;
	}

	public class KillSwitch implements Runnable {

		WakeableConsumer wakeable;

		public void init(WakeableConsumer wakeable) {
			this.wakeable = wakeable;
		}

		@Override
		public void run() {
			try {
				Thread.sleep(500);
				wakeable.wakeUp();
				System.out.println("wakeup!");
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

}
