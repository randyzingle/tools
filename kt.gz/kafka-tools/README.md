# GitLab project for CI360 Kafka Tools.

```
git clone git@gitlab.sas.com:CustomerIntelligence/Infra/mkt-kafka-tools.git
```

Builds are performed by Jenkins (bci2jml01) -
    http://bci2jml01.unx.sas.com:8080/job/MKT_Shared/


| Stage Build | Deploy Build | Code Coverage |
| ----------- | ------------ | ------------- |
| [![Build Status](http://bcijml01.unx.sas.com:8080/buildStatus/icon?job=mkt-kafka-tools_stage)](http://bcijml01.unx.sas.com:8080/view/MKT_Infra/job/mkt-kafka-tools_stage/) | [![Build Status](http://bcijml01.unx.sas.com:8080/buildStatus/icon?job=mkt-kafka-tools_deploy)](http://bcijml01.unx.sas.com:8080/view/MKT_Infra/job/mkt-kafka-tools_deploy/) | [![Quality Gate](http://dev-sonar.cidev.sas.us/api/badges/measure?key=com.sas.mkt.kafka.tools:com.sas.mkt.kafka.tools&metric=line_coverage)](http://dev-sonar.cidev.sas.us/dashboard/index/com.sas.mkt.kafka.tools:com.sas.mkt.kafka.tools) |


If you do not have Developer (committer) rights to the repo, you will need to Fork the repo and create a Merge Request from that forked repo (source) to the target repo, so your changes can be reviewed and accepted by the team that owns the target repo.

For more information, take a look at -
    http://sww.sas.com/saspedia/CI_TNG_CDP


## project: com.sas.mkt.kafka.tools

Source projects go here as a single level of nodes in a Gradle multiproject build.
Each subproject should generate at most one type of artifact, like one JAR or a Zip fileset.

**Note:**  The packages inside the JAR should match the project names like:
    mkt-<island>-<service>-<subproject> for package com.sas.mkt.<island>.<service>.<subproject>.*

> @@@TEMPLATE@@@
>
> But for the templates, we're reusing `package com.sas.mkt.example.*` across all templates.


## Builds:
To build and deploy the code to AWS using the latest verified Base AMI, run:
> `gradlew all -Dstack=<stack_prefix> -DbuildType=<personal | team> -Downer=<user_id> -DadminEmail=<first.last@sas.com> -DconfigStack=<config stack name>`

For example, to create a new personal Dev micro-stack with a specific Base AMI, run:
> `gradlew all -Dstack=mydev -DbuildType=personal -DbaseAMI=<`[CI360_BakedAMI](http://sww.sas.com/saspedia/CI360_BakedAMI)`> -Downer=<user_id> -DadminEmail=<first.last@sas.com>`

For example, to build and test your code locally, but don't upload or deploy to AWS (buildType will default to personal for local builds):
> `gradlew`
or to clean and rebuild locally:
> `gradlew rebuild`

To build, test, upload (CloudFormation and CodeDeploy artifacts to S3), deploy (CloudFormation update and CodeDeploy) and run smoke tests against your local code with the latest Base AMI to an **existing** micro-stack in AWS:
> `getawskey.py`
>
> `gradlew all -Dstack=<my_user_id>`

To generate Swagger documentation:
> `gradlew asciidoctor`

The output files are in the following formats: ADoc, JSON, mark-down, HTML5 and PDF
Look for the documentation output here:
> `ls -R  mkt-template-microservice-service/build/asciidoc/`


## Logging
In order for the microservice REST API to support certain aspects of the COE standards, the following changes were required:
1. Adding dependencies on the SAS Viya commons-rest and commons-rest-representations libraries. See [commons-rest](http://sww.sas.com/saspedia/Commons-rest) and [commons-rest-representations](http://sww.sas.com/saspedia/Commons-rest). The recommended Gradle specifications from those pages have been used and because the SAS REST API world is predicated on 'no breaking changes' it is not expected that there will be any issues consuming those libraries directly from the SAS Viya CDP (eventually).
2. Because the libraries above use logback instead of log4j as the implementation for slf4j, the spring-boot-starter-log4j2 library has been excluded otherwise multiple slf4j binding conflicts occur. The log4j2.xml file has been replace with a logback.xml file. The previously used logging patterns have been retained. See [Change logging implementation from log4j to logback](https://rndjira.sas.com/browse/NGMTS-2762) and [Logging in microservices](http://sww.sas.com/saspedia/Logging_in_microservices).


## mkt-shared-config-client
The following documents explain how the mkt-shared-config-client library is used to interact with
mkt-config and mkt-tenant:
* [Config service client](doc/config_service.md)
* [Tenant service client](doc/tenant_service.md)


## Liquibase Integration
This application has been integrated with Liquibase DB refactoring library and is documented here:
* [Liquibase info](doc/liquibase.md)


## Developing/Debugging from Eclipse
General notes on developing and debugging micro-services on your local desktop can be found here:
* [Eclipse Development Notes](doc/eclipse_dev_notes.md)

## Localization
Notes on localizing your microservice can be found here:
* [I18N Notes](doc/i18n_notes.md)


## Markdown Markup:

Please use markdown markup in the README.md files to maintain formatting for the GitLab UI.
> Example [Markdown guide from GitLab](https://docs.gitlab.com/ee/user/markdown.html)


## Copyright

Copyright © 2018 by SAS Institute Inc., Cary, NC, USA. All Rights Reserved.

This software is protected by copyright laws and international treaties.

U.S. GOVERNMENT RESTRICTED RIGHTS

Use, duplication or disclosure of this software and related
documentation by the United States government is subject to the
license terms of the Agreement with SAS Institute Inc. pursuant to,
as applicable, FAR 12.212, DFAR 227.7202-1(a), DFAR 227.7202-3(a)
and DFAR 227.7202-4 and, to the extent required under United
States federal law, the minimum restricted rights as set out
in FAR 52.227-19 (DEC 2007).
