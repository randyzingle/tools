package com.sas.mkt.template.docker.TEMPLATESAMPLE.data;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SampleRdsData {

	@Autowired
	private CustomerRepository repository;

	@RequestMapping(value = "/hello", produces = "text/plain", method = RequestMethod.GET)
	public String sayHello() {
		return "hello";
	}

	@RequestMapping("/getcustomers")
	public List<Customer> getCustomers() {
		List<Customer> clist = new ArrayList<>();
		for (Customer c : repository.findAll()) {
			clist.add(c);
		}
		return clist;
	}

	@RequestMapping("/addhobbit")
	public List<Customer> addhobbit() {
		repository.save(new Customer("Bilbo", "Baggins"));
		repository.flush();
		List<Customer> clist = new ArrayList<>();
		for (Customer c : repository.findAll()) {
			clist.add(c);
		}
		return clist;
	}

	@RequestMapping(value = "/loaddata", produces = "text/plain", method = RequestMethod.GET)
	public String loadData() {

		repository.save(new Customer("Baldur", "Zingle"));
		repository.save(new Customer("Mymir", "Zingle"));
		repository.save(new Customer("Butters", "Zingle"));
		repository.save(new Customer("Harry", "Potter"));
		repository.save(new Customer("Hermione", "Granger"));
		repository.flush();

		System.out.println("Finding all customers...");
		for (Customer customer : repository.findAll()) {
			System.out.println(customer);
		}

		System.out.println("Finding all Zingles...");
		for (Customer customer : repository.findByLastName("Zingle")) {
			System.out.println(customer);
		}

		return "loaded rds data";
	}

	@RequestMapping(value = "/deletedata", produces = "text/plain", method = RequestMethod.GET)
	public String deleteData() {
		repository.deleteAll();
		return "deleted all rds data";
	}

}
