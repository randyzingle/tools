'''
Load an S3 Connector to dump messages from Kafka to S3

Configuration:
topic:      topic name for source data
bucket:     bucket avro data files will be written to
region:     aws region for s3 endpoint
endpoint:   URL for Kafka Connect Cluster
flushsize:  number of messages to queue before flushing to S3

April 3, 2018
@author Randy Zingle <randall.zingle@sas.com>
'''

import argparse
import json
import time
from urllib.request import urlopen, Request, HTTPError, URLError
from urllib.parse import urlencode

# ===============================================================================
#  Sample S3 Connect JSON - this is what gets POSTed to the Connect endpoints
# ===============================================================================
'''
{
  "name": "s3-test-events",
  "config":
  {
    "connector.class":"io.confluent.connect.s3.S3SinkConnector",
    "enhanced.avro.schema.support": "true",
    "errors.deadletterqueue.topic.name": "deadletter",
    "errors.deadletterqueue.topic.replication.factor": "1",
    "errors.log.enable": "true",
    "errors.retries.delay.max.ms": "1000",
    "errors.retries.limit": "5",
    "errors.tolerance.limit": "-1",
    "errors.tolerance.rate.duration.ms": "6000",
    "errors.tolerance.rate.limit": "-1",
    "flush.size": "5000",
    "format.class": "io.confluent.connect.s3.format.avro.AvroFormat",
    "key.converter": "org.apache.kafka.connect.storage.StringConverter",
    "locale": "en",
    "partition.duration.ms": "100",
    "partitioner.class": "io.confluent.connect.storage.partitioner.TimeBasedPartitioner",
    "path.format": "YYYY/MM/dd/HH",
    "rotate.interval.ms": "600000",
    "rotate.schedule.interval.ms": "600000",
    "s3.bucket.name":"ci-360-test-dev-us-east-1",
    "s3.part.size": "5242880",
    "s3.region":"us-east-1",
    "schema.compatibility": "NONE",
    "schema.generator.class": "io.confluent.connect.storage.hive.schema.TimeBasedSchemaGenerator",
    "storage.class": "io.confluent.connect.s3.storage.S3Storage",
    "tasks.max": "1",
    "timestamp.extractor": "Record",
    "timezone": "UTC",
    "topics.dir": "topics",
    "topics.regex": "\\w*-test-events",
    "value.converter.schema.registry.url": "http://schema_registry:8081",
    "value.converter": "io.confluent.connect.avro.AvroConverter"
  }
}
'''

# ===============================================================================
# Create the request body given the input parameters
# ===============================================================================
def configure_connector(topic, bucket, region, flushsize, endpoint, timeout, schemaregistry, tasks):
    print(topic, bucket, region, flushsize, endpoint, timeout, schemaregistry, tasks)

    if not schemaregistry.startswith('http://'):
        schemaregistry = 'http://'+schemaregistry
        print('adding protocol to Schema Registry...')

    payload = {
        'name': 's3-'+topic,
        'config':{
            'connector.class':'io.confluent.connect.s3.S3SinkConnector',
            'enhanced.avro.schema.support': 'true',
            'errors.deadletterqueue.context.headers.enable': 'true',
            'errors.deadletterqueue.topic.name': topic + '-deadletter',
            'errors.deadletterqueue.topic.replication.factor': '1',
            'errors.log.enable': 'true',
            'errors.log.include.messages': 'true',
            'errors.retry.delay.max.ms': '2000',
            'errors.retry.timeout': '0',
            'errors.tolerance': 'all',
            'flush.size': flushsize,
            'format.class': 'io.confluent.connect.s3.format.avro.AvroFormat',
            'key.converter': 'org.apache.kafka.connect.storage.StringConverter',
            'locale': 'en',
            'partition.duration.ms': '100',
            'partitioner.class': 'io.confluent.connect.storage.partitioner.TimeBasedPartitioner',
            'path.format': 'YYYY/MM/dd/HH',
            'rotate.interval.ms': timeout,
            'rotate.schedule.interval.ms': '600000',
            's3.bucket.name':bucket,
            's3.part.size': '5242880',
            's3.region':region,
            'schema.compatibility': 'BACKWARD',
            'schema.generator.class': 'io.confluent.connect.storage.hive.schema.TimeBasedSchemaGenerator',
            'storage.class': 'io.confluent.connect.s3.storage.S3Storage',
            'tasks.max': tasks,
            'timestamp.extractor': 'Record',
            'timezone': 'UTC',
            'topics.dir': 'topics',
            #'topics.regex': '\\w*-'+topic,
            'topics':topic,
            'file.delim': '-',
            'value.converter.schema.registry.url': schemaregistry,
            'value.converter': 'io.confluent.connect.avro.AvroConverter'
        }
    }
    cname = 's3-'+topic
    create_connector(cname, endpoint, payload)

def update_connector(cname, endpoint, payload):
    print('updating connector...')
    url = endpoint+'connectors/'+cname+'/config'
    jsonpayload = json.dumps(payload['config'])
    jsonpayload = jsonpayload.encode('utf-8')
    request = Request(
        url,
        data=jsonpayload,
        method='PUT'
    )
    request.add_header('Content-Type','application/json')
    print(url)
    try:
        res = urlopen(request)
        #print(res.read())
        print(res.status)
    except Exception as e:
        print(e)

    restart_connector(cname, endpoint)


def restart_connector(cname, endpoint):
    print('restarting the connector...')
    time.sleep(2) #make sure the new config has been set
    url = endpoint+'connectors/'+cname+'/restart'
    request = Request(
        url,
        method='POST'
    )
    print(url)
    try:
        res = urlopen(request)
        #print(res.read())
        print(res.status)
    except Exception as e:
        print(e)


def new_connector(cname, endpoint, payload):
    jsonpayload = json.dumps(payload)
    jsonpayload = jsonpayload.encode('utf-8')
    print('creating connector...')
    url = endpoint+'connectors'
    print(url)
    request = Request(
        url,
        data=jsonpayload,
        method='POST'
    )
    request.add_header('Content-Type','application/json')
    try:
        res = urlopen(request)
        #print(res.read())
        print(res.status)
    except Exception as e:
        print(e)

# ===============================================================================
# Create a new connector if none exists or update and restart an existing one
# ===============================================================================
def create_connector(cname, endpoint, payload):
    url = endpoint+'connectors/'+cname
    request = Request(
        url,
        method='GET'
    )
    print('searching for: ', url)
    try:
        res = urlopen(request)
        status = res.status
        if status==200:
            body = str(res.read(), 'utf-8')
            print('found connector: ', cname)
            print(body)
            update_connector(cname, endpoint, payload)
    except HTTPError as e:
        if e.code == 404:
            message = json.loads(str(e.read(), 'utf-8'))
            print(message['message'])
            new_connector(cname, endpoint, payload)
        else:
            print('ERROR - Something wrong...')
    except URLError as u:
        print('ERROR - Invalid Endpoint for Kafka Connect: ' + endpoint)





# ===============================================================================
#  Entry point - runs from the command line: python3 KafkConnect.py (args)
# ===============================================================================
if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='Usage: python3 KafkaConnect.py --topic raw-events --bucket ci-360-kafka-connect-dev-us-east-1 --region us-east-1 --endpoint http://kafkadev-connect1.cidev.sas.us:8083/')

    parser.add_argument(
        '--topic',
        help="The topic basename used as source data",
        required=True
    )

    parser.add_argument(
        '--bucket',
        help="The name of the S3 Bucket the data will be written to",
        required=False,
        default='ci-360-kafka-connect-dev-us-east-1'
    )

    parser.add_argument(
        '--region',
        help="The aws region for the S3 endpoint",
        required=False,
        default='us-east-1'
    )

    parser.add_argument(
        '--endpoint',
        help="The URL of the Kafka Connect Endpoint",
        required=False,
        default="http://kafkadev-connect1.cidev.sas.us:8083/"
    )

    parser.add_argument(
        '--flushsize',
        help="Number of messages to queue before flushing to S3 [optional, defaults to 100000]",
        required=False,
        default="100000"
    )

    parser.add_argument(
        '--timeout',
        help="Time in ms (rotate.interval.ms) before before flushing to S3 [optional, defaults to 600000 (10 min)]",
        required=False,
        default="600000"
    )

    parser.add_argument(
        '--schemaregistry',
        help="The schema registry url",
        required=False,
        default='http://kafkadev-schema-registry.cidev.sas.us'
    )

    parser.add_argument(
        '--tasks',
        help="The number of tasks to run",
        required=False,
        default='1'
    )

    args = parser.parse_args()

    configure_connector(args.topic, args.bucket, args.region, args.flushsize, args.endpoint, args.timeout, args.schemaregistry, args.tasks)
