package com.sas.mkt.kafka.admin.topics.utils;

import java.util.Arrays;
import java.util.Properties;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;

public class SimpleGenericConsumer<T> {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private Consumer<String, T> consumer;
	private ApplicationConfiguration appConfig = new ApplicationConfiguration();
	
	private Class<T> type;
	
	public SimpleGenericConsumer(Class<T> type) {
		this.type = type;
	}

	public void setup(String topicName) {
		KafkaConnectionUtils kcu;
		try {
			kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
			System.out.println("VALID CONNECTION..........");
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			return;
		}
		String groupID = appConfig.getTierName() + "-" + appConfig.getComponentName() + System.currentTimeMillis();
		Properties props = kcu.getKafkaConsumerProperties();
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, org.apache.kafka.common.serialization.StringDeserializer.class);
		
		String tname = type.getName();
		if (type.getName().endsWith("String")) {
			System.out.println("String time");
			props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, org.apache.kafka.common.serialization.StringDeserializer.class);
		} else if (tname.endsWith("SpecificRecordBase")) {
			System.out.println("Avro time");
			props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, io.confluent.kafka.serializers.KafkaAvroDeserializer.class);
		}
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		consumer = new KafkaConsumer<>(props);
		consumer.subscribe(Arrays.asList(topicName));
	}
	
	public void readMessages(int numberMessages) {
		int cnt = 0;
		boolean done = false;
		while (!done) {	
			ConsumerRecords<String, T> records = consumer.poll(1000);
			for (ConsumerRecord<String, T> record: records) {
				cnt++;
				T value = record.value();
				System.out.printf("key=%s, value=%s%n", record.key(), value.toString());
				System.out.println("###########");
				if (cnt >= numberMessages) {
					done = true;
					break;
				}
			}	
		}
		System.out.printf("Read %d messages%n", cnt);
		consumer.close();
	}

}
