package com.sas.mkt.kafka.clients.jmx;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Set;

public class KafkaRejected {
	
	private String basedir = "/Users/razing/work/temp/";
	private HashMap<String, Integer> badMap = new HashMap<>();

	public static void main(String[] args) {
		KafkaRejected kr = new KafkaRejected();
		try {
			kr.run();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void run() throws Exception {
		File f = new File(basedir + "kafka-rejected-15.47.log");
		BufferedReader br = new BufferedReader(new FileReader(f));
		String s = "";
		while( (s = br.readLine()) != null) {
			int start = s.indexOf("SRC=");
			int end = s.indexOf(" DST=");
			String badIp = s.substring(start+4, end);
			if (badMap.containsKey(badIp)) {
				badMap.put(badIp, badMap.get(badIp) + 1);
			} else {
				badMap.put(badIp, 1);
			}
		}
		
		Set<String> keySet = badMap.keySet();
		for (String key: keySet) {
			System.out.printf("%s %d%n", key, badMap.get(key));
		}
	}

}
