package com.sas.mkt.kubectl.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.actuate.health.Health;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sas.mkt.kubectl.data.KubeConfig;
import com.sas.mkt.kubectl.data.TemplateData;
import com.sas.mkt.kubectl.operators.GenericOperator;
import com.sas.mkt.kubectl.operators.KubernetesOperator;
import com.sas.mkt.kubectl.operators.postgres.PostgresOperator;

@RestController
@RequestMapping("/")
public class KubeController {
	
	private Logger logger = LoggerFactory.getLogger(KubeController.class);
	private final String STATUS_FAILED = "FAILED";
	private final String STATUS_SUCCESS = "SUCCESS";
	
	@RequestMapping(value = "/commons/ping", method = RequestMethod.GET)
	public String ping() {
		return "pong";
	}
	
	@RequestMapping(value = "/commons/healthcheck", method = RequestMethod.GET)
	public @ResponseBody Health getHealth(final HttpServletResponse response, final HttpServletRequest request) {
		response.setHeader("Cache-Control", "must-revalidate,no-cache,no-store");
		boolean healthy = true;
		return healthy ? Health.up().build() : Health.down().build();
	}
	
	@RequestMapping(value = "/kubectl", method = RequestMethod.POST)
	public TemplateData runKubeCtl(@RequestBody TemplateData config) {
		KubernetesOperator ko = getOperator(config);
		TemplateData out = ko.run(config);
		// Return the status of the kubectl run
		return out;
	}
	
	@RequestMapping(value = "/notmuch", method = RequestMethod.POST)
	public KubeConfig notMuch(@RequestBody KubeConfig config) {
		String message = "";
		try {

			config.message = "Ran KubeController for " + config.userName;
			config.status = STATUS_SUCCESS;
		} catch (Exception e) {
			message = e.getMessage();
			logger.warn(message);
			config.status = STATUS_FAILED;
			config.message = message;
		}
		// Return the status of the kubectl run
		return config;
	}
	
	private KubernetesOperator getOperator(TemplateData templateData) {
		String templateName = templateData.template + "-" + templateData.version;
		System.out.println(templateName);
		// TODO we need to make this more dynamic ...
		KubernetesOperator ko = null;
		if (templateName.equals("postgres-template-1.0")) {
			ko = new PostgresOperator();
			System.out.println("using PostgresOperator");
		} else {
			ko = new GenericOperator();
		}
		return ko;
	}

}
