package com.sas.mkt.config.core.startup;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.appspecific.GlobalConfiguration;
import com.sas.mkt.config.core.BaseUtils;
import com.sas.mkt.config.core.ConfigUtils;
import com.sas.mkt.config.core.Configuration;
import com.sas.mkt.config.core.PropertyDetails;
import com.sas.mkt.config.core.events.ApplicationConfigurationEvent;

/**
 * Refresh the config server properties
 * 
 * @author razing
 *
 */
@Component
public class ConfigServiceHelper {
    
    private final static Logger logger = LoggerFactory.getLogger( ConfigServiceHelper.class );

    @Autowired
    ApplicationEventPublisher publisher;
    
	ConfigUtils configUtils;
    ApplicationConfiguration appConfig;
    GlobalConfiguration globalConfig;
    @Autowired
    public ConfigServiceHelper(ConfigUtils configUtils, ApplicationConfiguration appConfig, GlobalConfiguration globalConfig) {
    	this.configUtils = configUtils;
    	this.appConfig = appConfig;
    	this.globalConfig = globalConfig;
    }

    public synchronized void refreshProperties() {
        long startTime = System.currentTimeMillis();   
		configUtils.getApplicationProperties();
		configUtils.getTierGlobalProperties();
		List<PropertyDetails> masterList = new ArrayList<>();
		masterList.addAll(getChangeList(appConfig));
		masterList.addAll(getChangeList(globalConfig));
		// let interested parties know if we have a changes to some configuration properties
		if (!masterList.isEmpty()) {
			ApplicationConfigurationEvent ace = new ApplicationConfigurationEvent(this, masterList);
			publisher.publishEvent(ace);
		}
		BaseUtils.bigDebug("Changed config values: " + masterList.toString(), logger);
        long endTime = System.currentTimeMillis();
        logger.debug("Total runtime for config server hit: {}", (endTime - startTime) + " ms");
        logger.debug(appConfig.toString());
        logger.debug(globalConfig.toString());
    }
    
    private List<PropertyDetails> getChangeList(Configuration config) {
    		List<PropertyDetails> masterList = new ArrayList<>();
    		HashMap<String, PropertyDetails> oldo = config.getOldOverrides();
    	    HashMap<String, PropertyDetails> newo = config.getNewOverrides();
    	    HashMap<String, PropertyDetails> original = config.getOriginalProperties();
    	    Set<String> keysOld = oldo.keySet();
        Set<String> keysNew = newo.keySet();
       
        // We have a value in the new override list
        for (String key : keysNew) {
        		// is it in old and new
        		if (oldo.containsKey(key)) {
        			// has it changed
        			if (!oldo.get(key).equals(newo.get(key))) {
        				// we have a new value
        				masterList.add(newo.get(key));
        			}
        		} else {
        			// it's just in new so its a new value
        			masterList.add(newo.get(key));
        		}       
        }
        
        // Check the old override list to see if there are values that weren't in the new list
        for (String key: keysOld) {
        		if (!newo.containsKey(key)) {
        			// it's not in the new list - it has been deleted 			
        			masterList.add(original.get(key));
        			// roll it back to the original value 
        			configUtils.deleteApplicationConfigServerProperty(appConfig, original.get(key));
        		}
        }
    		return masterList;
    }

}
