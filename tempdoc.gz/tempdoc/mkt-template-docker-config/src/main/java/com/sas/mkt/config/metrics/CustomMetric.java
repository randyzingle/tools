package com.sas.mkt.config.metrics;

import java.util.Map;

public interface CustomMetric {
	
	public Map<String, String> getDimensions();

}
