# Eclipse Development Notes

## Introduction
These notes outline how a micro-service can be run from Eclipse instead of deploying it to a development stack.  This is useful for debugging, has faster development/debug cycle times and keeps AWS costs down.


## General Setup
This document assumes that you have already set up your development environment and can perform builds, etc.  Refer to the following links for more help on this:

* http://sww.sas.com/saspedia/CI_NextGen_development_environment
* http://sww.sas.com/saspedia/Using_getawskey_for_AWS_security_keys_and_tokens
* http://sww.sas.com/saspedia/Using_getawskey-go_for_AWS_security_keys_and_tokens
* http://sww.sas.com/saspedia/MicroService_CI360


## AWS Considerations
When running the micro-service application on the local desktop, most AWS operations can be accessed as long as there is an authentication file.  One of the exceptions is EC2 meta-data.  EC2 meta-data is
retrieved from a local service running on EC2 servers.  Any API calls trying to use this service will
fail on the developer desktop.

## Developing with mkt-shared-config-client library
The mkt-shared-config-client has the ability to run on the local desktop, even though it uses EC2 meta-data.

### No AWS mkt-shared-config-client
When running unit or integration tests and AWS is not to be used, one of the following configuration methods should be used:

#### Spring profiles (Older way)
application.properties file:
```
# Use this config to disable mkt-config resolution
#spring.profiles.active=nonec2,files
```

or in your JUnit test, use this annotation:
```
@ActiveProfiles({ SpringProfiles.FILES, SpringProfiles.NON_EC2 })
```

#### Annotation configuration options (New way)
Normally just used in your JUnit tests since it requires changing the arguments in code for the actual application class.
```
@EnableConfigClient(ourComponentNm = "my-component", nonEc2 = true, configClientMode = ConfigClientMode.FILE)
```

This specifies that a non-EC2 version of the Ec2MetaData interface be instantiated.  There should also be file versions of the mkt-config and mkt-tenant clients.  This is useful when your tests will not be using these resources.

See the *mkt-template-microservice* repo for examples of the above.
**Note:** The 'files' spring profile can still be used to override the @EnableConfigClient annotation to
aid in desktop development.


### AWS mkt-shared-config-client on desktop
When running your application or performing automated tests on your desktop environment but you also need mkt-config and/or mkt-tenant functionality, the following Spring profiles should be used:

#### Spring profiles (Older way)
application.properties file:
```
# Use this config to access mkt-config from Eclipse
spring.profiles.active=nonec2
```

or in your JUnit test, use this annotation:
```
@ActiveProfiles({ SpringProfiles.NON_EC2})
```

#### Annotation configuration options (New way)
application.properties file:
```
# Use this config to access mkt-config from Eclipse
# Note: You don't have to specify 'mkt-config' because @EnableConfigClient is
#       used in the application.
# Note: Once mkt-tenant is migrated to annotation-based configuration, it will
#       work the same way.
spring.profiles.active=nonec2
```

Spring application configuration:
```
@EnableConfigClient(ourComponentNm = "my-component", configClientMode = ConfigClientMode.MKT_CONFIG)
```


### Using Ec2MetaData in NON_EC2 mode
The concrete class *FileMetaData* implementing *Ec2MetaData* interface will initialize on its own in NON_EC2 mode but some values may not be desirable.  For example, the default stack-prefix is *localhost*.
This can be overridden with the system property: **stack**.  On Eclipse, you would add the following VM argument to the Run Configuration for your application:
```
-Dstack=dev -DServiceUrl="http://myservice-dev.cidev.sas.us:8080/myService"
```

Where **dev** is the stack prefix used.  This would cause Ec2MetaData to set The **Application** tag to *dev* and would resolve *dev-mkt-config* for its config service.

The following data is pre-filled for you in *FileMetaData*:
* Output - ConfigServiceUrl
* Tag - Application
* Tag - ConfigStackName
* Parameter - StackPrefix

In this mode, you can directly store: outputs, resources, tags, etc. as shown below.
This is useful for integration testing with JUnit.

```
    @Autowired
    protected transient Ec2MetaData metaData;

    @PostConstruct
    public void init() {
        /*
         * This simulates expected outputs that are retrieved via the
         * Ec2MetaData service when operating in NON_EC2 mode.
         */
        metaData.getOutputs().put("MySpecialOutput", "some value");
    }
```


## Logging and Spring Profiles
As mentioned in other sections, there are multiple Spring configuration files used for development
environments, JUnit test and deployment.  This is also the case for log configuration files.  Below
is a table of these file locations:

### Local development environment
* **src/main/resources/application*.properties** - Spring configuration files
* **src/main/resources/logback-spring.xml** - Logback configuration file

### JUnit test environment
* **src/test/resources/test.properties** - Spring configuration file
* **src/test/resources/logback-spring.xml** - Logback configuration file

### Deployment environment
* **mkt-template-microservice-cloudformation/src/main/cloudformation/cloudformation.json** - Location of Spring configuration file data
* **mkt-template-microservice-codedeploy/Source/content/bin/logback-spring.xml** - Logback configuration file

These multiple file locations allow the developer to have different Spring and logging configurations in each environment.
