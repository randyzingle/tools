'''
ECHO Echo echo e...

Source code located in GitLab:
    // TODO - put in layers project https://gitlab.sas.com/CustomerIntelligence/DevOps/mkt-infra

Configuration:
"Handler": "EchoServer.handler"
"Runtime": "python3.6"
"Timeout": "300"

Aug 7, 2019
@author: razing
'''
import json
from urllib.request import urlopen, Request, HTTPError, URLError
from urllib.parse import urlencode
import boto3
import re
import time
import uuid

# ===============================================================================
#  Sample CloudFormation events
# ===============================================================================
'''

'''

# ===============================================================================
#  Constants
# ===============================================================================
STATUS_FAILED = 'FAILED'
STATUS_SUCCESS = 'SUCCESS'

# ===============================================================================
#  Entry Point for Lambda
# ===============================================================================
def handler(event, context):
    #print(event)
    rtype = event['RequestType']
    status = event['ResourceProperties']['Status']
    gitsha = event['ResourceProperties']['GitTagShaVersion']
    #print(event['ResourceProperties'])

    if rtype == 'Create':
        print('creating stuff')
        #create_resources(event, context)
    elif rtype == 'Update':
        print('updating stuff')
        #update_resources(event, context)
    elif rtype == 'Delete':
        print('deleting stuff')
        #delete_resources(event, context)
    else:
        print(rtype, ' :Not a proper request-type, should be one of [Create|Update|Delete]')

    load_configuration(event)
    run_task(event)

    send_response(event, STATUS_SUCCESS)


# ===============================================================================
#  Spin up Docker Container
# ===============================================================================

def run_task(event):
    print ('running task')
    client = boto3.client('ecs')
    cluster = event['configParameters']['ECSCluster']
    taskDefinition = event['configParameters']['TaskDefinitionName']

    response = client.run_task(
        cluster=cluster,
        taskDefinition=taskDefinition,
        overrides={"containerOverrides": [ ] },
        count=1,
        startedBy='mymir',
        group='dogpack',
        launchType='EC2'
    )

    # healthStatus: 'HEALTHY'|'UNHEALTHY'|'UNKNOWN'
    # status for containers coming up: PROVISIONING, PENDING, ACTIVATING
    # status for running container: RUNNING
    # status for container going down: DEACTIVATING, STOPPING, DEPROVISIONING, STOPPED
    taskArn = response['tasks'][0]['taskArn']
    lastStatus = response['tasks'][0]['lastStatus']
    desiredStatus = response['tasks'][0]['desiredStatus']
    print('task: ' + taskArn)
    print('last: ' + lastStatus)
    print('desired: ' + desiredStatus)
    maxTries = 8
    tries = 0
    while tries < maxTries:
        response = client.describe_tasks(
            cluster=cluster,
            tasks=[
                taskArn,
            ]
        )
        tries += 1
        sleep = 2 ** tries
        print('sleeping for ' + str(sleep) + ' secs')
        time.sleep(sleep)
        lastStatus = response['tasks'][0]['lastStatus']
        desiredStatus = response['tasks'][0]['desiredStatus']

        print('+++++++++++++++++++++++++++')
        print('last: ' + lastStatus)
        print('desired: ' + desiredStatus)
        if lastStatus == desiredStatus:
            break

    response = client.describe_tasks(
        cluster=cluster,
        tasks=[
            taskArn,
        ]
    )
    container = response['tasks'][0]['containers'][0]
    networkBindings = container['networkBindings'][0]
    networkInterfaces = container['networkInterfaces']
    healthStatus = response['tasks'][0]['healthStatus']
    containerInstanceArn = response['tasks'][0]['containerInstanceArn']
    print(networkBindings)
    print(networkInterfaces)
    print(healthStatus)
    print(containerInstanceArn)

    response = client.describe_container_instances(
        cluster=cluster,
        containerInstances=[
            containerInstanceArn,
        ]
    )

    server = response['containerInstances'][0]['ec2InstanceId']
    print('server: ' + server)

    ec2_client = boto3.client('ec2')
    response = ec2_client.describe_instances(
        InstanceIds=[
            server,
        ]
    )

    ip = response['Reservations'][0]['Instances'][0]['PrivateIpAddress']
    print(ip)
    url = 'http://'+str(ip)+':'+str(networkBindings['hostPort'])+'/liquibaseManager/liquibase'
    print(url)
    event['Url'] = url


# ===============================================================================
#  Configuration Information
# ===============================================================================

def load_configuration(event):
    get_rds_parameters(event)
    get_configuration_parameters(event)

def get_configuration_parameters(event):
    outputMap = {}
    try:
        outputMap['ProjectName'] = event['ResourceProperties']['ProjectName']
        outputMap['StackPrefix'] = event['ResourceProperties']['StackPrefix']
        outputMap['DeploymentBucket'] = event['ResourceProperties']['DeploymentBucket']
        outputMap['CodeDeployLocation'] = event['ResourceProperties']['CodeDeployLocation']
        outputMap['ECSCluster'] = event['ResourceProperties']['ECSCluster']
        outputMap['TaskDefinitionName'] = event['ResourceProperties']['TaskDefinitionName']
        prod = event['ResourceProperties']['IsProduction']
        if prod == '1':
            outputMap['IsProduction'] = True
        else:
            outputMap['IsProduction'] = False
        print(json.dumps(outputMap, indent=2))
        event['configParameters'] = outputMap
    except Exception as ex:
        event['error'] = ex
        send_response(event, STATUS_FAILED)
    else:
        if outputMap['IsProduction']:
            print('IN PRODUCTION MODE....')
        else:
            print('not in production mode')


def get_rds_parameters(event):
    try:
        rdsStackName = event['ResourceProperties']['RDSStackName']
        cfclient = boto3.client('cloudformation')
        rds_info = cfclient.describe_stacks(StackName=rdsStackName)
        stack, = rds_info['Stacks']
        outputs = stack['Outputs']
        outputMap = {}
        for o in outputs:
            key = o['OutputKey']
            outputMap[key] = o['OutputValue']

        outputMap['AdminDatabase'] = outputMap['JdbcURL'].split('/')[3]
        stackPrefix = event['ResourceProperties']['StackPrefix']
        projectName = event['ResourceProperties']['ProjectName']
        outputMap['UserName'] = projectName
        outputMap['DatabaseName'] = stackPrefix + '-' + projectName
        decodedPassword = call_password_decoder(outputMap['RDSEncodedPassword'])['value']
        outputMap['Password'] = decodedPassword
        print(json.dumps(outputMap, indent=2))
        event['rdsParameters'] = outputMap
    except Exception as ex:
        event['error'] = ex
        send_response(event, STATUS_FAILED)

def call_password_decoder(password):
    lambda_client = boto3.client('lambda')
    print('Calling PasswordDecoder lambda')
    response = lambda_client.invoke(FunctionName='PasswordDecoder', Payload=json.dumps({'password': password}))
    streamingBody = response['Payload']
    stringData = streamingBody.read()
    data = json.loads(stringData)
    return data

# ===============================================================================
#  Cloudformation HTTP PUT response indicating SUCCESS or FAILURE of lambda
# ===============================================================================
def send_response(event, responseStatus):
    if 'StackId' not in event:
        print('no stack id - bailing')
        return
    print('sending response to CloudFormation')
    data = {}
    data['RequestType'] =  event['RequestType']
    responseBody = {
        'Status': responseStatus,
        'Reason': 'Why not? Why do I need to have a reason?',
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'Data': data
    }

    # PhysicalResourceId only sent with Update and Delete requests
    responseBody['PhysicalResourceId'] = event.get('PhysicalResourceId', 'None')

    #print(responseBody)
    edata = json.dumps(responseBody)
    edata = edata.encode('utf-8')
    headers = {'Content-Length': len(edata), 'Content-Type': ''}
    #Sprint(headers)
    req = Request(
        event['ResponseURL'],
        headers=headers,
        data=edata,
        method='PUT')
    req.get_method = lambda: 'PUT'
    try:
        urlopen(req)
    except Exception as e:
        print(e)


# ===============================================================================
#  Test Code for runs from the command line
# ===============================================================================
if __name__ == "__main__":
    print('in __main__ function')

    #"Status": "SUCCESS" | "FAILED"

    event = '''
    {
      "RequestType": "Create",
      "ResourceProperties": {
        "Description": "Lambda will manage Postgresql DB lifecycle",
        "ProjectName": "mkt-liquibase-manager",
        "StackPrefix": "mymir",
        "RDSStackName": "baldur-rds",
        "DeploymentBucket": "ci-360-deployment-dev-us-east-1",
        "CodeDeployLocation": "CodeDeploy/personal/mymir/mkt-liquibase-manager",
        "ECSCluster": "dev-ecs-infrastructure",
        "GitTagShaVersion": "asdf",
        "TaskDefinitionName": "mymir-mkt-liquibase-manager",
        "IsProduction": "1",
        "Status": "SUCCESS"
      },
      "OldResourceProperties": {
        "ProjectName": "mkt-liquibase-manager",
        "StackPrefix": "mymir",
        "RDSStackName": "baldur-rds",
        "DeploymentBucket": "ci-360-deployment-dev-us-east-1",
        "CodeDeployLocation": "CodeDeploy/personal/mymir/mkt-liquibase-manager",
        "ECSCluster": "dev-ecs-infrastructure",
        "GitTagShaVersion": "asdf",
        "TaskDefinitionName": "mymir-mkt-liquibase-manager",
        "IsProduction": "1",
        "Status": "SUCCESS"
      }
    }
    '''
    context = {}
    handler(json.loads(event), context)
