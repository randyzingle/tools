'''

Source code located in GitLab:
// TODO - put in layers project https://gitlab.sas.com/CustomerIntelligence/DevOps/mkt-infra

Configuration:
"Runtime": "python3.7"

July 7, 2020
@author: razing
'''
import json

def setOutputParameters(event, params):
    outputParameters = params['results']['outputParameters']
    # again we should be able to dynamically generate this - grab everything in the output parameters list
    event['data']['RdsDatabaseEndpointAddress'] = outputParameters['RdsDatabaseEndpointAddress']
    event['data']['JdbcURL'] = outputParameters['JdbcURL']
    event['data']['SecureParams'] = outputParameters['SecureParams']
    event['data']['RdsDNSEndpointAddress'] = outputParameters['RdsDNSEndpointAddress']
    event['data']['RdsSecurityGroup'] = outputParameters['RdsSecurityGroup']
    event['data']['RDSEncodedPassword'] = outputParameters.get('RDSEncodedPassword','')

    # common to all data
    event['message'] = params['results']['message']
    event['status'] = params['results']['status']
