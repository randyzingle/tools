## Definitions
### Api
|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|links||false|Link array||
|version||false|integer (int32)||


### Counter
|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|count||false|integer (int64)||


### Gauge
|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|value||false|object||


### Health
|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|description||false|string||
|status||false|string||


### Histogram
|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|count||false|integer (int64)||
|snapshot||false|Snapshot||


### Link
|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|href||false|string||
|itemType||false|string||
|method||false|string||
|rel||false|string||
|responseItemType||false|string||
|responseType||false|string||
|title||false|string||
|type||false|string||
|uri||false|string||


### Meter
|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|count||false|integer (int64)||
|fifteenMinuteRate||false|number (double)||
|fiveMinuteRate||false|number (double)||
|meanRate||false|number (double)||
|oneMinuteRate||false|number (double)||


### MetricRegistry
|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|counters||false|object||
|gauges||false|object||
|histograms||false|object||
|meters||false|object||
|metrics||false|object||
|names||false|string array||
|timers||false|object||


### Result
|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|error||false|Throwable||
|healthy||false|boolean||
|message||false|string||


### Snapshot
|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|75thPercentile||false|number (double)||
|95thPercentile||false|number (double)||
|98thPercentile||false|number (double)||
|999thPercentile||false|number (double)||
|99thPercentile||false|number (double)||
|max||false|integer (int64)||
|mean||false|number (double)||
|median||false|number (double)||
|min||false|integer (int64)||
|stdDev||false|number (double)||
|values||false|integer (int64) array||


### StackTraceElement
|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|className||false|string||
|fileName||false|string||
|lineNumber||false|integer (int32)||
|methodName||false|string||
|nativeMethod||false|boolean||


### Throwable
|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|cause||false|Throwable||
|localizedMessage||false|string||
|message||false|string||
|stackTrace||false|StackTraceElement array||
|suppressed||false|Throwable array||


### Timer
|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|count||false|integer (int64)||
|fifteenMinuteRate||false|number (double)||
|fiveMinuteRate||false|number (double)||
|meanRate||false|number (double)||
|oneMinuteRate||false|number (double)||
|snapshot||false|Snapshot||


### User
|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|id||false|integer (int64)||
|name||false|string||
|profileid||false|string||
|type||false|string||
|version||false|integer (int32)||


