package com.sas.mkt.kafka.tools.s3connect;

import com.fasterxml.jackson.annotation.JsonProperty;

public class StatusConnector {
	public StatusConnector() {}
	@JsonProperty("state")
	public String state;
	@JsonProperty("worker_id")
	public String workerId;
	
	@Override
	public String toString() {
		return "StatusConnector [state=" + state + ", workerId=" + workerId + "]";
	}
	
}