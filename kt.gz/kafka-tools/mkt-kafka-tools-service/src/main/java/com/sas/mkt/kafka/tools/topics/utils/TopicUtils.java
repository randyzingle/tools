package com.sas.mkt.kafka.tools.topics.utils;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ExecutionException;

import javax.annotation.PreDestroy;

import org.apache.avro.Schema;
import org.apache.avro.Schema.Field;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.Config;
import org.apache.kafka.clients.admin.ConfigEntry;
import org.apache.kafka.clients.admin.DescribeClusterResult;
import org.apache.kafka.clients.admin.DescribeConfigsResult;
import org.apache.kafka.clients.admin.DescribeTopicsResult;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndTimestamp;
import org.apache.kafka.common.PartitionInfo;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.config.ConfigResource;
import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.common.utils.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.core.BaseUtils;
import com.sas.mkt.config.health.ExternalDependency;
import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.tools.topics.data.ClusterInfoDTO;
import com.sas.mkt.kafka.tools.topics.data.FieldDTO;
import com.sas.mkt.kafka.tools.topics.data.RecordDTO;
import com.sas.mkt.kafka.tools.topics.data.RecordSetDTO;
import com.sas.mkt.kafka.tools.topics.data.TopicInfoDTO;

//import kafka.utils.ZKStringSerializer$;

@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
@Component
public class TopicUtils implements ExternalDependency {

	private Logger logger = LoggerFactory.getLogger(TopicUtils.class);

	private static final List<String> NO_FILTER_FIELD_LIST = Arrays.asList("null", "map", "record");
	private static final long FORTY_FIVE_MIN_IN_MS = 45 * 60 * 1000;

	private boolean deadLetter = true;
	private List<RecordDTO> badRecordList; // TODO we need a max limit on this

	private Consumer<String, SpecificRecordBase> avroConsumer;
	private Consumer<String, String> stringConsumer;
	private ApplicationConfiguration appConfig;
	private KafkaConnectionUtils kafkaConnectionUtils;
	private Map<String, String> kafkaProperties;

//	private ZkClient zkClient;

	private String bootStrapServers;
//	private String zkUrl;

//	private int timeout = 10;
//	private int sessionTimeout = timeout * 1000;
//	private int connectionTimeout = timeout * 1000;

	private AdminClient adminClient;

	private List<String> topicList;
	private Map<String, List<FieldDTO>> fieldMap = new HashMap<>();
	private Map<String, List<String>> cleanFieldMap = new HashMap<>();

	@Autowired
	public TopicUtils(ApplicationConfiguration appConfig) {
		BaseUtils.bigPrint("loading bean TopicUtils");
		this.appConfig = appConfig;
		this.init();
	}

	private int count = 0;

	// TEMP code to test session handling
	public int count() {
		System.out.println("max polls: " + appConfig.getMaxEmptyPolls());
		System.out.println("max records: " + appConfig.getMaxRecords());
		System.out.println("timeout: " + appConfig.getConsumerPollTimeoutMs());
		return count++;
	}

	private long countRecords(Map<TopicPartition, Long> startoff, Map<TopicPartition, Long> endoff) {
		long count = 0;
		Set<TopicPartition> endkeys = endoff.keySet();
		for (TopicPartition tp : endkeys) {
			count += endoff.get(tp) - startoff.get(tp);
		}
		return count;
	}

//	public boolean isTopicCompacted(String topicName) {
//		Properties props = getTopicProperties(topicName);
//		return isCompactedProperty(props);
//	}

//	public boolean isCompactedProperty(Properties props) {
//		boolean compacted = false;
//		String prop = props.getProperty("cleanup.policy");
//		if (prop != null && prop.equals("compact")) {
//			compacted = true;
//		}
//		return compacted;
//	}

	public TopicInfoDTO getTopicInfo(String topic) {
		logger.debug("getting topic information for {}", topic);
		TopicInfoDTO topicInfo = new TopicInfoDTO(topic, TopicInfoDTO.ValueType.Unknown, 0, null, null, null,
				false, null, 0, -1L, -1L, null, appConfig.getMaxRecords());
		
		Properties props = getTopicProperties(topic, topicInfo);

		// first we have to determine if the topic is compacted - if it is we can't
		// count the messages via offsets
		boolean compacted = topicInfo.compacted;

		long numberMessages = 0;
//		if (compacted) {
//			numberMessages = -1;
//		} else {
//			numberMessages = getNumberOfRecordsForTopic(topic);
//		}
		numberMessages = getNumberOfRecordsForTopic(topic);

		// get the number of partitions
		int numberPartitions = getNumberOfPartitionsForTopic(topic);

		// if we don't have any messages we can't determine anything about the topic
		if (numberMessages <= 0) {
			topicInfo.setInfo(topic, TopicInfoDTO.ValueType.Unknown, numberMessages, null, null, null,
					compacted, props, numberPartitions, -1L, -1L, null, appConfig.getMaxRecords());
			return topicInfo;
		}

		// we have messages - try to get Avro info
		try {
			avroConsumer.subscribe(Arrays.asList(topic));
			boolean done = false;
			while (!done) {
				try {
					// Try reading it as an Avro message (superclass SpecificRecordBase)
					ConsumerRecords<String, SpecificRecordBase> records = avroConsumer.poll(Duration.ofMillis(1000));
					for (ConsumerRecord<String, SpecificRecordBase> record : records) {
						Schema schema = record.value().getSchema();
						List<FieldDTO> fieldList = getAvroFieldInfo(schema);
						List<String> cleanFieldList = getCleanFieldList(schema);
						topicInfo.setInfo(topic, TopicInfoDTO.ValueType.AvroType, numberMessages,
								schema.getName(), fieldList, cleanFieldList, compacted, props, numberPartitions, -1L,
								-1L, null, appConfig.getMaxRecords());
						topicInfo = getFirstAndLastTimestamp(topicInfo);
						done = true;
						break;
					}
				} catch (Exception ex) {
					// it wasn't an Avro message but it has messages
					FieldDTO fdto = new FieldDTO("body", null, "String", null);
					List<FieldDTO> fieldList = Collections.singletonList(fdto);
					List<String> cleanFieldList = Collections.singletonList("body");
					topicInfo.setInfo(topic, TopicInfoDTO.ValueType.Unknown, numberMessages, null, fieldList,
							cleanFieldList, compacted, props, numberPartitions, -1L, -1L, null,
							appConfig.getMaxRecords());
					// implement the following when we setup the pure String reader
					topicInfo = getFirstAndLastTimestamp(topicInfo);
					done = true;
					break;
				}
			}
		} catch (Exception ex) {
			logger.warn(ex.getMessage());
			if (topicInfo == null) {
				topicInfo = new TopicInfoDTO(topic, TopicInfoDTO.ValueType.Unknown, numberMessages, null, null, null,
						compacted, props, numberPartitions, -1L, -1L, null, appConfig.getMaxRecords());
			}
			topicInfo.errorMessage = ex.getMessage();
		} finally {
			avroConsumer.unsubscribe();
		}
		return topicInfo;
	}

	public List<String> getCleanFieldList(Schema schema) {
		String name = schema.getFullName();
		if (cleanFieldMap.containsKey(name)) {
			return cleanFieldMap.get(name);
		} else {
			getAvroFieldInfo(schema);
		}
		return cleanFieldMap.get(name);
	}

	public List<FieldDTO> getAvroFieldInfo(Schema schema) {
		String name = schema.getFullName();
		if (fieldMap.containsKey(name))
			return fieldMap.get(name);

		List<FieldDTO> fieldList = new ArrayList<>();
		List<Field> fields = schema.getFields();
		System.out.printf("Name: %s, FullName: %s%n", schema.getName(), schema.getFullName());
		for (Field f : fields) {
			Schema testType = f.schema();
			String ftype = null;
			List<String> enumList = null;
			if (testType.getType().equals(Schema.Type.UNION)) {
				List<Schema> typeList = f.schema().getTypes();
				for (Schema fschema : typeList) {
					ftype = fschema.getType().getName();
					if (ftype.equals("null")) {
						continue;
					}
					if (ftype.equals("enum")) {
						enumList = fschema.getEnumSymbols();
					}
				}
			} else {
				ftype = testType.getType().getName();
				if (ftype.equals("enum")) {
					enumList = testType.getEnumSymbols();
				}
			}

			if (!NO_FILTER_FIELD_LIST.contains(ftype)) {
				fieldList.add(new FieldDTO(f.name(), null, ftype, enumList));
			}
		}
		fieldMap.put(name, fieldList);
		List<String> cleanFields = new ArrayList<>();
		for (FieldDTO fdto : fieldList) {
			cleanFields.add(fdto.getName());
		}
		cleanFieldMap.put(name, cleanFields);
		return fieldList;
	}

	public List<String> getTopics() {
		List<String> topicList = new ArrayList<>();
		Map<String, List<PartitionInfo>> topicMap = avroConsumer.listTopics();
		Set<String> keySet = topicMap.keySet();
		topicList.addAll(keySet);
		Collections.sort(topicList);
		return topicList;
	}

	public int getNumberOfPartitionsForTopic(String topic) {
		int number = 0;
		List<PartitionInfo> pinfo = avroConsumer.partitionsFor(topic);
		number = pinfo.size();
		return number;
	}

	public TopicInfoDTO getFirstAndLastTimestamp(TopicInfoDTO topicInfoDTO) {
		Consumer<String, ?> activeConsumer = null;
		if (topicInfoDTO.valueType == TopicInfoDTO.ValueType.AvroType) {
			activeConsumer = avroConsumer;
		} else {
			activeConsumer = stringConsumer;
		}
		long startTime = System.currentTimeMillis();
		String errorMessage = null;
		activeConsumer.unsubscribe();
		String topic = topicInfoDTO.topic;
		List<PartitionInfo> pinfo = activeConsumer.partitionsFor(topic);
		List<TopicPartition> fullList = new ArrayList<>();
		for (PartitionInfo pi : pinfo) {
			TopicPartition tp = new TopicPartition(pi.topic(), pi.partition());
			fullList.add(tp);
		}

		Map<TopicPartition, Long> startOffsets = activeConsumer.beginningOffsets(fullList);
		Map<TopicPartition, Long> endOffsets = activeConsumer.endOffsets(fullList);
		long first = Long.MAX_VALUE;
		long last = Long.MIN_VALUE;

		List<TopicPartition> activeList = new ArrayList<>();
		Set<TopicPartition> keySet = startOffsets.keySet();
		for (TopicPartition key : keySet) {
			long diff = endOffsets.get(key) - startOffsets.get(key);
			if (diff > 0)
				activeList.add(key);
		}
		activeConsumer.assign(activeList);
		activeConsumer.seekToBeginning(activeList);
		Set<TopicPartition> doneList = new HashSet<>(activeList.size());
		int emptyPolls = 0;
		boolean done = false;
		while (!done) {
			ConsumerRecords<String, ?> records = null;
			try {
				records = activeConsumer.poll(Duration.ofMillis(appConfig.getConsumerPollTimeoutMs()));
				if (records.isEmpty()) {
					emptyPolls++;
				} else {
					emptyPolls = 0;
				}
				if (emptyPolls > appConfig.getMaxEmptyPolls()) {
					System.out.println("Too many empty loops, timing out....");
					done = true;
					break;
				}
				for (ConsumerRecord<String, ?> record : records) {
					TopicPartition tp = new TopicPartition(record.topic(), record.partition());
					if (doneList.contains(tp))
						continue;
					long timestamp = record.timestamp();
					if (timestamp < first) {
						first = timestamp;
					}
					doneList.add(tp);
					if (doneList.size() == activeList.size()) {
						System.out.println("Found start timestamps for all active partitions....");
						done = true;
						break;
					}
				}
			} catch (SerializationException serex) {
				first = System.currentTimeMillis() - 2419200000L;
				done = true;
				errorMessage = "Bad record at first timestamp, picking *4 weeks ago* for lower time-bounds: "
						+ serex.getMessage();
				logger.warn(errorMessage);
			}
		}

		for (TopicPartition tp : activeList) {
			long offset = endOffsets.get(tp) - 1;
			activeConsumer.seek(tp, offset);
		}
		doneList.clear();
		emptyPolls = 0;
		done = false;
		while (!done) {
			ConsumerRecords<String, ?> records = null;
			try {
				records = activeConsumer.poll(Duration.ofMillis(appConfig.getConsumerPollTimeoutMs()));
				if (records.isEmpty()) {
					emptyPolls++;
				} else {
					emptyPolls = 0;
				}
				if (emptyPolls > appConfig.getMaxEmptyPolls()) {
					System.out.println("Too many empty loops, timing out....");
					done = true;
					break;
				}

				for (ConsumerRecord<String, ?> record : records) {
					TopicPartition tp = new TopicPartition(record.topic(), record.partition());
					if (doneList.contains(tp))
						continue;
					long timestamp = record.timestamp();
					if (timestamp > last) {
						last = timestamp;
					}
					doneList.add(tp);
					if (doneList.size() == activeList.size()) {
						System.out.println("Found end timestamps for all active partitions....");
						done = true;
						break;
					}
				}
			} catch (SerializationException serex) {
				done = true;
				last = System.currentTimeMillis();
				errorMessage = "Bad record at last timestamp, picking *now* for upper time-bounds: "
						+ serex.getMessage();
				logger.warn(errorMessage);
			}
		}

		activeConsumer.unsubscribe();
		// TODO think about this, should we increase the poll time or number of polls?
		// Should we make these appconfig parameters or force increase if we see number
		// message != 0
		if (first == Long.MAX_VALUE)
			first = System.currentTimeMillis() - 432000000; // five days ago
		if (last == Long.MIN_VALUE)
			last = System.currentTimeMillis(); // now

		topicInfoDTO.firstTimestamp = first;
		topicInfoDTO.lastTimestamp = last;
		topicInfoDTO.errorMessage = errorMessage;
		long endTime = System.currentTimeMillis();
		System.out.printf("Took %d ms to calculate start and end times for messages%n", (endTime - startTime));
		return topicInfoDTO;
	}

	public long getNumberOfRecordsForTopic(String topic) {
		long number = 0;

		List<PartitionInfo> pinfo = avroConsumer.partitionsFor(topic);
		List<TopicPartition> plist = new ArrayList<>();
		for (PartitionInfo pi : pinfo) {
			TopicPartition tp = new TopicPartition(pi.topic(), pi.partition());
			plist.add(tp);
		}
		Map<TopicPartition, Long> startoff = avroConsumer.beginningOffsets(plist);
		Map<TopicPartition, Long> endoff = avroConsumer.endOffsets(plist);
		number = countRecords(startoff, endoff);

		return number;
	}

	public Map<String, Long> getNumberOfRecordsForAllTopics() {
		Map<String, Long> topicMap = new HashMap<>();
		List<String> topics = getTopics();
		for (String topic : topics) {
			long nrecords = getNumberOfRecordsForTopic(topic);
			topicMap.put(topic, nrecords);
		}
		return topicMap;
	}

	private void convertKeyToPartition(RecordSetDTO recordSetDTO, Consumer<String, ?> activeConsumer) {
		// If we have a keyFilter, figure out what partition it belongs to
		String keyFilter = recordSetDTO.keyFilter;
		if (keyFilter != null && !keyFilter.isEmpty()) {
			StringSerializer stringSerializer = new StringSerializer();
			byte[] keyBytes = stringSerializer.serialize(recordSetDTO.topic, keyFilter);
			stringSerializer.close();
			int numPartitions = activeConsumer.partitionsFor(recordSetDTO.topic).size();
			int partition = Utils.toPositive(Utils.murmur2(keyBytes)) % numPartitions;
			recordSetDTO.requestedPartition = partition;
		}
	}

	private Map<TopicPartition, OffsetAndTimestamp> getOffsetsForTimestamp(List<TopicPartition> topicPartitionList,
			long startTime, Consumer<String, ?> activeConsumer) {
		Map<TopicPartition, Long> timestamps = new HashMap<>(topicPartitionList.size());
		for (TopicPartition tp : topicPartitionList) {
			timestamps.put(tp, startTime);
		}
		Map<TopicPartition, OffsetAndTimestamp> offsetMap = activeConsumer.offsetsForTimes(timestamps);
		TreeMap<TopicPartition, OffsetAndTimestamp> sortedMap = new TreeMap<>(
				Comparator.comparing(TopicPartition::partition));
		for (TopicPartition tp : offsetMap.keySet()) {
			if (offsetMap.get(tp) != null) {
				sortedMap.put(tp, offsetMap.get(tp));
			}
		}
		return sortedMap;

	}

	public RecordSetDTO getBadRecords(TopicInfoDTO topicInfoDTO) {
		System.out.println("scanning for bad records ...");
		badRecordList = new ArrayList<>();
		avroConsumer.unsubscribe();
		stringConsumer.unsubscribe();
		avroConsumer.subscribe(Collections.singleton(topicInfoDTO.topic));
		boolean done = false;
		int emptyPolls = 0;
		while (!done) {
			ConsumerRecords<String, SpecificRecordBase> records = null;
			try {
				records = avroConsumer.poll(Duration.ofMillis(appConfig.getConsumerPollTimeoutMs()));
				if (records.isEmpty()) {
					emptyPolls++;
				} else {
					emptyPolls = 0;
				}
				if (emptyPolls > appConfig.getMaxEmptyPolls()) {
					System.out.println("Too many empty loops, timing out....");
					done = true;
					break;
				}
				for (ConsumerRecord<String, SpecificRecordBase> record : records) {
					// do nothing - throw exception if we can't deserialize
				}
			} catch (SerializationException serex) {
				String message = serex.getMessage();
				try {
					String sub = message.substring(message.indexOf("partition"), message.indexOf("."));
					String[] s1 = sub.split(" ");
					int partition = Integer.parseInt(s1[1].substring(s1[1].lastIndexOf("-") + 1, s1[1].length()));
					String topic = s1[1].substring(0, s1[1].lastIndexOf("-"));
					long offset = Long.parseLong(s1[4]);
					TopicPartition tp = new TopicPartition(topic, partition);

					// we've found the bad topic-partition + offset, seek past it with our consumer
					avroConsumer.seek(tp, offset + 1);
					stringConsumer.assign(Arrays.asList(tp));
					stringConsumer.seek(tp, offset);
					int empty2 = 0;
					while (true) {
						ConsumerRecords<String, String> badRecords = stringConsumer
								.poll(Duration.ofMillis(appConfig.getConsumerPollTimeoutMs()));
						if (records.isEmpty()) {
							empty2++;
							continue;
						} else {
							empty2 = 0;
						}
						if (empty2 > appConfig.getMaxEmptyPolls()) {
							System.out.println("Too many empty loops, timing out....");
							done = true;
							break;
						}
						for (ConsumerRecord<String, String> record : badRecords) {
							RecordDTO recordDTO = getStringRecordDTO(record);
							badRecordList.add(recordDTO);
							break;
						}
						break;
					}
				} catch (Exception ex) {
					logger.warn("Failed to skip bad record data: {}", ex.getMessage());
				}
			}

		}

		System.out.printf("%d messages in badList%n", badRecordList.size());
		stringConsumer.unsubscribe();
		avroConsumer.unsubscribe();
		RecordSetDTO recordSetDTO = new RecordSetDTO();
		recordSetDTO.badRecordList = badRecordList;
		return recordSetDTO;
	}

	public RecordSetDTO getRecords(RecordSetDTO recordSetDTO) {
		recordSetDTO.maxRecords = appConfig.getMaxRecords();
		if (deadLetter)
			badRecordList = new ArrayList<>();
		if (recordSetDTO.valueType == TopicInfoDTO.ValueType.AvroType) {
			System.out.println("getAvroRecords...");
			recordSetDTO = getFilteredRecords(recordSetDTO, avroConsumer, TopicInfoDTO.ValueType.AvroType,
					appConfig.getMaxRecords());
		} else {
			System.out.println("getStringRecords...");
			recordSetDTO = getFilteredRecords(recordSetDTO, stringConsumer, TopicInfoDTO.ValueType.StringType,
					appConfig.getMaxRecords());
		}
		recordSetDTO.badRecordList = badRecordList;
		return recordSetDTO;
	}

	private RecordSetDTO getFilteredRecords(RecordSetDTO recordSetDTO, Consumer<String, ?> activeConsumer,
			TopicInfoDTO.ValueType type, int maxRecords) {
		convertKeyToPartition(recordSetDTO, activeConsumer);

		// Don't let this run for ever, time the run and bail if it's taking too long
		long startTime = System.currentTimeMillis();

		// Validate the recordSetDTO first (offsets, partitions, times, topic, etc) or
		// return error message
		activeConsumer.unsubscribe();
		List<RecordDTO> recordList = new ArrayList<>(maxRecords);
		recordSetDTO.recordList = recordList;

		List<TopicPartition> fullPartitionList = new ArrayList<>();
		Map<TopicPartition, OffsetAndTimestamp> offsets = null;

		// Assign the proper partitions to the consumer
		if (recordSetDTO.requestedPartition != -1) {
			// yes we do, just read this partition
			fullPartitionList.add(new TopicPartition(recordSetDTO.topic, recordSetDTO.requestedPartition));
		} else {
			// no we don't read all partitions
			List<PartitionInfo> pi = activeConsumer.partitionsFor(recordSetDTO.topic);
			for (PartitionInfo info : pi) {
				fullPartitionList.add(new TopicPartition(recordSetDTO.topic, info.partition()));
			}
		}
		activeConsumer.assign(fullPartitionList);

		// do we have just 1 partition
		if (fullPartitionList.size() == 1 && recordSetDTO.requestedStartOffset != -1L) {
			// do we have a start offset
			if (recordSetDTO.requestedStartOffset != -1L) {
				offsets = new HashMap<>(1);
				OffsetAndTimestamp oat = new OffsetAndTimestamp(recordSetDTO.requestedStartOffset, 0L);
				offsets.put(fullPartitionList.get(0), oat);
			}
		} else {
			// we are using the start time stamp whether there is just one partition or many
			// get the offset for the given time stamp
			offsets = getOffsetsForTimestamp(fullPartitionList, recordSetDTO.requestedStartTime, activeConsumer);
		}

		if (offsets == null || offsets.isEmpty()) {
			return recordSetDTO;
		}

		// Assign partitions that have data
		List<TopicPartition> dataPartitionList = new ArrayList<>(offsets.keySet());
		activeConsumer.assign(dataPartitionList);

		// Seek to the start offset
		Set<TopicPartition> keys = offsets.keySet();
		for (TopicPartition partition : keys) {
			activeConsumer.seek(partition, offsets.get(partition).offset());
		}

		String s = String.format("looking for messages from %s to %s%n",
				new Date(recordSetDTO.requestedStartTime).toString(),
				new Date(recordSetDTO.requestedEndTime).toString());
		logger.debug(s);
		System.out.println(s);
		boolean done = false;

		int cnt = 0;
		int recordsExamined = 0;
		long first = Long.MAX_VALUE;
		long last = Long.MIN_VALUE;
		Set<TopicPartition> doneList = new HashSet<>(dataPartitionList.size());
		int emptyPolls = 0;
		while (!done) {
			long now = System.currentTimeMillis();
			if (now - startTime > FORTY_FIVE_MIN_IN_MS) {
				logger.debug("exceeded alloted query time");
				System.out.println(s);
			}
			ConsumerRecords<String, ?> records = null;
			try {
				records = activeConsumer.poll(Duration.ofMillis(appConfig.getConsumerPollTimeoutMs()));
				if (records.isEmpty()) {
					emptyPolls++;
				} else {
					emptyPolls = 0;
				}
				if (emptyPolls > appConfig.getMaxEmptyPolls()) {
					logger.debug("Too many empty loops, timing out....");
					System.out.println(s);
					done = true;
					break;
				}
				for (ConsumerRecord<String, ?> record : records) {
					boolean valid = true;
					long timestamp = record.timestamp();
					cnt++;
					recordsExamined++;
					if (recordSetDTO.requestedPartition != -1 && recordSetDTO.requestedEndOffset != -1
							&& record.offset() > recordSetDTO.requestedEndOffset) {
						cnt--;
						logger.debug("Passed requested end offset....");
						System.out.println(s);
						done = true;
						break;
					}
					if (timestamp > recordSetDTO.requestedEndTime) {
						cnt--;
						doneList.add(new TopicPartition(record.topic(), record.partition()));
						activeConsumer.pause(doneList);
						if (doneList.size() == dataPartitionList.size()) {
							logger.debug("Partitions all drained for time window....");
							System.out.println(s);
							done = true;
							break;
						} else {
							continue;
						}
					}
					if (cnt > maxRecords) {
						logger.debug("Hit max records limit....");
						System.out.println(s);
						done = true;
						break;
					}
					if (timestamp < first) {
						first = timestamp;
					}
					if (timestamp > last) {
						last = timestamp;
					}
					// more than one key may be serialized to the same partition, make sure this
					// record has the right key
					if (recordSetDTO.keyFilter != null && !recordSetDTO.keyFilter.isEmpty()) {
						if (record.key() == null || !record.key().equals(recordSetDTO.keyFilter)) {
							valid = false;
							cnt--;
						}
					}
					if (valid && recordSetDTO.valueFilters != null && !recordSetDTO.valueFilters.isEmpty()) {
						Set<String> keySet = recordSetDTO.valueFilters.keySet();
						for (String key : keySet) {
							String filter = recordSetDTO.valueFilters.get(key);
							Object value = null;
							if (type == TopicInfoDTO.ValueType.AvroType) {
								value = ((SpecificRecordBase) record.value()).get(key);
							} else {
								value = record.value();
							}
							if (value == null || !filter.equals(value.toString())) {
								valid = false;
								cnt--;
								break;
							}
						}
					}
					if (valid) {
						if (type == TopicInfoDTO.ValueType.AvroType) {
							recordList.add(getAvroRecordDTO(record));
						} else {
							recordList.add(getStringRecordDTO(record));
						}
					}
				}
			} catch (SerializationException serex) {
				skipBadData(serex.getMessage());
			}

		}

		System.out.printf("%d messages in messageList%n", recordList.size());
		System.out.println("first message: " + new Date(first).toString());
		System.out.println("last message: " + new Date(last).toString());
		System.out.printf("examined %d records%n", recordsExamined);
		done = false;
		recordSetDTO.firstTimestamp = first;
		recordSetDTO.lastTimestamp = last;
		activeConsumer.unsubscribe();

		return recordSetDTO;
	}

	// Note we're just grabbing the first bad record here, we could get more
	// sophisticated.
	public void skipBadData(String message) {
		try {
			String sub = message.substring(message.indexOf("partition"), message.indexOf("."));
			String[] s1 = sub.split(" ");
			int partition = Integer.parseInt(s1[1].substring(s1[1].lastIndexOf("-") + 1, s1[1].length()));
			String topic = s1[1].substring(0, s1[1].lastIndexOf("-"));
			long offset = Long.parseLong(s1[4]);
			TopicPartition tp = new TopicPartition(topic, partition);

			// we've found the bad topic-partition + offset, seek past it with our consumer
			avroConsumer.seek(tp, offset + 1);

			// if we want to examine the bad data write it to a dead letter queue
			if (deadLetter) {
				stringConsumer.unsubscribe();
				stringConsumer.assign(Arrays.asList(tp));
				stringConsumer.seek(tp, offset);
				while (true) {
					ConsumerRecords<String, String> records = stringConsumer.poll(Duration.ofMillis(1000));
					for (ConsumerRecord<String, String> record : records) {
						RecordDTO recordDTO = getStringRecordDTO(record);
						if (deadLetter) {
							badRecordList.add(recordDTO);
						}
						break;
					}
					break;
				}
				stringConsumer.unsubscribe();
			}
		} catch (Exception ex) {
			logger.warn("Failed to skip bad record data: {}", ex.getMessage());
		} finally {
			stringConsumer.unsubscribe();
		}

	}

	private RecordDTO getStringRecordDTO(ConsumerRecord<String, ?> record) {
		RecordDTO recordDTO = new RecordDTO();
		recordDTO.key = record.key();
		recordDTO.offset = record.offset();
		recordDTO.partition = record.partition();
		recordDTO.timestamp = record.timestamp();
		Map<String, String> vmap = new HashMap<>();
		String val = (String) record.value();
		vmap.put("body", val);
		recordDTO.value = vmap;
		return recordDTO;
	}

	private RecordDTO getAvroRecordDTO(ConsumerRecord<String, ?> record) {
		RecordDTO recordDTO = new RecordDTO();
		recordDTO.key = record.key();
		recordDTO.offset = record.offset();
		recordDTO.partition = record.partition();
		recordDTO.timestamp = record.timestamp();
		Map<String, String> vmap = new HashMap<>();
		SpecificRecordBase val = (SpecificRecordBase) record.value();
		recordDTO.avroRecord = val;
		if (val != null) {
			Schema schema = val.getSchema();
			if (schema != null) {
				List<Field> fieldList = schema.getFields();
				for (Field field : fieldList) {
					Object obj = val.get(field.name());
					if (obj == null) {
						vmap.put(field.name(), "null");
					} else {
						vmap.put(field.name(), obj.toString());
					}
				}
			}
		}
		recordDTO.value = vmap;
		return recordDTO;
	}

	public ClusterInfoDTO getClusterInfo() {
		ClusterInfoDTO cid = new ClusterInfoDTO();
		DescribeClusterResult dcr = describeCluster();
		String bootStrapServers = getBootStrapServers();
//		String zooKeeperUrl = getZooKeeperUrl();
		try {
			cid.clusterId = dcr.clusterId().get();
		} catch (InterruptedException | ExecutionException ex) {
			logger.info(ex.getMessage());
		}
		cid.bootStrapServers = bootStrapServers;
//		cid.zooKeeperUrl = zooKeeperUrl;
		return cid;
	}

	public DescribeClusterResult describeCluster() {
		DescribeClusterResult results = null;
		results = adminClient.describeCluster();
		return results;
	}

	public DescribeConfigsResult describeConfigs(java.util.Collection<ConfigResource> resources) {
		DescribeConfigsResult results = null;
		results = adminClient.describeConfigs(resources);
		return results;
	}

	public DescribeTopicsResult describeTopics(Collection<String> topicNames) {
		DescribeTopicsResult results = null;
		results = adminClient.describeTopics(topicNames);
		return results;
	}

	private void openAdminClient() {
		if (adminClient == null) {
			String servers = getBootStrapServers();
			Properties props = new Properties();
			props.put("bootstrap.servers", servers);
			adminClient = AdminClient.create(props);
		}
	}

	public String getBootStrapServers() {
		if (this.bootStrapServers == null || this.bootStrapServers.isEmpty()) {
			this.bootStrapServers = kafkaProperties.get(KafkaConnectionUtils.SAS_MKT_KAFKA_CLUSTER);
		}
		return this.bootStrapServers;
	}

//	public String getZooKeeperUrl() {
//		if (this.zkUrl == null || this.zkUrl.isEmpty()) {
//			this.zkUrl = kafkaProperties.get(KafkaConnectionUtils.SAS_MKT_KAFKA_ZOOKEEPER);
//		}
//		return this.zkUrl;
//	}

	public Properties getTopicProperties(String topicName, TopicInfoDTO topicInfo) {
		Properties props = new Properties();
		Collection<ConfigResource> cr = Collections.singleton(new ConfigResource(ConfigResource.Type.TOPIC, topicName));

		DescribeConfigsResult ConfigsResult = adminClient.describeConfigs(cr);
		Config all_configs = null;
		try {
			all_configs = (Config) ConfigsResult.all().get().values().toArray()[0];
		} catch (InterruptedException | ExecutionException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		Iterator ConfigIterator = all_configs.entries().iterator();
//		{"message.format.version":"2.7-IV2","unclean.leader.election.enable":"true"}

		while (ConfigIterator.hasNext()) {
			ConfigEntry currentConfig = (ConfigEntry) ConfigIterator.next();
			if (!currentConfig.isDefault()) {
				props.put(currentConfig.name(), currentConfig.value());
			}
			if (currentConfig.name().equals("cleanup.policy") && currentConfig.value().contentEquals("compact")) {
				topicInfo.compacted = true;
			}
		}
		
		return props;
	}

	public Consumer<String, SpecificRecordBase> getConsumer() {
		String groupID = appConfig.getTierName() + "-" + appConfig.getComponentName();
		Properties props = kafkaConnectionUtils.getKafkaConsumerProperties(appConfig.getTierName(), appConfig.getComponentName());
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
		avroConsumer = new KafkaConsumer<>(props);
		return avroConsumer;
	}

	public Consumer<String, String> getStringConsumer() {
		String groupID = appConfig.getTierName() + "-" + appConfig.getComponentName();
		Properties props = kafkaConnectionUtils.getKafkaConsumerProperties(appConfig.getTierName(), appConfig.getComponentName());
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
				org.apache.kafka.common.serialization.StringDeserializer.class);
		stringConsumer = new KafkaConsumer<>(props);
		return stringConsumer;
	}

	@Override
	public boolean isHealthy() {
		try {
			avroConsumer.listTopics();
			return true;
		} catch (Exception ex) {
			logger.warn("Kafka Consumer failed to connect in health check: {}", ex.getMessage());
		}
		return false;
	}

	@Override
	public void init() {
		BaseUtils.bigPrint("initializing TopicUtils");
		try {
			kafkaConnectionUtils = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
			kafkaProperties = kafkaConnectionUtils.getKafkaProperties();
			bootStrapServers = kafkaProperties.get(KafkaConnectionUtils.SAS_MKT_KAFKA_CLUSTER);
//			zkUrl = kafkaProperties.get(KafkaConnectionUtils.SAS_MKT_KAFKA_ZOOKEEPER);
//			zkClient = new ZkClient(zkUrl, sessionTimeout, connectionTimeout, ZKStringSerializer$.MODULE$);
			openAdminClient();
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
		}
		avroConsumer = getConsumer();
		stringConsumer = getStringConsumer();
		topicList = getTopics();
		logger.debug("found {} topics", topicList.size());
	}

	@Override
	public void restart() {
		// this is a session-scoped bean, session timeout or reload of browser will
		// restart for us ...
	}

	@PreDestroy
	public void destroy() {
		System.out.println("Shutting down TopicUtils...");
		logger.debug("Shutting down TopicUtils...");
//		if (zkClient != null) {
//			logger.debug("closing zookeeper connection");
//			zkClient.close();
//		}
		if (avroConsumer != null) {
			logger.debug("closing kafka consumer");
			avroConsumer.unsubscribe();
			avroConsumer.close();
		}
		if (stringConsumer != null) {
			stringConsumer.unsubscribe();
			stringConsumer.close();
		}
		if (adminClient != null) {
			adminClient.close();
		}
	}

}
