package com.sas.mkt.baldur.spring.db.data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Widget {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "customer_generator")
	@SequenceGenerator(name = "customer_generator", sequenceName = "customer_id_seq", allocationSize = 1)
	public Long id;
	public String widget_name;
	public String company;
	public String pgcolstuff;

	protected Widget() {
	}

	public Widget(String widget_name, String company, String pgcolstuff) {
		this.widget_name = widget_name;
		this.company = company;
		this.pgcolstuff = pgcolstuff;
	}


}
