'''
Get the value for the provided SSM parameter
    - if no version supplied it will get the latest version
    (e.g. --parameter /dev-mkt-config/tier_global/mkt-kafka/baldur)
    - if a version is supplied it will get the value for that version
    (e.g. --parameter /dev-mkt-config/tier_global/mkt-kafka/baldur:1)

Source code located in GitLab:
    https://gitlab.sas.com/CustomerIntelligence/DevOps/mkt-infra

Configuration:
"Handler": "SSMLookup.handler"
"Runtime": "python3.6"
"Timeout": "20"

April 15, 2019
@author: razing
'''
import boto3
import argparse
import json
from urllib.request import urlopen, Request

# ===============================================================================
#  Entry Point for Lambda
# ===============================================================================
def handler(event, context):
    rtype = event['RequestType']
    if rtype == 'Create' or rtype == 'Update':
        get_parameter(event, context)
    else:
        # nothing to delete but we don't want to hang
        send_response(event, 'SUCCESS', {})

# ===============================================================================
#  Get the Parameter and Return to CF Stack
# ===============================================================================
def get_parameter(event, context):
    ssm = boto3.client('ssm')
    data = {}
    try:
        parameterName = event['ResourceProperties']['ParameterName']
        parameter = ssm.get_parameter(Name=parameterName)
        parameterValue = parameter['Parameter']['Value']
        print('found parameter: ' + parameterName + ' = ' + parameterValue)
        data["ParameterName"] = parameterValue

        send_response(event, 'SUCCESS', data)
    except:
        print('failed to lookup/parse parameter')
        print(event)
        data['Reason'] = 'failed to lookup/parse parameter'
        send_response(event, 'FAILED', data)

# ===============================================================================
#  Cloudformation HTTP PUT response indicating SUCCESS or FAILURE of lambda
# ===============================================================================
def send_response(event, status, data):
    responseBody = {
        'Status': status,
        'Reason': 'See the details in CloudWatch Log Stream',
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'Data': data
    }

    # PhysicalResourceId only sent with Update and Delete requests
    responseBody['PhysicalResourceId'] = event.get('PhysicalResourceId', 'None')

    # print(responseBody)
    edata = json.dumps(responseBody)
    edata = edata.encode('utf-8')
    headers = {'Content-Length': len(edata), 'Content-Type': ''}
    # print(headers)
    req = Request(
        event['ResponseURL'],
        headers=headers,
        data=edata,
        method='PUT')
    req.get_method = lambda: 'PUT'
    try:
        urlopen(req)
    except Exception as e:
        print(e)

# ===============================================================================
#  Test Code for runs from the command line
# ===============================================================================
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Usage: python3 KafkaConnect.py --topic raw-events --bucket ci-360-test-dev-us-east-1 --region us-east-1 --endpoint http://kafka-kafka1.cidev.sas.us:8085/')

    parser.add_argument(
        '--parameter',
        help="The fully qualified name of the SSM parameter you want to look up",
        required=False,
        default='/dev-mkt-config/tier_global/mkt-kafka/baldur'
    )

    args = parser.parse_args()
    parameterName = args.parameter

    event = {
      'RequestType': 'Create',
      'ServiceToken': 'arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-WAFCreatorLambda-XRSHVD5NRA7I',
      'ResponseURL': 'http://localhost:8080/service',
      'StackId': 'arn:aws:cloudformation:us-east-1:952478859445:stack/razing-custom/afb9dbe0-8cd7-11e7-bd36-500c219ab02a',
      'RequestId': '7310f283-36ce-43b8-a88e-2f022103ba7c',
      'LogicalResourceId': 'SSMParameterInfo',
      'PhysicalResourceId': 'None',
      'ResourceType': 'AWS::CloudFormation::CustomResource',
      'ResourceProperties': {
        'ServiceToken': 'arn:aws:lambda:us-east-1:952478859445:function:razing-lambda-SSMParameterLambda-XRSHVD5NRA7I',
        'StackName': 'opdstage',
        'ParameterName': parameterName
      }
    }
    context = {}
    print(event)
    handler(event, context)
