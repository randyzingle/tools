/**
 * 
 */
package com.sas.mkt.kafka.clients.files;

import java.io.File;
import java.util.Arrays;
import java.util.Properties;

import org.apache.avro.Schema;
import org.apache.avro.file.DataFileWriter;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.specific.SpecificDatumWriter;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;

/**
 * @author razing
 *
 */
public class KafkaFileSink {
    
    private static Logger logger = LoggerFactory.getLogger(KafkaFileSink.class);


    Consumer<String, SpecificRecordBase> consumer;

    private ApplicationConfiguration appConfig = new ApplicationConfiguration();
    private static String topic;
    
    public static void main(String[] args) {
        
        KafkaFileSink tfd = new KafkaFileSink();

        topic = "dev-raw-events";

        System.out.println("Reading from: " + topic);
        String fileName = "src/main/resources/data/"+topic+".avro";
        int numberRecords = 50000;
        try {
            tfd.dump(fileName, numberRecords);
        } catch (Exception ex) {
            logger.error(ex.getMessage());
        }
    }

    /**
     * @param fileName
     * @param numberRecords
     */
    private void dump(String fileName, int numberRecords) throws Exception {
        long startTime = System.currentTimeMillis();
        KafkaConnectionUtils kcu = null;
        kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
     
        // Create the Kafka Consumer
        Properties props = kcu.getKafkaConsumerProperties();
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        String groupID = appConfig.getTierName() + "-" + appConfig.getComponentName() + System.currentTimeMillis();
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, true);
        props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, 1000);
        props.put("session.timeout.ms", "30000");
        KafkaConsumer<String, SpecificRecordBase> consumer = new KafkaConsumer<>(props);
        consumer.subscribe(Arrays.asList(topic));
        
        // Set up the File Dump
        File file = new File(fileName);
//        DatumWriter<TestEvent> datumWriter = new SpecificDatumWriter<>(TestEvent.class);
//        DataFileWriter<TestEvent> dataFileWriter = new DataFileWriter<>(datumWriter);
//        dataFileWriter.create(TestEvent.SCHEMA$, file);
        DatumWriter<SpecificRecordBase> datumWriter = null;
        DataFileWriter<SpecificRecordBase> dataFileWriter = null;
        Class clazz = null;
        
        long endTime = System.currentTimeMillis();
        System.out.println("Startup time: " + (endTime - startTime));
        startTime = System.currentTimeMillis();
        int cnt = 0;
        boolean done = false;
        while (!done) {     
            ConsumerRecords<String, SpecificRecordBase> records = consumer.poll(100);
            for (ConsumerRecord<String, SpecificRecordBase> record: records) {
            	if (cnt == 0) {
            		SpecificRecordBase base = record.value();
            		Schema schema = base.getSchema();
            		String name = schema.getFullName();
            		clazz = base.getClass();
            		System.out.println(clazz.getName());
            		datumWriter = new SpecificDatumWriter<>(clazz);
            		dataFileWriter = new DataFileWriter<>(datumWriter);
            		dataFileWriter.create(schema, file);
            	}
            	cnt++;
            	dataFileWriter.append(record.value());
                if (cnt%1000 == 0) {
                    System.out.printf(cnt + ": offset = %d, key = %s%n", record.offset(), record.key());
                }
                if (cnt >= numberRecords) {
                    done = true;
                    break;
                }
            }
        }
        endTime = System.currentTimeMillis();
        System.out.println("Runtime: " + (endTime - startTime) / 1000.0 + " secs");
        System.out.println("Messages per sec: " + numberRecords*1000.0 / (endTime - startTime));
        dataFileWriter.close();
        consumer.close();
        
    }

}
