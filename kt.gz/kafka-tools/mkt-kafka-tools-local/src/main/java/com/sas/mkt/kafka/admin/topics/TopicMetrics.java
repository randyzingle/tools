package com.sas.mkt.kafka.admin.topics;

import java.util.Date;
import java.util.Map;
import java.util.Properties;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndTimestamp;
import org.apache.kafka.common.TopicPartition;

import com.sas.mkt.kafka.admin.topics.admin.KafkaTopicAdministrator;
import com.sas.mkt.kafka.admin.topics.utils.TopicUtils;
import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;

public class TopicMetrics {

	private KafkaTopicAdministrator kta;
	private TopicUtils topicUtils;
	

	public static void main(String[] args) {
		TopicMetrics tm = new TopicMetrics();
		tm.topicUtils = new TopicUtils();
		try {
			tm.run();
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
	}
	
	private void run() throws Exception {

		
		String topic = "mymir-test-events";
		long start = ( 6 * 60 * 1000);
		long startTime = System.currentTimeMillis() - start;
		long end = ( 2 * 60 * 1000);
		long endTime = System.currentTimeMillis() - end;
		System.out.println("Searching for offset at time: " + new Date(startTime).toString());
		topicUtils.init();
		Map<TopicPartition, OffsetAndTimestamp> startOffsets = topicUtils.offsetsForTimestamp(topic, startTime, null, null);
		Map<TopicPartition, OffsetAndTimestamp> endOffsets = topicUtils.offsetsForTimestamp(topic, endTime, null, null);
		System.out.println("Start....");
		for (TopicPartition tp: startOffsets.keySet()) {
			OffsetAndTimestamp ot = startOffsets.get(tp);
			System.out.printf("   partition=%d, %s, offset=%d%n", tp.partition(), new Date(ot.timestamp()).toString(), ot.offset());
		}
		System.out.println("End....");
		for (TopicPartition tp: endOffsets.keySet()) {
			OffsetAndTimestamp ot = endOffsets.get(tp);
			System.out.printf("   partition=%d, %s, offset=%d%n", tp.partition(), new Date(ot.timestamp()).toString(), ot.offset());
		}
		
//		startTime = System.currentTimeMillis();
//		List<String> topicList = kta.getAllTopics();
//		endTime = System.currentTimeMillis();
//		System.out.printf("Took %d ms to retrieve %d topic names%n", (endTime-startTime), topicList.size());
//		
//		startTime = System.currentTimeMillis();
//		consumer.subscribe(topicList);
//		endTime = System.currentTimeMillis();
//		System.out.printf("Took %d ms to subscribe to %d topics%n", (endTime-startTime), topicList.size());
//		
//		startTime = System.currentTimeMillis();
//		Map<String, Long> topicMap = topicUtils.getNumberOfRecordsForAllTopics(consumer);
//		endTime = System.currentTimeMillis();
//		System.out.printf("Took %d ms to count records in %d topics%n", (endTime-startTime), topicList.size());
//		
//		List<CustomTopicData> dataList = new ArrayList<>();
//		Set<String> keySet = topicMap.keySet();
//		for (String key: keySet) {
//			if (topicMap.get(key) > 0) {
//				CustomTopicData ctd = new CustomTopicData(key, topicMap.get(key));
//				dataList.add(ctd);
//			}
//		}
//		Collections.sort(dataList, null);
//
//		System.out.printf("Found %d topics that contain messages%n", dataList.size());	
//		for (CustomTopicData topic: dataList) {
//			System.out.printf("%d: %s%n", topic.getNumberMessages(), topic.getTopicName());
//		}

	}

}
