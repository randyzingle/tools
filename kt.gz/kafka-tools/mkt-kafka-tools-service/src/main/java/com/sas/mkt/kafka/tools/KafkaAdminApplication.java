package com.sas.mkt.kafka.tools;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import com.ryantenney.metrics.spring.config.annotation.EnableMetrics;

@SpringBootApplication
@EnableMetrics
@ComponentScan({ "com.sas.mkt.kafka.*", "com.sas.mkt.config.*" })
public class KafkaAdminApplication {
	private static final Logger logger = LoggerFactory.getLogger(KafkaAdminApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(KafkaAdminApplication.class, args).registerShutdownHook();
	}
}
