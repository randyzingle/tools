package com.sas.mkt.config.core;

import java.io.Serializable;
import java.lang.reflect.Method;

public class PropertyDetails implements Comparable<PropertyDetails>, Serializable {

	private static final long serialVersionUID = 1L;
	private String name;
	private String value;
	private String id;
	private transient Class<?> type;
	private String componentNm;
	private String tierNm;
	private String propertySourceName;
	private transient Method getMethod;
	private transient Method setMethod;

	public PropertyDetails(PropertyDetails pd) {
		super();
		this.name = pd.getName();
		this.value = pd.getValue();
		this.id = pd.getId();
		this.type = pd.getType();
		this.componentNm = pd.getComponentNm();
		this.tierNm = pd.getTierNm();
		this.propertySourceName = pd.getPropertySourceName();
		this.getMethod = pd.getGetMethod();
		this.setMethod = pd.getSetMethod();
	}
	
	public PropertyDetails(String name, String value, Class<?> type, Method getMethod, Method setMethod) {
		this.name = name;
		this.value = value;
		this.type = type;
		this.getMethod = getMethod;
		this.setMethod = setMethod;
	}

	public PropertyDetails() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Class<?> getType() {
		return type;
	}

	public void setType(Class<?> type) {
		this.type = type;
	}

	public Method getGetMethod() {
		return getMethod;
	}

	public void setGetMethod(Method getMethod) {
		this.getMethod = getMethod;
	}

	public Method getSetMethod() {
		return setMethod;
	}

	public void setSetMethod(Method setMethod) {
		this.setMethod = setMethod;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getComponentNm() {
		return componentNm;
	}

	public void setComponentNm(String componentNm) {
		this.componentNm = componentNm;
	}

	public String getTierNm() {
		return tierNm;
	}

	public void setTierNm(String tierNm) {
		this.tierNm = tierNm;
	}

	public String getPropertySourceName() {
		return propertySourceName;
	}

	public void setPropertySourceName(String propertySourceName) {
		this.propertySourceName = propertySourceName;
	}

	@Override
	public int compareTo(PropertyDetails pd) {
		return this.name.compareTo(pd.getName());
	}
	
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((value == null) ? 0 : value.hashCode());
        return result;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PropertyDetails other = (PropertyDetails) obj;
        if (name == null) {
            if (other.getName() != null)
                return false;
        } else if (!name.equals(other.getName()))
            return false;
        if (value == null) {
            if (other.getValue() != null)
                return false;
        } else if (!value.equals(other.getValue()))
            return false;
        return true;
    }

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PropertyDetails [name=").append(name).append(", value=").append(value).append(", id=")
				.append(id).append(", componentNm=").append(componentNm).append(", tierNm=").append(tierNm)
				.append(", propertySourceName=").append(propertySourceName).append("]");
		return builder.toString();
	}


}
