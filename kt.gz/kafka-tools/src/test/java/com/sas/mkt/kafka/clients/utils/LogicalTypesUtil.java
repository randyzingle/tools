package com.sas.mkt.kafka.clients.utils;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.nio.ByteBuffer;
import java.util.List;

import org.apache.avro.Conversions.DecimalConversion;
import org.apache.avro.LogicalType;
import org.apache.avro.LogicalTypes;
import org.apache.avro.LogicalTypes.Decimal;
import org.apache.avro.Schema;
import org.apache.avro.Schema.Field;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


//The intention is for this to be a utility available from mkt-kafka-shared
//but at the moment the values are corrupted after serialization.
//Storing under test and disabling the test case until issues are resolved.
//tag
public class LogicalTypesUtil
{
	private static Logger logger = LoggerFactory.getLogger(LogicalTypesUtil.class);

	private static LogicalTypesUtil instance = null;
	public static LogicalTypesUtil getInstance()
	{

		if(null == instance)
		{
			synchronized(LogicalTypesUtil.class)
			{
				if(null == instance)
					instance = new LogicalTypesUtil();
			}
		}

		return instance;
	}

	/**
	 * Used for testing / mock override
	 * */
	public static void setInstance(LogicalTypesUtil instance)
	{
		LogicalTypesUtil.instance = instance;
	}

	/**
	 * Used for testing / mock override
	 * */
	public static void resetInstance()
	{
		LogicalTypesUtil.instance = null;
	}

	private Schema getTypeFromField(Field field)
	{
		List<Schema> types = field.schema().getTypes();

		Schema logicalTypeSchema = null;

		for(Schema s:types)
		{
			//got to be a better way..
			if(s.getType().getName().compareTo("null") == 0)
				continue;

			//should only be two since we are using null union
			logicalTypeSchema = s;
			break;
		}

		return logicalTypeSchema;
	}

	public ByteBuffer getByteBufferFromDecimal(String value, Field field)
	{
		BigDecimal bd = new BigDecimal(value, MathContext.DECIMAL64);
		DecimalConversion dc = new DecimalConversion();

		Schema logicalTypeSchema = getTypeFromField(field);

		if(null != logicalTypeSchema)
		{
			LogicalType lt = LogicalTypes.fromSchemaIgnoreInvalid(logicalTypeSchema);

			if(null != lt)
			{
				Decimal d = (Decimal)lt;

				//bd = bd.setScale(d.getScale(), d.getPrecision());
				bd = bd.setScale(d.getScale(), RoundingMode.HALF_EVEN);

				ByteBuffer bb = dc.toBytes(bd, logicalTypeSchema, d);

				return bb;
			}
		}

		return null;
	}

	public BigDecimal getDecimalFromByteBuffer(ByteBuffer byteBuffer, Field field)
	{
		if(null == byteBuffer)
			return null;

//		try
//		{
//			Double d = byteBuffer.getDouble();
//			return BigDecimal.valueOf(d);
//		}
//		catch(Exception e)
//		{
//			System.out.println("Error getting double -" + e.getMessage());
//		}

		DecimalConversion dc = new DecimalConversion();

		Schema logicalTypeSchema = getTypeFromField(field);

		if(null != logicalTypeSchema)
		{
			LogicalType lt = LogicalTypes.fromSchemaIgnoreInvalid(logicalTypeSchema);

			try
			{
				BigDecimal bd = dc.fromBytes(byteBuffer, logicalTypeSchema, lt);
				return bd;
			}
			catch(Exception ex)
			{
				logger.error(ex.getMessage());
			}


		}

		return null;
	}

}
