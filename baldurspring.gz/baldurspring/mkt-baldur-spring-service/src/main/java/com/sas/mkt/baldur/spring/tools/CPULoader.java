package com.sas.mkt.baldur.spring.tools;

import java.util.Arrays;

public class CPULoader implements Runnable {
	
	static final double MAX_RUN_SECS = 60 * 5.0; // five minute run
	public boolean kill = false;

	public static void main(String[] args) {
		CPULoader cl = new CPULoader();
		cl.run(); 
	}

	@Override
	public void run() {
		System.out.println("Loading cpu...");
		long startTime = System.currentTimeMillis();
		double runTime = 0.0;
		double arr[] = new double[10000];
		Arrays.fill(arr, 0.0);
		for (int i = 0; i < Integer.MAX_VALUE; i++) {
			while (!kill) {
				double x = Math.random();
				double y = Math.atan(x);
				String s = "";
				for (int j = 0; j < arr.length; j++) {
					double val = arr[j];
					if (val < y) arr[j] = val;
					s = s + String.valueOf(arr[j]);
					if (s.contains("randyzingle")) System.out.println("ya not going to happen!");
				}
				if (i % 1000 == 0) {
					long endTime = System.currentTimeMillis();
					runTime = (endTime - startTime) / 1000.0;
					if (runTime > MAX_RUN_SECS) kill = true;
				}
			}
		}
		System.out.println("runtime: " + runTime + " secs");
		System.out.println("MAX_RUN_SECS: " + MAX_RUN_SECS + " secs");
	}
	
	public void killNow() {
		System.out.println("Killing load generating thread");
		kill = true;
	}

}
