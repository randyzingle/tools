# General Use

You will have to rename the packages from com.sas.mkt.template.docker to com.sas.mkt._yourService_

Make sure you specify a 'method=' on each @RequestMapping, otherwise SpringFox generates documentation endpoints for **all** possible HTTP methods.

## /commons endpoints

There are support for 4 endpoints you need to supply in your service in this template. The controller for them is AdminMetricsController. You may not need any changes to the controller, but to see how the endpoints work see the [saspedia](http://sww.sas.com/saspedia/MicroService_CI360#Service_Ops_Checks "read this!") article.

Two things you will need to do are:

1. Replace the classes GeneralHealthCHeck and BeachBoysHealthCheck. Add at least one class that extends com.codahale.metrics.health.HealthCheck to contribute to the health check registry.
2. Consider how often diagnostics run in a background thread. This is set in ScheduledTasks.

## API name

Your API name needs to be specified in the web application context (server.servlet.context-path) as some aspects of SAS commons.rest rely on it being there (true for 9.4 not sure for Viya). See [REST API standard for API names](http://sww.sas.com/saspedia/REST_API_standards#API_names) for specifics on correct API names.

In this example you can find it set to /templateService in the following places:
1. mkt-template-microservice-service/src/main/resources/application.properties: sets the web application context path for spring to pick up - **server.servlet.context-path=/templateService**
2. mkt-template-microservice-cloudformation/src/main/cloudformation/cloudformation.json#L202: Target for ELB healthcheck needs to be set to correct url, otherwise deployed instance will fail - e.g. **"Target": "HTTP:8080/templateService/commons/ping"**

This results in all the endpoints correctly including the API name without it being hardcoded into the controller e.g. "http://localhost:8080/templateService/hello".

## Using the Shared Configuration Server Client

### Update Your Main Class
In your main-method class that starts Spring Boot, uncomment the shared client's annotations changing this:
```
@SpringBootApplication
@EnableMetrics
@ComponentScan({ "com.sas.mkt.template.*", "com.sas.mkt.config.*" })
//@EnableConfigClient(ourComponentNm = "mkt-template-docker")
//@EnableTenantClient
public class TemplateDockerApplication {
	public static void main(String[] args) throws Throwable {
		SpringApplication application = new SpringApplication(TemplateDockerApplication.class);
		application.addListeners(new PreContextLoadedConfiguration());
		application.run(args);
	}
}
```
To this:
```
@SpringBootApplication
@EnableMetrics
@ComponentScan({ "com.sas.mkt.template.*", "com.sas.mkt.config.*" })
@EnableConfigClient(ourComponentNm = "mkt-template-docker")
@EnableTenantClient
public class TemplateDockerApplication {
	public static void main(String[] args) throws Throwable {
		SpringApplication application = new SpringApplication(TemplateDockerApplication.class);
		application.addListeners(new PreContextLoadedConfiguration());
		application.run(args);
	}
}
```
### Update your service build.gradle
In your <projectname>-service/build.gradle file change this:
```
// CI360 @@@SHARED@@@ - Common ConfigService Client
// see https://gitlab.sas.com/CustomerIntelligence/Infra/mkt-shared-infra-client/tree/master
//compile ("com.sas.mkt.shared:mkt-shared-infra-client:1.${buildSprint}.+")
```
To this:
```
// CI360 @@@SHARED@@@ - Common ConfigService Client
// see https://gitlab.sas.com/CustomerIntelligence/Infra/mkt-shared-infra-client/tree/master
compile ("com.sas.mkt.shared:mkt-shared-infra-client:1.${buildSprint}.+")
```
