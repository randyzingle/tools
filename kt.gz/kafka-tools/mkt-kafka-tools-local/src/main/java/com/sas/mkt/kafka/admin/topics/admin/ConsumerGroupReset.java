package com.sas.mkt.kafka.admin.topics.admin;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.consumer.ConsumerConfig;

import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;

public class ConsumerGroupReset {
	
	private static String fileBase = "src/main/resources/topics/";

	public static void main(String[] args) {
		String first = "/Users/razing/work/tools/confluent/bin/kafka-consumer-groups --group ";
		String last = " --bootstrap-server kafka-kafka1.cidev.sas.us:9092 --reset-offsets  --to-earliest --all-topics --execute";
		ArrayList<String> groupList = new ArrayList<>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(fileBase+"cgroups.sh"));
			String ss = "";
			while ((ss = br.readLine()) != null) {
				groupList.add(ss);
			}
		} catch (Exception ex) {ex.printStackTrace();}
		File f = new File(fileBase + "uberupdate.sh");
		try (FileWriter fw = new FileWriter(f)) {
			for (String s : groupList) {
				String full = first + s + last;
				fw.write(full + System.lineSeparator());
			}
			fw.flush();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		
		
		
		
		
//		ApplicationConfiguration appConfig = new ApplicationConfiguration();
//		appConfig.setConfigServiceUrl("http://configservice-dev.cidev.sas.us:8080/");
//		ConsumerGroupReset cgr = new ConsumerGroupReset(appConfig);
//		cgr.init();
	}
	
	private ApplicationConfiguration appConfig;
	
	private Map<String, ConsumerGroupDTO> masterMap = new HashMap<>();
	private AdminClient admin;
	
	public ConsumerGroupReset(ApplicationConfiguration appConfig) {
//		this.appConfig = appConfig;
//		this.init();
	}
	
	public void init() {
		try {
    		KafkaConnectionUtils kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
    		HashMap<String, String> kafkaProperties = kcu.getKafkaProperties();
    		Properties props = new Properties();
    		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.get(KafkaConnectionUtils.SAS_MKT_KAFKA_CLUSTER));
    		admin = AdminClient.create(props);
    		createMasterList();
    	} catch (Exception ex) {

    	}
	}
	
	private void createMasterList() throws Exception {
		
		Set<String> topics = admin.listTopics().names().get();
		System.out.println(topics);
		
//		masterMap.clear();
//		
//		long startTime = System.currentTimeMillis();
//		Map<String, Set<Integer>> topicMap = new HashMap<>();
//
//		Collection<ConsumerGroupListing> cglist = admin.listConsumerGroups().all().get();
//		List<String> groupIds = cglist.stream()
//				.map(group -> group.groupId())
//				.collect(Collectors.toList());
//		
//		for (String gid: groupIds) {
//			System.out.println(gid);
//		}
	}

}
