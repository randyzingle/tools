package com.sas.mkt.kubectl.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.Bucket;

@RestController
@RequestMapping("/")
public class ExternalStuffController {
	
    @RequestMapping(value = "/aws/bucketlist", method = RequestMethod.GET)
    public List<String> getS3BucketList() {
        List<String> buckets = null;
        try {
            buckets = listBuckets();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return buckets;
    }
    
	@RequestMapping(value = "/getenv", method = RequestMethod.GET)
	public List<String> getEnv() {
		List<String> result = new ArrayList<>();
		Map<String, String> envmap = System.getenv();
		for (String key: envmap.keySet()) {
			result.add(key + "=" + envmap.get(key));
		}
		return result;
	}
    
    @RequestMapping(value = "/version", method = RequestMethod.GET)
    public String getVersion() {
        return "v13";
    }
    
    private List<String>  listBuckets() throws Exception {
        AmazonS3 s3 = getS3Client();
        List<Bucket> buckets = s3.listBuckets();
        List<String> bname = new ArrayList<>();
        System.out.println("Your Amazon S3 buckets are:");
        for (Bucket b : buckets) {
            bname.add(b.getName());
            System.out.println("* " + b.getName());
        }
        return bname;
    }

    private AmazonS3 getS3Client() {
        Region region = Regions.getCurrentRegion();
        AmazonS3 s3 = null;
        if (region == null) {
            System.out.println("setting region to us-east-1");
            s3 = AmazonS3ClientBuilder.standard().withRegion(Regions.US_EAST_1.getName()).build();
        } else {
        	System.out.println("Found S3 Region: " + region.getName());
            s3 = AmazonS3ClientBuilder.standard().build();
        }
        return s3;
    }

}
