package com.sas.mkt.kafka.tools.topics.data;

public class ClusterInfoDTO {

	public String clusterId;
	public String bootStrapServers;
//	public String zooKeeperUrl;
	
	@Override
	public String toString() {
		return "ClusterInfoDTO [clusterId=" + clusterId + ", bootStrapServers=" + bootStrapServers + "]";
	}
	
}
