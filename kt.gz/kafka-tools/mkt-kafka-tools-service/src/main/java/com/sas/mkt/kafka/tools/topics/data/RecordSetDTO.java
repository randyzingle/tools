package com.sas.mkt.kafka.tools.topics.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class RecordSetDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	public String id = UUID.randomUUID().toString();
	
	public String topic;
	public long requestedStartTime = -1;
	public long requestedEndTime = -1;
	public long requestedStartOffset = -1;
	public long requestedEndOffset = -1;
	public int requestedPartition = -1;
	public String keyFilter;
	public Map<String, String> valueFilters;
	
	public long firstTimestamp;
	public long lastTimestamp;
	
	public List<RecordDTO> recordList = new ArrayList<>();
	public List<RecordDTO> badRecordList;
	
	public int maxRecords;
	public TopicInfoDTO.ValueType valueType;
	@Override
	public String toString() {
		return "RecordSetDTO [id=" + id + ", topic=" + topic + ", requestedStartTime=" + requestedStartTime
				+ ", requestedEndTime=" + requestedEndTime + ", requestedStartOffset=" + requestedStartOffset
				+ ", requestedEndOffset=" + requestedEndOffset + ", requestedPartition=" + requestedPartition
				+ ", keyFilter=" + keyFilter + ", valueFilters=" + valueFilters + ", firstTimestamp=" + firstTimestamp
				+ ", lastTimestamp=" + lastTimestamp + ", recordList=" + recordList + ", badRecordList=" + badRecordList
				+ ", maxRecords=" + maxRecords + ", valueType=" + valueType + "]";
	}

}
