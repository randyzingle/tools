package com.sas.mkt.config.core.controllers;

import java.util.TreeMap;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mock.env.MockEnvironment;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.appspecific.GlobalConfiguration;
import com.sas.mkt.config.core.ConfigUtils;
import com.sas.mkt.config.core.PropertyDetails;
import com.sas.mkt.config.core.PropertyMap;
import com.sas.mkt.config.core.configserver.ConfigServerClient;
import com.sas.mkt.config.core.startup.ConfigServiceHelper;

public class ConfigurationControllerTest {
	
	private static ConfigurationController configController;
	private static ConfigServerClient client;
	private static ConfigUtils configUtils;
	private static ApplicationConfiguration appConfig;
	private static GlobalConfiguration globalConfig;
	private static ConfigServiceHelper configServiceHelper;
	private static PropertyMap propertyMap;
	private static MockEnvironment env;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		appConfig = new ApplicationConfiguration();
		globalConfig = new GlobalConfiguration();
		env = new MockEnvironment();
		propertyMap = new PropertyMap(appConfig, globalConfig, env);
		
		TreeMap<String, PropertyDetails> applicationMap = new TreeMap<>();
		propertyMap.propertyMap.put(PropertyMap.APPLICATION, applicationMap);
		TreeMap<String, PropertyDetails> globalMap = new TreeMap<>();
		propertyMap.propertyMap.put(PropertyMap.GLOBAL, globalMap);
		client = new ConfigServerClient(appConfig);
		configUtils = new ConfigUtils(appConfig, globalConfig, propertyMap, client, env);
		configServiceHelper = new ConfigServiceHelper(configUtils, appConfig, globalConfig);
		configController = new ConfigurationController(appConfig, client, configUtils, configServiceHelper, propertyMap);
	}

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testAppconf() {
		configController.appconf();
	}

	@Test
	public void testProps() {
		configController.props();
	}

	@Test
	public void testGetLogLevels() {
		configController.getLogLevels();
	}

	@Test(expected = IllegalArgumentException.class)
	public void testEdit() {
		ConfigurationController.PropTuple data = new ConfigurationController.PropTuple("baldur", "baldur", "baldur", "baldur", "baldur", "baldur", "baldur");
		configController.edit(data);
	}

	@Test(expected = IllegalArgumentException.class)
	public void testDelete() {
		ConfigurationController.PropTuple data = new ConfigurationController.PropTuple("baldur", "baldur", "baldur", "baldur", "baldur", "baldur", "baldur");
		configController.delete(data);
	}

	@Test
	public void testSpewLogLevel() {
		Logger logger = LoggerFactory.getLogger(ConfigurationController.class);
		configController.spewLogLevel(logger);
	}

	@Test
	public void testGetLoggerInfo() {
		configController.getLoggerInfo();
	}

	@Test
	public void testGetPropertySources() {
		configController.getPropertySources();
	}

	@Test
	public void testGetSubDisplayConfig() {
		TreeMap<String, PropertyDetails> applicationMap = new TreeMap<>();
		configController.getSubDisplayConfig("Application-Specific Configuration", applicationMap);
	}

	@Test
	public void testGetTypeString() {
		PropertyDetails pds = new PropertyDetails();
		pds.setType(String.class);
		configController.getTypeString(pds);
		pds.setType(Boolean.class);
		configController.getTypeString(pds);
		pds.setType(Byte.class);
		configController.getTypeString(pds);
		pds.setType(Integer.class);
		configController.getTypeString(pds);
		pds.setType(Short.class);
		configController.getTypeString(pds);
		pds.setType(Double.class);
		configController.getTypeString(pds);
		pds.setType(Long.class);
		configController.getTypeString(pds);
		pds.setType(Float.class);
		configController.getTypeString(pds);
		configController.toString();
	}

}
