package com.sas.mkt.config.appspecific;

import static org.junit.Assert.*;

import org.junit.Test;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;

public class ApplicationConfigurationTest {
	
	ApplicationConfiguration appConfig = new ApplicationConfiguration();
	private static final String blarg = "blarg";

	@Test
	public void testGetConfigStackName() {
		appConfig.configStackName = blarg;
		assertTrue(appConfig.configStackName.equals(blarg));
	}




}
