package com.sas.mkt.template.docker.utils;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import org.hibernate.service.spi.ServiceException;
import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertySource;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.AWSLambdaClientBuilder;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * An ApplicationEnvironmentPreparedEvent is sent when the Environment to be
 * used in the context is known, but before the context is created. This means
 * application.properties, application-x.properties, environment variables,
 * system properties are all loaded, but the Spring Beans haven't been
 * constructed yet.
 * 
 * This class does two main things:
 * 
 * 1) takes a base set of configuration properties and creates system properties
 * with the names expected by certain components.
 * 
 * 2) if certain postgres environment variables are present it assumes it is
 * running in AWS, calls the password decoder, and sets up the proper database
 * url for the component.
 * 
 * @author razing
 * @since 02/2020
 *
 */

public class PreContextLoadedConfiguration implements ApplicationListener<ApplicationEvent> {

	private Logger logger = LoggerFactory.getLogger(PreContextLoadedConfiguration.class);

	// property source names and prefixes
	private static final String PSN_APPLICATION_CONFIG = "applicationConfig: [classpath:/application.properties]";
	private static final String PSN_SYSTEM_ENVIRONMENT = "systemEnvironment";
	private static final String PSN_SYSTEM_PROPERTIES = "systemProperties";

	// canonical names for our application's core configuration properties
	private static final String PROJECT_NAME = "ProjectName";
	private static final String CONFIG_STACK_NAME = "ConfigStackName";
	private static final String CONFIG_SERVICE_URL = "ConfigServiceUrl";
	private static final String TIER_NAME = "TierName";
	private static final String SERVICE_URL = "ServiceUrl";

	// canonical names for our RDS database connection info
	private static final String RDS_ENCODED_PASSWORD = "RDSEncodedPassword";
	private static final String JDBC_URL = "JdbcURL";
	private static final String SECURE_PARAMS = "SecureParams";
	
	// aws region, us-east-1 if running locally (unable to determine with aws sdk)
	private static String AWS_REGION = "us-east-1";

	private Map<String, String> configMap = new HashMap<>();

	@Override
	public void onApplicationEvent(ApplicationEvent event) {

		if (event instanceof ApplicationEnvironmentPreparedEvent) {
			AWS_REGION = getRegion();
		
			ConfigurableEnvironment environment = ((ApplicationEnvironmentPreparedEvent) event).getEnvironment();
			MutablePropertySources propertySources = environment.getPropertySources();

			basePropertySetup(environment, propertySources);
			configureDatabase(environment);

		}

	}

	private void basePropertySetup(ConfigurableEnvironment env, MutablePropertySources sources) {

		String name = "";

		// 1. application.properties
		PropertySource<?> ps = sources.get(PSN_APPLICATION_CONFIG);
		name = "application.tierName";
		if (ps.containsProperty(name)) {
			logger.debug(name + " = " + ps.getProperty(name));
			configMap.put(TIER_NAME, ps.getProperty(name).toString());
		}
		name = "application.componentName";
		if (ps.containsProperty(name)) {
			logger.debug(name + " = " + ps.getProperty(name));
			configMap.put(PROJECT_NAME, ps.getProperty(name).toString());
		}
		name = "application.configStackName";
		if (ps.containsProperty(name)) {
			logger.debug(name + " = " + ps.getProperty(name));
			configMap.put(CONFIG_STACK_NAME, ps.getProperty(name).toString());
		}
		name = "application.configServiceUrl";
		if (ps.containsProperty(name)) {
			logger.debug(name + " = " + ps.getProperty(name));
			configMap.put(CONFIG_SERVICE_URL, ps.getProperty(name).toString());
		}

		// 2. environment variables (override application.properties if present)
		ps = sources.get(PSN_SYSTEM_ENVIRONMENT);
		name = "TierName";
		if (ps.containsProperty(name)) {
			logger.debug("env." + name + " = " + ps.getProperty(name));
			configMap.put(TIER_NAME, ps.getProperty(name).toString());
		}
		name = "ProjectName";
		if (ps.containsProperty(name)) {
			logger.debug("env." + name + " = " + ps.getProperty(name));
			configMap.put(PROJECT_NAME, ps.getProperty(name).toString());
		}
		name = "ConfigStackName";
		if (ps.containsProperty(name)) {
			logger.debug("env." + name + " = " + ps.getProperty(name));
			configMap.put(CONFIG_STACK_NAME, ps.getProperty(name).toString());
		}
		name = "ConfigServiceUrl";
		if (ps.containsProperty(name)) {
			logger.debug("env." + name + " = " + ps.getProperty(name));
			configMap.put(CONFIG_SERVICE_URL, ps.getProperty(name).toString());
		}
		name = "ServiceUrl";
		if (ps.containsProperty(name)) {
			logger.debug("env." + name + " = " + ps.getProperty(name));
			configMap.put(SERVICE_URL, ps.getProperty(name).toString());
		}

		// 3. system properties
		ps = sources.get(PSN_SYSTEM_PROPERTIES);
		name = "TierName";
		if (ps.containsProperty(name)) {
			logger.debug("sys." + name + " = " + ps.getProperty(name));
			configMap.put(TIER_NAME, ps.getProperty(name).toString());
		}
		name = "ProjectName";
		if (ps.containsProperty(name)) {
			logger.debug("sys." + name + " = " + ps.getProperty(name));
			configMap.put(PROJECT_NAME, ps.getProperty(name).toString());
		}
		name = "ConfigStackName";
		if (ps.containsProperty(name)) {
			logger.debug("sys." + name + " = " + ps.getProperty(name));
			configMap.put(CONFIG_STACK_NAME, ps.getProperty(name).toString());
		}
		name = "ConfigServiceUrl";
		if (ps.containsProperty(name)) {
			logger.debug("sys." + name + " = " + ps.getProperty(name));
			configMap.put(CONFIG_SERVICE_URL, ps.getProperty(name).toString());
		}

		generatePropsForConfigServerSharedClient(configMap);
		generatePropsForEventDatahubClient(configMap);
	}

	private void generatePropsForEventDatahubClient(Map<String, String> configMap) {

		if (configMap.containsKey(CONFIG_STACK_NAME)) {
			System.setProperty("APPLICATION_CONFIG_STACK_NAME", configMap.get(CONFIG_STACK_NAME));
		}
		if (configMap.containsKey(CONFIG_SERVICE_URL)) {
			System.setProperty("APPLICATION_CONFIG_SERVICE_URL", configMap.get(CONFIG_SERVICE_URL));
		}
		if (configMap.containsKey(TIER_NAME)) {
			System.setProperty("APPLICATION_TIER_NAME", configMap.get(TIER_NAME));
		}
		if (configMap.containsKey(SERVICE_URL)) {
			System.setProperty("APPLICATION_SERVICE_DISCOVERY_URL", configMap.get(SERVICE_URL));
		}

	}

	private void generatePropsForConfigServerSharedClient(Map<String, String> configMap) {

		if (configMap.containsKey(CONFIG_STACK_NAME)) {
			System.setProperty("our.config.stack.name", configMap.get(CONFIG_STACK_NAME));
		}
		if (configMap.containsKey(CONFIG_SERVICE_URL)) {
			System.setProperty("our.config.service.url", configMap.get(CONFIG_SERVICE_URL));
		}
		if (configMap.containsKey(TIER_NAME)) {
			System.setProperty("our.stack.prefix", configMap.get(TIER_NAME));
		}
		if (configMap.containsKey(SERVICE_URL)) {
			System.setProperty("our.service.url", configMap.get(SERVICE_URL));
		}
		if (configMap.containsKey(TIER_NAME) && configMap.containsKey(PROJECT_NAME)) {
			System.setProperty("our.stack.name", configMap.get(TIER_NAME) + "-" + configMap.get(PROJECT_NAME));
			System.setProperty("APPLICATION_NAME", configMap.get(TIER_NAME) + "-" + configMap.get(PROJECT_NAME));
		}
		// This is for ECS only (but won't break other environments
		System.setProperty("ECS_ENABLE_CONTAINER_METADATA", "true");

	}

	/**
	 * If we're connecting to one of our AWS RDS instances we'll pass in the
	 * following three environment variables to the application (all three provided
	 * as stack outputs of the RDS cloudformation stack):
	 * 
	 * RDSEncodedPassword -> SAS encoded password, needs to be run through the
	 * PasswordDecoder lambda to be decrypted
	 * 
	 * JdbcURL -> URL provided for the RDS instance, including management database
	 * at the end of the URL
	 * 
	 * SecureParams -> extra parameters that specify SSL connections are required
	 * 
	 * @param environment
	 */
	private void configureDatabase(ConfigurableEnvironment environment) {

		String password = null;
		String fullUrl = null;

		String encodedPassword = null;
		String jdbcUrl = null;
		String secureParams = null;

		// In AWS the values will be injected as environment variables
		encodedPassword = environment.getProperty(RDS_ENCODED_PASSWORD);
		jdbcUrl = environment.getProperty(JDBC_URL);
		secureParams = environment.getProperty(SECURE_PARAMS);

		// If we don't have the encodedPassword and jdbcUrl then there's nothing to do.
		// We also can't do anything without the projectName & tierName
		// as these are used to construct the database name and user name.
		if (encodedPassword == null || encodedPassword.isEmpty() || jdbcUrl == null || jdbcUrl.isEmpty()
				|| configMap == null || !configMap.containsKey(PROJECT_NAME) || !configMap.containsKey(TIER_NAME)) {
			// do nothing
		} else {
			// decrypt the password and construct the proper database url
			password = decryptPassword(encodedPassword);
			fullUrl = constructRdsUrl(jdbcUrl, secureParams);
			// setup the Spring datasource parameters
			System.setProperty("spring.datasource.url", fullUrl);
			System.setProperty("spring.datasource.username", configMap.get(PROJECT_NAME));
			System.setProperty("spring.datasource.password", password);
		}

	}

	private String constructRdsUrl(String jdbcUrl, String secureParams) {
		String fullUrl = "";
		String[] parts = jdbcUrl.split("/");
		if (parts.length == 4 && parts[3] != null && !parts[3].isEmpty()) {
			String admindb = "/" + parts[3];
			String databaseName = "/" + configMap.get(TIER_NAME) + "-" + configMap.get(PROJECT_NAME);
			fullUrl = jdbcUrl.replace(admindb, databaseName) + ((secureParams == null) ? "" : secureParams);
		}
		return fullUrl;
	}

	private String decryptPassword(String encodedPassword) {
		String password = "";
		String json = "{ \"password\": \"" + encodedPassword + "\" }";
		InvokeRequest invokeRequest = new InvokeRequest().withFunctionName("PasswordDecoder").withPayload(json);
		InvokeResult invokeResult = null;
		try {
			AWSLambda lambda = AWSLambdaClientBuilder.standard().withRegion(AWS_REGION).build();
			invokeResult = lambda.invoke(invokeRequest);
			String result = new String(invokeResult.getPayload().array(), StandardCharsets.UTF_8);
			ObjectMapper mapper = new ObjectMapper();
			JsonNode node = mapper.readTree(result);
			password = node.get("value").asText();
		} catch (Exception ex) {
			logger.error(ex.toString());
		}
		return password;
	}

	private String getRegion() {
		String name = Regions.US_EAST_1.getName();
		Region region = Regions.getCurrentRegion();
		if (region != null)
			name = region.getName();
		return name;
	}

}