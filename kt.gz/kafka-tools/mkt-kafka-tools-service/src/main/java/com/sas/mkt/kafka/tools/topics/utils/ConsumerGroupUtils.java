package com.sas.mkt.kafka.tools.topics.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.PreDestroy;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.ConsumerGroupDescription;
import org.apache.kafka.clients.admin.ConsumerGroupListing;
import org.apache.kafka.clients.admin.MemberAssignment;
import org.apache.kafka.clients.admin.MemberDescription;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.TopicPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.sas.mkt.config.appspecific.ApplicationConfiguration;
import com.sas.mkt.config.core.BaseUtils;
import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.tools.topics.data.ConsumerDTO;
import com.sas.mkt.kafka.tools.topics.data.ConsumerGroupDTO;

@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
@Component
public class ConsumerGroupUtils {
	
	private static final Logger logger = LoggerFactory.getLogger(ConsumerGroupUtils.class);
	// refresh list of topic-consumer groups if it's older than an hour - it takes a little over a minute to generate
	private static final long updateInfoFrequencyMs = 1000 * 60 * 60; 
	// don't let users force cache refresh more often than once every 5 mins
	private static final long minRefreshFrequencyMs = 1000 * 60 * 5; 
	
	private AdminClient adminClient;
	private ApplicationConfiguration appConfig;
	
	private long lastUpdate = 0L;
	
	private Map<String, ConsumerGroupDTO> masterMap = new HashMap<>();
	private AdminClient admin;
	
	@Autowired
	public ConsumerGroupUtils(ApplicationConfiguration appConfig) {
		BaseUtils.bigPrint("loading bean ConsumerGroupUtils");
		this.appConfig = appConfig;
		this.init();
	}
	
	public void init() {
		BaseUtils.bigPrint("initializing ConsumerGroupUtils");
		BaseUtils.bigDebug("initializing ConsumerGroupUtils", logger);
		try {
			logger.debug("attempting to create the AdminClient...");
    		KafkaConnectionUtils kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
    		HashMap<String, String> kafkaProperties = kcu.getKafkaProperties();
    		Properties props = new Properties();
    		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.get(KafkaConnectionUtils.SAS_MKT_KAFKA_CLUSTER));
    		admin = AdminClient.create(props);
    		createMasterList();
    	} catch (Exception ex) {
    		logger.error("failed to create the AdminClient...{}", ex.getMessage());
    	}
	}
	
	public List<ConsumerGroupDTO> getConsumerGroupListForTopic(String topic) {
		List<ConsumerGroupDTO> groupList = new ArrayList<>();
		for (String groupId: masterMap.keySet()) {
			ConsumerGroupDTO cg = masterMap.get(groupId);
			if (cg.readsTopic(topic)) groupList.add(cg);
		}
		return groupList;
	}
	
	public synchronized void forceRefresh() {
		System.out.println("refreshing list of consumer groups and consumers...");
		try {
			createMasterList();
		} catch (Exception e) {
			logger.warn(e.getMessage());
		}
	}
	
	private void createMasterList() throws Exception {
		masterMap.clear();
		
		long startTime = System.currentTimeMillis();
		Map<String, Set<Integer>> topicMap = new HashMap<>();

		Collection<ConsumerGroupListing> cglist = admin.listConsumerGroups().all().get();
		List<String> groupIds = cglist.stream()
				.map(group -> group.groupId())
				.collect(Collectors.toList());
		Map<String, ConsumerGroupDescription> cgmap = admin.describeConsumerGroups(groupIds).all().get();
		for (String groupId: cgmap.keySet()) {
			ConsumerGroupDescription cgd = cgmap.get(groupId);
			String state = cgd.state().toString();
			String partitionAssignor = cgd.partitionAssignor();
			Collection<MemberDescription> members = cgd.members();
			List<ConsumerDTO> consumerList = new ArrayList<>();
			for (MemberDescription member: members) { // This is a consumer
				String clientId = member.clientId();
				String consumerId = member.consumerId();
				String host = member.host().replaceAll("/", "");
				MemberAssignment assignment = member.assignment();
				topicMap.clear();
				for (TopicPartition tp: assignment.topicPartitions()) {
					String topic = tp.topic();
					int partition = tp.partition();
					if (topicMap.containsKey(topic)) {
						topicMap.get(topic).add(partition);
					} else {
						Set<Integer> pt = new HashSet<>();
						pt.add(partition);
						topicMap.put(topic, pt);
					}
				}
				for (String topic: topicMap.keySet()) {
					ConsumerDTO consumer = new ConsumerDTO(clientId, consumerId, host, topic, topicMap.get(topic).toString());
					consumerList.add(consumer);
				}
			}
			ConsumerGroupDTO consumerGroup = new ConsumerGroupDTO(groupId, state, partitionAssignor, consumerList);
			masterMap.put(groupId, consumerGroup);
		}

		System.out.printf("found %d consumer groups%n", cgmap.size());
		long endTime = System.currentTimeMillis();
		System.out.println("Runtime: " + (endTime - startTime));

	}
	
	@PreDestroy
	public void destroy() {
		System.out.println("Shutting down ConsumerGroupUtils...");
		logger.debug("closing the AdminClient...");
		adminClient.close();
	}
	
//    public Collection<Node> findAllBrokers() {
//    	Collection<Node> nodeList = JavaConversions.asJavaCollection(adminClient.findAllBrokers());
//    	for (Node node: nodeList) {
//    		System.out.println(node);
//    	}
//    	return nodeList;
//    }
    
//    public List<ConsumerGroupDTO> getConsumerGroupListForTopic(String topic) {
//    	long timeSinceLastUpdate = System.currentTimeMillis() - lastUpdate;
//    	if (topicConsumerGroupMap == null || timeSinceLastUpdate  > updateInfoFrequencyMs) {
//    		System.out.println("updating map...");
//    		topicConsumerGroupMap = getConsumerGroupsPerTopic();
//    	}
//    	return topicConsumerGroupMap.get(topic);
//    }
//    
//    private List<String> getAssignmentList(Collection<TopicPartition> tplist) {
//    	List<String> assignmentList = new ArrayList<>(tplist.size());
//    	for(TopicPartition tp: tplist) {
//    		String s = Integer.toString(tp.partition());
//    		assignmentList.add(s);
//    	}
//    	return assignmentList;
//    }
//    
//    public synchronized Map<String, List<ConsumerGroupDTO>> getConsumerGroupsPerTopic() {
//    	if (!adminClient.running()) init();
//    	topicConsumerGroupMap = new HashMap<>();
//    	Collection<GroupOverview> groupList = listAllConsumerGroups();
//    	for (GroupOverview group: groupList) {
//    		AdminClient.ConsumerGroupSummary summary = adminClient.describeConsumerGroup(group.groupId(), 0);
//    		Collection<AdminClient.ConsumerSummary> consumers = JavaConversions.asJavaCollection(summary.consumers().get());
//    		List<ConsumerDTO> consumerList = new ArrayList<>(consumers.size());
//    		ConsumerGroupDTO cgi = new ConsumerGroupDTO();
//    		for (AdminClient.ConsumerSummary cs: consumers) {
//    			ConsumerDTO consumer = new ConsumerDTO();
//    			consumer.assignment = JavaConversions.asJavaCollection(cs.assignment());
//    			consumer.partitions = getAssignmentList(consumer.assignment);
//    			consumer.clientId = cs.clientId();
//    			consumer.consumerId = cs.consumerId();
//    			consumer.host = cs.host().replaceAll("/", "");
//    			consumerList.add(consumer);
//    			// loop through topic partitions to determine topic subscription
//    			for (TopicPartition tp: consumer.assignment) {
//    				String topic = tp.topic();
//    				if (topicConsumerGroupMap.containsKey(topic)) {
//    					List<ConsumerGroupDTO> cglist = topicConsumerGroupMap.get(topic);
//    					if (!cglist.contains(cgi)) {
//    						cglist.add(cgi);
//    					}
//    				} else {
//    					List<ConsumerGroupDTO> cglist = new ArrayList<>();
//    					cglist.add(cgi);
//    					topicConsumerGroupMap.put(topic, cglist);
//    				}
//    			}
//    		}   		
//    		cgi.groupId = group.groupId();
//    		cgi.protocolType = group.protocolType();
//    		cgi.assignmentStrategy = summary.assignmentStrategy();
//    		cgi.coordinator = summary.coordinator().toString();
//    		cgi.state = summary.state();
//    		cgi.consumers = consumerList;
//    	}
//    	lastUpdate = System.currentTimeMillis();
//    	return topicConsumerGroupMap;
//    }
//	
//    /**
//     * top level consumer group data: GroupOverview. Contains the groupId (name) and protocolType (typically = consumer)
//     * @return Collection<GroupOverview>
//     */
//    public Collection<GroupOverview> listAllConsumerGroups() {
//    	if (!adminClient.running()) init();
//    	Collection<GroupOverview> consumerGroupList = JavaConversions.asJavaCollection(adminClient.listAllConsumerGroupsFlattened());
//    	return consumerGroupList;
//    }
//    
//    /**
//     * Consumer group details. Get using groupId of GroupOverview. Contains list of Consumers that belong to the group
//     * @param groupId
//     * @param timeoutMs
//     * @return AdminClient.ConsumerGroupSummary
//     */
//    public AdminClient.ConsumerGroupSummary getConsumerGroupSummary(String groupId, Long timeoutMs) {
//    	AdminClient.ConsumerGroupSummary cgSummary = null;
//    	cgSummary = adminClient.describeConsumerGroup(groupId, timeoutMs);
//    	return cgSummary;
//    }
//    
//    /**
//     * Given a ConsumerSummary return the list of Consumers
//     * @param consumerGroup
//     * @return Collection<AdminClient.ConsumerSummary>
//     */
//    public Collection<AdminClient.ConsumerSummary> getConsumersForGroup(AdminClient.ConsumerGroupSummary consumerGroup) {
//    	Collection<AdminClient.ConsumerSummary> consumers = JavaConversions.asJavaCollection(consumerGroup.consumers().get());
//    	return consumers;
//    }
	

}
