package com.sas.mkt.kafka.admin.topics.utils;

import java.io.Serializable;
import java.util.List;

public class RecordSetDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	public long firstTimeStamp;
	public long lastTimeStamp;
	public long requestedStartTime;
	public long requestedEndTime;
	public String topic;
	
	public List<RecordDTO> recordList;
	

}
