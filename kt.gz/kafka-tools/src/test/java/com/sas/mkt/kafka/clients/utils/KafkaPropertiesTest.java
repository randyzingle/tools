package com.sas.mkt.kafka.clients.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;

import java.util.Map;
import java.util.Properties;

import static org.junit.Assert.*;

public class KafkaPropertiesTest {

    @Test
    public void testDeserializeMapper(){
        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        Properties props = new Properties();
        Map<String, Object> map;

        String value = "{\"max.poll.records\":\"200\",\"auto.commit.interval.ms\":\"500\"}";

        try {
            map = mapper.readValue(value, new TypeReference<Map<String, Object>>() {});
            for (String key : map.keySet()) {
                System.out.println("key: " + key + ", value: " + map.get(key));
                props.put(key, map.get(key));
            }

            assertEquals("200", props.getProperty("max.poll.records"));
        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Test
    public void testSerializeMapper(){
        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        Properties props = new Properties();

        //auto.commit.interval.ms=1000
        props.put("auto.commit.interval.ms", "500");
        //max.poll.records=500
        props.put("max.poll.records", "200");

        //Map<String, Object> map;

        String value = null;

        try {

            value = mapper.writeValueAsString(props);

            assertNotNull(value);

        } catch (JsonProcessingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}