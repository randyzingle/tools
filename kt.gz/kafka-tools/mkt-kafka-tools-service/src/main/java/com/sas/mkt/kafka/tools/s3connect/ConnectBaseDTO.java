package com.sas.mkt.kafka.tools.s3connect;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonIgnoreProperties(ignoreUnknown=true)
@JsonInclude(Include.NON_NULL)
public class ConnectBaseDTO {
	
	@JsonProperty("version")
	public String version;
	
	@JsonProperty("commit")
	public String commit;
	
	@JsonProperty("kafka_cluster_id")
	public String kafkaClusterId;

	@Override
	public String toString() {
		return "ConnectBaseDTO [version=" + version + ", commit=" + commit + ", kafkaClusterId=" + kafkaClusterId + "]";
	}

}
