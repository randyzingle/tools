package com.sas.mkt.template.docker.TEMPLATESAMPLE.data;

import java.util.List;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.palantir.docker.compose.DockerComposeRule;
import com.palantir.docker.compose.configuration.ProjectName;
import com.palantir.docker.compose.connection.DockerMachine;
import com.palantir.docker.compose.connection.DockerPort;
import com.palantir.docker.compose.connection.waiting.HealthChecks;
import com.sas.mkt.template.docker.TemplateDockerApplication;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = TemplateDockerApplication.class)
@TestPropertySource(locations = "classpath:integration-test.properties")
public class PostgresTests {

	private static final int POSTGRES_PORT = 5432;
	private static final String POSTGRES = "postgres";

	@Autowired
	private CustomerRepository customerRepository;
	@Autowired
	private WidgetRepository widgetRepository;

	@LocalServerPort
	int randomServerPort;

	private static final DockerMachine dockerMachine = DockerMachine.localMachine().build();
	private static final String BALDUR_PASSWORD = "baldur";

	@ClassRule
	public static DockerComposeRule docker = DockerComposeRule.builder().machine(dockerMachine)
			.file("src/test-integration/resources/postgres.yaml").projectName(ProjectName.random())
			.waitingForService(POSTGRES, HealthChecks.toHaveAllPortsOpen())
			.saveLogsTo("build/dockerLogs/dockerComposeRuleTest").build();

	@BeforeClass
	public static void initialize() {
		setupPorts();
	}

	public static void setupPorts() {

		DockerPort postgres = docker.containers().container(POSTGRES).port(POSTGRES_PORT);
		String postgresurl = String.format("jdbc:postgresql://%s:%s/postgres", postgres.getIp(),
				postgres.getExternalPort());
		System.out.println("broker: " + postgresurl);
		System.setProperty("spring.datasource.url", postgresurl);
		System.setProperty("spring.datasource.username", "postgres");
		System.setProperty("spring.datasource.password", BALDUR_PASSWORD);

	}

	@Test
	public void getCustomers() {
		customerRepository.save(new Customer("Harry", "Potter"));
		customerRepository.save(new Customer("Hermione", "Granger"));
		customerRepository.flush();
		long numberCustomers = customerRepository.count();
		Assert.assertTrue(numberCustomers == 2);
		List<Customer> customers = customerRepository.findByLastName("Granger");
		Assert.assertTrue(customers.size() == 1);
		Assert.assertTrue(customers.get(0).getFirstName().equals("Hermione"));
	}
	
	@Test
	public void getWidgets() {
		widgetRepository.save(new Widget("dogbrush", "baldursoft", "works well on dogs"));
		widgetRepository.save(new Widget("collar", "baldursoft", "works well on dogs"));
		widgetRepository.save(new Widget("jetski", "baldursoft", "dogs love this!"));
		widgetRepository.save(new Widget("catbowl", "catsoft", "cats love this!"));
		widgetRepository.flush();
		
		long numberWidgets = widgetRepository.count();
		Assert.assertTrue(numberWidgets == 4);
		
		List<Widget> widgets = widgetRepository.findByCompany("baldursoft");
		Assert.assertTrue(widgets.size() == 3);
	}

}
