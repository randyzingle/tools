package com.sas.mkt.kafka.admin.topics.admin;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.PartitionInfo;
import org.apache.kafka.common.TopicPartition;

import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;

public class TopicMunger {

	private static String fileBase = "src/main/resources/topics/";
	private static String commandBase = "/Users/razing/work/tools/confluent/bin/";

	private static String createTopic = commandBase
			+ "kafka-topics --create --zookeeper kafkadev-zookeeper3.cidev.sas.us:2181/kafka --replication-factor 2 --partitions 50 --topic ";
	private static String deleteTopic = commandBase
			+ "kafka-topics --zookeeper kafkadev-zookeeper3.cidev.sas.us:2181/kafka --delete --topic ";
	private static String modifyTopic = commandBase
			+ "kafka-configs --zookeeper kafkadev-zookeeper3.cidev.sas.us:2181/kafka --entity-type topics --alter --add-config retention.ms=1000 --entity-name ";
	private static String unmodifyTopic = commandBase
			+ "kafka-configs --zookeeper kafkadev-zookeeper3.cidev.sas.us:2181/kafka --entity-type topics --alter --delete-config retention.ms --entity-name ";


	private static ApplicationConfiguration appConfig = new ApplicationConfiguration();
	private static String configServiceURL = "http://configservice-dev.cidev.sas.us:8080/";

	public static void main(String[] args) {
		appConfig.setConfigServiceUrl(configServiceURL);
		KafkaTopicAdministrator kta = new KafkaTopicAdministrator(appConfig);
		TopicMunger tm = new TopicMunger();
		List<String> reservedTopicList = kta.getCoreTopicList();
		List<String> allTopicsList = kta.getAllTopics();
		List<String> whiteList = tm.getTopicWhiteList(reservedTopicList);
		System.out.printf("found %d topics, %d are reserved, %d are eligible for deletion%n", allTopicsList.size(), reservedTopicList.size(), whiteList.size());
		
		tm.deleteTopicIfEmpty(whiteList);
		
		// unmodifyTopic(topicList);
		// deleteTopic(topicList);

	}

	private List<String> getTopicWhiteList(List<String> blackList) {
		KafkaTopicAdministrator kta = new KafkaTopicAdministrator(appConfig);
		List<String> topicList = kta.getAllTopics();
		List<String> whiteList = new ArrayList<>(topicList.size());
		for (String s : topicList) {
			if (!blackList.contains(s)) {
				whiteList.add(s);
			}
		}
		Collections.sort(whiteList);
		return whiteList;
	}
	
	private long getNumberOfRecordsForTopic(KafkaConsumer<String, SpecificRecordBase> consumer, String topic) {
		long number = 0;

		List<PartitionInfo> pinfo = consumer.partitionsFor(topic);
		List<TopicPartition> plist = new ArrayList<>();
		for (PartitionInfo pi: pinfo) {
			TopicPartition tp = new TopicPartition(pi.topic(), pi.partition()); 
			plist.add(tp);
		}
		// try catch org.apache.kafka.common.errors.TimeoutException
		try {
			Map<TopicPartition, Long> startoff = consumer.beginningOffsets(plist);
			Map<TopicPartition, Long> endoff = consumer.endOffsets(plist);
			number = countRecords(startoff, endoff);
		} catch (org.apache.kafka.common.errors.TimeoutException tex) {
			System.out.println(tex.getMessage());
			number = 99;
		}
	
		return number;
	}
	
	private long countRecords(Map<TopicPartition, Long> startoff, Map<TopicPartition, Long> endoff) {
		long count = 0;
		Set<TopicPartition> endkeys = endoff.keySet();
		for (TopicPartition tp: endkeys) {
			count += endoff.get(tp) - startoff.get(tp);
		}
		return count;
	}

	private void deleteTopicIfEmpty(List<String> whiteList) {
		KafkaConnectionUtils kcu;
		KafkaConsumer<String, SpecificRecordBase> consumer = null;
		List<String> emptyTopicList = new ArrayList<String>();
		try {
			kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
			System.out.println("VALID CONNECTION..........");
			String groupID = appConfig.getTierName() + "-" + appConfig.getComponentName() + System.currentTimeMillis();
			Properties props = kcu.getKafkaConsumerProperties();
			props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
			props.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
			consumer = new KafkaConsumer<>(props);
			consumer.subscribe(whiteList);
			long startTime = 0;
			long endTime = 0;
			startTime = System.currentTimeMillis();
			for (String topic : whiteList) {
				long messages = getNumberOfRecordsForTopic(consumer, topic);
				if (messages == 0 && !topic.contains("_kafka_lenses")) {
					emptyTopicList.add(topic);
					System.out.printf("%s: %d%n", topic, messages);
				}
			}
			endTime = System.currentTimeMillis();
			System.out.printf("Took %d ms to find %d empty topics%n", (endTime - startTime), emptyTopicList.size());
			deleteTopic(emptyTopicList);
			modifyTopic(emptyTopicList);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			consumer.close();
		}

	}

	private void modifyTopic(List<String> topicList) {
		File f = new File(fileBase + "modifytopic.sh");
		try (FileWriter fw = new FileWriter(f)) {
			int i = 0;
			for (String s : topicList) {
				i++;
				String ss = modifyTopic + s;
//				System.out.println(ss);
				fw.write(ss + System.lineSeparator());
				if (i % 20 == 0) fw.write(System.lineSeparator());
			}
			fw.flush();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private void unmodifyTopic(List<String> topicList) {
		File f = new File(fileBase + "unmodifytopic.sh");
		try (FileWriter fw = new FileWriter(f)) {
			for (String s : topicList) {
				String ss = unmodifyTopic + s;
//				System.out.println(ss);
				fw.write(ss + System.lineSeparator());
			}
			fw.flush();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private void deleteTopic(List<String> topicList) {
		File f = new File(fileBase + "deletetopic.sh");
		try (FileWriter fw = new FileWriter(f)) {
			int i=0;
			for (String s : topicList) {
				i++;
				String ss = deleteTopic + s;
//				System.out.println(ss);
				fw.write(ss + System.lineSeparator());
				if (i % 20 == 0) fw.write(System.lineSeparator());
			}
			fw.flush();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
