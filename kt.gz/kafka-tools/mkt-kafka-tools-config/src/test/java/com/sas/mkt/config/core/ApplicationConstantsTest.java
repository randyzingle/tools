package com.sas.mkt.config.core;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.sas.mkt.config.core.ApplicationConstants;

public class ApplicationConstantsTest {
	
	private ApplicationConstants applicationConstants;
	
	@Before
	public void setup() {
		String dumb = "bwahaha this is dumb";
		applicationConstants = new ApplicationConstants();
	}
	
	@Test
	public void simpleTest() {
		String s = applicationConstants.APPLICATION_PROPERTY_PREFIX;
		assertEquals(s, applicationConstants.APPLICATION_PROPERTY_PREFIX);
	}

}
