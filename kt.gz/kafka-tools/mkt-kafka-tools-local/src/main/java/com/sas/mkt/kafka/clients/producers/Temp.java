package com.sas.mkt.kafka.clients.producers;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Temp {

	public static void main(String[] args) {
		String[] list = {"one", "two-testx-events", "three", "olive", "0bob-test-events", "bob0", "033-test-events"};
		Pattern p = Pattern.compile("\\w*-testx-events");
		
		for (String s: list) {
			Matcher m = p.matcher(s);
			if (m.matches()) {
				System.out.println(s);
			}
		}

	}

}
