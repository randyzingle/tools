package com.sas.mkt.kafka.tools.s3connect;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonIgnoreProperties(ignoreUnknown=true)
@JsonInclude(Include.NON_NULL)
public class ConnectConfigDTO {
	
	@JsonProperty("connector.class")
	public String connectorClass;
	
	@JsonProperty("enhanced.avro.schema.support")
	public String enhancedAvroSchemaSupport;
	
	@JsonProperty("errors.deadletterqueue.context.headers.enable")
	public String errorsDeadletterqueueContextHeadersEnable;
	
	@JsonProperty("errors.deadletterqueue.topic.name")
	public String errorsDeadletterqueueTopicName;
	
	@JsonProperty("errors.deadletterqueue.topic.replication.factor")
	public String errorsDeadletterqueueTopicReplicationFactor;
	
	@JsonProperty("errors.log.enable")
	public String errorsLogEnable;
	
	@JsonProperty("errors.log.include.messages")
	public String errorsLogIncludeMessages;
	
	@JsonProperty("errors.retry.delay.max.ms")
	public String errorsRetryDelayMaxMs;
	
	@JsonProperty("errors.retry.timeout")
	public String errorsRetryTimeout;
	
	@JsonProperty("errors.tolerance")
	public String errorsToleranceRateDurationMs;
	
	@JsonProperty("flush.size")
	public String flushSize;
	
	@JsonProperty("format.class")
	public String formatClass;
	
	@JsonProperty("key.converter")
	public String keyConverter;
	
	@JsonProperty("locale")
	public String locale;
	
	@JsonProperty("name")
	public String name;
	
	@JsonProperty("partition.duration.ms")
	public String partitionDurationMs;
	
	@JsonProperty("partitioner.class")
	public String partitionerClass;
	
	@JsonProperty("path.format")
	public String pathFormat;
	
	@JsonProperty("rotate.interval.ms")
	public String rotateIntervalMs;

	@JsonProperty("rotate.schedule.interval.ms")
	public String rotateScheduleIntervalMs;
	
	@JsonProperty("s3.bucket.name")
	public String s3BucketName;
	
	@JsonProperty("s3.part.size")
	public String s3PartSize;
	
	@JsonProperty("s3.region")
	public String s3Region;

	@JsonProperty("schema.compatibility")
	public String schemaCompatibility;
	
	@JsonProperty("schema.generator.class")
	public String schemaGeneratorClass;
	
	@JsonProperty("storage.class")
	public String storageClass;
	
	@JsonProperty("tasks.max")
	public String tasksMax;
	
	@JsonProperty("timestamp.extractor")
	public String timestampExtractor;
	
	@JsonProperty("timezone")
	public String timezone;
	
	@JsonProperty("topics.dir")
	public String topicsDir;

	@JsonProperty("topics")
	public String topics;
	
	@JsonProperty("topics.regex")
	public String topicsRegex;
	
	@JsonProperty("value.converter.schema.registry.url")
	public String valueConverterSchemaRegistryUrl;
	
	@JsonProperty("value.converter")
	public String valueConverter;

	@JsonProperty("file.delim")
	public String fileDelim;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((connectorClass == null) ? 0 : connectorClass.hashCode());
		result = prime * result + ((enhancedAvroSchemaSupport == null) ? 0 : enhancedAvroSchemaSupport.hashCode());
		result = prime * result + ((errorsDeadletterqueueContextHeadersEnable == null) ? 0
				: errorsDeadletterqueueContextHeadersEnable.hashCode());
		result = prime * result
				+ ((errorsDeadletterqueueTopicName == null) ? 0 : errorsDeadletterqueueTopicName.hashCode());
		result = prime * result + ((errorsDeadletterqueueTopicReplicationFactor == null) ? 0
				: errorsDeadletterqueueTopicReplicationFactor.hashCode());
		result = prime * result + ((errorsLogEnable == null) ? 0 : errorsLogEnable.hashCode());
		result = prime * result + ((errorsLogIncludeMessages == null) ? 0 : errorsLogIncludeMessages.hashCode());
		result = prime * result + ((errorsRetryDelayMaxMs == null) ? 0 : errorsRetryDelayMaxMs.hashCode());
		result = prime * result + ((errorsRetryTimeout == null) ? 0 : errorsRetryTimeout.hashCode());
		result = prime * result
				+ ((errorsToleranceRateDurationMs == null) ? 0 : errorsToleranceRateDurationMs.hashCode());
		result = prime * result + ((fileDelim == null) ? 0 : fileDelim.hashCode());
		result = prime * result + ((flushSize == null) ? 0 : flushSize.hashCode());
		result = prime * result + ((formatClass == null) ? 0 : formatClass.hashCode());
		result = prime * result + ((keyConverter == null) ? 0 : keyConverter.hashCode());
		result = prime * result + ((locale == null) ? 0 : locale.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((partitionDurationMs == null) ? 0 : partitionDurationMs.hashCode());
		result = prime * result + ((partitionerClass == null) ? 0 : partitionerClass.hashCode());
		result = prime * result + ((pathFormat == null) ? 0 : pathFormat.hashCode());
		result = prime * result + ((rotateIntervalMs == null) ? 0 : rotateIntervalMs.hashCode());
		result = prime * result + ((rotateScheduleIntervalMs == null) ? 0 : rotateScheduleIntervalMs.hashCode());
		result = prime * result + ((s3BucketName == null) ? 0 : s3BucketName.hashCode());
		result = prime * result + ((s3PartSize == null) ? 0 : s3PartSize.hashCode());
		result = prime * result + ((s3Region == null) ? 0 : s3Region.hashCode());
		result = prime * result + ((schemaCompatibility == null) ? 0 : schemaCompatibility.hashCode());
		result = prime * result + ((schemaGeneratorClass == null) ? 0 : schemaGeneratorClass.hashCode());
		result = prime * result + ((storageClass == null) ? 0 : storageClass.hashCode());
		result = prime * result + ((tasksMax == null) ? 0 : tasksMax.hashCode());
		result = prime * result + ((timestampExtractor == null) ? 0 : timestampExtractor.hashCode());
		result = prime * result + ((timezone == null) ? 0 : timezone.hashCode());
		result = prime * result + ((topics == null) ? 0 : topics.hashCode());
		result = prime * result + ((topicsDir == null) ? 0 : topicsDir.hashCode());
		result = prime * result + ((topicsRegex == null) ? 0 : topicsRegex.hashCode());
		result = prime * result + ((valueConverter == null) ? 0 : valueConverter.hashCode());
		result = prime * result
				+ ((valueConverterSchemaRegistryUrl == null) ? 0 : valueConverterSchemaRegistryUrl.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ConnectConfigDTO other = (ConnectConfigDTO) obj;
		if (connectorClass == null) {
			if (other.connectorClass != null)
				return false;
		} else if (!connectorClass.equals(other.connectorClass))
			return false;
		if (enhancedAvroSchemaSupport == null) {
			if (other.enhancedAvroSchemaSupport != null)
				return false;
		} else if (!enhancedAvroSchemaSupport.equals(other.enhancedAvroSchemaSupport))
			return false;
		if (errorsDeadletterqueueContextHeadersEnable == null) {
			if (other.errorsDeadletterqueueContextHeadersEnable != null)
				return false;
		} else if (!errorsDeadletterqueueContextHeadersEnable.equals(other.errorsDeadletterqueueContextHeadersEnable))
			return false;
		if (errorsDeadletterqueueTopicName == null) {
			if (other.errorsDeadletterqueueTopicName != null)
				return false;
		} else if (!errorsDeadletterqueueTopicName.equals(other.errorsDeadletterqueueTopicName))
			return false;
		if (errorsDeadletterqueueTopicReplicationFactor == null) {
			if (other.errorsDeadletterqueueTopicReplicationFactor != null)
				return false;
		} else if (!errorsDeadletterqueueTopicReplicationFactor
				.equals(other.errorsDeadletterqueueTopicReplicationFactor))
			return false;
		if (errorsLogEnable == null) {
			if (other.errorsLogEnable != null)
				return false;
		} else if (!errorsLogEnable.equals(other.errorsLogEnable))
			return false;
		if (errorsLogIncludeMessages == null) {
			if (other.errorsLogIncludeMessages != null)
				return false;
		} else if (!errorsLogIncludeMessages.equals(other.errorsLogIncludeMessages))
			return false;
		if (errorsRetryDelayMaxMs == null) {
			if (other.errorsRetryDelayMaxMs != null)
				return false;
		} else if (!errorsRetryDelayMaxMs.equals(other.errorsRetryDelayMaxMs))
			return false;
		if (errorsRetryTimeout == null) {
			if (other.errorsRetryTimeout != null)
				return false;
		} else if (!errorsRetryTimeout.equals(other.errorsRetryTimeout))
			return false;
		if (errorsToleranceRateDurationMs == null) {
			if (other.errorsToleranceRateDurationMs != null)
				return false;
		} else if (!errorsToleranceRateDurationMs.equals(other.errorsToleranceRateDurationMs))
			return false;
		if (fileDelim == null) {
			if (other.fileDelim != null)
				return false;
		} else if (!fileDelim.equals(other.fileDelim))
			return false;
		if (flushSize == null) {
			if (other.flushSize != null)
				return false;
		} else if (!flushSize.equals(other.flushSize))
			return false;
		if (formatClass == null) {
			if (other.formatClass != null)
				return false;
		} else if (!formatClass.equals(other.formatClass))
			return false;
		if (keyConverter == null) {
			if (other.keyConverter != null)
				return false;
		} else if (!keyConverter.equals(other.keyConverter))
			return false;
		if (locale == null) {
			if (other.locale != null)
				return false;
		} else if (!locale.equals(other.locale))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (partitionDurationMs == null) {
			if (other.partitionDurationMs != null)
				return false;
		} else if (!partitionDurationMs.equals(other.partitionDurationMs))
			return false;
		if (partitionerClass == null) {
			if (other.partitionerClass != null)
				return false;
		} else if (!partitionerClass.equals(other.partitionerClass))
			return false;
		if (pathFormat == null) {
			if (other.pathFormat != null)
				return false;
		} else if (!pathFormat.equals(other.pathFormat))
			return false;
		if (rotateIntervalMs == null) {
			if (other.rotateIntervalMs != null)
				return false;
		} else if (!rotateIntervalMs.equals(other.rotateIntervalMs))
			return false;
		if (rotateScheduleIntervalMs == null) {
			if (other.rotateScheduleIntervalMs != null)
				return false;
		} else if (!rotateScheduleIntervalMs.equals(other.rotateScheduleIntervalMs))
			return false;
		if (s3BucketName == null) {
			if (other.s3BucketName != null)
				return false;
		} else if (!s3BucketName.equals(other.s3BucketName))
			return false;
		if (s3PartSize == null) {
			if (other.s3PartSize != null)
				return false;
		} else if (!s3PartSize.equals(other.s3PartSize))
			return false;
		if (s3Region == null) {
			if (other.s3Region != null)
				return false;
		} else if (!s3Region.equals(other.s3Region))
			return false;
		if (schemaCompatibility == null) {
			if (other.schemaCompatibility != null)
				return false;
		} else if (!schemaCompatibility.equals(other.schemaCompatibility))
			return false;
		if (schemaGeneratorClass == null) {
			if (other.schemaGeneratorClass != null)
				return false;
		} else if (!schemaGeneratorClass.equals(other.schemaGeneratorClass))
			return false;
		if (storageClass == null) {
			if (other.storageClass != null)
				return false;
		} else if (!storageClass.equals(other.storageClass))
			return false;
		if (tasksMax == null) {
			if (other.tasksMax != null)
				return false;
		} else if (!tasksMax.equals(other.tasksMax))
			return false;
		if (timestampExtractor == null) {
			if (other.timestampExtractor != null)
				return false;
		} else if (!timestampExtractor.equals(other.timestampExtractor))
			return false;
		if (timezone == null) {
			if (other.timezone != null)
				return false;
		} else if (!timezone.equals(other.timezone))
			return false;
		if (topics == null) {
			if (other.topics != null)
				return false;
		} else if (!topics.equals(other.topics))
			return false;
		if (topicsDir == null) {
			if (other.topicsDir != null)
				return false;
		} else if (!topicsDir.equals(other.topicsDir))
			return false;
		if (topicsRegex == null) {
			if (other.topicsRegex != null)
				return false;
		} else if (!topicsRegex.equals(other.topicsRegex))
			return false;
		if (valueConverter == null) {
			if (other.valueConverter != null)
				return false;
		} else if (!valueConverter.equals(other.valueConverter))
			return false;
		if (valueConverterSchemaRegistryUrl == null) {
			if (other.valueConverterSchemaRegistryUrl != null)
				return false;
		} else if (!valueConverterSchemaRegistryUrl.equals(other.valueConverterSchemaRegistryUrl))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ConnectConfigDTO [connectorClass=").append(connectorClass)
				.append(", enhancedAvroSchemaSupport=").append(enhancedAvroSchemaSupport)
				.append(", errorsDeadletterqueueContextHeadersEnable=")
				.append(errorsDeadletterqueueContextHeadersEnable).append(", errorsDeadletterqueueTopicName=")
				.append(errorsDeadletterqueueTopicName).append(", errorsDeadletterqueueTopicReplicationFactor=")
				.append(errorsDeadletterqueueTopicReplicationFactor).append(", errorsLogEnable=")
				.append(errorsLogEnable).append(", errorsLogIncludeMessages=").append(errorsLogIncludeMessages)
				.append(", errorsRetryDelayMaxMs=").append(errorsRetryDelayMaxMs).append(", errorsRetryTimeout=")
				.append(errorsRetryTimeout).append(", errorsToleranceRateDurationMs=")
				.append(errorsToleranceRateDurationMs).append(", flushSize=").append(flushSize).append(", formatClass=")
				.append(formatClass).append(", keyConverter=").append(keyConverter).append(", locale=").append(locale)
				.append(", name=").append(name).append(", partitionDurationMs=").append(partitionDurationMs)
				.append(", partitionerClass=").append(partitionerClass).append(", pathFormat=").append(pathFormat)
				.append(", rotateIntervalMs=").append(rotateIntervalMs).append(", rotateScheduleIntervalMs=")
				.append(rotateScheduleIntervalMs).append(", s3BucketName=").append(s3BucketName).append(", s3PartSize=")
				.append(s3PartSize).append(", s3Region=").append(s3Region).append(", schemaCompatibility=")
				.append(schemaCompatibility).append(", schemaGeneratorClass=").append(schemaGeneratorClass)
				.append(", storageClass=").append(storageClass).append(", tasksMax=").append(tasksMax)
				.append(", timestampExtractor=").append(timestampExtractor).append(", timezone=").append(timezone)
				.append(", topicsDir=").append(topicsDir).append(", topics=").append(topics).append(", topicsRegex=")
				.append(topicsRegex).append(", valueConverterSchemaRegistryUrl=")
				.append(valueConverterSchemaRegistryUrl).append(", valueConverter=").append(valueConverter)
				.append(", fileDelim=").append(fileDelim).append("]");
		return builder.toString();
	}
	
	

}
