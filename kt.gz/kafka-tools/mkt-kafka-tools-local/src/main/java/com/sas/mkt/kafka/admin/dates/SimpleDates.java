package com.sas.mkt.kafka.admin.dates;

import java.util.Date;

public class SimpleDates {

	public static void main(String[] args) {
		long now = System.currentTimeMillis();
		
		long fourHoursAgo = now - (1000 * 60 * 60 * 24 * 5);
		
		System.out.printf("now: %d, four hours ago: %d%n", now, fourHoursAgo);
		System.out.printf("now: %s, four hours ago: %s%n", new Date(now).toString(), new Date(fourHoursAgo).toString());

	}

}
