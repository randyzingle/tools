package com.sas.mkt.kafka.examples.config;

public class ConfigUtils {
	public static void bigPrint(String message) {
		System.out.println("***********************************");
		System.out.println("*  " + message);
		System.out.println("***********************************");
	}
}
