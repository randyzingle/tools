# Template Service API

## Overview
A template REST API implementation for CI360 microservices

### Version information
Version: 1.0

### Contact information
Contact: Clif Jones
Contact Email: clif.jones@sas.com

### URI scheme
Host: localhost
BasePath: /

### Tags

* hello-controller: Hello Controller
* i-18-n-demo-controller: I 18 N Demo Controller
* root-controller: Root Controller
* user-controller: User Controller
* admin-metrics-controller: Admin Metrics Controller


