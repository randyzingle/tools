package com.sas.mkt.kafka.clients.consumers.simple;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.clients.utils.KafkaTopicUtils;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;

/**
 * @author razing
 *
 */
public class SingleThreadConsumer {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private boolean done = false;
	private static String fileBase = "src/main/resources/data/";

	private long first = 0L;
	private long last = 0L;
	Consumer<String, SpecificRecordBase> consumer;
	private ApplicationConfiguration appConfig = new ApplicationConfiguration();

	public static void main(String[] args) {
		SingleThreadConsumer bc = new SingleThreadConsumer();
		bc.appConfig.setConfigServiceUrl("http://configservice-dev.cidev.sas.us:8080/");
		bc.simpleConsumeMessages();
//		Timer metricsTimer = KafkaConnectionUtils.scheduleMetricsTimer( consumer, "ConsumerGroup", consumerGroup, 45, 60 );
//        Timer metricsTimerProducer = KafkaConnectionUtils.scheduleMetricsTimer( producer, TestEventsTopic, 45, 60 );
	}

	private void simpleConsumeMessages() {
		// Set up the consumer
		KafkaConnectionUtils kcu;
		try {
			kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			return;
		}
		// If we want to re-read from the beginning each time then we need to make this
		// unique
		String groupID = "mymir" + "-" + "finnr" + System.currentTimeMillis();

		Properties props = kcu.getKafkaConsumerProperties();
		// also need this to read from the beginning each time
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupID);
		consumer = new KafkaConsumer<>(props);
//		Timer metricsTimer = KafkaConnectionUtils.scheduleMetricsTimer( consumer, "ConsumerGroup", groupID, 45, 60 );
		KafkaTopicUtils ktu = new KafkaTopicUtils(appConfig.getConfigServiceUrl());
		String topic = "finnr-test-events";
		consumer.subscribe(Arrays.asList(topic));

		// Test the metrics code
		TestConsumerMetrics cmetrics = new TestConsumerMetrics(consumer, "/SAS/CI360/KafkaConsumerMetrics", "baldur");
		cmetrics.run();

		// Consume Messages
		int cnt = 0;
//		File f = new File(fileBase + "data.csv");

		SpecificRecordBase te = null;
		Thread t = new Thread(new KillSwitch());
		t.start();
//		ArrayList<String> messageList = new ArrayList<>();
		System.out.println("CONSUMING MESSAGES.....");
		Map<String, List<String>> pmap = new HashMap<>();
		while (!done) {
			ConsumerRecords<String, SpecificRecordBase> records = consumer.poll(1000);
			for (ConsumerRecord<String, SpecificRecordBase> record : records) {
				cnt++;
				te = record.value();
//				String s = String.format("%s, %d, %d, %s, %s", record.key(), cnt, record.timestamp(), new Date(record.timestamp()).toString(), te.toString());
//				System.out.println(s);
//				messageList.add(s);
				if (cnt % 1 == 0) {
					System.out.println(te);
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e) {
//						e.printStackTrace();
//					}
				}
				long timestamp = record.timestamp();
				if (first == 0) {
					first = timestamp;
				}
				last = timestamp;
			}
		}
//		System.out.printf("%d messages in messageList%n", messageList.size());
//		try (FileWriter fw = new FileWriter(f)) {
//			for (String s : messageList) {
//				fw.write(s + System.lineSeparator());
//			}
//			fw.flush();
//		} catch (Exception ex) {
//			ex.printStackTrace();
//		}
		System.out.printf("Read %d messages%n", cnt);
		System.out.println("first message: " + new Date(first).toString());
		System.out.println("last message: " + new Date(last).toString());
		consumer.close();
	}

	public class KillSwitch implements Runnable {

		@Override
		public void run() {
			try {
				Thread.sleep(100000);
				done = true;
			} catch (Exception ex) {
				ex.printStackTrace();
			}

		}

	}
}
