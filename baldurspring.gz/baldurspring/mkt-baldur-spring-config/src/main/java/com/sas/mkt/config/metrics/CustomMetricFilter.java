package com.sas.mkt.config.metrics;

import java.util.ArrayList;
import java.util.List;

import com.codahale.metrics.Metric;
import com.codahale.metrics.MetricFilter;

public class CustomMetricFilter implements MetricFilter {
	
	private List<String> filterList = new ArrayList<>();
	
	public CustomMetricFilter(String filters) {
		parseFilters(filters);
	}
	
	public void addFilter(String filter) {
		filterList.add(filter);
	}
	
	public void removeFilter(String filter) {
		filterList.remove(filter);
	}
	
	public List<String> getRegisteredFilters() {
		return filterList;
	}
	
	private void parseFilters(String filters) {
		if (filters == null || filters.trim().isEmpty()) return;
		String[] list = filters.split(",");
		for (String filter : list) {
			addFilter(filter.trim());
		}
	}

	@Override
	public boolean matches(String name, Metric metric) {
		// If we don't have any filters record everything
		if (filterList.isEmpty()) return true;
		// Otherwise only record metrics that have names that start with the given filters
		for (String filter: filterList) {
			if (name.startsWith(filter)) return true;
		}
		return false;
	}

}
