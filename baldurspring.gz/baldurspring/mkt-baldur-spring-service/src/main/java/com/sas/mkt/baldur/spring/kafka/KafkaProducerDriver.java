package com.sas.mkt.baldur.spring.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class KafkaProducerDriver {
	
	@Autowired
	SampleProducer producer;
	
	Thread producerThread;
	
	public void start() {
		// configure Kafka Producer with props and fire it up
		producerThread = new Thread(producer);
		producerThread.start();
	}
	
	public void restart() {
		// restart Kafka Producer with new props
		producerThread.interrupt(); // we may be sleep-throttling the producer
		producer.stop();
		try {
			producerThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		producerThread = new Thread(producer);
		producerThread.start();
	}
	
	public void stop() {
		producer.stop();
		producerThread.interrupt(); // we may be sleep-throttling the producer	
	}

}
