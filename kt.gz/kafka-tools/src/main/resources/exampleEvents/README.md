project:  com.sas.mkt.kafka.sdk
folder:   Example Events

This folder is to be used to collect existing events and their structure as being used by CI360 solution before AVRO schema.

Web-Event:

webevent1 - example "New Configuration 1" web event
webevent2 - example "visibilitychange" web event

Mobile-Event:

mobevent1 - example web event
mobevent2 - example web event
