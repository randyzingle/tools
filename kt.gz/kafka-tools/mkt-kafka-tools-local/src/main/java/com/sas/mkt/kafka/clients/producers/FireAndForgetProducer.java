package com.sas.mkt.kafka.clients.producers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.Metric;
import org.apache.kafka.common.MetricName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sas.mkt.kafka.clients.producers.utils.TestRecordGenerator;
import com.sas.mkt.kafka.clients.utils.KafkaConnectionUtils;
import com.sas.mkt.kafka.domain.TestEvent;
import com.sas.mkt.kafka.examples.config.ApplicationConfiguration;


public class FireAndForgetProducer {
	
	private static final Logger logger = LoggerFactory.getLogger(FireAndForgetProducer.class);

	ApplicationConfiguration appConfig = new ApplicationConfiguration();

	public static void main(String[] args) {
		FireAndForgetProducer app = new FireAndForgetProducer();
		app.appConfig.setConfigServiceUrl("http://configservice-dev.cidev.sas.us:8080/");
		app.fireAndForget();
	}
	
	private void fireAndForget() {
		KafkaConnectionUtils kcu;
		try {
			kcu = KafkaConnectionUtils.getInstance(appConfig.getConfigServiceUrl());
		} catch (Exception ex) {
			logger.error("Failed to connect to Kafka");
			logger.error(ex.getMessage());
			System.out.println(ex.toString());
			return;
		}
		String topic = "baldur-test-events";
		String clientID = appConfig.getTierName() + "-" + appConfig.getComponentName();
		Properties props = kcu.getKafkaProducerProperties(clientID);
		Producer<String, SpecificRecordBase> producer = new KafkaProducer<>(props);
		TestRecordGenerator werg = new TestRecordGenerator();
		
		// create the ProducerRecord and send ignoring the returned RecordMetadata
		int cnt = 0;
		int nloops = 1;
		int nrecords = 300;
		long startTime = System.currentTimeMillis();

		List<TestEvent> weblist = null;
//		List<String> metrics = Arrays.asList("record-error-rate", "request-latency-avg", "outgoing-byte-rate", "record-send-rate", "request-rate", "request-size-avg","record-size-avg", "record-queue-time-avg");
		int nbaldur = 100;
		int nmymir = 100;
		int nbutters = 100;
		for (int i=0; i<nloops; i++) {
			weblist = werg.getSetEventList(nbaldur, nmymir, nbutters, 1000);
			for (TestEvent we: weblist) {
				cnt++;
				ProducerRecord<String, SpecificRecordBase> record = new ProducerRecord<>(topic, we.getTenant(), we);
				// note, send() actually places the message in a buffer which is read and sent by a separate thread
				producer.send(record);
//				if (cnt%(nrecords/nloops)==0) {
				if (cnt%(nrecords/10)==0) {
					System.out.println(cnt + " " + record.key());
				}
			}
		}
		long endTime = System.currentTimeMillis();
		long duration = endTime - startTime;
		long mps = cnt * 1000 / duration;
		System.out.printf("Produced %d records at a rate of %d messages / sec, total runtime of %d sec...%n", cnt, mps, duration/1000);
		
		
		// give the buffer a chance to empty out
		producer.flush();
		long sleep = 2000L;
		producer.close(sleep, TimeUnit.MILLISECONDS);
	}
}
