# ConfigService Client Usage

## Introduction

The mkt-template micro-service interacts with mkt-config for both service settings
and for service discovery using the *mkt-shared-config-client* library.
When necessary, the mkt-template micro-service will initialize or update its configuration
settings from internal defaults at the **application** level.  If a micro-service is a 
**regional** service, there is a mechanism in CloudFormation
to initialize the **regional** (i.e. **tier_global**) properties for the service.


## Build Dependencies
The template-microservice uses the mkt-shared-config-client library.
It is pulled in via Gradle with the following build.gradle setting:

```
    // CI360 @@@SHARED@@@ - Common ConfigService Client
    // see https://gitlab.sas.com/CustomerIntelligence/Infra/mkt-shared/tree/master/mkt-shared-config-client
    compile ("com.sas.mkt.shared:mkt-shared-config-client:1.${buildSprint}.+") {
        exclude group: 'log4j'
    }
```

## EC2 Meta-Data Requirements
The mkt-shared-config-client requires information in order to resolve mkt-config.  The old method for
doing this was to utilize AWS EC2 tags and CloudFormation outputs, which does not scale.  The new method
is to pass in the information from CloudFormation via SSM parameters to CodeDeploy scripts, which in turn will create Spring application.properties entries, system properties, etc.  


### Required Meta-Data
The following meta-data is required for the mkt-shared-config-client:

* **Application name** - Our application name.
* **Our project name** - The name of our project. ex. 'mkt-config'
* **Our stack prefix** - The value of EC2 StackPrefix or APPLICATION tags.
* **Our service URL** - The base URL for our service.
* **Our config service URL** - The URL to our associated mkt-config service.
* **Our config stack name** - The AWS stack name for our associated mkt-config service.
* **Our config stack prefix** - The EC2 StackPrefix tag value of our associated mkt-config service.


### SSM Parameter Conventions
The required meta-data is passed in to CodeDeploy via SSM parameters.  There are common scripts that
do this the same way for all services in order to simplify maintenance and to prevent data clashes.
The 'common_functions' script uses the following environment and SSM parameters to retrieve the
required meta-data:

* **Application name** - env:'APPLICATION_NAME'=<Our stack prefix>-<Our project name>
* **Our project name** - SSM parameter: '/<Application name>/ProjectName'
* **Our stack prefix** - Derived from <Application name> and <Our project name>.
* **Our service URL** - SSM parameter: '/<Application name>/ServiceUrl'
* **Our config service URL** - SSM parameter: '/<Application name>/ConfigServiceUrl'
* **Our config stack name** - SSM parameter: '/<Application name>/ConfigStackName'
* **Our config stack prefix** - Derived from <Our config stack name>


### mkt-shared-config-client meta-data properties
The mkt-shared-config-client receives the required meta-data the following ways:

#### Spring application.properties
The config client initialization code will first check for the meta-data in the following
Spring application.properties entries:

* **spring.application.name** - Application name.
* **our.stack.prefix** - Our stack prefix.
* **our.service.url** - Our service URL.
* **our.config.service.url** - Our config service URL.
* **our.config.stack.name** - Our config stack name.
* **our.config.stack.prefix** - Our config stack prefix.

#### Java system properties
If the required meta-data is is not populated from the Spring application.properties entries,
the following Java system properties are queried for the missing values:

* **ApplicationName** - Application name.  Defaults to 'UNKNOWN'.
* **ServiceUrl** - Our service URL.
* **StackPrefix** - Our stack prefix.
* **ConfigServiceUrl** - Our config service URL.
* **ConfigStackName** - Our config stack name.
* **ConfigStackPrefix** - Our config stack prefix.


## Runtime Dependencies
In order to have run-time support for mkt-shared-config-client, you must include the proper Spring
annotation: **@com.sas.mkt.shared.configclient.annotation.EnableConfigClient**

Certain behaviors can be overridden by the various Spring application.properties files.
Consult the mkt-shared-config-client documentation for more details. 

**NOTE:** There are separate spring profiles for:
* **Local development** - src/main/resources/application.properties
* **JUnit test** - src/test/resources/test.properties
* **Production** - CloudFormation user data that writes an application.properties file on EC2


## Initialization
Once the the components and configuration classes are scanned in mkt-shared-config-client, the
AWS meta-data support and the mkt-config client components will automatically load and initialize.
These components are under the following package: **com.sas.mkt.shared.configclient.***

Here is an example SpringBoot application class including the mkt-shared-config-client component
initialization:

```
@SpringBootApplication
@EnableSwagger2
@ComponentScan({ "com.sas.mkt.example.*" })
@EnableJpaRepositories("com.sas.mkt.example.*")
@EntityScan("com.sas.mkt.example.*")
@EnableConfigClient(ourComponentNm = Constants.MKT_EXAMPLE_COMPONENT, validator = ExampleConfigValidator.class)
public class Application implements Constants {
...
```
This will initialize the AWS meta-data client, mkt-config client.


## Operation
The mkt-config client is designed to work with a local property interface **ConfigPropertyHandler** but
is not required, when using **ConfigStorage** interface.


**ConfigPropertyHandler** will manage the defined property values, defaults, and comments for each
property key.  It will also notify code subscribers for changes in a specific property key.


### Property Keys
**ConfigPropertyHandler** is initialized in this application by the **FilePropertyInfoFactory** class.
This factory reads the property key information from the resource file: **config-properties.json**
In there, property keys are defined, along with their characteristics.
There is also a separate interface (**ExampleKeys**) that holds the actual property key names.
This makes it more convenient using properties elsewhere in the application, but is not required.

The **EnableConfigClient** annotation initializes the local instance of **ConfigPropertyHandler**
using the **FilePropertyInfoFactory** and sets the local property handling policy.

The developer must write the glue code to validate the properties from mkt-config (if needed).
This allows custom logic and handling of incoming property data validation.
The **ExampleConfigValidator** class shows one way that you can validate incoming mkt-config properties
that you own.  Note: The mkt-shared-config-client controls the scoping and bridging of both owned and
consumed properties between mkt-config and the local **ConfigPropertyHandler**.  As long as you declare
the properties that you own and also subscribe to the properties that you consume, this will all
be handled automatically with PubSub instant updates.
The **ExampleConfigPropertyListener** also has example code showing how one can watch for property value
changes.  Putting all these pieces together, you can change a property on mkt-config and then have
a running application automatically re-configure in near real-time.


## Service Discovery and Publication

Service discovery on **ConfigStorage** allows one to advertise a micro-service to other applications
using mkt-config and a pre-defined protocol.  **ConfigStorage handles this protocol (several properties) in a set of method calls.

### Service Discovery
The **Application** class file demonstrates service discovery. The *discoverService* method call
queries mkt-config for the desired service name and prints out the discovery data, if found.
The **ConfigStorage** *discoverService* call takes the desired service component being sought out and
the local service's component name for the AuditHeader value.

### Service Publication
The mkt-shared-config client will publish the service-discovery properties automatically.  No action
is required by the application developer other than providing the required meta-data.



